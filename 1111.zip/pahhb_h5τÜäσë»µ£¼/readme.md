# 项目目录

```
├── build									// Vue打包相关文件
├── config									// Vue的配置
├── index.cdn.html							// 打包时用到的HTML模板(将VUE 和 vue-router 采用cdn 的 script引入方式, 不打在包内)
├── index.html								// dev模式使用的HTML模板
├── package-lock.json
├── package.json
├── src										// 项目代码文件夹
│   ├── App.vue								// 路由挂载点
│   ├── common								// 公共文件夹
│   │   ├── comComponent					// 公共组件文件夹
│   │   │   ├── alertWindow					// 弹窗动画
│   │   │   ├── echarts						// echarts
│   │   │   ├── header						// 头部组件
│   │   │   ├── linkageMenu					// 外部端选择机构
│   │   │   ├── loading						// 加载动画
│   │   │   ├── schedule					// 进度条(已弃用)
│   │   │   ├── scrollAjax					// 上拉加载, 下拉刷新
│   │   │   ├── tab							// tab切换页面
│   │   │   ├── textScroll					// 头部文字走马灯组件
│   │   │   └── toast						// 吐司提示
│   │   ├── css								// 公共样式文件夹
│   │   │   ├── 1px.less
│   │   │   ├── newCarOutOfTheSingleOne.css
│   │   │   └── theme.less
│   │   ├── filters							// 公共过滤器文件夹
│   │   │   ├── conCar.js
│   │   │   ├── conPhone.js
│   │   │   ├── convertAmount.js
│   │   │   ├── convertDate.js
│   │   │   ├── convertIdType.js
│   │   │   ├── convertPayType.js
│   │   │   ├── convertRelation.js
│   │   │   └── convertSex.js
│   │   ├── images							// 公共图片文件夹
│   │   └── js								// 公共js方法文件夹
│   │       ├── axiosConfig.js				// axios配置
│   │       ├── comConfig.js				// 接口地址配置
│   │       ├── comES6.js					// ES6兼容
│   │       ├── comMap.js
│   │       ├── comUtils.js       // 公共方法
│   │       ├── comValidate.js    // 常用的校验方法
│   │       ├── getTestLoginToken.js // 开发环境获取token
│   │       ├── native.js            // 与iso端和安卓端交互的逻辑
│   │       ├── native.js.bak
│   │       └── ptsSwiper.js        // 小型滑动轮播图
│   ├── inServiceLogic						// 内部端页面
│   │   ├── chooseCarType					// 新增车型模块(配合Native极速报价功能)
│   │   │   ├── carList.vue					// 车品牌页面
│   │   │   ├── cellPage.vue				// 车型.车款.排气量等页面
│   │   │   └── index.vue					// 首页
│   │   ├── continue						// 续保模块
│   │   │   ├── approveModel.vue			// 续保模式确认页面
│   │   │   ├── chooseModel.vue				// 续保模式选择页面
│   │   │   ├── con_info.vue				// 续保详情页面
│   │   │   ├── dataReport.vue				// 续保报表页面
│   │   │   ├── index.vue					// 续保首页
│   │   │   ├── persona.vue					// 用户画像详情页面
│   │   │   ├── search.vue					// 续保搜索页面
│   │   │   ├── templates					// 子组件文件夹
│   │   │   └── userRemakeAdd.vue			// 用户信息回补
│   │   ├── formPageToNative				// 极速报价跳转第三方页面(配合Navtive极速报价功能)
│   │   │   └── index.vue
│   │   ├── inClaim							// 理赔案件模块
│   │   │   └── inClaimDetail.vue
│   │   ├── inCoreData						// 业绩查询模块
│   │   │   ├── image
│   │   │   └── index.vue
│   │   ├── inDataAnalysis					// 推修数据模块
│   │   │   ├── inContactAnalyse
│   │   │   └── inOutputValAnalyse
│   │   ├── inRepairTask					// 推修任务模块
│   │   │   ├── css
│   │   │   ├── images
│   │   │   ├── index.vue
│   │   │   ├── info.vue
│   │   │   ├── page
│   │   │   ├── prodPremium
│   │   │   └── resourceTotal
│   │   └── selectOrganization.vue			// 公用选择机构页面
│   ├── main.js								// Vue.js入口文件
│   ├── outServcieLogic						// 外部端页面
│   │   ├── claim							// 理赔案件模块
│   │   │   ├── claimInfo.vue
│   │   │   ├── claimList.vue
│   │   │   └── template
│   │   ├── continue						// 续保模块
│   │   │   ├── con_info.vue				// 续保详情
│   │   │   ├── dataReport.vue				// 续保报表
│   │   │   ├── index.vue					// 续保首页
│   │   │   └── templates					// 子组件文件夹
│   │   ├── coreData						// 业绩查询
│   │   │   ├── boardList.vue
│   │   │   └── index.vue
│   │   ├── newCarIss						// 买车险模块
│   │   │   └── carInsure.vue				// 买车险页面
│   │   ├── orderManagement					// 订单管理模块
│   │   │   ├── checkbox					// 选择保险弹窗组件
│   │   │   ├── index.vue					// 首页
│   │   │   ├── om_info.vue					// 保单详情页面
│   │   │   └── page						// 子组件文件夹
│   │   ├── repairTask						// 推修任务模块
│   │   │   ├── index.vue					// 列表首页
│   │   │   ├── info.vue					// 详情页面
│   │   │   └── page						// 子组件文件夹
│   │   ├── search							// 公用搜索页面
│   │   └── visualMend						// 推修数据模块
│   │       ├── pushDataCon					// 推修数据 联系分析
│   │       ├── pushDataFlow				// 推修数据 客户流向
│   │       ├── pushDataVsiual				// 推修数据 产值分析
│   │       └── pushIndex.vue				// 推修数据首页(已弃用)
│   ├── router								// 路由文件夹
│   │   └── index.js						// 路由配置文件
│   └── test
│       └── main.vue						// 项目的测试首页
└── static   								// 不打包的文件

```
## 项目简介

该项目是服务于 车商 (4s店的工作人员) 方便车商人员快速卖保险, 并管理自己网点下的保险续保、车险成交数据展示等；
项目分为两种模式 车商端 队伍端
  * 车商端 (4s店的工作人员)
  * 队伍端 (产险内部员工)


## src 文件夹下的介绍

### common (公用文件)

#### comComponent (封装的公用Vue组件)

##### alertWindow(弹窗动画组件)

> 弹窗过度动画的效果的封装, 使用后整个APP的弹窗动画保持一至


`Props:`

| Name | Info | valueType | defaultValue|
|------|------|-----------|--------|
| `value`(`v-model`)| 为true时显示, 为false时隐藏| Boolean | false|

`使用实例:`

```
<template>
  <section>
    <pts-alert v-model="show">
      <h1 @click="show = false" style="background: #FFffff">这里是页面的代码</h1>
    </pts-alert>
    <button @click="show = true">点击</button>
  </section>
</template>

<script>
  // 引入组件
  import ptsAlert from 'pts/alertWindow';

  export default {
    Name: "test",
    data () {
      return {
        show: false
      }
    },
    // 注册组件
    components: {
      ptsAlert
    }
  }
</script>

<style scoped lang="less">

</style>

```

--

##### echarts ([百度echarts组件](http://echarts.baidu.com))

> 建立这个的初衷是防止在使用的页面中频繁的实例化echarts
> 内部的组件使用的props与对外方法一致, 不在分开描述


`Props:`

| Name | Info | valueType | defaultValue|
|------|------|-----------|--------|
| `options`| echarts的配置项| Object | -|

`Methods:`

| Name | Info | Params | other|
|------|------|-----------|--------|
| `setData`| 从后台拿到值以后通过此方法让图表呈现出来|callback(echarts的实例) | -|
| `init`| 当页面的状态改变时, 例如 从日数据转换为月数据, 运行该方法,使eahcer变为刚刚进页面的状态|- | -|

`使用实例:`

```
<template>
  <section>
    <!-- 通过refs 找到组件实例来调用组件内的方法 -->
    <pts-pie :options="pieOptions" ref="ptsPie"></pts-pie>
    <button @click="initEcharts">初始化</button>
  </section>
</template>

<script>
  // 引入组件
  import ptsPie from 'pts/echarts/pie';
  import {loadEcharts} from "../common/js/comUtils";

  export default {
    name: "test",
    data () {
      return {
        show: false,
        pieOptions: {
          color: ['#60D194', '#FFDB4B', '#559EFF'],
          series: [
            {
              name: '饼状图的名称',
              type: 'pie',
              radius: ['75%', '90%'],
              legendHoverLink: false,
              label: {
                normal: {
                  show: false
                },
                emphasis: {
                  show: false
                }
              },
              labelLine: {
                normal: {
                  show: false
                },
                emphasis: {
                  show: false
                }
              },
              hoverAnimation: false,
              data: [0, 0]
            }
          ]
        }
      }
    },
    methods: {
      /* 初始化echarts */
      initEcharts () {
        this.$refs.ptsPie.init();
      }
    },
    mounted () {
      let _this = this;
      setTimeout(function () {
        _this.$refs.ptsPie.setData(function (echarts) {
          echarts.setOption({
            series: {
              data: [80, 20]
            }
          })
        })
      }, 2000);
    },
    // 注册组件
    components: {
      ptsPie
    },
    // 因为是H5页面 并不是所有的页面都需要这个echarts 因此在这里做了判断, 需要的时候手动引入
    beforeRouteEnter (t, f, n) {
      loadEcharts(n); // 加载echarts的方法
    }
  }
</script>

<style scoped lang="less">

</style>

```

--

##### header (头部组件)

> 头部组件 后续头部由Native来负责,这个应该很快就不用了;
> 该组件已在全局注册不需要在局部引入,注册!!!


`Props:`

| Name | Info | valueType | defaultValue|
|------|------|-----------|--------|
| `titleText`| 需要显示的title文字, 如果没有会自动显示搜索框| String | -|
| `showRight`| 是否显示右边的图标/插槽| Boolean | false |
| `leftFlag`| 是否阻止左边箭头点击历史回退的功能| Boolean | false|
| `inputPlh`| 显示为搜索框状态时, placeholder 的文字 | String | 请输入搜索的内容（案件号、车牌)|
| `flagName`| 跳转搜索页面时url的query中flag的值| String | taskList|
| `stopEvery`| 头部的所有事件不在响应| Boolean | -|

`Methods:`

| Name | Info | Params | other|
|------|------|-----------|--------|
| `on-right`| 右边搜索图标的点击事件 | -|-|
| `on-left`| 当`Props`中`leftFlag` 为`true`时, 点击左边的箭头会触发该事件|- | -|

`Slot:`

| Name | Info |other|
|------|------|--------|
| `center`| 取代中间的文字或搜索框 | -|
| `right`| 取代右边的放大镜图标 |- |

`使用实例:`

```
<template>
  <section> <!-- 当section含有class="box"时 头部会固定在头部 具体查看App.vue -->
    <pts-header title-text="测试title"></pts-header>
    <!-- 别的方面请自己试验 -->
  </section>
</template>

<script>
  // 全局注册 不需要在引入和注册
  export default {
    name: "test",
    data () {
      return {}
    },
    methods: {
    }
  }
</script>

<style scoped lang="less">

</style>
```
--

##### linkageMenu (外部端总对总机构选择器)

> 外部端总部角色选择查看该企业下分机构的数据的选择器, 作用是: 选择分机构;

`Props:`

| Name | Info | valueType | defaultValue|
|------|------|-----------|--------|
| `show`| 控制是否显示 | `Boolean` |`false` |

`Methods:`

| Name | Info | Params | other|
|------|------|-----------|--------|
| `on-shadow-change`| 用户滑动模块使选中的值发生改变时触发 | `ids` {Array} 最多三个选项的ID值的数组<br/>`name` {Array} 最多三个选项的name值的数组|-|
| `on-hide`| 组件关闭时触发 |`closeFlag` {Boolean} 为`false`时组件是点击取消按钮关闭的,为`true`时用户是点击确认关闭的,此时第二个实参返回为一个对象<br/>`msg` {Object} 当用户点击确认关闭时,该对象返回用户选中的值 | -|

`使用实例:`

```
<template>
  <section>
    <pts-choose-city :show="show" @on-shadow-change="change" @on-hide="hide"></pts-choose-city>
    <button @click="show = true">显示</button>
  </section>
</template>

<script>
  import ptsChooseCity from 'pts/linkageMenu'

  export default {
    name: "test",
    data () {
      return {
        show: false
      }
    },
    methods: {
      change (ids, names) {
        console.log('用户改变');
        console.log(ids);
        console.log(names);
      },
      hide (isClose, msg) {
        console.log('用户关闭');
        this.show = false; // 这里需手动将状态重置;
        isClose ? console.log(msg) : '';
      }
    },
    components: {
      ptsChooseCity
    }
  }
</script>

<style scoped lang="less">

</style>

```

--

##### loading (加载动画组件)

> 该组件类似于一个`JS`的类, 因此引入组件内部的时候不需要实例化;也不包含`VUE`的`Props`等;
> 它自带有透明的遮罩, 因此它显示时是不可点击的;

`使用实例:`

```
<template>
  <section>

    <button @click="showLoading">显示</button>
  </section>
</template>

<script>
  import loading from 'pts/loading'
  // 该组件不需要实例化
  export default {
    name: "test",
    data () {
      return {}
    },
    methods: {
      showLoading () {
        loading(true); // 传入true时 显示
        setTimeout(function () {
          loading(false); // 传入false时隐藏
        }, 2000)
      }
    }
  }
</script>

<style scoped lang="less">

</style>

```

--

##### scrollAjax (上拉记载, 下拉刷新组件)

> 模拟原生端 上拉加载, 下拉刷新组件

`Props:`

| Name | Info | valueType | defaultValue|
|------|------|-----------|--------|
| `bottomAjax`| 控制是否允许上拉加载 | `Boolean` |`false` |
| `topAjax`| 控制是否允许下拉刷新 | `Boolean` |`false` |
| `overflow`| 控制是否禁止滑动 | `Boolean` |`false` |

`Methods:`

| Name | Info | Params | other|
|------|------|-----------|--------|
| `on-bottom-ajax`| 上拉加载时触发 |-|-|
| `on-top-ajax`| 下拉刷新时触发 |- | -|
|`reset`|数据加载完成后调用时需手动调用回调函数,进行滑动距离的重新计算|`flag` 当时下拉刷新时需要传递`true`进来|-|

`调用实例:`

```
<template>
  <section style="height: 100%"> // dropAjax的高度会按照父元素的高度来计算
    <pts-drop-ajax>
      这里是你的内容
    </pts-drop-ajax>
    // 具体方式请自行测试
  </section>
</template>

<script>
  import ptsDropAjax from 'pts/scrollAjax'
  export default {
    name: "test",
    data () {
      return {}
    },
    methods: {},
    components: {
      ptsDropAjax
    }
  }
</script>

<style scoped lang="less">

</style>

```
--


##### tab (顶部标题切换组件)

> 在顶部标题切换, 带动下面的页面切换

Props:

| Name | Info | valueType | defaultValue|
|------|------|-----------|--------|
| `titleList`| tab上标题的数组(必传)格式见实例 | `Array` |- |
| `height`| 组件在页面中的高度, 默认计算方式是 屏幕的高度 减去 组件距离屏幕顶的高度 | `Number`,`String` |- |
| `v-model`| 不接受外部的赋值, 只是对外返回当前是在第个页面 | Number |- |

Methods:

| Name | Info | Params | other|
|------|------|-----------|--------|
| `on-change`| 当tab的页面变化时触发 |返回当前页面在传入titleList中的当前值|-|
| `on-child-change`| 当tab子选项发生变化时触发 | 返回当前页面在传入titleList中的当前值 | -|

调用实例:

```
<template>
  <section style="height: 100%">
    <pts-tab :titleList="titleTab" @on-change="change" @on-child-change="childChange">
      <pts-tab-item v-for="item in titleTab">{{item.title}}</pts-tab-item>
    </pts-tab>
  </section>
</template>

<script>
  import ptsTab from 'pts/tab'

  export default {
    name: "test",
    data () {
      return {
        titleTab: [
          {
            title: '应续',
            isRed: true // 显示小红点作为提示
          },
          {
            title: '未续',
            childs: [
              {title: '未续', flag: '1'},
              {title: '当月应续', flag: '4'},
              {title: '下月应续', flag: '5'}
            ]
          },
          {title: '脱保'},
          {title: '已续'}
        ]
      }
    },
    methods: {
      change (item) {
        console.log(item);
      },
      childChange (item) {
        console.log(item);
      }
    },
    components: {
      ptsTab,
      ptsTabItem: ptsTab.Item // 注意需注册子组件 itme
    }
  }
</script>

<style scoped lang="less">

</style>
```

--

##### textScroll (文字走马灯组件)

> 内部端显示网点名称时会存在显示不全, 因此采用走马灯的方式进行显示(配置头部组件使用)

Props:

| Name | Info | valueType | defaultValue|
|------|------|-----------|--------|
| `text`| 走马灯中显示的默认文字 | `String` |- |


Methods:

| Name | Info | Params | other|
|------|------|-----------|--------|
| `input`| 当用户选择的网点发生改变时触发 |返回当前网点的编码|-|

调用实例:

```
<template>
  <section style="height: 100%">
    <pts-header title-text="该文字必须有">
      <div class="textBanner" slot="center">
        <pts-text-scroll @input="changModel" :text="titleText"></pts-text-scroll>
      </div>
    </pts-header>
  </section>
</template>

<script>
  import ptsTextScroll from 'pts/textScroll';

  export default {
    name: "test",
    data () {
      return {
        titleText: '默认文字'
      }
    },
    methods: {
      changModel (item) {
        console.log(item);
      }
    },
    components: {
      ptsTextScroll
    }
  }
</script>

<style scoped lang="less">

</style>
```

--

##### toast (吐司提示)

> 吐司提示组件
> 该组件不需要实例化 引入后, 直接调用即可;

调用实例:

```
<template>
  <section>
    <input type="text" v-model="text" placeholder="请输入测试文字" style="border: 1px solid #000">
    <button @click="showToast">显示</button>
  </section>
</template>

<script>
  import toast from 'pts/toast';

  export default {
    name: "test",
    data () {
      return {
        text: ''
      }
    },
    methods: {
      showToast () {
        toast(this.text);
      }
    }
  }
</script>

<style scoped lang="less">

</style>
```

--

#### css (公用css页面)

+ 1px.less (解决移动端1px边框问题的less文件)
+ newCarOutOfTheSingleOne.css (切图提供的css文件, 业务页面的样式基本都在这个页面中)
+ theme.less (主题颜色的区域, 会覆盖vux 的颜色)

#### filters (Vue注册的过滤器)

> 具体请看各个文件中的注释

#### images (公共图片组件)

>以后的图片在每个业务模块单独维护

#### js (公共方法组件)

+ axiosConfig.js (配置有axios的拦截器, 使用axiso发送请求时直接引用该方法即可)
+ comConfig.js (配置所有后台接口地址的文件)
+ comES6.js (有些ES6的语法webpack并没有编译为ES5导致有的安卓手机会有兼容性问题)
+ comMap.js ()
+ comUtils.js (公用的方法)
+ comValidate.js (公用的校验方法)
+ getTestLoginToken.js (模拟Navtive的登录数据)
+ native.js (与Navtive交互的方式)
+ ptsSwiper.js (一个很简易的轮播图的插件)

### inServiceLogic (内部端业务页面文件夹)

### outServcieLogic (外部端业务页面文件夹)
#### 新车出单[`carinsure`]
+ 投保地区自动通过接口带出<br>
+ 车牌号码 省份自动带出,如果是新车用'*'号代替<br>
+ 已有车牌可支持手动输入车牌号<br>
+ 点击立即投保跳转到imcs出单页面<br>

涉及接口:

| 接口名 | 接口地址 |
| ------ | ------ |
| `新车出单` | <font color='red'>[`iCorePts-mobile/api/acceptinsurance/createindex.do`]</font>|


#### 理赔查询[`claim`]
+ 理赔列表
> 查询理赔的数据,分状态查询[`全部` `报案` `定损` `理算` `结案`]<br>
> 支持上拉加载,下拉刷新 每页20条<br>
> 列表用了[`PTS-tabs` `PTS-tab-item`]组件<br>

+ 理赔详情
>展示理赔的数据信息[报案信息 定损信息 险种信息 支付信息等]
+ 查询
> 精确查找:报案号 车牌号<br>
> 时间维度:支持半年时间,一个月的时间段查询<br>

涉及接口:

| 接口名 | 接口地址 |
| ----- | ------- | -----------|--------|
| `理赔列表查询` | <font color='red'>[`iCorePts-mobile/api/claimscase/settlementList.do`]</font> |
| `理赔详情查询` | <font color='red'>[`iCorePts-mobile/api/claimscase/settlementList.do`]</font>|

#### 业绩查询[`coreData`]
> 查询维度分 日 月 年 <br/>
> 总队总需求涉及:车型品牌,机构网点维度---<font color='red'>车型品牌调用Native接口得到</font><br>
> 展示的有新保 转保 续保 <br/>
> 分折线图和饼状图的图标展示 <br/>
> 榜单查询分:[`明星榜,进取榜`]<br>

涉及接口:

| 接口名  | 接口地址 |
|------|------|-----------|--------|
| `查询机构列表`| <font color='red'>[`/iCorePts-mobile/api/coreDate/queryOrganized`]</font>|
| `获取核心数据报表` |<font color='red'>[`iCorePts-mobile/api/coreDate/queryPreamData`]</font>|
| `获取榜单排行列表` | <font color='red'>[`iCorePts-mobile//api/coreDate/billList`]</font>|



#### 产值分析[`pushDataVsiual`]
> 查询维度分 日 月 年 报案口径 定损口径 结案口径<br>
> 展示的有[`产值 ``推修量(台)` `维修量(台)`]<br>
> 分折现图和柱状图<br>
> 查询维度比较多,需仔细查看<br>

涉及接口:

| 接口名  | 接口地址 |
|------|------|-----------|--------|
|`推修分析`| <font color='red'>[`/iCorePts-mobile/api/recommendedRepair/repairAnalysis.do`]</font> |
|`查询机构`| <font color='red'>[`/iCorePts-mobile/api/coreDate/queryOrganized`]</font> |

### router (vue 路由配置)

### test (测试文件目录)

+ main.vue (项目的根页面, 含有进入所有页面的链接)

### App.vue (Vue路由的根挂载文件)

### main.js (Vue的入口文件)








