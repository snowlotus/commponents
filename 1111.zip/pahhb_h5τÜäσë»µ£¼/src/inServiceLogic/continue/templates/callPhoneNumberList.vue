<template>
  <alert-window v-model="showAlert">
    <div class="xubaoTelArea dialing">
      <h3 style="border: none;" class="pts-b-b">拨打电话</h3>
      <ul class="dialingList">
        <li v-for="item in userNumList">
          <p>{{item.mobileNo | phoneNum}}<em>({{item.mobileScore * 100}}分)</em></p>
          <a href="javascript:;" otype="button" otitle="拨打电话" @click="call(item.mobileNo)">拨打电话</a>
        </li>
      </ul>
      <a href="javascript:;" otype="button" otitle="关闭" class="close" @click="close">关闭</a>
    </div>
  </alert-window>
</template>

<script>
  import alertWindow from '../../../common/comComponent/alertWindow'
  import '../../../common/filters/conPhone'

  export default {
    name: "call-phone-number-list",
    props: {
      userNumList: Array,
      showAlert: Boolean
    },
    data () {
      return {}
    },
    methods: {
      close () {
        this.$emit('update:showAlert', false);
      },
      call (callNum) {
        this.$emit('on-call', callNum);
      }
    },
    components: {
      alertWindow
    }
  }
</script>

<style scoped lang="less">

</style>
