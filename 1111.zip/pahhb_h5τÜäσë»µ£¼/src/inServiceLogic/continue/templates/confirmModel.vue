<template>
  <div class="confirm-model-wrap model-wrap">
    <div class="name pts-b-b pts-cell">
      <label>网点名称</label>
      <span class="text-hidden">{{datas.carDealerName}}</span>
    </div>
    <div class="model pts-b-b pts-cell">
      <label>网点模式</label>
      <span class="text-hidden">【{{datas.preModifyMode | modelName}}】更改为【{{datas.modifiedMode | modelName}}】</span>
    </div>
    <div class="pts-cell btn-box" v-if="datas.approveState === '0'">
      <button class="pts-btn cancel fr" @click="confirm(0)">不同意</button>
      <button class="pts-btn confirm fr" @click="confirm(1)">同意</button>
    </div>
    <div class="pts-cell btn-box" v-else>
      <p v-if="datas.approveState === '1'">已同意</p>
      <p v-else>不同意</p>
    </div>
  </div>
</template>

<script>
  export default {
    name: "confirm-model",
    props: {
      datas: Object
    },
    data () {
      return {}
    },
    methods: {
      confirm (flag) {
        this.$emit('on-comfirmModel', !!flag, this.datas.auditNumber);
      }
    },
    filters: {
      modelName (v) {
        let obj = ['自续', '协续', '转新'];
        let index = isNaN(Number(v)) ? 2 : v;
        return obj[index];
      }
    }
  }
</script>

<style scoped lang="less">
  @import 'style';
</style>
