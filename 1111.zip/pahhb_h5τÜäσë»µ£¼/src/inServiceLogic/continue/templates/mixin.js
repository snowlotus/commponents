import Vue from 'vue';
import axios from '../../../common/js/axiosConfig';
import url from '../../../common/js/comConfig';
import toast from '../../../common/comComponent/toast';

export default {
  data () {
    return {
      showCallAlert: false, // 是否显示选择手机号列表弹窗
      userNumList: [], // 手机号弹窗的数据
      showCallMsg: false, // 是否显示打过电话后记录联系备注的弹窗
      callUserTime: '' // 用户拨打电话的时间
    }
  },
  methods: {
    /* 唤醒选择电话号弹窗 */
    awakenCallAlert (msg) {
      if (msg.batchNo) this.activeDatas = msg;
      const _this = this;
      /*axios.post('http://localhost:8888/postGetData', {
        file: 'phoneNum',
        path: 'xubao'
      })*/
      axios.post(url.getWebServiceUrls('getPhoneNum'), {
        "batchNo": msg.batchNo || _this.datas && _this.datas.batchNo,
        "markNo": msg.idAcssVehicleInfo || _this.datas && _this.datas.idAcssVehicleInfo,
      })
        .then(res => {
          // console.log(res);
          res = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
          if (res.code !== 0) {
            toast(res.msg);
            return;
          }
          _this.userNumList = res.data;
          _this.showCallAlert = true
        }).catch(err => {
        console.log(err);
        toast('获取电话号失败, 请重试。')
      })
    },
    /* 拨打电话 并唤醒记录备注信息窗口 */
    callUser (callNum) {
      let _this = this;
      // 在ios系统中, 拨打电话会有一个拦截框, 需要native 告诉我用户是否点击了拨打 在安卓中则没有这个问题。
      if (window.urlHeader.os === 'iOS') {
        window.getUserIsCall = function () {
          _this.getCallTime();
          setTimeout(function () {
            _this.showCallMsg = true
          }, 1000);
          return window.getUserIsCall = null;
        }
      }
      window.eventAnalytics('内部端_续保查询', `续保状态-${this.tabName || '续保详情'}-拨打电话`);
      window.location.href = 'tel:' + callNum;
      _this.showCallAlert = false;
      if (window.urlHeader.os === 'iOS') return;
      _this.getCallTime();
      setTimeout(function () {
        this.showCallMsg = true
      }.bind(this), 1000)
    },
    /* @info 添加接触历史函数 */
    getMsg (msg) {
      let _this = this;
      const date = new Date();
      axios.post(url.getWebServiceUrls('setInsideHistory'), {
        "remarkInfo": msg,
        "renewalId": this.activeDatas && this.activeDatas.renewalId || _this.datas && _this.datas.renewalId,
        "callTime": _this.callUserTime || `${date.getFullYear()}-${(date.getMonth() + 1) > 9 ? (date.getMonth() + 1) : '0' + (date.getMonth() + 1) }-${date.getDate() > 9 ? date.getDate() : '0' + date.getDate()} ${date.getHours() > 9 ? date.getHours() : '0' + date.getHours()}:${date.getMinutes() > 9 ? date.getMinutes() : '0' + date.getMinutes()}:${date.getSeconds() > 9 ? date.getSeconds() : '0' + date.getSeconds()}`
      }).then(res => {
        let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
        switch (data.code) {
          case 0:
            _this.showCallMsg = false;
            toast('提交成功');
            _this.callUserTime = '';
            typeof _this.getHistory === 'function' && _this.getHistory();
            break;
          default:
            toast(data.msg);
            break
        }
      }).catch(err => {
        console.log(err)
        // if (msg.contactCustomerResult) toast('提交失败, 请重试');
      })
    },
    /* 获取拨打时间 */
    getCallTime () {
      const date = new Date();
      this.callUserTime = `${date.getFullYear()}-${(date.getMonth() + 1) > 9 ? (date.getMonth() + 1) : '0' + (date.getMonth() + 1) }-${date.getDate() > 9 ? date.getDate() : '0' + date.getDate()} ${date.getHours() > 9 ? date.getHours() : '0' + date.getHours()}:${date.getMinutes() > 9 ? date.getMinutes() : '0' + date.getMinutes()}:${date.getSeconds() > 9 ? date.getSeconds() : '0' + date.getSeconds()}`;
    }
  }
}
