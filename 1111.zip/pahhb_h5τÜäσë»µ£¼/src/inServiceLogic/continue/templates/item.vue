<template>
  <div class="taskArea mb20" @click="goInfo">
    <dl class="pts-b-b">
      <dt v-if="datas.renewalStatus === '0'" style="border-color:#FE883A; color:#FE883A;">未续</dt>
      <dt v-if="datas.renewalStatus === '1'" style="border-color:#ff6666; color:#ff6666;">脱保</dt>
      <dt v-if="datas.renewalStatus === '2'" style="border-color:#2ab768; color:#2ab768;">已续</dt>
      <dd v-if="datas.renewalStatus !== '2'" style="color:#999;">{{datas.dateInsuranceEnd}}<span> 到期</span>
        <span v-if="datas.renewalStatus === '1'">已脱保<em>{{datas.dayNum}}</em>天</span>
        <span v-if="datas.renewalStatus === '0'">距离到期<em>{{datas.dayNum}}</em>天</span>
      </dd>
      <dd v-else style="color:#999;">
        {{datas.renewalDate}} 已续
      </dd>
    </dl>
    <div class="taskBox nb" style="border: none;">
      <dl>
        <dt>被保人</dt>
        <dd>{{datas.insuredName}}<span class="scores" v-if="datas.renewalRate>=60">{{datas.renewalRate}}分</span></dd>
      </dl>
      <dl>
        <dt>车牌号</dt>
        <dd>{{datas.vehicleLicenceCode | vehicleFrameNoHidden}}</dd>
      </dl>
      <dl>
        <dt>车龄</dt>
        <dd>{{datas.vehicleAge}}年</dd>
      </dl>
      <dl>
        <dt>车型</dt>
        <dd class="text-hidden">{{datas.autoModelChnName}}</dd>
      </dl>
      <dl>
        <dt>车架号</dt>
        <dd>{{datas.vehicleFrameNo}}</dd>
      </dl>
      <a href="javascript:;" otype="button" otitle="拨打电话" v-if="datas.renewalStatus !== '2' && datas.status !=='1'" class="btnState btnStateTell pts-b-l" style="border:none" @click.stop="callUser">拨打电话</a>
    </div>
  </div>
</template>

<script>
  import {vehicleFrameNoHidden} from '../../../common/filters/conCar'

  export default {
    name: "continue-item",
    props: {
      flagName: String,
      datas: Object
    },
    data () {
      return {
        /*datas : {
          autoModelChnName: "宝马BMW7200HL(BMW320Li)轿车",
          batchNo: "201803",
          clientPhone: "13510992422,075582854251,13522223333",
          dateInsuranceBegin: "2017-03-06",
          dateInsuranceEnd: "2018-03-01",
          dayNum: "8",
          engineNo: "2238C853",
          idAcssVehicleInfo: "2D463943C660EB1BE054A0369F5ADC40",
          insuredName: "兰斌",
          renewalDate: "2017-09-29",
          renewalId: "5A4C1472020E54E2E3340010E0C0AEFC",
          renewalStatus: "0",
          status: "0",
          totalPremium: "20551.36",
          touchStatus: "0",
          updateTime: "2018-03-07 15:31:44",
          vehicleAge: "3",
          vehicleFrameNo: "LBV8V3105GMF42945",
          vehicleLicenceCode: "津F-BN118"
        }*/
      }
    },
    methods: {
      // 传递拨打电话的动作
      callUser () {
        this.$emit('on-calluser', {
          "batchNo": this.datas.batchNo,
          "idAcssVehicleInfo": this.datas.idAcssVehicleInfo,
          "renewalId": this.datas.renewalId
        })
      },
      // 跳往详情页面
      goInfo () {
        let {batchNo, idAcssVehicleInfo, renewalStatus, status, insuredName, insuranceDelite} = this.datas;
        let policyNo = insuranceDelite.map((v) => v.lastpolicyNo).join(',');
        let obj = {batchNo, idAcssVehicleInfo, renewalStatus, status, insuredName, policyNo};
        this.$router.push({path: '/inside/continueInfo', query: obj});
      }
    },
    mounted(){
      console.log(this.datas);
    }
  }
</script>

<style scoped lang="less">
  .scores{
    font-size: 0.22rem;
    color: #fe883a;
    line-height: 0.22rem;
    margin-left: 0.2rem;
    width: 0.49rem;
    height: 0.22rem;
  }
</style>
