<template>
  <section class="insideXubaoWrap tabArea listWrap">
    <pts-scroll-ajax ref="dropAjax" :topAjax="topAjax && !searchCondition && !showDateNull"
                     :bottomAjax="bottomAjax && !showDateNull"
                     @on-top-ajax="getFirstPage" @on-bottom-ajax="getNextPage">
      <div class="searchArea c" v-if=" flagName==='1' || flagName==='2' ">
        <p v-if="flagName==='1'">距离保单到期</p>
        <p v-else>距离保单脱保</p>
        <input type="tel" class="searchVal" v-model="searchDayNum" min="0" :max="flagName==='1' ? '92' : '62'"
               :placeholder="flagName==='1' ? '最多输入92天':'最多输入62天'" @keyup.enter="getFirstPage" ref="telInput">
        <p>天</p>
        <input type="button" value="搜索" class="searchBtn" @click.stop="getFirstPage">
      </div>
      <p class="totalOrder" v-if="!showDateNull && dataLength > 0">本次查询共{{dataLength}}单</p>
      <pts-itme :flagName="flagName" v-for="(item,index) in dataList" :datas="item" :key="index"
                @on-calluser="awakenCallAlert"></pts-itme>
      <!-- 数据为空显示页面 -->
      <div v-if="showDateNull" class="dataNullWrap">
        <div class="imgWrap"></div>
        <div class="dataNullText">没有查询到匹配的数据…</div>
      </div>
    </pts-scroll-ajax>
    <!-- 记录打过电话的结果 -->
    <call-msg :showCallMsg.sync="showCallMsg" :time="callUserTime" @on-updata-callmsg="getMsg"></call-msg>
    <!-- 选择要拨打的电话 -->
    <call-choose-num :showAlert.sync="showCallAlert" :userNumList="userNumList" @on-call="callUser"
    ></call-choose-num><!--@on-updata-alert="calluser"-->
  </section>
</template>

<script>
  import ptsItme from './item';
  import ptsScrollAjax from '../../../common/comComponent/scrollAjax';
  import axios from '../../../common/js/axiosConfig';
  import url from '../../../common/js/comConfig';
  import toast from '../../../common/comComponent/toast';
  import callMsg from './callRemarks'
  import callChooseNum from './callPhoneNumberList'
  import mixin from './mixin';

  export default {
    name: "continue-list",
    mixins: [mixin],
    props: {
      active: Boolean,
      tabChildFlag: String,
      flagName: String,
      searchCondition: {
        type: String,
        default: ''
      },
      modelCode: {
        type: String,
        default: ''
      },
      tabName: String
    },
    data () {
      return {
        searchDayNum: '', // 未续或已续下 天数筛选框中输入的数据
        showDateNull: false, // 是否显示页面数据为空的页面
        topAjax: true, // 是否允许下拉刷新
        bottomAjax: false, // 是否允许上拉加载
        page: 1, // 当前是第几页的数据
        dataList: [], // 页面的数据
        activeDatas: {}, // 记录item传递过来的批次号/ 标的号/ 保单号
        showDataOver: false, // 是否显示页面加载完毕
        dataLength: 0 // 显示近30天加载多少条数据
      }
    },
    methods: {
      /* 下拉刷新 加载第一页的数据 */
      getFirstPage () {
        console.log('搜索的值为' + this.searchDayNum)
        if (this.searchDayNum === '') {
          this.page = 1;
          this.getData(true, true);
          return;
        }
        if (this.searchDayNum < 1) {
          this.searchDayNum = 1;
          toast('最小只能搜索1天的哦');
        }
        if (this.flagName === '1' && this.searchDayNum > 92) {
          this.searchDayNum = 92;
          toast('未续订单最大只能搜索92天的哦');
        }
        if (this.flagName === '2' && this.searchDayNum > 62) {
          this.searchDayNum = 62;
          toast('脱保订单最大只能搜索62天的哦');
        }
        if (this.searchDayNum && isNaN(Number(this.searchDayNum))) {
          toast('请输入数字');
          return;
        }
        if (this.searchDayNum) {
          let flagText = (this.flagName === '1' ? '未续' : undefined) || (this.flagName === '2' ? '脱续' : undefined);
          flagText && window.eventAnalytics('队伍端_续保查询','续保状态-'+flagText+'-时间搜索');
        }
        this.$refs.telInput.blur();
        this.page = 1;
        this.getData(true);
      },
      /* 上拉加载下一页的数据 */
      getNextPage () {
        this.page++;
        this.getData();
      },
      /* 获取数据
       * flag {Boolean} 是否加载的第一页数据
       * */
      getData (flag) {
        let _this = this;
        if (flag) {
          this.dataLength = 0;
          this.dataList = [];
          this.showDateNull = false;
          this.showDataOver = false;
        }
        axios.post(url.getWebServiceUrls('getContinList'), {
          "dayNumber": this.searchDayNum || undefined,
          "dealerCode": this.modelCode,
          "pageNo": this.page,
          "pageSize": 10,
          "searchCondition": this.searchCondition || undefined,
          "status": this.tabChildFlag || this.flagName,
        })
          .then(res => {
            res = res.data;
            if (res.code !== 0) {
              toast(res.msg);
              if (flag) {
                if (_this.searchCondition) {
                  _this.$emit('data-back', true);
                } else {
                  _this.showDateNull = true;
                }
              }
              _this.$nextTick(function () {
                _this.$refs.dropAjax && _this.$refs.dropAjax.reset(flag);
              });
              return;
            }
            _this.dataLength = res.totalCount;
            if (res.data && res.data.length < 1) {
              if (flag) {
                if (_this.searchCondition) {
                  _this.$emit('data-back', true);
                } else {
                  _this.showDateNull = true;
                  _this.bottomAjax = false;
                }
                return
              } else {
                _this.showDataOver = true;
                _this.bottomAjax = false;
              }
              _this.$nextTick(function () {
                _this.$refs.dropAjax && _this.$refs.dropAjax.reset(flag);
              });
              return
            }
            res.data.forEach(v => {
              _this.dataList.push(v);
            });
            _this.bottomAjax = true;
            if (res.pageNo * res.pageSize > res.totalCount) {
              _this.bottomAjax = false;
              if (flag) {
                _this.showDataOver = true;
              }
            }
            _this.$nextTick(function () {
              _this.$refs.dropAjax && _this.$refs.dropAjax.reset(flag);
              if (_this.searchCondition) {
                _this.$emit('data-back');
              }
            });
          }).catch(e => {
          console.log(e);
          if (flag) {
            if (_this.searchCondition) {
              _this.$emit('data-back', true);
            } else {
              _this.showDateNull = true;
            }
          }
          _this.$nextTick(function () {
            _this.$refs.dropAjax && _this.$refs.dropAjax.reset(flag);
          });
        })
      }
    },
    mounted () {
      if (this.active) this.getData(true);
    },
    components: {
      ptsItme,
      ptsScrollAjax,
      callChooseNum,
      callMsg
    },
    watch: {
      active (to, from) {
        if (to && this.dataList.length === 0) {
          this.page = 1;
          this.getData(true);
        }
      },
      tabChildFlag (to, from) {
        this.searchDayNum = undefined;
        this.page = 1;
        this.getData(true);
      },
      modelCode () {
        this.page = 1;
        this.bottomAjax = false;
        this.active && this.getData(true);
      }
    }
  }
</script>

<style scoped lang="less">
  .listWrap {
    height: 100%;
    width: 100%;
  }
</style>
