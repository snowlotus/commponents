<template>
  <alert-window v-model="showCallMsg">
    <div class="xubaoTelArea recordTel">
      <h3 style="border: none;" class="pts-b-b">添加拨打记录</h3>
      <div class="recordTelBox">
        <p>拨打时间<em>{{time}}</em></p>
        <textarea name="addRecord" id="addRecord" placeholder="选填：是否需要输入备注信息" v-model="remarkText"
                  maxlength="20"></textarea>
        <span class="txtNum">{{remarkText.length}}/20</span>
      </div>
      <div class="btnTel">
        <a href="javascript:;" otype="button" otitle="取消" class="cancel" @click="off">取消</a>
        <a href="javascript:;" otype="button" otitle="提交" class="cur" @click="confirm">提交</a>
      </div>
    </div>
  </alert-window>
</template>

<script>
  import alertWindow from '../../../common/comComponent/alertWindow';
  import toast from '../../../common/comComponent/toast';

  export default {
    name: "call-remarks",
    props: {
      showCallMsg: Boolean,
      time: String
    },
    data () {
      return {
        remarkText: ''
      }
    },
    components: {
      alertWindow
    },
    computed: {
      remarkTextLength () {
        return this.remarkText.length;
      }
    },
    methods: {
      confirm () {
        let text = this.remarkText.trim();
        if (!text) {
          toast('请输入备注信息');
          return
        }
        this.$emit('on-updata-callmsg', text);
        this.$emit('update:showCallMsg', false);
        this.remarkText = '';
      },
      off () {
        this.remarkText = '';
        this.$emit('update:showCallMsg', false);
      }
    }
  }
</script>

<style scoped lang="less">

</style>
