<template>
  <div class="choose-wrap model-wrap">
    <div class="name pts-b-b pts-cell">
      <label>网点名称</label>
      <span class="text-hidden">{{data.dealerName}}</span>
    </div>
    <div class="model pts-cell" @click="clickEven">
      <label>网点模式</label>
      <span class="text-hidden">{{modelName}}</span>
    </div>
  </div>
</template>

<script>
  export default {
    name: "choose-model",
    props: {
      data: Object,
      index: Number
    },
    data () {
      return {}
    },
    methods: {
      clickEven () {
        this.$emit('on-chooseModel', this.index);
      }
    },
    computed: {
      modelName () {
        let obj = ['自续', '协续', '转新'];
        return obj[this.data.renewalMode];
      }
    }
  }
</script>

<style scoped lang="less">
  @import "style";
</style>
