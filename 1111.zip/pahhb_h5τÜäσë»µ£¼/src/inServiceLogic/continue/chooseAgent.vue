<template>
  <div class="box">
    <pts-header titleText="选择网点"></pts-header>
    <div class="cellWrap">
      <ul class="cell-list">
        <li class="cell-item pts-b-b cell-title">
          <label class="cell-label">网点信息</label>
          <p class="content text-hidden"></p>
        </li>
        <li class="cell-item pts-b-b text-hidden">
          <label class="cell-label">网点</label>
          <p class="content text-hidden active">{{pageMsg.dealerName}}</p>
        </li>
        <li class="cell-item pts-b-b text-hidden">
          <label class="cell-label">渠道来源</label>
          <p class="content text-hidden active">{{pageMsg.channelSourceName}}</p>
        </li>
        <li class="cell-item pts-b-b text-hidden triangle" @click="chooseChannelSourceVO">
          <label class="cell-label">渠道来源细分</label>
          <p class="content text-hidden active" v-if="pageMsg.channelSource">{{pageMsg.channelSource}}</p>
          <p class="content text-hidden" v-else>请选择</p>
        </li>
        <li class="cell-item pts-b-b text-hidden triangle" @click="chooseAgent" v-if="isHaveAgent">
          <label class="cell-label" v-if="jingjiren">经济人</label>
          <label class="cell-label" v-else>代理人</label>
          <p class="content text-hidden active" v-if="pageMsg.agent">{{pageMsg.agent}}</p>
          <p class="content text-hidden" v-else>请选择</p>
        </li>
      </ul>
      <div class="button-wrap">
        <button class="button-item active" @click="oneKeyRenewal" v-if="showBtn">下一步</button>
        <button class="button-item" v-else>下一步</button>
      </div>
      <!-- 底部弹出选择项 -->
      <ul class="selected-wrap" :class="{'showWrap': show}">
        <li class="selected-item pts-b-b text-hidden"
            :class="{'active':!isChooseAgent && activeIndex === index || isChooseAgent && activeArgenIndex === index}"
            v-for="(item,index) in dataList"
            @click="selectedItem(item, index)">
          {{item.channelbusinessDetailName}}
        </li>
      </ul>
      <div class="selected-mask" v-if="show" @click="hideSelected"></div>
    </div>
    <form :action="fromData.imcsUrl" method="post" ref="formElem">
      <input type="hidden" name="params" :value="fromData.params">
      <input type="hidden" name="signData" :value="fromData.signData">
      <input type="hidden" name="systemId" :value="fromData.systemId">
    </form>
  </div>
</template>

<script>
  import toast from '../../common/comComponent/toast';
  import axios from '../../common/js/axiosConfig';
  import url from '../../common/js/comConfig';

  export default {
    name: "cell-page",
    data () {
      return {
        data: {},
        dataList: [],
        isHaveAgent: false, // 直接业务或特殊情况下是没有代理人的因此不需要选择
        activeIndex: -1,
        show: false,
        pageMsg: {
          networkName: '', // 网点名称
          channelSourceName: '', // 渠道来源
          channelSource: '', // 渠道细分
          channelSourceCode: '',
          agent: '',// 代理人或经纪人
          agentCode: ''
        },
        isChooseAgent: false,
        activeArgenIndex: -1,
        fromData: {
          imcsUrl: '',
          params: '',
          signData: '',
          systemId: ''
        }, // 一键续保 跳转from表单数据
        jingjiren: false // 是否是经纪人
      }
    },
    methods: {
      // 弹出窗选中数据时触发
      selectedItem (item, index) {
        if (this.isChooseAgent) {
          this.activeArgenIndex = index;
          this.pageMsg.agentCode = item.code;
          this.pageMsg.agent = item.channelbusinessDetailName;
        } else {
          this.activeIndex = index;
          this.pageMsg.channelSource = item.channelbusinessDetailName;
          this.pageMsg.channelSourceCode = item.channelSourceInfoVO;
          this.pageMsg.agentCode = '';
          this.pageMsg.agent = '';
          this.activeArgenIndex = -1;
          this.jingjiren = item.brokerList && item.brokerList.length > 0;
          this.isHaveAgent = item.agentList && item.agentList.length > 0 || item.brokerList && item.brokerList.length > 0;
          console.log(item);
        }
        this.show = false;
      },
      // 关闭弹出窗
      hideSelected () {
        this.show = false;
      },
      // 点击渠道来源细分
      chooseChannelSourceVO () {
        this.dataList = this.data.chooseChannelSourceVO;
        this.isChooseAgent = false;
        this.show = true;
      },
      // 获取页面数据
      getData () {
        axios.post(url.getWebServiceUrls('getAgentList'), {
          dealerCode: this.$route.query.dealerCode
        })
          .then(res => {
            let data = res.data;
            if (data.code !== 0) {
              toast(data.msg);
              return;
            }
            this.data = data.data;
            this.pageMsg = {
              dealerName: data.data.dealerName, // 网点名称
              channelSourceName: data.data.channelSourceName, // 渠道来源
              channelSource: '', // 渠道细分
              channelSourceCode: '',
              agent: '',// 代理人或经纪人
              agentCode: ''
            }
          })
          .catch(e => {
            console.log(e);
          })
      },
      // 选择代理人
      chooseAgent () {
        let arr = [];
        this.isChooseAgent = true;
        let item = this.data.chooseChannelSourceVO[this.activeIndex];
        let list = item.agentList && item.agentList.length > 0 ? item.agentList : item.brokerList;
        list.forEach(v => {
          arr.push({
            channelbusinessDetailName: `${v.agentCode || v.brokerCode}-${v.agentName || v.brokerName}`,
            code: v
          })
        });
        this.dataList = arr;
        this.show = true;
      },
      /* 一键续保 */
      oneKeyRenewal () {
        const _this = this;
        let query = this.$route.query;
        let obj = Object.assign(query, this.pageMsg.channelSourceCode, this.pageMsg.agentCode);
        console.log(obj);
        axios.post(url.getWebServiceUrls('oneKeyRenewal'), obj).then(res => {
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            switch (data.code) {
              case 0:
                _this.fromData.imcsUrl = data.data.imcsUrl;
                _this.fromData.params = data.data.params;
                _this.fromData.signData = data.data.signData;
                _this.fromData.systemId = data.data.systemId;
                _this.$nextTick(function () {
                  console.log('提交form')
                  _this.$refs.formElem.submit()
                })
                break
              default:
                toast(data.msg)
                break
            }
          }
        ).catch(err => {
          // toast('网络错误啦~ \\(≧▽≦)/~, 请重试')
          console.log(err)
        })
      },
    },
    mounted () {
      this.getData();
    },
    computed: {
      showBtn () {
        let pageMsg = this.pageMsg;
        return !this.isHaveAgent && pageMsg.channelSource && pageMsg.channelSourceCode || this.isHaveAgent && pageMsg.channelSource && pageMsg.channelSourceCode && pageMsg.agentCode && pageMsg.agent;
      }
    }
  }
</script>

<style scoped lang="less">
  @import "../../common/css/theme";

  .cellWrap {
    height: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    font-size: .28rem;
    .cell-list {
      background: #fff;
      .cell-item {
        display: flex;
        margin-left: 0.3rem;
        padding: 0.3rem 0;
        font-size: 0.28rem;
        &.triangle { // 向右的箭头
          padding: 0.3rem 0.3rem 0.3rem 0rem;
          background: url('../../common/images/icon_arrow.png') no-repeat 95% center;
          background-size: 0.12rem 0.24rem;
        }
        &.active { // 对号
          padding: 0.2rem 0;
          background: url('../../common/images/icon_tick.png') no-repeat 95% center;
          background-size: 0.2rem 0.2rem;
          & > .car-type, & > .car-info {
            color: @theme-color;
          }
        }
        &.cell-title {
          position: relative;
          & > .cell-label {
            color: #000;
          }
          &:after {
            content: '';
            display: block;
            position: absolute;
            top: 50%;
            left: -0.3rem;
            width: 0.08rem;
            height: 0.2rem;
            transform: translateY(-50%);
            background: @theme-color;
          }
        }
        .cell-label {
          flex: 0.2;
          margin-right: 0.3rem;
          color: #666;
        }
        .content {
          flex: 0.8;
          margin-right: 0.3rem;
          color: #999;
          text-align: right;
          &.active {
            color: #333;
          }
        }
        .car-type {
          width: 100%;
          margin-bottom: 0.01rem;
          font-size: 0.28rem;
          color: #000;
        }
        .car-info {
          width: 100%;
          font-size: 0.26rem;
          color: #666;
        }
      }
    }
    .button-wrap {
      margin-top: 0.9rem;
      text-align: center;
      .button-item {
        /*box-shadow: 0 0.02rem 0.11rem 0 hsla(0,0%,87%,.5);*/
        background: #999999;
        border-radius: .04rem;
        width: 6.9rem;
        height: .9rem;
        font-size: .32rem;
        color: #fff;
        outline: none;
        border: none;
        &.active {
          background-color: #fd9244;
        }
      }
    }
  }

  .selected-wrap {
    position: fixed;
    bottom: -100%;
    left: 0;
    z-index: 100;
    width: 100%;
    max-height: 4.65rem;
    overflow: auto;
    background: #fff;
    font-size: 0.3rem;
    line-height: 0.93rem;
    text-align: center;
    transition: all 0.5s;
    &.showWrap {
      bottom: 0;
    }
    .selected-item {
      height: 0.93rem;
      box-sizing: border-box;
      padding: 0 10%;
      &.active {
        color: @theme-color;
      }
    }
  }

  .selected-mask {
    position: fixed;
    z-index: 99;
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    background: rgba(0, 0, 0, .6);
  }
</style>
