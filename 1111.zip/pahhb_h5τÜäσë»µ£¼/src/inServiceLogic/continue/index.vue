<template>
  <section>
    <pts-header title-text="续保列表" flagName="continue" leftFlag @on-left="goMenu" show-right>
      <div class="textBanner" slot="center">
        <pts-text-scroll @input="changModel"></pts-text-scroll>
      </div>
      <router-link to="/inside/continueSearch" href="javascript:;" slot="right" class="nav-search-icon"></router-link>
    </pts-header>
    <pts-Tab :titleList="tabTitle" v-model="index" ref="tabVue" @on-child-change="tabChildChange"
             @on-change="tabMaiDian">
      <pts-tab-item>
        <!-- 应续 -->
        <pts-list :active="index===0" flagName="0" :modelCode="code" :tabName="tabName"></pts-list>
      </pts-tab-item>
      <pts-tab-item>
        <!-- 未续 -->
        <pts-list :active="index===1" :tabChildFlag="tabChildFlag" flagName="1" :modelCode="code" :tabName="tabName"></pts-list>
      </pts-tab-item>
      <pts-tab-item>
        <!-- 脱保 -->
        <pts-list :active="index===2" flagName="2" :modelCode="code" :tabName="tabName"></pts-list>
      </pts-tab-item>
      <pts-tab-item>
        <!-- 已续 -->
        <pts-list :active="index===3" flagName="3" :modelCode="code" :tabName="tabName"></pts-list>
      </pts-tab-item>
    </pts-Tab>
  </section>
</template>

<script>
  import ptsTab from '../../common/comComponent/tab'
  import ptsTextScroll from '../../common/comComponent/textScroll';

  export default {
    name: "continue-index",
    data () {
      return {
        tabTitle: [
          {
            title: '应续'
          },
          {
            title: '未续',
            childs: [
              {title: '未续', flag: '1'},
              {title: '当月应续', flag: '4'},
              {title: '下月应续', flag: '5'}
            ]
          },
          {title: '脱保'},
          {title: '已续'}
        ],
        index: 0,
        tabChildFlag: '',
        code: '',
        branchName: '',
        dealerIcon: require('../../common/images/allCarIcon.png'),
        tabName: ''
      }
    },
    methods: {
      tabChildChange (item) {
        this.tabChildFlag = item.flag
      },
      /*
       * @info 返回app主页
       * */
      goMenu () {
        //回到Native主页
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      /*
      *
      * */
      tabMaiDian (item) {
        this.tabName = item.title;
        window.eventAnalytics('队伍端_续保查询', '续保状态-' + item.title);
      },
      changModel (code) {
        this.code = code;
        window.eventAnalytics('队伍端_续保查询', '网点选择');
        // console.log(code);
      },
      /* 跳转搜索页面 */
      goSearch () {
        this.$router.push({path: '/inside/continueSearch'})
      }
    },
    created () {
      this.index = ~~this.$route.query.status;
    },
    mounted () {
      this.tabName = this.tabTitle[this.index].title;
      window.eventAnalytics('队伍端_续保查询', '续保状态-' + this.tabTitle[this.index].title);
    },
    components: {
      ptsTab,
      ptsTabItem: ptsTab.Item,
      ptsList: resolve => require.ensure([], () => resolve(require('./templates/list.vue')), 'InsideSearchComtinueList'),
      ptsTextScroll
    }
  }
</script>

<style scoped lang="less">

</style>
