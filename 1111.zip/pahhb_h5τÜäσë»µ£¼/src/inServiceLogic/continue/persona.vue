<template>
  <section class="box bg_fff">
    <pts-header title-text="用户属性"></pts-header>
    <div class="wrap insideXubaoWrap">
      <!-- main start -->
      <div class="mainWrap" style="position: relative">
        <div class="scoreArea c">
          <div class="scoreAreaLeft">
            <div class="chartBox"><img :src="imgFiveStart" alt=""></div>
            <p class="txtT">{{userMsg.renewalFlagTop1}}</p>
            <p class="txtLM">{{userMsg.renewalFlagTop2}}</p>
            <p class="txtRM">{{userMsg.renewalFlagTop3}}</p>
            <p class="txtLD">{{userMsg.renewalFlagTop4}}</p>
            <p class="txtRD">{{userMsg.renewalFlagTop5}}</p>
          </div>
          <div class="scoreAreaRight">
            <p class="scoreNum">{{userMsg.renewalRate * 10}}分</p>
            <p>续保意愿较高</p>
          </div>
        </div>
        <ul class="userPropertyArea c">
          <li v-for="(item, index) in title" @click="goIndex(index)">
            <a href="javascript:;" otype="button" :otitle="item"
               :class="{'cur': index === activeIndex}">{{item}}</a>
          </li>
        </ul>
        <div class="scrollPropWrap" ref="swiperWrap">
          <ul class="scrollPropArea c" ref="swiperBox" style="left: 0;">
            <li>
              <dl>
                <dt>连续投保年数:</dt>
                <dd>{{userMsg.insureYear}}</dd>
              </dl>
              <dl>
                <dt>购买险种类型:</dt>
                <dd>{{userMsg.policyType}}</dd>
              </dl>
              <dl class="speWidth">
                <dt>是否投保车损险:</dt>
                <dd>{{userMsg.vehicleDamageInsurance}}</dd>
              </dl>
            </li>
            <li>
              <dl>
                <dt>是否贷款车:</dt>
                <dd>{{userMsg.vehicleFlag}}</dd>
              </dl>
              <dl>
                <dt>投保人年龄:</dt>
                <dd>{{userMsg.insurerAge}}</dd>
              </dl>
              <dl class="speWidth">
                <dt>上年提前投保天数:</dt>
                <dd>{{userMsg.aheadTime}}</dd>
              </dl>
              <dl>
                <dt>投保人性别:</dt>
                <dd>{{userMsg.gender}}</dd>
              </dl>
            </li>
            <li>
              <dl>
                <dt>案件类型:</dt>
                <dd>{{userMsg.caseType}}</dd>
              </dl>
              <dl>
                <dt>是否4S店修理:</dt>
                <dd>{{userMsg.repairSite}}</dd>
              </dl>
              <dl class="speWidth">
                <dt>平台返回NCD系数:</dt>
                <dd>{{userMsg.ncd}}</dd>
              </dl>
              <dl>
                <dt>当年出险次数:</dt>
                <dd>{{userMsg.accidentNum}}</dd>
              </dl>
              <dl>
                <dt>结案时长:</dt>
                <dd>{{userMsg.endCaseTime}}</dd>
              </dl>
              <dl>
                <dt>总赔款区间:</dt>
                <dd>{{userMsg.indemnityInterval}}</dd>
              </dl>
            </li>
            <li>
              <dl>
                <dt>新车购置价:</dt>
                <dd>{{userMsg.newCarValue}}</dd>
              </dl>
              <dl>
                <dt>车龄:</dt>
                <dd>{{userMsg.carAge}}</dd>
              </dl>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- main end -->
  </section>

</template>

<script>
  // -70%
  import PtsSwiper from '../../common/js/ptsSwiper';

  export default {
    name: "persona",
    data () {
      return {
        userMsg: {},
        imgFiveStart: require('../../common/images/img_score.jpg'),
        ptsSwiper: null,
        title: ['保单属性', '客户属性', '理赔属性', '车辆属性'],
        activeIndex: 0
      }
    },
    methods: {
      getData () {
        this.userMsg = this.$route.query;
      },
      goIndex (index) {
        // this.activeIndex = index;
        this.ptsSwiper.goPage(index);
      }
    },
    activated () {
      this.getData();
      let _this = this;
      this.ptsSwiper = new PtsSwiper({
        box: this.$refs.swiperWrap,
        ul: this.$refs.swiperBox,
        liWidth: false,
        callback: function (index) {
          _this.activeIndex = index;
        }
      });
    }
  }
</script>

<style scoped lang="less">
  .insideXubaoWrap .scoreArea{
    height: 3.9rem;
  }
  .userPropertyArea{
    top: 3.2rem;
  }
</style>
