<template>
  <section class="box">
    <pts-header title-text="续保模式确认" leftFlag @on-left="goMenu"></pts-header>
    <pts-drop-ajax ref="dropAjax" :bottom-ajax="bottomAjax" @on-bottom-ajax="getNextPage" v-if="dataList.length">
      <pts-confirm-model @on-comfirmModel="approve" v-for="(item,index) in dataList" :key="index"
                         :datas="item"></pts-confirm-model>
    </pts-drop-ajax>
    <div class="data-null" v-else></div>
  </section>
</template>

<script>
  import ptsConfirmModel from './templates/confirmModel';
  import ptsDropAjax from '../../common/comComponent/scrollAjax';
  import axios from '../../common/js/axiosConfig';
  import url from '../../common/js/comConfig';
  import toast from '../../common/comComponent/toast';

  export default {
    name: "approve-model",
    data () {
      return {
        page: 1,
        dataList: [],
        bottomAjax: false
      }
    },
    components: {
      ptsConfirmModel,
      ptsDropAjax
    },
    methods: {
      /*
       * @info 返回app主页
       * */
      goMenu () {
        //回到Native主页
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      /* 确认修改 */
      approve (flag, auditNumber) {
        let title = `是否确定${flag ? '' : '不'}同意更改该网点的续保模式？`;
        this.$vux.confirm.show({
          content: title,
          confirmText: '提交',
          cancelText: '取消',
          onConfirm: () => {
            axios.post(url.getWebServiceUrls('approveRenewalMode'), {
              "auditNumber": auditNumber,
              "auditStatus": flag ? '1' : '2'
            })
              .then(res => {
                res = res.data;
                if (res.code !== 0) {
                  toast(res.msg);
                  return;
                }
                toast('审核成功');
                this.getData(true);
              }).catch(e => {
              console.log(e);
            })
          }
        })
      },
      /* 获取数据 */
      getData (flag) {
        let _this = this;
        if (flag) {
          this.dataList = [];
        }
        axios.post(url.getWebServiceUrls('getApproveList'), {
          "limit": 10,
          "pageNo": _this.page
        }).then(res => {
          res = res.data;
          if (res.code !== 0) {
            toast(res.msg);
            return;
          }
          res.data.forEach(v => {
            _this.dataList.push(v);
          });
          _this.bottomAjax = true;
          if (res.pageNo * res.pageSize > res.totalCount) {
            _this.bottomAjax = false;
          }
          _this.$nextTick(function () {
            _this.$refs.dropAjax && _this.$refs.dropAjax.reset(flag);
          });
        }).catch(e => {
          console.log(e);
        })
      },
      getNextPage () {
        this.page++;
        this.getData();
      }
    },
    mounted () {
      this.getData(true);
    }
  }
</script>

<style scoped lang="less">

</style>
