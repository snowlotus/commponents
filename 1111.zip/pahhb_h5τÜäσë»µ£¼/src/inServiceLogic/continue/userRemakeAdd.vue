<template>
  <section class="box insidehuibuWrap">
    <pts-header title-text="客户信息回补" leftFlag @on-left="goMenu"></pts-header>
    <pts-drop-ajax ref="dropAjax" :bottom-ajax="bottomAjax" @on-bottom-ajax="getNextData">
      <div class="taskArea mb20" v-for="(item, index) in dataList" :keys="index">
        <div class="taskBox pts-b-b" :class="{'taskBoxed': item.coverStatus !=='0'}">
          <dl>
            <dt>被保人</dt>
            <dd>{{item.insuredName}}</dd>
          </dl>
          <dl>
            <dt>车牌号</dt>
            <dd>{{item.carMark}}</dd>
          </dl>
          <dl>
            <dt>车架号</dt>
            <dd>{{item.carRackNo}}</dd>
          </dl>
          <dl>
            <dt>车龄</dt>
            <dd>{{item.carAge}}年</dd>
          </dl>
          <dl>
            <dt>联系方式</dt>
            <dd class="clientTel" v-if="item.phoneNo">{{item.phoneNo | justShowOne | thereSpace}}<a href="javascript:;" otype="button" otitle="查看更多"
                                                                   class="lookSome"
                                                                   @click="openContact(index)" v-if="item.phoneNo">查看更多&gt;</a>
            </dd>
          </dl>
        </div>
        <div class="anaplerosisBox c clear" :class="{'expiredBox': item.coverStatus !=='0'}">
          <dl>
            <dt v-if="item.coverStatus === '1'" style="color:#FE883A;"><a href="javascript:;" otype="button"
                                                                          otitle="回补记录" class="takenBtn"
                                                                          @click="getHistory(index)">回补记录</a>
            </dt>
            <dd>
              <a href="javascript:;" otype="button" otitle="放弃" class="leftBtn fl" @click="onCancel(index)">放弃</a>
              <a href="javascript:;" otype="button" otitle="回补" class="rightBtn fr" @click="onConfirm(index)">回补</a>
            </dd>
          </dl>
        </div>
      </div>
    </pts-drop-ajax>

    <!-- 添加手机号 -->
    <pts-alert v-model="showAddNum">
      <div class="popTelNum popTelNumTwo">
        <ul class="popTelNumList">
          <li><p>联系方式</p>
            <div class="por pts-b-b">
              <input type="tel" style="width: 100%;" v-model="phoneNum"
                     placeholder="请输入手机号"/> <!--或带区号的座机号-->
            </div>
          </li>
        </ul>
        <p class="c">
          <a href="javascript:;" class="pts-b-tr" otype="button" otitle="取消" @click="offAddNum">取消</a>
          <a href="javascript:;" class="pts-b-t" otitle="提交" @click="submitNum">提交</a>
        </p>
      </div>
    </pts-alert>
    <!-- 回补记录 -->
    <pts-alert v-model="showHistory">
      <div class="popRecDet">
        <img :src="offIconImg" @click="showHistory = false" alt="关闭"/>
        <p class="popRecDettitle pts-b-b">回补记录</p>
        <div class="popRecDetCon pts-b-b">
          <div class="popRecDetConBox" v-for="(item,index) in historyList" :keys="index">
            <dl class="c">
              <dt>回补时间</dt>
              <dd>{{item.coverTime}}</dd>
            </dl>
            <dl class="c">
              <dt>联系方式</dt>
              <dd><span>{{item.phoneNo | thereSpace}}</span></dd>
            </dl>
            <dl class="c">
              <dt>验真状态</dt>
              <dd class="fc2AB" v-if="item.code == 0">正确</dd>
              <dd class="fcFE3" v-else>不正确</dd>
            </dl>
          </div>
        </div>
        <!--<div class="popRecDetCon">
          <div class="popRecDetConBox">
            <dl class="c">
              <dt>回补时间</dt>
              <dd>2018-02-06 10:45:45</dd>
            </dl>
            <dl class="c">
              <dt>联系方式</dt>
              <dd><span>152 7441 8899</span></dd>
            </dl>
            <dl class="c">
              <dt>验真状态</dt>
              <dd class="fc2AB">正确</dd>
            </dl>
          </div>
        </div>-->
      </div>
    </pts-alert>
    <!-- 联系方式 -->
    <pts-alert v-model="showContactList">
      <div class="popRecDet">
        <img :src="offIconImg" @click="showContactList = false" alt="关闭"/>
        <p class="popRecDettitle pts-b-b">联系方式</p>
        <div class="contactWrap">
          <div class="contactItem pts-b-b" v-for="item in contactList">{{item | thereSpace}}</div>
        </div>
      </div>
    </pts-alert>
  </section>
</template>

<script>
  import ptsAlert from '../../common/comComponent/alertWindow';
  import validate from '../../common/js/comValidate';
  import ptsDropAjax from '../../common/comComponent/scrollAjax';
  import axios from '../../common/js/axiosConfig';
  import url from '../../common/js/comConfig';
  import toast from '../../common/comComponent/toast';
  import '../../common/filters/convertAmount'

  export default {
    name: "user-remake-add",
    data () {
      return {
        dataList: [], // 列表的数据
        offIconImg: require('../../common/images/icon_closeClaim.png'),
        showAddNum: false, // 显示添加手机号弹窗
        phoneNum: '', // 用户输入的电话号的值
        showHistory: false, // 显示回补记录
        showContactList: false, // 显示联系方式列表
        contactList: [], // 联系方式列表
        page: 1,
        bottomAjax: false,
        activeIndex: '',
        historyList: []
      }
    },
    methods: {
      /*
       * @info 返回app主页
       * */
      goMenu () {
        //回到Native主页
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      // 关闭添加电话号弹窗
      offAddNum () {
        window.eventAnalytics('队伍端_客户信息回补', '回补-取消');
        this.showAddNum = false;
        this.phoneNum = '';
      },
      // 提交电话号
      submitNum () {
        let item = this.dataList[this.activeIndex];
        let isValidate = this.validatePhoneNum();
        if (!isValidate) return;
        window.eventAnalytics('队伍端_客户信息回补', '回补-提交');
        let _this = this;
        axios.post(url.getWebServiceUrls('setConvering'), {
          "coverInfo": {
            "phoneNo": this.phoneNum + ''
          },
          "processType": "01",
          "reaewalCoverInfoId": item.reaewalCoverInfoId
        }).then(res => {
          res = res.data;
          if (res.code !== 0) {
            toast(res.msg);
          } else {
            item.coverStatus = '1';
            _this.offAddNum();
          }
        }).catch(e => {
          console.log(e);
        })
      },
      /* 校验手机号或固定电话号 */
      validatePhoneNum () {
        let value = this.phoneNum + ''.trim();
        if (!value) {
          toast('请输入手机号'); // 或带区号的座机号
          return false;
        }
        let msg1 = validate.checkMobile(value); //value.charAt(0) === '1' ? validate.checkMobile(value) : validate.checkFixedPhone(value);
        if (typeof msg1 !== 'boolean') {
          toast(msg1);
          return false;
        } else {
          return msg1;
        }
      },
      /* 获取列表数据 */
      getData (flag) {
        let _this = this;
        axios.post(url.getWebServiceUrls('getqueryConvering'), {
          "perPageSize": 10,
          "currentPage": _this.page
        })
          .then(res => {
            res = res.data;
            if (res.code !== 0) {
              toast(res.msg);
              return;
            }
            res.data.forEach(v => {
              _this.dataList.push(v);
            });
            if (flag) {
              _this.bottomAjax = true;
            }
            if (res.pageNo * res.pageSize > res.totalCount) {
              _this.bottomAjax = false;
            }
            _this.$nextTick(function () {
              _this.$refs.dropAjax && _this.$refs.dropAjax.reset(flag);
            })
          }).catch(e => {
          console.log(e);
        })
      },
      /* 放弃回补 */
      onCancel (index) {
        let item = this.dataList[index];
        if (item.coverStatus !== '0') return;
        this.$vux.confirm.show({
          content: `是否确定放弃回补?`,
          confirmText: '确定',
          cancelText: '取消',
          onConfirm: () => {
            window.eventAnalytics('队伍端_客户信息回补', '放弃');
            axios.post(url.getWebServiceUrls('setConvering'), {
              "processType": "02",
              "reaewalCoverInfoId": item.reaewalCoverInfoId
            }).then(res => {
              res = res.data;
              if (res.code !== 0) {
                toast(res.msg);
                return;
              }
              item.coverStatus = '2'
            }).catch(e => {
              console.log(e);
            })
          }
        })
      },
      /* 点击回补按钮触发 */
      onConfirm (index) {
        window.eventAnalytics('队伍端_客户信息回补', '回补');
        let item = this.dataList[index];
        if (item.coverStatus !== '0') return;
        this.showAddNum = true;
        this.activeIndex = index
      },
      /* 显示联系方式 */
      openContact (index) {
        this.contactList = JSON.parse(this.dataList[index].phoneNo);
        this.showContactList = true;
      },
      /* 获取下一页的数据 */
      getNextData () {
        this.page++;
        this.getData();
      },
      /* 显示接触历史  */
      getHistory (index) {
        window.eventAnalytics('队伍端_客户信息回补', '回补记录');
        let item = this.dataList[index], _this = this;
        axios.post(url.getWebServiceUrls('setConvering'), {
          processType: '03',
          reaewalCoverInfoId: item.reaewalCoverInfoId
        })
          .then(res => {
            console.log(res);
            res = res.data;
            if (res.code !== 0) {
              toast(res.msg);
              return;
            }
            _this.historyList = res.data.coverRecord;
            this.showHistory = true;
          }).catch(e => {
          console.log(e);
        });
      }
    },
    components: {
      ptsAlert,
      ptsDropAjax
    },
    mounted () {
      this.getData(true);
      window.eventAnalytics('队伍端_客户信息回补', '列表');
    },
    filters: {
      justShowOne (v) {
        if (!v) return v;
        return JSON.parse(v)[0];
      }
    }
  }
</script>

<style scoped lang="less">
  @import "./templates/style";
</style>
