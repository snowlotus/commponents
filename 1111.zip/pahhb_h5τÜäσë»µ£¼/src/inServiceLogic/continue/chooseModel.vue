<template>
  <section class="box">
    <pts-header title-text="续保模式更改" leftFlag @on-left="goMenu"></pts-header>
    <pts-choose-model v-if="list.length" v-for="(item,index) in list" :index="index" :data="item" :key="item.dealerCode"
                      @on-chooseModel="clickEven"></pts-choose-model>
    <div class="data-null" v-else></div>
    <popup-picker style="display: none" v-model="ModelCode" :data="pickerData" :show.sync="showPicker" :show-cell="!1"
                  @on-hide="change"></popup-picker>
  </section>
</template>

<script>
  import Vue from 'vue';
  import ptsChooseModel from './templates/chooseModel';
  import axios from '../../common/js/axiosConfig';
  import url from '../../common/js/comConfig';
  import toast from '../../common/comComponent/toast';
  import {PopupPicker, AlertPlugin} from 'vux'

  Vue.use(AlertPlugin);
  export default {
    name: "choose-model",
    data () {
      return {
        list: [],
        ModelCode: [],
        pickerData: [[
          {
            name: '自续',
            value: '0',
            parent: 0
          },
          {
            name: '协续',
            value: '1',
            parent: 0
          },
          {
            name: '转新',
            value: '2',
            parent: 0
          }
        ]],
        showPicker: false,
        beLeft: 0, // 剩余多少次数
        activeIndex: -1, // 用户选中的item的索引
        isQuDao: false //'是否是渠道管路员'
      }
    },
    components: {
      ptsChooseModel,
      PopupPicker
    },
    methods: {
      /*
       * @info 返回app主页
       * */
      goMenu () {
        //回到Native主页
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      // 获取列表数据
      getData () {
        let _this = this;
        /*_this.list = [
          {
            dealerName: '测试数据',
            renewalMode: '1',
            dealerCode: 111
          }
        ];*/
        axios.post(url.getWebServiceUrls('getDealerInfoList'))
          .then(res => {
            res = res.data;
            if (res.code !== 0) {
              toast(res.msg);
              return;
            }
            _this.isQuDao = res.data.isChannelManager;
            _this.list = res.data.dealerRenewalModeList;
          }).catch(e => {
          console.log(e);
        })
      },
      // 子组件触发点击事件
      clickEven (index) {
        let _this = this;
        if (this.isQuDao) {
          _this.showPicker = true;
          _this.activeIndex = index;
          _this.ModelCode = [_this.list[index].renewalMode]
        } else {
          axios.post(url.getWebServiceUrls('getInitiateCount'), {
            dealerCode: this.list[index].dealerCode
          }).then(res => {
            res = res.data;
            if (res.code !== 0) {
              toast(res.msg);
              return;
            }
            this.$vux.alert.show({
              content: `每月只能修改3次，还剩${res.data}次机会`,
              onHide: () => {
                if (res.data > 0) {
                  _this.beLeft = res.data;
                  _this.showPicker = true;
                  _this.activeIndex = index;
                  _this.ModelCode = [_this.list[index].renewalMode]
                }
              }
            });
          }).catch(e => {
            console.log(e);
          })
        }

      },
      change (item) {
        let data = this.list[this.activeIndex], _this = this;
        if (!item || this.ModelCode[0] === data.renewalMode) return;
        let content = '', msg = '';
        if (this.isQuDao) {
          content = `是否确定更改该网点的续保模式?`
          msg = '已修改成功';
        } else {
          content = `是否确定更改该网点的续保模式?还剩${this.beLeft}次机会`;
          msg = '申请已提交成功';
        }
        this.$vux.confirm.show({
          content: content,
          confirmText: '确定',
          cancelText: '取消',
          onConfirm: () => {
            axios.post(url.getWebServiceUrls('setRenewalModel'), {
              "dealerCode": data.dealerCode,
              "dealerName": data.dealerName,
              "renewalMode": this.ModelCode[0]
            }).then(res => {
              res = res.data;
              if (res.code !== 0) {
                toast(res.msg);
                return;
              }
              toast(msg);
              if (_this.isQuDao) {
                data.renewalMode = this.ModelCode[0];
              }
            }).catch(e => {
              console.log(e);
            })
          }
        })
      }
    },
    mounted () {
      this.getData();
    }
  }
</script>

<style scoped lang="less">

</style>
