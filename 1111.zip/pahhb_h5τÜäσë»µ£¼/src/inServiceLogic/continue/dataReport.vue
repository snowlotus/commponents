<template>
  <section class="box">
    <pts-header title-text="续保分析" leftFlag @on-left="goMenu" :show-right="!innerAccountRoleType">
      <div class="textBanner" slot="center" v-if="innerAccountRoleType">
        <pts-text-scroll v-model="dealerCode"></pts-text-scroll>
      </div>
      <router-link to="/inside/selectOrganization" slot="right" class="nav-go-choose-model">
        <span class="nav-text text-hidden">{{dealerName}}</span>
        <span class="arrow"></span>
      </router-link>
    </pts-header>
    <div class="mainWrap insideXubaoWrap pos-rel">
      <ul class="taskTitleArea c columnThree date-tab">
        <li class="pts-b-b" :class="{'cur': activeTab === 'A'}" @click="changeTab('A')"><em>当日</em></li>
        <li class="moreOption pts-b-b" :class="{'cur': activeTab === 'B'}" @click="changeTab('B')">
          <em>{{monthValue | chineseMonth}}月<a href="javascript:;" :class="{'arrowUp': showDateTime}" otype="button"
                                               otitle="展开"
                                               class="openSlect">展开</a></em>
        </li>
        <li class="pts-b-b" :class="{'cur': activeTab === 'C'}" @click="changeTab('C')"><em>当年</em></li>
      </ul>
      <!-- 日 开始 -->
      <section v-if="activeTab === 'A'" style="margin-top: -3px;">
        <div class="dataArea pt20 mb20">
          <p class="timeTxt">{{systemTime}}</p>
          <div class="chartBox mb15">
            <pts-pie :options="continuPie" ref="dayContinuPie"></pts-pie>
          </div>
          <div class="chartDataBox">
            <dl class="f_c_green">
              <dt>已续</dt>
              <dd>{{continuData.totalRenewalFinish}}</dd>
            </dl>
            <dl class="f_c_yellow">
              <dt>脱保</dt>
              <dd>{{continuData.totalRenewalOff}}</dd>
            </dl>
            <!--<dl class="f_c_blue">
              <dt>未续</dt>
              <dd>{{continuData.totalRenewalUnfinish}}</dd>
            </dl>-->
          </div>
        </div>

        <div class="dataArea dataSpeArea mb20" v-if="isShowCon">
          <dl class="mb25">
            <dt>联系分析<em>（仅支持协续模式）</em></dt>
          </dl>
          <div class="chartBox mb45">
            <div class="chartBoxImg" style="padding:0;">
              <pts-pie :options="ConPie" ref="dayConPie"></pts-pie>
            </div>
            <ul class="chartBoxTxt">
              <li class="f_c_green">拨打</li>
              <li class="f_c_yellow">接通</li>
              <li class="f_c_blue">成功</li>
            </ul>
          </div>
          <div class="probArea">
            <dl>
              <dt>拨打率</dt>
              <dd>{{conData.alreadyCallNumRatio}}</dd>
            </dl>
            <dl>
              <dt>接通率</dt>
              <dd>{{conData.alreadyConnectNumRatio}}</dd>
            </dl>
            <dl>
              <dt>成功率</dt>
              <dd>{{conData.alreadyXbNumRatio}}</dd>
            </dl>
          </div>
        </div>
      </section>
      <!-- 日 结束 -->
      <!-- 月/年 开始 -->
      <section v-if="activeTab !== 'A'" style="margin-top: -3px; border-top:1px solid #fff;">
        <div class="month-year-title bg_fff pt20" v-if="isShowCon">
          <ul class="analyBtnArea">
            <li :class="{'cur': isContinu}" @click="changeContinu(1)">续保分析</li>
            <li :class="{'cur': !isContinu}" @click="changeContinu(0)">联系分析</li>
          </ul>
        </div>
        <!-- 续保分析 开始 -->
        <section v-if="isContinu">
          <div class="dataArea dataSpeArea pt20 mb20">
            <p class="timeTxt">{{systemTime}}</p>
            <div class="chartBox mb15">
              <pts-pie :options="continuPie" ref="monthContinuPie" v-if="isContinu"></pts-pie>
            </div>
            <div class="chartDataBox">
              <dl class="f_c_green">
                <dt>已续</dt>
                <dd>{{continuData.totalRenewalFinish}}</dd>
              </dl>
              <dl class="f_c_yellow">
                <dt>脱保</dt>
                <dd>{{continuData.totalRenewalOff}}</dd>
              </dl>
              <dl class="f_c_blue">
                <dt>未续</dt>
                <dd>{{continuData.totalRenewalUnfinish}}</dd>
              </dl>
            </div>
          </div>

          <div class="dataArea dataSpeArea mb20">
            <dl class="mb10">
              <dt>续保数据走势</dt>
            </dl>
            <div class="chartBox pb20">
              <pts-line :options="continuLine" ref="monthContinuLine" v-if="isContinu"></pts-line>
            </div>
          </div>
        </section>
        <!-- 续保分析 结束 -->

        <!-- 联系分析 开始 -->
        <section v-else>
          <div class="dataArea dataSpeArea pt20 mb20">
            <p class="timeTxt">{{systemTime}}</p>
            <div class="chartBox mb45">
              <div class="chartBoxImg" style="padding:0;">
                <pts-pie :options="ConPie" ref="monthConPie" v-if="!isContinu"></pts-pie>
              </div>
              <ul class="chartBoxTxt">
                <li class="f_c_green">拨打</li>
                <li class="f_c_yellow">接通</li>
                <li class="f_c_blue">成功</li>
              </ul>
            </div>

            <div class="probArea">
              <dl>
                <dt>拨打率</dt>
                <dd>{{conData.alreadyCallNumRatio}}</dd>
              </dl>
              <dl>
                <dt>接通率</dt>
                <dd>{{conData.alreadyConnectNumRatio}}</dd>
              </dl>
              <dl>
                <dt>成功率</dt>
                <dd>{{conData.alreadyXbNumRatio}}</dd>
              </dl>
            </div>
          </div>

          <div class="dataArea dataSpeArea mb20">
            <dl class="mb10">
              <dt>联系走势</dt>
            </dl>
            <div class="chartBox">
              <pts-line :options="conLine" ref="monthConLine" v-if="!isContinu"></pts-line>
            </div>
          </div>
        </section>
        <!-- 联系分析 结束 -->
      </section>
      <!-- 月/年 结束 -->
    </div>
  </section>
</template>

<script>
  import ptsLine from '../../common/comComponent/echarts/line';
  import ptsPie from '../../common/comComponent/echarts/pie';
  import ptsTextScroll from '../../common/comComponent/textScroll';
  import {loadEcharts, remInPx, numberShowType} from '../../common/js/comUtils';
  import axios from '../../common/js/axiosConfig';
  import toast from '../../common/comComponent/toast';
  import url from '../../common/js/comConfig';
  import '../../common/filters/convertDate';
  import '../../common/filters/convertAmount';

  export default {
    name: 'insideContinueDataReport',
    data () {
      return {
        monthValue: -1,
        systemTime: '2018-03-06 59:00:00',
        continuPie: {
          title: [
            {
              text: '总保单(单)',
              textStyle: {
                fontSize: remInPx(0.26),
                fontWeight: 'normal',
                color: '#666666'
              },
              top: '35%',
              left: 'center'
            },
            {
              text: '0',
              textStyle: {
                fontSize: remInPx(0.6),
                fontWeight: 'normal',
                color: '#333'
              },
              top: '45%',
              left: 'center'
            },
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.26),
                fontWeight: 'normal',
                color: 'red'
              },
              top: '67%',
              left: 'center'
            }
          ],
          color: ['#60D194', '#FFDB4B', '#559EFF'],
          series: [
            {
              name: '其实没什么用',
              type: 'pie',
              radius: ['75%', '90%'],
              legendHoverLink: false,
              label: {
                normal: {
                  show: false
                },
                emphasis: {
                  show: false
                }
              },
              labelLine: {
                normal: {
                  show: false
                },
                emphasis: {
                  show: false
                }
              },
              hoverAnimation: false,
              data: [0, 0]
            }
          ]
        }, // 续保饼状图
        ConPie: {
          title: [
            {
              text: '拨打标的(单)',
              textStyle: {
                fontSize: remInPx(0.26),
                fontWeight: 'normal',
                color: '#666666'
              },
              top: '35%',
              left: 'center'
            },
            {
              text: '0',
              textStyle: {
                fontSize: remInPx(0.6),
                fontWeight: 'normal',
                color: '#333'
              },
              top: '45%',
              left: 'center'
            }
          ],
          color: ['#60D194', '#FFDB4B', '#559EFF'],
          legend: {
            show: false
          },
          series: [
            {
              name: '其实没什么用',
              type: 'pie',
              radius: ['65%', '80%'],
              legendHoverLink: false,
              label: {
                formatter: '{c}'
              },
              labelLine: {
                length: 5,
                length2: 10
              },
              hoverAnimation: false,
              data: [
                {
                  value: 0,
                  name: '拨打'
                },
                {
                  value: 0,
                  name: '接通'
                },
                {
                  value: 0,
                  name: '成功'
                }
              ]
            }
          ]
        }, // 联系分析饼状图
        continuLine: {
          legend: {
            data: ['已续', '脱续'] //, '未续'
          },
          xAxis: {
            data: []
          },
          color: ['#60D194', '#FFDB4B'], // , '#559EFF'
          series: [
            {
              name: '已续',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [0]
            },
            {
              name: '脱续',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [0]
            }
          ]
        },
        conLine: {
          legend: {
            data: ['已拨标的', '接通标的', '成功标的'] //, '未续'
          },
          xAxis: {
            data: []
          },
          color: ['#60D194', '#FFDB4B', '#559EFF'], // ,
          series: [
            {
              name: '已拨标的',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [0]
            },
            {
              name: '接通标的',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [0]
            },
            {
              name: '成功标的',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [0]
            }
          ]
        },
        activeTab: 'A',
        isContinu: true, // 是否是续保分析
        activeMonth: '',
        dealerCode: '',
        dealerName: '',
        continuData: {
          totalRenewalFinish: 0, // 已续
          totalRenewalOff: 0, // 脱续
          totalRenewalUnfinish: 0 // 未续
        },
        conData: {
          alreadyCallNumRatio: '0%', // 已拨打率
          alreadyConnectNumRatio: '0%', // 接通率
          alreadyXbNumRatio: '0%' // 成功率
        },
        innerAccountRoleType: window.dealerData.innerAccountRoleType === '1',
        isShowCon: false, // 显示联系分析
        showDateTime: false
      }
    },
    methods: {
      /*
       * @info 返回app主页
       * */
      goMenu () {
        //回到Native主页
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      /* 日月年切换tab
       * type A 日, B 月, C 年
       * */
      changeTab (type) {
        if ((type === 'A' || type === 'C') && this.activeTab === type) {
          return
        }
        const date = new Date();
        const year = date.getFullYear();
        let startDate = new Date();
        startDate.setMonth(date.getMonth() - 10);
        if (type === 'B') {
          if (this.activeTab === type) {
            this.$vux.datetime.show({
              value: this.activeMonth,
              cancelText: '取消',
              confirmText: '确定',
              format: 'YYYY-MM',
              minYear: year,
              maxYear: year,
              startDate: `${startDate.getFullYear()}-${startDate.getMonth() > 10 ? '0' + startDate.getMonth() : startDate.getMonth()}-01`,
              endDate: `${year}-${(date.getMonth() + 1) > 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1)}-01`,
              onConfirm: (v) => {
                if (this.activeMonth === v) return;
                this.activeMonth = v;
                this.monthValue = v.substr(v.indexOf('-') + 1);
                this.$nextTick(function () {
                  this.getData('B', v);
                })
              },
              onShow: () => {
                this.showDateTime = true;
              },
              onHide: () => {
                this.showDateTime = false;
              },
            })
          } else {
            this.$nextTick(function () {
              this.getData('B', this.activeMonth);
            });
          }
        } else {
          this.$nextTick(function () {
            this.getData(type);
          });
        }
        this.activeTab = type;
      },
      /* 联系分析与续保分析切换
       * 月/年下 联系分析与续保分析
        * */
      changeContinu (type) {
        this.isContinu = type;
        this.getData(this.activeTab, this.activeMonth);
      },
      /* 向后台请求数据
       * type A 日, B 月, C 年
       * month 月份 类似 2018-03
       *  */
      getData (type, month) {
        let text = this.isContinu ? '续保分析' : '联系分析';
        switch (type) {
          case 'A':
            window.eventAnalytics('队伍端_续保分析', '日报');
            break;
          case 'B':
            window.eventAnalytics('队伍端_续保分析', '月报-' + text);
            break;
          case 'C':
            window.eventAnalytics('队伍端_续保分析', '年报-' + text);
            break;
        }
        /*if (type === 'A') {
          this.getContinData('A');
          this.getConData('A');
          this.initEcharts();
          return;
        }
        if (this.isContinu) {
          this.getContinData(type, month);
        } else {
          this.getConData(type, month);
        }*/
        this.getContinData(type, month);
        // 只有前线角色才会看到联系分析
        Number(window.dealerData.innerAccountRoleType) === 1 && this.getConData(type, month);
        this.initEcharts();
      },
      /* 请求续保报表数据
       * type A 日, B 月, C 年
       *  month 月份 类似 2018-03
       * */
      getContinData (type, month) {
        let _this = this;
        axios.post(url.getWebServiceUrls('getInsideContinue'), {
          "dealerCode": this.dealerCode || '',
          "queryNum": month || undefined,
          "queryType": type
        })
        /*axios.post('http://localhost:8888/postGetData', {
          file: 'xubaodata',
          path: 'xubao'
        })*/
          .then(res => {
            res = res.data;
            if (res.code !== 0) {
              toast(res.msg);
              return;
            }
            let data = res.data;
            _this.systemTime = res.data.sysTime;
            _this.continuData = {
              totalRenewalFinish: data.totalRenewalFinish, // 已续
              totalRenewalOff: data.totalRenewalOff, // 脱续
              totalRenewalUnfinish: data.totalRenewalUnfinish // 未续
            };
            this.$nextTick(function () {
              if (type === 'A') {
                this.$refs.dayContinuPie && this.$refs.dayContinuPie.setData(echarts => {
                  echarts.setOption({
                    title: [
                      {},
                      {
                        text: numberShowType(data.totalVehicleNumber)
                      }
                    ],
                    series: {
                      data: [data.totalRenewalFinish, data.totalRenewalOff]
                    }
                  })
                })
              } else {
                let renewalFinishs = []; // 已续
                let renewalOff = []; // 脱续
                let dateTimes = []; // x 轴时间
                let showSymbol = data.queryRenewalReportDTO.length === 1;
                data.queryRenewalReportDTO.forEach(v => {
                  renewalFinishs.push(v.renewalFinish);
                  renewalOff.push(v.renewalOff);
                  dateTimes.push(v.dateTime);
                });
                let arr = [
                  {
                    showSymbol: showSymbol,
                    data: renewalFinishs,
                    type: 'line'
                  },
                  {
                    showSymbol: showSymbol,
                    data: renewalOff,
                    type: 'line'
                  }
                ];
                let xData = _this.makeXData(dateTimes, type);
                let ass = Array.prototype.concat.call([], renewalFinishs, renewalOff); //, noRenewals
                let max = Math.max.apply(Math, ass);
                ass = null;
                this.$refs.monthContinuPie && this.$refs.monthContinuPie.setData(echarts => {
                  echarts.setOption({
                    title: [
                      {},
                      {
                        text: numberShowType(data.totalVehicleNumber)
                      },
                      {
                        text: '续保率' + data.totalRenewalRatio
                      }
                    ],
                    series: {
                      data: [data.totalRenewalFinish, data.totalRenewalOff, data.totalRenewalUnfinish]
                    }
                  })
                });
                this.$refs.monthContinuLine && this.$refs.monthContinuLine.setData(echarts => {
                  echarts.setOption({
                    title: [
                      {
                        text: xData[0] // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                      },
                      {
                        text: xData[xData.length - 1]
                      }
                    ],
                    xAxis: {
                      data: xData
                    },
                    yAxis: {
                      minInterval: Math.ceil(max / 4)
                    },
                    series: arr
                  })
                })
              }
            });
          }).catch(e => {
          console.log(e);
          this.$nextTick(function () {
            this.initEcharts('A');
          });
        })
      },
      /* 请求联系分析数据
       * type A 日, B 月, C 年
       * month 月份 类似 2018-03
       * */
      getConData (type, month) {
        let _this = this;
        axios.post(url.getWebServiceUrls('getInsideCon'), {
          "dealerCode": this.dealerCode,
          "queryNum": month || undefined,
          "queryType": type
        })
          .then(res => {
            res = res.data;
            console.log(res);
            if (res.code !== 0) {
              toast(res.msg);
              return
            }
            let data = res.data;
            _this.isShowCon = data.status === '0';
            if (data.status !== '0') {
              return;
            }
            _this.systemTime = data.sysTime || _this.systemTime;
            _this.conData = {
              alreadyCallNumRatio: data.alreadyCallNumRatio, // 已拨打率
              alreadyConnectNumRatio: data.alreadyConnectNumRatio, // 接通率
              alreadyXbNumRatio: data.alreadyXbNumRatio // 成功率
            };
            this.$nextTick(function () {
              let obj = {
                title: [
                  {},
                  {
                    text: numberShowType(data.shouldCallNum)
                  }
                ],
                series: {
                  data: [data.alreadyCallNum, data.alreadyConnectNum, data.alreadyXbNum]
                }
              };
              let alreadyCallNums = []; // 已拨标的
              let alreadyConnectNum = []; // 接通标的
              let alreadyXbNum = [];//成功标的
              let sysTimes = []; // x 轴时间
              let showSymbol = data.renewalTouchVoList.length === 1;
                data.renewalTouchVoList.forEach(v => {
                  alreadyCallNums.push(v.alreadyCallNum);
                  alreadyConnectNum.push(v.alreadyConnectNum);
                  alreadyXbNum.push(v.alreadyXbNum);
                  sysTimes.push(v.sysTime);
                });
                let arr = [
                  {
                    showSymbol: showSymbol,
                    data: alreadyCallNums,
                    type: 'line'
                  },
                  {
                    showSymbol: showSymbol,
                    data: alreadyConnectNum,
                    type: 'line'
                  },
                  {
                    showSymbol: showSymbol,
                    data: alreadyXbNum,
                    type: 'line'
                  }
                ];
                let xData = _this.makeXData(sysTimes, type);
                let ass = Array.prototype.concat.call([], alreadyCallNums, alreadyConnectNum); //, noRenewals
                let max = Math.max.apply(Math, ass);
                ass = null;
                this.$refs.monthConLine && this.$refs.monthConLine.setData(echarts => {
                  echarts.setOption({
                    title: [
                      {
                        text: xData[0] // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                      },
                      {
                        text: xData[xData.length - 1]
                      }
                    ],
                    xAxis: {
                      data: xData
                    },
                    yAxis: {
                      minInterval: Math.ceil(max / 4)
                    },
                    series: arr
                  })
                })
              this.$refs.dayConPie && this.$refs.dayConPie.setData(echarts => {
                echarts.setOption(obj)
              });
              this.$refs.monthConPie && this.$refs.monthConPie.setData(echarts => {
                echarts.setOption(obj)
              });
            });
          }).catch(e => {
          console.log(e);
          this.$nextTick(function () {
            this.initEcharts('B');
          });
        })
      },
      /* 切换状态时 让echarts 正确切换 */
      initEcharts (type) {
        switch (type) {
          case 'A':
            this.continuData = {
              totalRenewalFinish: 0, // 已续
              totalRenewalOff: 0, // 脱续
              totalRenewalUnfinish: 0 // 未续
            };
            this.$nextTick(function () {
              let refs = this.$refs;
              refs.dayContinuPie && refs.dayContinuPie.init();
              refs.monthContinuPie && refs.monthContinuPie.init();
              refs.monthContinuLine && refs.monthContinuLine.init();
            });
            break;
          case 'B':
            this.conData = {
              alreadyCallNumRatio: '0%', // 已拨打率0%
              alreadyConnectNumRatio: '0%', // 接通率
              alreadyXbNumRatio: '0%' // 成功率
            };
            this.$nextTick(function () {
              let refs = this.$refs;
              refs.dayConPie && refs.dayConPie.init();
              refs.monthConPie && refs.monthConPie.init();
              refs.monthConLine && refs.monthConLine.init();
            });
            break;
          default:
            this.continuData = {
              totalRenewalFinish: 0, // 已续
              totalRenewalOff: 0, // 脱续
              totalRenewalUnfinish: 0 // 未续
            };
            this.conData = {
              alreadyCallNumRatio: '0%', // 已拨打率0%
              alreadyConnectNumRatio: '0%', // 接通率
              alreadyXbNumRatio: '0%' // 成功率
            };
            this.$nextTick(function () {
              let refs = this.$refs;
              refs.dayContinuPie && refs.dayContinuPie.init();
              refs.dayConPie && refs.dayConPie.init();
              refs.monthContinuPie && refs.monthContinuPie.init();
              refs.monthConPie && refs.monthConPie.init();
              refs.monthConLine && refs.monthConLine.init();
              refs.monthContinuLine && refs.monthContinuLine.init();
            });
            break;
        }
      },
      /* 生成折线图的x轴的数据
       * list 根据list确定x轴的长度
       * type B 月(03.08), C 年(2018.03)
       * */
      makeXData (list, type) {
        let arr = [];
        list.forEach(v => {
          // 截取字符串
          v = v.replace(/-/g, '.');
          v = type === 'B' ? v.substr(v.indexOf('.') + 1, 6) : v.substr(0, 7);
          arr.push(v);
        });
        return arr;
      }
    },
    components: {
      ptsLine,
      ptsPie,
      ptsTextScroll
    },
    activated () {
      this.isShowCon = false;
      this.isContinu = true;
      let query = this.$route.query;
      if (query.adCode) {
        window.eventAnalytics('队伍端_续保分析', '机构选择');
        this.dealerName = query.adName;
        this.dealerCode = query.adCode;
      } else {
        this.dealerName = window.dealerData.innerAccountRoleType === '1' ? '' : window.dealerData.deptName;
        this.dealerCode = '';
      }
      let date = new Date();
      let month = date.getMonth() + 1;
      if (this.activeMonth === '') {
        this.monthValue = month;
        this.activeMonth = date.getFullYear() + '-' + (month > 9 ? month : '0' + month)
      } else {
        this.monthValue = Number(this.activeMonth.split('-')[1]);
      }
      month = this.activeTab === 'B' ? this.activeMonth : undefined;
      this.$nextTick(function () {
          this.getData(this.activeTab, month);
      })
    },
    watch: {
      dealerCode () {
        console.log('aaa')
        if (window.dealerData.innerAccountRoleType !== '1') return;
        window.eventAnalytics('队伍端_续保分析', '网点选择');
        this.isShowCon = false;
        this.isContinu = true;
        let month = this.activeTab === 'B' ? this.activeMonth : undefined;
        this.$nextTick(function () {
          this.getData(this.activeTab, month);
        })
      }
    },
    beforeRouteEnter (to, from, next) {
      loadEcharts(next);
    }
  }
</script>

<style lang="less">
.insideXubaoWrap .chartDataBox dt:before, .insideXubaoWrap .chartBoxTxt li:before, .insideXubaoWrap .trendAreaTips li:before{
  left: -0.1rem;
}
</style>
