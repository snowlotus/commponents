<template>
	<section class="box">
    <pts-header :titleText="titleText" leftFlag @on-left="goMenu">
      <div slot="center" class="textBanner">
        <text-scroll v-model="chooseName"></text-scroll>
      </div>
    </pts-header>
    <div class="wrap insideXubaoWrap insideTuixiuWrap">
      <div class="mainWrap pb20">
        <div class="tabWrap pt20">
          <ul class="analyBtnArea">
            <li :class="{cur:index == 1}" @click="getData(chooseName,'A','1')">当日</li>
            <li :class="{cur:index == 2}" @click="getData(chooseName,'B','2')">当月</li>
          </ul>
        </div>
        <div>
          <div class="tuixiuBox" style="display: block;">
            <div class="dataArea pt20 mb20">
              <p class="timeTxt" style="line-height: .26rem">{{systemTime}}</p>
              <div class="chartBox mb15 pt20">
                <pts-pie-com :options="pieOptions" ref="pie"></pts-pie-com>
              </div>
              <ul class="chartDataBox c">
                <li class="f_c_green" @click.prevent="showSuccess = !showSuccess">
                  <p :class="{active:showSuccess}"><em>已联系(台)</em><em>{{successMsg.sum}}</em></p>
                  <ul class="selectList c dn" style="display: block;" v-if="showSuccess">
                    <li><em>同意到店<span class="bbb">(成功)</span></em><em>{{successMsg.confirm}}</em></li>
                    <li><em>拒绝到店<span class="bbb">(失败)</span></em><em>{{successMsg.decline}}</em></li>
                    <li><em>暂不确定是否到店<span class="bbb">(待确认)</span></em><em>{{successMsg.indeterminacy}}</em></li>
                  </ul>
                </li>
                <li class="f_c_yellow" @click.prevent="showFail = !showFail">
                  <p :class="{active:showFail}"><em>未联系(台)</em><em>{{noCallMsg.sum}}</em></p>
                  <ul class="selectList c" v-if="showFail">
                    <!-- <li><em>超时二推</em><em>{{noCallMsg.timeOut}}</em></li> -->
                    <li><em>返修自留</em><em>{{noCallMsg.self}}</em></li>
                  </ul>
                </li>
              </ul>
            </div>

            <div class="dataArea pb15">
              <dl>
                <dt>联系时效</dt>
                <dd>单位:分钟</dd>
              </dl>
              <div class="chartBox pb20">
                <pts-bar-com :options="barOptions" ref="bar"></pts-bar-com>
              </div>
            </div>

            <div class="dataArea pb15" v-if="index == 2">
              <dl>
                <dt>维修时效走势</dt>
              </dl>
              <div class="chartBox pb20">
                <pts-line-com :options="lineOptions" ref="line"></pts-line-com>
              </div>
            </div>
          </div>
        </div>
        <!--<div class="pageTab_year_hr"></div>-->
      </div>
    </div>
  </section>
</template>

<script>
    import API from '../../../common/js/comConfig'
    import textScroll from '../../../common/comComponent/textScroll'
    import Axios from '../../../common/js/axiosConfig'
    import toast from '../../../common/comComponent/toast'
    import ptsBarCom from '../../../common/comComponent/echarts/bar'
    import ptsLineCom from '../../../common/comComponent/echarts/line'
    import ptsPieCom from '../../../common/comComponent/echarts/pie'
    import {remInPx,loadEcharts} from "../../../common/js/comUtils";

    const date = new Date();
    const year = date.getFullYear();
    const month = date.getMonth()+1;
    /*const day = date.getDate();
    const hour = date.getHours() >= 10 ? date.getHours() : '0' + date.getHours();
    const minute = date.getMinutes() >= 10 ? date.getMinutes() : '0' + date.getMinutes();*/
    const colors = ['#60D194', '#FFDB4B', '#559EFF'];

    export default {
        name: "inContactAnalyse",
        data(){
          return {
            titleText:' ',
            chooseName:'',
            showSuccess:false,
            showFail:false,
            queryType:'A', //A当日,B当月
            index:1, //1当日,2当月
            systemTime:'',
            successMsg: {
              sum: 0, // 总数
              confirm: 0, // 确定到店
              decline: 0, // 拒绝
              indeterminacy: 0 // 不确定
            }, //已联系
            noCallMsg: {
              sum: 0,
              timeOut: 0, // 超时
              self: 0 // 自修
            }, //未联系
            pieOptions: {
              title: [
                {
                  text: '总推修量(台)',
                  textStyle: {
                    fontSize: remInPx(0.26),
                    fontWeight: 'normal',
                    color: '#666666'
                  },
                  top: '32%',
                  left: 'center'
                },
                {
                  text: '0',
                  textStyle: {
                    fontSize: remInPx(0.6),
                    fontWeight: 'normal',
                    color: '#333'
                  },
                  top: '42%',
                  left: 'center'
                },
                {
                  text: '推修成功率0%',
                  textStyle: {
                    fontSize: remInPx(0.26),
                    fontWeight: 'normal',
                    color: '#FE3A3A '
                  },
                  top: '64%',
                  left: 'center'
                }
              ],
              color: colors,
              series: [
                {
                  type: 'pie',
                  radius: ['75%', '90%'],
                  label: {
                    normal: {
                      show: false
                    },
                    emphasis: {
                      show: false
                    }
                  },
                  hoverAnimation: false,
                  data: [
                    {
                      value: 0,
                      name: '未联系'
                    },
                    {
                      value: 0,
                      name: '已联系'
                    }
                  ]
                }
              ]
            },
            barOptions: {
              legend: {
                data: ['大案', '非大案'],
                itemGap: 100
              },
              color: colors,
              xAxis: [
                {
                  show: true,
                  type: 'category',
                  splitNumber: 1,
                  data: ['其实没什么用'],
                  axisLine: {
                    show: true,
                    lineStyle: {
                      type: 'dashed',
                      color: 'rgba(0,0,0,0)'
                    }
                  },
                  axisTick: {
                    show: false
                  },
                  position: 'bottom',
                  boundaryGap: true
                }, {
                  type: 'category',
                  boundaryGap: false,
                  data: (function () {
                    var res = [];
                    var len = 0;
                    while (len < 10) {
                      res.push(len);
                      len++;
                    }
                    return res;
                  })(),
                  axisLine: {
                    show: true,
                    lineStyle: {
                      type: 'dashed',
                      color: 'rgba(0,0,0,0)'
                    }
                  },
                  axisTick: {
                    show: false
                  },
                  position: 'top'
                }
              ],
              yAxis: {
                type: 'value',
                splitLine: {
                  show: true,
                  lineStyle: {
                    type: 'dashed',
                    color: '#eee'
                  }
                },
                axisLine: {
                  show: false
                },
                axisTick: {
                  show: false
                },
                axisLabel: {
                  color: '#999999',
                  fontSize: remInPx(0.26)
                }
              },
              series: [
                {
                  name: '大案',
                  type: 'bar',
                  label: {
                    normal: {
                      show: true,
                      position: 'top',
                      textStyle: {
                        color: '#666666'
                      }
                    }
                  },
                  itemStyle: {
                    normal: {
                      color: colors[2]
                    },
                    emphasis: {
                      color: colors[2]
                    }
                  },
                  barGap: '150%',
                  barWidth: remInPx(1),
                  data: []
                },
                {
                  name: '非大案',
                  type: 'bar',
                  label: {
                    normal: {
                      show: true,
                      position: 'top',
                      textStyle: {
                        color: '#666666'
                      }
                    }
                  },
                  itemStyle: {
                    normal: {
                      color: colors[0]
                    },
                    emphasis: {
                      color: colors[0]
                    }
                  },
                  barGap: '150%',
                  barWidth: remInPx(1),
                  data: []
                },
                {
                  name: '均值',
                  type: 'line',
                  xAxisIndex: 1,
                  data: [],
                  lineStyle: {
                    normal: {
                      width: 1,
                      color: '#c0c0c0'
                    }
                  },
                  symbol: 'rect',
                  symbolSize: 1,
                  showSymbol: true,
                  label: {
                    normal: {
                      show: true,
                      position: 'top',
                      formatter: function (a) {
                        if (a.dataIndex > 8) {
                          return `均值:${a.data}分钟`
                        } else {
                          return ''
                        }
                      },
                      color: '#c0c0c0'
                    },
                    emphasis: {
                      show: true,
                      position: 'right',
                      formatter: function (a) {
                        if (a.dataIndex > 8) {
                          return `均值:${a.data}分钟`
                        } else {
                          return ''
                        }
                      },
                      color: '#c0c0c0'
                    }
                  }
                }
              ]
            },
            lineOptions: {
              color: colors,
              legend: {
                data: ['大案', '非大案', '均值']
              },
              series: [
                {
                  name: '大案',
                  type: 'line',
                  showSymbol: false,
                  symbol: 'circle',
                  hoverAnimation: false,
                  lineStyle: {
                    normal: {
                      width: 1
                    }
                  },
                  data: []
                }, {
                  name: '非大案',
                  type: 'line',
                  showSymbol: false,
                  symbol: 'circle',
                  hoverAnimation: false,
                  lineStyle: {
                    normal: {
                      width: 1
                    }
                  },
                  data: []
                },
                {
                  name: '均值',
                  type: 'line',
                  showSymbol: false,
                  symbol: 'circle',
                  hoverAnimation: false,
                  lineStyle: {
                    normal: {
                      width: 1
                    }
                  },
                  data: []
                }
              ]
            },
            timeArr:['日报','月报'], //存储时间埋点
            addStorage:{}, //存储每次请求回来的数据
          }
        },
        methods:{
          //回到Native主页
          goMenu(){
            Native.requestHybrid({
              tagname:'backHome'
            })
          },
          /**
           * @info 请求数据
           * @params dealercode 网点名称
           * @params type A为当日,B为当月
           * @params index 1为当日,2为当月
           * */
          getData(dealerCode,type,index){
            const _this = this;
            _this.initEcharts();
            _this.addStorage = {};
            _this.successMsg = {};
            _this.noCallMsg = {};
            _this.queryType = type;
            _this.index = index;

            Axios.post(API.getWebServiceUrls('pushRepairContactAnalyse'),{
              "dealerCode":dealerCode, //如果参数为空或者QG,默认为全部网点查询
              "monthDate": month,
              "queryType": _this.queryType
            }).then(res => {
              let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
              // console.log(res)
              if(data.code == '0' || data.code == 0){
                data = data.data;
                _this.systemTime = data.sysTimes;

                if (_this.index == 2 && data.contactAnalysisResult) {
                  _this.addStorage = data.contactAnalysisResult;
                }

                let successSum = data.successNum + data.failNum + data.undeterminedNum; //已联系总数
                let fileSum = data.timeOutTwoPush + data.repairRetention; //未联系总数
                let majorCase = data.contactAnalysisResult.sumMajorCase; // 大案
                let unMajorCase = data.contactAnalysisResult.sumUnMajorCase;  // 非大案
                let averageValue = data.contactAnalysisResult.sumAverageValue; // 均值
                _this.successMsg = {
                  sum: successSum,
                  confirm: data.successNum,
                  decline: data.failNum,
                  indeterminacy: data.undeterminedNum
                };
                _this.noCallMsg = {
                  sum: fileSum,
                  timeOut: data.timeOutTwoPush, // 超时
                  self: data.repairRetention // 自修
                };
                _this.$nextTick(function () {
                  _this.$refs.pie.setData(function (echarts) {
                    echarts.setOption({
                      title: [
                        {},
                        {
                          text: (function (value) {
                            if (Number.isNaN(Number(value))) {
                              return value;
                            }
                            if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
                              return Number(value).toLocaleString();
                            } else {
                              return value;
                            }
                          })((successSum + fileSum))
                        },
                        {
                          text:(function(a,b) {
                            if (Number.isNaN(a/b)) {
                              return '推修成功率0.00%'
                            } else {
                              return '推修成功率'+ (a/b*100).toFixed(2)+'%'
                            }
                          })(_this.successMsg.confirm, (_this.successMsg.sum + _this.noCallMsg.sum))
                        }
                      ],
                      series: [
                        {
                          data: [
                            {value:successSum},
                            {value:fileSum}
                          ]
                        }
                      ]
                    })
                  });
                  _this.$refs.bar.setData(function (echarts) {
                    let arr = [
                      {data: [majorCase]}, // 大案
                      {data: [unMajorCase]}, // 非大案
                      {
                        data: (function () {
                          let lishi = [];
                          let i = 0;
                          while (i < 10) {
                            lishi.push(averageValue);
                            i++
                          }
                          return lishi
                        })()
                      } // 均值
                    ];
                    let ass = [majorCase, unMajorCase];
                    let max = Math.max.apply(Math, ass);
                    echarts.setOption({
                      yAxis: {
                        minInterval: Math.ceil(max / 4)
                      },
                      series: arr
                    });
                    max = null;
                    ass = null;
                  });
                  if (_this.queryType == 'B') {
                    let majorCases = []; // 大案
                    let unMajorCases = []; // 非大案
                    let averageValues = []; // 均值
                    data.contactAnalysisResult.contactMajorCaseVO.forEach(v => {
                      majorCases.push(v.majorCase);
                      unMajorCases.push(v.unMajorCase);
                      averageValues.push(v.averageValue)
                    });
                    _this.$refs.line.setData(function (echarts) {
                      let arrs = [
                        {
                          data: majorCases,
                          showSymbol: majorCases.length < 2
                        },
                        {
                          data: unMajorCases,
                          showSymbol: unMajorCases.length < 2
                        },
                        {
                          data: averageValues,
                          showSymbol: averageValues.length < 2
                        }
                      ];
                      let date = data.yearAndMonth;
                      let xData = _this.xDatas();
                      let ass = Array.prototype.concat.call([], majorCases, unMajorCases, averageValues);
                      let max = Math.max.apply(Math, ass);
                      ass = null; // 内存回收
                      echarts.setOption({
                        title: [
                          {
                            text: `${xData[0].substring(5)}` // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                          },
                          {
                            text: `${xData[xData.length-1].substring(5)}`
                          }
                        ],
                        xAxis: {
                          data: xData
                        },
                        yAxis: {
                          // 为了显示五个y轴
                          minInterval: Math.ceil(max / 4)
                        },
                        series: arrs
                      });
                      max = null;
                    })
                  }
                });
              }else{
                toast(data.msg || '系统繁忙,请稍后重试')
              }
            }).catch(err => {
              console.log(err)
            })
            window.eventAnalytics('队伍端_联系分析',`${_this.timeArr[_this.index-1]}`)
          },
          /*
           * @info 生成 x 轴数据 YYYY-MM-DD格式
           * @param month {number, string} MM的值
           * @param day {number} 一共生成多少天
           * @return array 值类型是YYYY-MM-DD格式 的数组
           * */
          xDatas () {
            /*let arr = []
            for (let i = 1; i <= day; i++) {
              arr.push(`${month}-${i < 10 ? '0' + i : i}`)
            }
            return arr*/
            let arr = [];
            let dataArr = this.addStorage.contactMajorCaseVO;
            for (let i = 0;i < dataArr.length;i++) {
              arr.push(`${dataArr[i].datatime.substring(0,4)}-${dataArr[i].datatime.substring(4,6)}-${dataArr[i].datatime.substring(6)}`)
            }
            return arr
          },
          /**
           * @info 初始化Echarts
           */
          initEcharts () {
            this.$nextTick(function () {
              this.successMsg = {
                sum: 0,
                confirm: 0, //确定(成功)
                decline: 0, //拒绝
                indeterminacy: 0 //不确定
              };
              this.noCallMsg = {
                sum: 0,
                timeOut: 0, // 超时
                self: 0 // 自修
              };
              this.$refs.pie.setData(function (echarts) {
                echarts.setOption({
                  title: [
                    {},
                    {
                      text: (function (value) {
                        if (Number.isNaN(Number(value))) {
                          return value;
                        }
                        if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
                          return Number(value).toLocaleString();
                        } else {
                          return value;
                        }
                      })(0)
                    }
                  ],
                  silent:true,
                  series: [
                    {
                      data: [
                        {value: 0},
                        {value: 0}
                      ]
                    }
                  ]
                })
              });
              this.$refs.bar.setData(function (echarts) {
                let arr = [
                  {data: [0]}, // 大案
                  {data: [0]}, // 非大案
                  {
                    data: (function () {
                      let lishi = []
                      let i = 0
                      while (i < 10) {
                        lishi.push(0)
                        i++
                      }
                      return lishi
                    })()
                  } // 均值
                ]
                echarts.setOption({
                  series: arr
                })
              });
              this.$refs.line && this.$refs.line.setData(function (echarts) {
                let arrs = [
                  {
                    data: []
                  },
                  {
                    data: []
                  },
                  {
                    data: []
                  }
                ]
                echarts.setOption({
                  xAxis: {
                    data: []
                  },
                  series: arrs
                })
              });
            })
          }
        },
        created(){
          this.getData('',this.queryType,this.index);
          window.eventAnalytics('队伍端_联系分析', '日报');
        },
        beforeRouteEnter (to, from, next) {
          loadEcharts(next);
        },
        watch:{
          chooseName (newVal,oldVal) {
            this.getData(newVal,this.queryType,this.index);
            window.eventAnalytics('队伍端_联系分析', '网点选择');
          },
          showSuccess () {
            const _this = this;
            window.eventAnalytics('队伍端_联系分析', `${_this.timeArr[_this.index-1]}-已联系`);
          },
          showFail () {
            const _this = this;
            window.eventAnalytics('队伍端_联系分析', `${_this.timeArr[_this.index-1]}-未联系`);
          }
        },
        components:{
          textScroll,
          ptsBarCom,
          ptsLineCom,
          ptsPieCom
        }
    }
</script>

<style scoped lang="less">
  .insideTuixiuWrap .chartDataBox > li p.active:after{
    content:"";
    display: block;
    position: absolute;
    top:50%;
    right:.3rem;
    width: .14rem;
    height: .08rem;
    margin-top: -.04rem;
    background: url(../../../common/images/icon_arrow_cf83_up.png) no-repeat 0 0;
    background-size: .14rem .08rem;
  }
  .insideTuixiuWrap .selectList li em:last-child {
    float: right;
    margin-right: .6rem;
    font-size: .3rem;
  }

</style>
