<template>
<div class="box">
  <pts-header leftFlag @on-left="goMenu" :titleText="titleText" :showRight="showRight">
    <div slot="center" class="textBanner">
      <text-scroll v-model="chooseName"></text-scroll>
    </div>
    <a slot="right" class="nav_search_icon fr" @click.stop.prevent="gotoSearch"></a>
  </pts-header>
  <div class="wrap insideXubaoWrap insideVisuWrap">
    <div class="mainWrap">
      <pts-tab :titleList="titleList" v-model="index" ref="tabElem" @on-child-change="tabChildChange" @on-change="tabChange">
        <pts-tab-item>
          <!--全部-->
          <pts-task-list flagName="07" :active="index===0" :dealerCode="chooseName"></pts-task-list>
        </pts-tab-item>
        <pts-tab-item>
          <!--新任务-->
          <pts-task-list flagName="00" @on-offRedDot="offRedDot" :active="index===1" :dealerCode="chooseName"></pts-task-list>
        </pts-tab-item>
        <pts-tab-item>
          <!--待确认-->
          <pts-task-list flagName="02" :active="index===2" :dealerCode="chooseName"></pts-task-list>
        </pts-tab-item>
        <pts-tab-item>
          <!--已完成-->
          <pts-task-list flagName="06" :active="index===3" :tabChild="tabChild" :dealerCode="chooseName"></pts-task-list>
        </pts-tab-item>
      </pts-tab>
    </div>
  </div>
</div>
</template>

<script>
  import ptsTab from '../../common/comComponent/tab'
  import textScroll from '../../common/comComponent/textScroll'

  //  import ptsTaskList from './page/list.vue'
  export default {
    name: "inRepairTask",
    data () {
      return {
        titleText:' ',
        chooseName:'',
        showRight:true,
        titleList: [
          {
            title: '全部'
          },
          {
            title: '新任务',
            isRed: false
          },
          {
            title: '待确认'
          },
          {
            title: '已完成',
            childs: [
              {title: '已完成', flag: '06'},
              {title: '成功', flag: '04'},
              {title: '失败', flag: '05'},
              {title: '失效', flag: '03'}
            ]
          }
        ],
        index: 0, //默认全部
        tabChild: '06'
      }
    },
    components: {
      ptsTab,
      textScroll,
      ptsTabItem: ptsTab.Item,
      ptsTaskList: resolve => require.ensure([], () => resolve(require('./page/list.vue')), 'SearchTaskList')
    },
    methods: {
      /**
       * @param item为已完成,成功,失败,失效
       * @info 将item的flag值赋给tabchild,传给list子组件作为查询类型参数
       */
      tabChildChange (item) {
        this.tabChild = item.flag;
      },
      //回到Native主页
      goMenu () {
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      /**
       * @info 关闭新任务上的红点
       */
      offRedDot () {
        this.titleList[1].isRed = false
      },
      tabChange (item) {
        window.eventAnalytics('队伍端_推修任务',`任务状态-${item.title}`)
      },
      gotoSearch(){
        this.$router.push({path:'/inside/inSearch'})
        window.eventAnalytics('队伍端_推修任务','搜索')
      }
    },

    created () {
      const _this = this;

      //@info 定义全局方法供Native调用,Native监听有无新消息来触发
      window.setRedDot = function () {
        _this.titleList[1].isRed = true
      }
    },
    watch: {
      index (to) {
        if (to === 1) {
          this.offRedDot();
        }
      }
    }
  }
</script>

<style lang="less" scoped>
    .nav_search_icon {
      display: inline-block;
      width: .48rem;
      height: .48rem;
      background: url("../../common/images/filter_icon@3x.png") no-repeat;
      margin-right: .31rem;
      margin-top: -0.65rem;
      background-size: 100%;
    };
</style>
