<template>
  <div class="tabArea">
    <pts-scroll-ajax ref="scrollAjax"
                     :topAjax="topAjax && !showCallAlert && !searchCondition && !startDate && !showDataNull"
                     @on-top-ajax="getFirstPage" :bottomAjax="bottomAjax && !showDataNull"
                     @on-bottom-ajax="getNextPage">
      <pts-task-item @on-call="calluser" v-if="dataList.length" v-for="(item,i) in dataList" :key="item.reportNo"
                     :datas="item"  class="taskArea" :class="{pt20:i !== 0}"></pts-task-item>
      <p class="totalOrder" v-if="dataList.length">{{$route.path == '/inside/inRepairTask'? '近一个月' : '本次查询'}}共<em style="font-weight: bold;">{{maxNum}}</em>单</p>
      <!--` 第一次获取的数据为空时显示的页面 -->
      <div v-if="showDataNull" class="dataNullWrap">
        <div class="imgWrap"></div>
        <div class="dataNullText">没有搜到匹配的数据…</div>
      </div>
    </pts-scroll-ajax>
    <!-- 填写　拨号后, 收集结果的页面 -->
    <pts-call-msg :showCallMsg="showCallMsg" @on-updata-callmsg="getMsg"
    ></pts-call-msg>
  </div>
</template>

<script>
  import toast from '../../../common/comComponent/toast'
  import ptsScrollAjax from '../../../common/comComponent/scrollAjax'
  import ptsTaskItem from  './item.vue'
  import Axios from '../../../common/js/axiosConfig'
  import API from '../../../common/js/comConfig'
  import ptsCallMsg from './callMsg.vue'

  export default {
    name: "inTaskList",
    props: {
      flagName: String, //07全部,00新任务,02待确认,06已完成
      active: Boolean, //ture代表当前切换的tab页面
      tabChild: String,
      searchCondition: String,
      startDate: String,
      endDate: String,
      dealerCode: String //index组件传过来的网点值
    },
    data () {
      return {
        topAjax: true,
        bottomAjax: false,
        dataList: [],
        showDataNull: false,
        page: 1, //默认请求第一页
        maxNum: 0, // 显示近30天有多少单
        showCallMsg:false,
        showCallAlert:false,
      }
    },
    methods: {
      getData (flag, topajax) {
        const _this = this;
        if (flag) {
          this.dataList = [];
          this.showDataNull = false;
        }
        let obj = {
          "dealerCode" : _this.dealerCode || '', //网点搜索,默认全部网点
          "taskStatus": _this.tabChild || _this.flagName, // 查询类型
          "endDate": _this.endDate || undefined, // 搜索结束时间
          "searchCondition": _this.searchCondition || undefined, // 搜索车牌号or案件号
          "startDate": _this.startDate || undefined, //  搜索开始时间
          "pageNo": _this.page,
          "pageSize": 10
        }

        Axios.post(API.getWebServiceUrls('pushRepairList'),obj, {loading: !topajax})
          .then(res => {
            // console.table(res.data.data);
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
            switch (data.code) {
              case 0:
                _this.maxNum = data.totalCount;
                //判断无数据时,或在无数据且在搜索页时,让无数据的图片展示出来
                if (data.data && data.data.length === 0) {
                  if (flag) {
                    if (_this.searchCondition || _this.startDate) {
                      _this.$emit('data-back', true)
                    } else {
                      _this.showDataNull = true
                      _this.bottomAjax = false
                    }
                  } else {
                    _this.bottomAjax = false
                  }
                  _this.$refs.scrollAjax && _this.$refs.scrollAjax.reset(flag);
                  return
                }

                data.data.forEach(v => {
                  _this.dataList.push(v)
                });

                _this.bottomAjax = true

                //pageSize默认每次请求10条,两者乘积大于总条数时,禁止上拉加载
                if (data.pageNo * data.pageSize >= data.totalCount) {
                  _this.bottomAjax = false
                }

                //DOM 更新循环结束之后,如果在搜索页,触发搜索页组件中的loading效果
                _this.$nextTick(function () {
                  (_this.searchCondition || _this.startDate) && this.$emit('data-back')
                  _this.$refs.scrollAjax && _this.$refs.scrollAjax.reset(flag)
                })
                break
              default:
                if (flag) {
                  if (_this.searchCondition || _this.startDate) {
                    _this.$emit('data-back', true) // 返回搜索页面让其显示搜索为空
                  } else {
                    _this.showDataNull = true
                  }
                }
                _this.$nextTick(function () {
                  _this.$refs.scrollAjax && _this.$refs.scrollAjax.reset(flag)
                })
                toast(data.msg || '系统繁忙,请稍后重试')
                break
            }
          }).catch(err => {
            if (flag) {
              if (_this.searchCondition || _this.startDate) {
                _this.$emit('data-back', true) // 返回搜索页面让其显示搜索为空
              } else {
                _this.showDataNull = true
              }
              _this.$refs.scrollAjax && _this.$refs.scrollAjax.reset(flag)
            }
        })
      },
      /* 获取安全号码并拨打 */
      calluser (taskId, flag, num, numList) {
        const _this = this
        _this.callAlertActiveTaskId = taskId
        window.eventAnalytics('推修任务', 'list页面点击拨打电话');
        /*this.showCallAlert = false
         if (!flag) {
         return
         }*/
        /* 如果用户修改号码 通知navtive 刷新修改的电话号 */
        /*if (numList) {
         _this.userNum = numList
         Native.requestHybrid({
         tagname: 'setUserPhoneNum',
         param: {
         numList: numList + ''
         },
         callback: function (data) {
         }
         })
         }*/
        Axios.post(API.getWebServiceUrls('applysecurityphonenumber'), {
          taskId: _this.callAlertActiveTaskId
          // csPhoneNum: num
        }).then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
          switch (data.code) {
            case 0:
              if (window.urlHeader.os === 'iOS') {
                window.getUserIsCall = function () {
                  setTimeout(function () {
                    _this.showCallMsg = true;
                  }, 1000);
                  return window.getUserIsCall = null;
                }
              }
              window.location.href = 'tel: ' + data.data;
              if (window.urlHeader.os === 'iOS') return;
              setTimeout( () => {
                this.showCallMsg = true
              }, 1000);
              break
            default:
              toast(data.msg)
              break
          }
        }).catch(err => {
          console.log(err)
          // toast('获取安全号码失败, 请重试。')
        })
      },
      /* 获取用户填写的信息并发送到服务端 */
      getMsg (msg) {
        msg.taskId = this.callAlertActiveTaskId
        this.callAlertActiveTaskId = 0
//        console.log(msg)
        Axios.post(API.getWebServiceUrls('contactresult'), {
          contactCustomerResult: msg.contactCustomerResult,
          contactFailedOtherReason: msg.contactFailedOtherReason || msg.krFailReason,
          taskId: msg.taskId
        }).then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
          switch (data.code) {
            case 0:
              this.showCallMsg = false
              toast('提交成功')
              break
            default:
              toast(data.msg)
              break
          }
        }).catch(err => {
          // toast('提交失败, 请重试');
          console.log(err)
        })
      },
      /* 唤醒选择电话号弹窗 */
      awakenCallAlert (taskId) {
        const _this = this
        Native.requestHybrid({
          tagname: 'getUserPhoneNum',
          callback: function (data) {
            let datas = typeof data === 'string' ? JSON.parse(data) : data
            _this.userNum = datas.data.phoneNum
          }
        })
        _this.callAlertActiveTaskId = taskId
        _this.showCallAlert = true
      },
      /**
       *@info 上拉加载
       */
      getNextPage () {
        this.page++;
        this.getData();
      },
      /**
       * @info 下拉加载
       */
      getFirstPage () {
        this.page = 1;
        this.getData(true, true);
        if (this.flagName === '00') {
          this.$emit('on-offRedDot');
        }
      }
    },
    //首次加载为全部,active为true
    mounted () {
      if (this.active) {
        this.getData(true)
      }
    },
    components: {
      ptsScrollAjax,
      ptsTaskItem,
      ptsCallMsg
    },
    watch: {
      //监听active值变化,值为true时tab切换请求数据,false时tab返回不请求数据
      active (to, from) {
        if (to && this.dataList.length === 0) {
          this.page = 1;
          this.getData(true)
        }
      },
      //监听tabchild值变化请求数据04成功,失败05,03失效,06已完成
      tabChild (to, from) {
        this.page = 1;
        this.getData(true)
      },
      dealerCode(){
        this.getData(true)
        window.eventAnalytics('队伍端_推修任务','网点选择')
      }
    },
  }
</script>

<style lang="less" scoped>
  .tabArea {
    width: 100%;
    height: 100%;
    box-sizing: border-box;
  }

</style>
