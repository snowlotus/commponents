<template>
  <pts-alert v-model="show">
    <div class="inTelNo">
      <dl>
        <dt>手机号</dt>
        <dd>
          <input type="tel" ref="phoneNume" v-model="phone" v-if="showWrite" @blur="verifyNum">
          <input type="text" readonly :value="phone | phoneType" v-else @click="changInput">
        </dd>
      </dl>
      <p>
        <a href="javascript:;" otype="button" otitle="取消" @click.prevent="off(false, false)">取消</a>
        <a href="javascript:;" otype="button" otitle="确认拨打" @click.prevent="off(true, true)" class="cur">确认拨打</a>
      </p>
    </div>
  </pts-alert>
</template>

<script>
  import verify from '../../../common/js/comValidate'
  import toast from '../../../common/comComponent/toast'
  import ptsAlert from '../../../common/comComponent/alertWindow'
  export default {
    name: "callAlert",
    props: {
      showAlert: Boolean,
      userNum: String
    },
    data () {
      return {
        show: false,
        write: false,
        phone: 0,
        activeNum: 0,
        userPhoneNum: 0,
        showWrite: false,
        activeIndex: 0
      }
    },
    methods: {
      hides () {
        this.show = false
        setTimeout(function () {
          this.$emit('on-updata-alert', false, 111)
        }.bind(this), 500)
      },
      off (flag, isWrite) {
        if (!flag) {
          this.show = false
        }
        const _this = this
        let numList = ''
        if (isWrite && flag) {
          if (!this.verifyNum()) return
          if ((this.phone + '') != this.userPhoneNum) {
            numList = this.phone
          }
          this.show = false
        }
        setTimeout(function () {
          let phoneNum = this.phone
          this.$emit('on-updata-alert', flag, phoneNum, numList)
          this.userPhoneNum = ''
        }.bind(this), 500)
      },
      verifyNum () {
        const msg = verify.checkMobile(this.phone)
        if (typeof msg !== 'boolean') {
          toast(msg)
          return false
        }
        this.showWrite = false
        return true
      },
      changInput () {
        this.showWrite = true
        this.$nextTick(function () {
          this.$refs.phoneNume.focus()
        })
      }
    },
    watch: {
      'showAlert': {
        handler: function (val) {
          setTimeout(function () {
            this.show = val
          }.bind(this), 0)
        },
        immediate: true
      }
    },
    filters: {
      phoneType (value) {
        let arr = (value + '').split('')
        if (arr.length > 3) {
          arr.splice(3, 0, '-')
        }
        if (arr.length > 7) {
          arr.splice(8, 0, '-')
        }
        return arr.join('')
      }
    },
    mounted () {
      this.phone = this.userPhoneNum = this.userNum
    },
    components: {
      ptsAlert
    }
  }
</script>

<style lang="less">

</style>
