<template>
  <pts-alert v-model="show">
    <div class="reMaskArea minHeight">
      <h3>记录联系结果</h3>
      <div class="maskBox c">
        <dl class="c">
          <dt class="_333">结果</dt> <!--:class="{'_333': msg.contactCustomerResult,'bbb': !msg.contactCustomerResult}"-->
          <dd>
            <p :class="{'_333': msg.contactCustomerResult,'bbb': !msg.contactCustomerResult}" @click.prevent="showResult = true">{{resultText}}</p>
            <ul v-if="showResult">
              <li v-for="(item, index) in result" :class="{'cur':resultActive === index}"
                  @click="chooseResult(item, index)">{{item.title}}
              </li>
            </ul>
          </dd>
        </dl>
        <dl class="c"> <!-- v-if="resultMsgList.length"-->
          <dt class="bbb" :class="{'_333': !msg.contactCustomerResult || !msg.contactCustomerResult.includes('01')}">原因</dt>
          <dd>
            <p @click.prevent="showMsgEvent"  :class="{'_333': msg.contactFailedOtherReason,'bbb': !msg.contactFailedOtherReason}">{{resultMsg}}</p>
            <ul v-if="showMsg && !showResult && resultMsgList.length">
              <li :class="{'cur':msgActive===index}" v-for="(item, index) in resultMsgList"
                  @click.prevent="chooseMsg(item, index)">{{item.title}}
              </li>
            </ul>
          </dd>
        </dl>
        <div class="inTxt"><textarea name="form" ref="textElem" placeholder="手动输入原因"
                                     v-model="writeMsg" :readonly="!showWrite"></textarea></div> <!--v-if="showWrite"-->
      </div>
      <a href="javascript:;" otype="button" otitle="提交" class="sendUp abBtm" :class="{'saveBtn': isCanSave}" @click.prevent="off">提交</a>
    </div>
  </pts-alert>
</template>

<script>
  import ptsAlert from '../../../common/comComponent/alertWindow'
  import toast from '../../../common/comComponent/toast'
  export default {
    name: "call-msg",
    props: {
      showCallMsg: Boolean
    },
    data () {
      return {
        show: false,
        resultText: '请选择联系结果', // 在选择结果区域显示的文字
        result: [
          {title: '同意到店', flag: '01'},
          {
            title: '拒绝到店',
            flag: '02',
            msgList: [
              {title: '距离太远不方便', flag: '03'},
              {title: '未曾来过,不熟悉', flag: '05'},
              {title: '拒接电话', flag: '06'},
              {title: '已在别的修理厂修理', flag: '01'},
              {title: '手动输入', flag: '04'}
            ]
          },
          {
            title: '暂不确定是否到店',
            flag: '03',
            msgList: [
              {title: '电话未接通', flag: '07'},
              {title: '待跟进', flag: '08'},
              {title: '手动输入', flag: '09'}
            ]
          }
        ],
        resultActive: -1, // 选择的结果的索引 -1 代表还没有选择结果
        resultMsg: '请选择原因', // 在原因区域显示的文字
        resultMsgList: [],
        msgActive: -1,
        showResult: false,
        showMsg: false,
        showWrite: false,
        writeMsg: '',
        msg: { // 用户填写的信息 记录选择的flag
          contactCustomerResult: undefined,  // 联系结果 成功、失败、 待确定
          contactFailedOtherReason: undefined, // 联系失败的原因
          krFailReason: undefined, // 手写的信息录入
        },
        isCanSave: false
      }
    },
    methods: {
      off () {
        if (this.resultActive < 0) {
          toast('请选择联系结果')
          return
        }
        if (this.resultActive > 0 && this.msgActive < 0) {
          toast('请选择原因')
          return
        }
        if (this.showWrite && this.writeMsg.trim().length < 1) {
          toast('请输入原因')
          return
        }
        this.msg.contactFailedOtherReason = this.showWrite ? undefined : this.msg.contactFailedOtherReason;
        this.msg.krFailReason = this.writeMsg || undefined;
        this.$emit('on-updata-callmsg', this.msg)
      },
      chooseResult (item, index) {
        /*this.resultMsgList = item.msgList ? item.msgList : []
        this.showResult = false
        this.showWrite = false
        this.resultMsg = '请选择原因'
        this.msgActive = -1
        this.writeMsg = '';*/
        this.init();
        this.resultActive = index;
        this.resultText = item.title;
        this.resultMsgList = item.msgList ? item.msgList : []
        this.msg.contactCustomerResult = `${item.flag}_${item.title}`;
        this.isCanSave = item.flag === '01';
      },
      chooseMsg (item, index) {
        this.msgActive = index;
        this.resultMsg = item.title;
        this.writeMsg = '';
        this.showWrite = item.flag === '04' || item.flag === '09';
        this.showMsg = false;
        this.$nextTick(function () {
          this.$refs.textElem && this.$refs.textElem.focus();
        });
        this.msg.contactFailedOtherReason = item.title;
        this.isCanSave = item.flag !== '04' || item.flag !== '09';
      },
      init () {
        this.resultText = '请选择联系结果';
        this.resultActive = -1; // 选择的结果的索引 -1 代表还没有选择结果
        this.resultMsg = '请选择原因'; // 在原因区域显示的文字
        this.resultMsgList = [];
        this.msgActive = -1;
        this.showResult = false;
        this.showMsg = false;
        this.showWrite = false;
        this.writeMsg = '';
        this.isCanSave = false;
        this.msg = { // 用户填写的信息 记录选择的flag
          contactCustomerResult: undefined,  // 联系结果 成功、失败、 待确定
            contactFailedOtherReason: undefined, // 联系失败的原因
            krFailReason: undefined, // 手写的信息录入
        }
      },
      showMsgEvent () {
        if (this.resultMsgList.length) this.showMsg = true;
      }
    },
    watch: {
      /*'showCallMsg': {
       handler: function (val) {
       if (val) {
       this.init();
       }
       setTimeout(function () {
       this.show = val;
       }.bind(this), 0) // 使用定时器来创造一个代码的时间差, 达到有过渡动画的效果
       },
       immediate: true
       }*/
      showCallMsg (to) {
        this.show = to;
        if (to) {
          window.PageEvent.stopBackNative()
          this.init();
        } else {
          window.PageEvent.allowBackNative()
        }
        window.PageStatus.headerStop = to // 阻止头部的所有行为
      }
    },
    components: {
      ptsAlert
    }
  }
</script>

<style lang="less">
  .minHeight {
    min-height: 7.3rem;
    .abBtm {
      width: 100%;
      position: absolute;
      bottom: 0;
      left: 0;
    }
  }
</style>
