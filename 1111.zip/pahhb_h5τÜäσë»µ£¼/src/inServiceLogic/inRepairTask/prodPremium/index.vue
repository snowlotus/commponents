/**
* Created by chenchangwei837 on 2018/3/13.
* 推修模块--产值保费
*/
<template>
  <section class="box" style="background: #FFFFFF;">
    <pts-header title-text="产值保费" leftFlag @on-left="goMenu()">
      <!--<div class="textBanner" slot="center" v-if="innerAccountRoleType==='1'">-->
      <!--<pts-text-scroll @input="changModel"></pts-text-scroll>-->
      <!--</div>-->
    </pts-header>
    <div class="wrap insideTuixiuWrap">
      <div class="pos-rel">
        <ul class="taskTitleArea c date-tab">
          <li class="pts-b-b" :class="{'cur':activeTab==='D'}" @click.stop="changTab('D')"><em>日</em></li>
          <li class="moreOption pts-b-b" :class="{'cur':activeTab==='M'}" @click.stop="changTab('M')">
            <em>{{monthValue|chineseMonth}}月<a href="javascript:;" otype="button"
                                               otitle="展开" class="openSlect " :class="{arrowUp:showFlag}">展开</a></em>
          </li>
          <li class="pts-b-b" :class="{'cur':activeTab==='Y'}" @click.stop="changTab('Y')"><em>年</em></li>
        </ul>
      </div>
      <!-- main start -->
      <div class="mainWrap" v-if="activeTab==='D'">
        <div class="premiumArea">
          <div class="pt20 pb20" v-if="innerAccountRoleType!=='1'">
            <ul class="tabTopBox c">
              <li :class="{cur:dayType.organAndGroup==='1'}" @click.stop="dayType.organAndGroup='1',changeTax('D')">机构
              </li>
              <li :class="{cur:dayType.organAndGroup==='2'}" @click.stop="dayType.organAndGroup='2',changeTax('D')">集团
              </li>
            </ul>
          </div>
          <div class="premiumData" v-if="innerAccountRoleType==='3'">
            <!-- 机构 start -->
            <ul class="premiumDataArea" v-if="dayType.organAndGroup==='1'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li>
                <p>
                  <em>{{JGData.name}}</em>
                  <em>{{JGData.afterTaxPremium}}</em>
                  <em>{{JGData.outputValue}}</em>
                  <em>{{JGData.outputValuePremiumRatio}}</em>
                </p>
              </li>
              <li class="selectLarArea">
                <p @click.stop="earthData.type=!earthData.type">
                  <em><i :class="{openSelect:earthData.type}">{{earthData.name}}</i></em>
                  <em>{{earthData.afterTaxPremium}}</em>
                  <em>{{earthData.outputValue}}</em>
                  <em>{{earthData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:!earthData.type}">
                  <li v-for="item in earthData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
              <li class="selectLarArea">
                <p @click.stop="northData.type=!northData.type">
                  <em><i :class="{openSelect:northData.type}">{{northData.name}}</i></em>
                  <em>{{northData.afterTaxPremium}}</em>
                  <em>{{northData.outputValue}}</em>
                  <em>{{northData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:!northData.type}">
                  <li v-for="item in northData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
            </ul>
            <!-- 机构 end -->
            <!-- 集团 start -->
            <ul class="premiumDataArea" v-if="dayType.organAndGroup==='2'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li v-for="item in organList">
                <p>
                  <em>{{item.name}}</em>
                  <em>{{item.data.afterTaxPremium}}</em>
                  <em>{{item.data.outputValue}}</em>
                  <em>{{item.data.outputValuePremiumRatio}}</em>
                </p>
              </li>
            </ul>
            <!-- 集团 end -->
          </div>
          <!-- 当日 后线角色 start-->
          <div class="premiumData" v-if="innerAccountRoleType==='2'">
            <!-- 机构 start -->
            <ul class="premiumDataArea" v-if="dayType.organAndGroup==='1'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li class="selectLarArea">
                <p @click.stop="JGData.type=!JGData.type">
                  <em><i :class="{openSelect:!JGData.type}">{{JGData.name}}</i></em>
                  <em>{{JGData.afterTaxPremium}}</em>
                  <em>{{JGData.outputValue}}</em>
                  <em>{{JGData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:JGData.type}">
                  <li v-for="item in JGData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
            </ul>
            <!-- 机构 end -->
            <!-- 集团 start -->
            <ul class="premiumDataArea" v-if="dayType.organAndGroup==='2'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li v-for="item in organList">
                <p>
                  <em>{{item.name}}</em>
                  <em>{{item.data.afterTaxPremium}}</em>
                  <em>{{item.data.outputValue}}</em>
                  <em>{{item.data.outputValuePremiumRatio}}</em>
                </p>
              </li>
            </ul>
            <!-- 集团 end -->
          </div>
          <!-- 当日 后线角色 end-->
          <!-- 当日 前线角色 start-->
          <div class="premiumData" v-if="innerAccountRoleType==='1'" style="margin-top: .5rem">
            <!-- 网点 start -->
            <ul class="premiumDataArea">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li class="selectLarArea">
                <p @click.stop="JGData.type=!JGData.type">
                  <em><i :class="{openSelect:!JGData.type}">{{JGData.name}}</i></em>
                  <em>{{JGData.afterTaxPremium}}</em>
                  <em>{{JGData.outputValue}}</em>
                  <em>{{JGData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:JGData.type}">
                  <li v-for="item in JGData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
            </ul>
            <!-- 网点 end -->
          </div>
          <!-- 当日 前线角色 end-->
        </div>
        <div>
          <ul class="btn_b">
            <li :class="{cur:dayType.calibreType==='1'}"><a href="javascript:;" otype="button" otitle="签单口径"
                                                            @click.stop="dayType.calibreType='1',changeTax('D')">签单口径</a>
            </li>
            <li :class="{cur:dayType.calibreType==='2'}"><a href="javascript:;" otype="button" otitle="企划口径"
                                                            @click.stop="dayType.calibreType='2',changeTax('D')">企划口径</a>
            </li>
          </ul>
        </div>
      </div>
      <!-- main end -->
      <div class="mainWrap" v-if="activeTab==='M'">
        <div class="premiumArea">
          <div class="pt20 pb20" v-if="innerAccountRoleType!=='1'">
            <ul class="tabTopBox c">
              <li :class="{cur:monthType.organAndGroup==='1'}" @click.stop="monthType.organAndGroup='1',changeTax('M')">
                机构
              </li>
              <li :class="{cur:monthType.organAndGroup==='2'}" @click.stop="monthType.organAndGroup='2',changeTax('M')">
                集团
              </li>
            </ul>
          </div>
          <div class="premiumData" v-if="innerAccountRoleType==='3'">
            <!-- 机构 start -->
            <ul class="premiumDataArea" v-if="monthType.organAndGroup==='1'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li>
                <p>
                  <em>{{JGData.name}}</em>
                  <em>{{JGData.afterTaxPremium}}</em>
                  <em>{{JGData.outputValue}}</em>
                  <em>{{JGData.outputValuePremiumRatio}}</em>
                </p>
              </li>
              <li class="selectLarArea">
                <p @click.stop="earthData.type=!earthData.type">
                  <em><i :class="{openSelect:earthData.type}">{{earthData.name}}</i></em>
                  <em>{{earthData.afterTaxPremium}}</em>
                  <em>{{earthData.outputValue}}</em>
                  <em>{{earthData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:!earthData.type}">
                  <li v-for="item in earthData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
              <li class="selectLarArea">
                <p @click.stop="northData.type=!northData.type">
                  <em><i :class="{openSelect:northData.type}">{{northData.name}}</i></em>
                  <em>{{northData.afterTaxPremium}}</em>
                  <em>{{northData.outputValue}}</em>
                  <em>{{northData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:!northData.type}">
                  <li v-for="item in northData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
            </ul>
            <!-- 机构 end -->
            <!-- 集团 start -->
            <ul class="premiumDataArea" v-if="monthType.organAndGroup==='2'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li v-for="item in organList">
                <p>
                  <em>{{item.name}}</em>
                  <em>{{item.data.afterTaxPremium}}</em>
                  <em>{{item.data.outputValue}}</em>
                  <em>{{item.data.outputValuePremiumRatio}}</em>
                </p>
              </li>
            </ul>
            <!-- 集团 end -->
          </div>
          <!-- 当日 后线角色 start-->
          <div class="premiumData" v-if="innerAccountRoleType==='2'">
            <!-- 机构 start -->
            <ul class="premiumDataArea" v-if="monthType.organAndGroup==='1'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li class="selectLarArea">
                <p @click.stop="JGData.type=!JGData.type">
                  <em><i :class="{openSelect:!JGData.type}">{{JGData.name}}</i></em>
                  <em>{{JGData.afterTaxPremium}}</em>
                  <em>{{JGData.outputValue}}</em>
                  <em>{{JGData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:JGData.type}">
                  <li v-for="item in JGData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
            </ul>
            <!-- 机构 end -->
            <!-- 集团 start -->
            <ul class="premiumDataArea" v-if="monthType.organAndGroup==='2'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li v-for="item in organList">
                <p>
                  <em>{{item.name}}</em>
                  <em>{{item.data.afterTaxPremium}}</em>
                  <em>{{item.data.outputValue}}</em>
                  <em>{{item.data.outputValuePremiumRatio}}</em>
                </p>
              </li>
            </ul>
            <!-- 集团 end -->
          </div>
          <!-- 当日 后线角色 end-->
          <!-- 当日 前线角色 start-->
          <div class="premiumData" v-if="innerAccountRoleType==='1'" style="margin-top: .5rem">
            <!-- 网点 start -->
            <ul class="premiumDataArea">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li class="selectLarArea">
                <p @click.stop="JGData.type=!JGData.type">
                  <em><i :class="{openSelect:!JGData.type}">{{JGData.name}}</i></em>
                  <em>{{JGData.afterTaxPremium}}</em>
                  <em>{{JGData.outputValue}}</em>
                  <em>{{JGData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:JGData.type}">
                  <li v-for="item in JGData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
            </ul>
            <!-- 网点 end -->
          </div>
          <!-- 当日 前线角色 end-->
        </div>
        <div>
          <ul class="btn_b">
            <li :class="{cur:monthType.calibreType==='1'}"><a href="javascript:;" otype="button" otitle="签单口径"
                                                              @click.stop="monthType.calibreType='1',changeTax('M')">签单口径</a>
            </li>
            <li :class="{cur:monthType.calibreType==='2'}"><a href="javascript:;" otype="button" otitle="企划口径"
                                                              @click.stop="monthType.calibreType='2',changeTax('M')">企划口径</a>
            </li>
          </ul>
        </div>
      </div>
      <div class="mainWrap" v-if="activeTab==='Y'">
        <div class="premiumArea">
          <div class="pt20 pb20" v-if="innerAccountRoleType!='1'">
            <ul class="tabTopBox c">
              <li :class="{cur:yearType.organAndGroup==='1'}" @click.stop="yearType.organAndGroup='1',changeTax('Y')">机构
              </li>
              <li :class="{cur:yearType.organAndGroup==='2'}" @click.stop="yearType.organAndGroup='2',changeTax('Y')">集团
              </li>
            </ul>
          </div>
          <div class="premiumData" v-if="innerAccountRoleType==='3'">
            <!-- 机构 start -->
            <ul class="premiumDataArea" v-if="yearType.organAndGroup==='1'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li>
                <p>
                  <em>{{JGData.name}}</em>
                  <em>{{JGData.afterTaxPremium}}</em>
                  <em>{{JGData.outputValue}}</em>
                  <em>{{JGData.outputValuePremiumRatio}}</em>
                </p>
              </li>
              <li class="selectLarArea">
                <p @click.stop="earthData.type=!earthData.type">
                  <em><i :class="{openSelect:earthData.type}">{{earthData.name}}</i></em>
                  <em>{{earthData.afterTaxPremium}}</em>
                  <em>{{earthData.outputValue}}</em>
                  <em>{{earthData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:!earthData.type}">
                  <li v-for="item in earthData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
              <li class="selectLarArea">
                <p @click.stop="northData.type=!northData.type">
                  <em><i :class="{openSelect:northData.type}">{{northData.name}}</i></em>
                  <em>{{northData.afterTaxPremium}}</em>
                  <em>{{northData.outputValue}}</em>
                  <em>{{northData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:!northData.type}">
                  <li v-for="item in northData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
            </ul>
            <!-- 机构 end -->
            <!-- 集团 start -->
            <ul class="premiumDataArea" v-if="yearType.organAndGroup==='2'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li v-for="item in organList">
                <p>
                  <em>{{item.name}}</em>
                  <em>{{item.data.afterTaxPremium}}</em>
                  <em>{{item.data.outputValue}}</em>
                  <em>{{item.data.outputValuePremiumRatio}}</em>
                </p>
              </li>
            </ul>
            <!-- 集团 end -->
          </div>
          <!-- 当日 后线角色 start-->
          <div class="premiumData" v-if="innerAccountRoleType==='2'">
            <!-- 机构 start -->
            <ul class="premiumDataArea" v-if="yearType.organAndGroup==='1'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li class="selectLarArea">
                <p @click.stop="JGData.type=!JGData.type">
                  <em><i :class="{openSelect:!JGData.type}">{{JGData.name}}</i></em>
                  <em>{{JGData.afterTaxPremium}}</em>
                  <em>{{JGData.outputValue}}</em>
                  <em>{{JGData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:JGData.type}">
                  <li v-for="item in JGData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
            </ul>
            <!-- 机构 end -->
            <!-- 集团 start -->
            <ul class="premiumDataArea" v-if="yearType.organAndGroup==='2'">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li v-for="item in organList">
                <p>
                  <em>{{item.name}}</em>
                  <em>{{item.data.afterTaxPremium}}</em>
                  <em>{{item.data.outputValue}}</em>
                  <em>{{item.data.outputValuePremiumRatio}}</em>
                </p>
              </li>
            </ul>
            <!-- 集团 end -->
          </div>
          <div class="premiumData" v-if="innerAccountRoleType==='1'" style="margin-top: .5rem">
            <!-- 网点 start -->
            <ul class="premiumDataArea">
              <li>
                <p>
                  <em>名称</em>
                  <em>保费(万元)</em>
                  <em>产值(万元)</em>
                  <em>产值保费比</em>
                </p>
              </li>
              <li class="selectLarArea">
                <p @click.stop="JGData.type=!JGData.type">
                  <em><i :class="{openSelect:!JGData.type}">{{JGData.name}}</i></em>
                  <em>{{JGData.afterTaxPremium}}</em>
                  <em>{{JGData.outputValue}}</em>
                  <em>{{JGData.outputValuePremiumRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:JGData.type}">
                  <li v-for="item in JGData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.afterTaxPremium}}</em>
                    <em>{{item.data.outputValue}}</em>
                    <em>{{item.data.outputValuePremiumRatio}}</em>
                  </li>
                </ul>
              </li>
            </ul>
            <!-- 网点 end -->
          </div>
        </div>
        <div>
          <ul class="btn_b">
            <li :class="{cur:yearType.calibreType==='1'}"><a href="javascript:;" otype="button" otitle="签单口径"
                                                             @click.stop="yearType.calibreType='1',changeTax('Y')">签单口径</a>
            </li>
            <li :class="{cur:yearType.calibreType==='2'}"><a href="javascript:;" otype="button" otitle="企划口径"
                                                             @click.stop="yearType.calibreType='2',changeTax('Y')">企划口径</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>
</template>
<script>
  import Axios from '../../../common/js/axiosConfig'
  import API from '../../../common/js/comConfig'
  import {chineseMonth} from '../../../common/filters/convertDate'
  import {NumberThere} from '../../../common/filters/convertAmount'
  import Toast from '../../../common/comComponent/toast'

  const date = new Date()
  const YEAR = date.getFullYear();
  const MONTH = date.getMonth() + 1;
  export default {
    name: 'prodPremium',
    data() {
      return {
        activeTab: 'D',//D 日 M 年 Y 年
        monthValue: MONTH,
        showFlag: false,
        yearAndMonth: `${YEAR}-${MONTH > 10 ? MONTH : '0' + MONTH}`,
        dayType: {
          calibreType: '1', //1 签单 2 企划
          organAndGroup: '1'//1 机构 2 集团 3 网点
        },
        monthType: {
          calibreType: '1',
          organAndGroup: '1'
        },
        yearType: {
          calibreType: '1',
          organAndGroup: '1'
        },
        JGData: {
          type: false,
          name: '全国',
          afterTaxPremium: '',//保费
          outputValue: '',//产值
          outputValuePremiumRatio: '',//产值保费比
          list: []
        },
        earthData: {
          type: false,
          name: '东南区',
          afterTaxPremium: '',//保费
          outputValue: '',//产值
          outputValuePremiumRatio: '',//产值保费比
          list: []
        },//东南区
        northData: {
          type: true,
          name: '西北区',
          afterTaxPremium: '',//保费
          outputValue: '',//产值
          outputValuePremiumRatio: '',//产值保费比
          list: []
        },//西北区
        organList: [],//集团List
        innerAccountRoleType: '',//角色 前线 1; 后线 2;总部 3;
        listType: '1', //1 机构 2 集团 3 网点
        queryType: 'D', // D 日 M 月 Y 年
        statisticType: '1', //1 签单口径 2 企划口径
        statisticList: ['签单口径', '企划口径'],//用于数据埋点
        JGlist: ['机构', '集团', '网点']//用于数据埋点
      }
    },
    //
    mounted() {
      let self = this;
      self.innerAccountRoleType = window.dealerData.innerAccountRoleType;
      self.listType = self.innerAccountRoleType === '1' ? '3' : '1'; //如果前线角色进来 listType==3 后线和总部listType 为1
      window.eventAnalytics("队伍端_产值保费", `${this.statisticList[~~(this.dayType.calibreType) - 1] + "-日报-" + this.JGlist[~~(this.listType) - 1]}`);
      let reqData = {
        listType: self.listType,
        queryType: self.queryType,
        statisticType: self.statisticType
      }
      this.$nextTick(function () {
        self.getData(reqData);
      })
    },
    methods: {
      goMenu() {
        Native.requestHybrid({
          tagname: 'backHome'
        });
      },
      changTab(type) {
        let self = this;
        let reqData = {};
        if ((type === 'D' || type === "Y") && this.activeTab === type) {
          return
        }
        switch (type) {
          case 'D':
            self.listType = self.innerAccountRoleType === '1' ? '3' : self.dayType.organAndGroup;
            window.eventAnalytics("队伍端_产值保费", `${this.statisticList[~~(this.dayType.calibreType) - 1] + "-日报-" + this.JGlist[~~(this.listType) - 1]}`);
            reqData = {
              "listType": self.listType,
              "queryType": type,
              "statisticType": self.dayType.calibreType
            };
            this.$nextTick(function () {
              this.getData(reqData);
            });
            break;
          case 'M':
            let month = date.getMonth() + 1;
            let newMonth = 12 - month === 0 ? 1 : month + 1;
            let year = date.getFullYear();
            self.listType = self.innerAccountRoleType === '1' ? '3' : self.monthType.organAndGroup;
            console.log(newMonth);
            if (self.activeTab === type) {
              this.showFlag = true;
              this.$vux.datetime.show({
                value: this.yearAndMonth,
                cancelText: '取消',
                confirmText: '确定',
                format: 'YYYY-MM',
                minYear: year - 1,
                maxYear: year,
                startDate: `${year - 1}-${newMonth > 10 ? '0' + newMonth : newMonth}-01`,
                endDate: `${year}-${month > 10 ? '0' + month : month}-01`,
                onConfirm: (a) => {
                  window.eventAnalytics("队伍端_产值保费", `${self.statisticList[~~(self.monthType.calibreType) - 1] + "-月报-选择月份" + self.JGlist[~~(self.listType) - 1]}`);
                  if (this.yearAndMonth === a) return
                  // this.monthValue = a
                  this.monthValue = a.substr(a.indexOf('-') + 1)
                  // this.monthValue = this.selectMonth
                  this.yearAndMonth = a;
                  reqData = {
                    queryValue: this.monthValue,
                    listType: self.innerAccountRoleType === '1' ? '3' : self.monthType.organAndGroup,
                    queryType: type,
                    statisticType: self.monthType.calibreType
                  }
                  this.getData(reqData)
                },
                onShow: () => {
                  // window.eventAnalytics("内部端产值保费", "点击了切换月份", {'confirmBtn': '点击了切换月份的确认按钮'});
                  this.showDateTime = true;
                },
                onHide: () => {
                  this.showFlag = false;
                  // window.eventAnalytics("内部端产值保费", "点击了切换月份", {'cancelBtn': '点击了切换月份的取消按钮'});
                  this.showDateTime = false;
                }
              })
            } else {
              // window.eventAnalytics("队伍端_产值保费", "签单口径-月报");
              window.eventAnalytics("队伍端_产值保费", `${self.statisticList[~~(self.monthType.calibreType) - 1] + "-月报-" + self.JGlist[~~(self.listType) - 1]}`);
              reqData = {
                queryValue: this.monthValue,
                listType: self.innerAccountRoleType === '1' ? '3' : self.monthType.organAndGroup,
                queryType: type,
                statisticType: self.monthType.calibreType
              }
              this.getData(reqData);
            }
            break;
          case 'Y':
            self.listType = self.innerAccountRoleType === '1' ? '3' : self.yearType.organAndGroup;
            window.eventAnalytics("队伍端_产值保费", `${this.statisticList[~~(this.yearType.calibreType) - 1] + "-年报-" + this.JGlist[~~(this.listType) - 1]}`);
            reqData = {
              listType: self.innerAccountRoleType === '1' ? '3' : self.yearType.organAndGroup,
              queryType: type,
              statisticType: self.yearType.calibreType
            };
            this.$nextTick(function () {
              this.getData(reqData);
            });
            break;
          default:
            Toast('系统繁忙,请稍后重试');
            break;
        }
        this.activeTab = type;
      },
      //获取入参的值
      changeTax(tType) {
        let self = this;
        let reqData = {};
        let tTypeValue = { //数据埋点
          'D': '-日报-',
          'M': '-月报-',
          'Y': '-年报-'
        }
        if (tType === 'D') {  //日
          self.listType = self.innerAccountRoleType === '1' ? '3' : self.dayType.organAndGroup;
          window.eventAnalytics("队伍端_产值保费", `${this.statisticList[~~(this.dayType.calibreType) - 1] + tTypeValue[tType] + this.JGlist[~~(this.listType) - 1]}`);
          reqData = {
            "listType": self.listType,
            "queryType": tType,
            "statisticType": self.dayType.calibreType
          }
        } else if (tType === 'M') { //月
          self.listType = self.innerAccountRoleType === '1' ? '3' : self.monthType.organAndGroup;
          window.eventAnalytics("队伍端_产值保费", `${this.statisticList[~~(this.monthType.calibreType) - 1] + tTypeValue[tType] + this.JGlist[~~(this.listType) - 1]}`);
          reqData = {
            "listType": self.listType,
            "queryValue": self.monthValue,
            "queryType": tType,
            "statisticType": self.monthType.calibreType
          }
        } else if (tType == 'Y') {  //年
          self.listType = self.innerAccountRoleType === '1' ? '3' : self.yearType.organAndGroup;
          window.eventAnalytics("队伍端_产值保费", `${this.statisticList[~~(this.yearType.calibreType) - 1] + tTypeValue[tType] + this.JGlist[~~(this.listType) - 1]}`);
          reqData = {
            "listType": self.listType,
            "queryType": tType,
            "statisticType": self.yearType.calibreType
          }
        }
        console.log(reqData);
        this.getData(reqData);
      },
      /*
       * 获取产值保费
       * @param dateType
       * @param reqData
       */
      getData(reqData) {
        let self = this;
        Axios.post(API.getWebServiceUrls('pushRepairDataCollection'), reqData).then(res => {
          let resData = typeof res.data === 'string' ? JSON.stringify(res.data) : res.data;
          if (resData.code === '0' || resData.code === 0) {
            let prodData = resData.data.collectionDataList;
            switch (~~self.innerAccountRoleType) {
              case 1:
                self.JGData['name'] = prodData[0].name;
                self.JGData['afterTaxPremium'] = prodData[0].data.afterTaxPremium;
                self.JGData['outputValue'] = prodData[0].data.outputValue;
                self.JGData['outputValuePremiumRatio'] = prodData[0].data.outputValuePremiumRatio;
                self.JGData.list = prodData[0].data.childList;
                break;
              case 2:
                if (reqData.listType === '1') {
                  self.JGData['name'] = prodData[0].name;
                  self.JGData['afterTaxPremium'] = prodData[0].data.afterTaxPremium;
                  self.JGData['outputValue'] = prodData[0].data.outputValue;
                  self.JGData['outputValuePremiumRatio'] = prodData[0].data.outputValuePremiumRatio;
                  self.JGData.list = prodData[0].data.childList;
                } else if (reqData.listType === '2') {
                  self.organList = prodData;
                } else {

                }
                break;
              case 3:
                if (reqData.listType === '1') {
                  self.JGData['name'] = prodData[0].name;
                  self.JGData['afterTaxPremium'] = prodData[0].data.afterTaxPremium;
                  self.JGData['outputValue'] = prodData[0].data.outputValue;
                  self.JGData['outputValuePremiumRatio'] = prodData[0].data.outputValuePremiumRatio;
                  self.northData['name'] = prodData[1].name;
                  self.northData['afterTaxPremium'] = prodData[1].data.afterTaxPremium;
                  self.northData['outputValue'] = prodData[1].data.outputValue;
                  self.northData['outputValuePremiumRatio'] = prodData[1].data.outputValuePremiumRatio;
                  self.northData.list = prodData[1].data.childList;
                  self.earthData['name'] = prodData[2].name;
                  self.earthData['afterTaxPremium'] = prodData[2].data.afterTaxPremium;
                  self.earthData['outputValue'] = prodData[2].data.outputValue;
                  self.earthData['outputValuePremiumRatio'] = prodData[2].data.outputValuePremiumRatio;
                  self.earthData.list = prodData[2].data.childList;
                } else if (reqData.listType === '2') {
                  self.organList = prodData;
                } else {

                }

                break;
              default:
                Toast('角色不存在!!!');
                break;
            }
          } else {
            Toast(resData.msg || '系统繁忙请稍后重试!');
          }
        })
      }
    },
  }
</script>
<style scoped>
  @import '../css/css.css';

  .mainWrap {
    position: relative;
    padding-bottom: 1.2rem;
  }

  .taskTitleArea {
    padding: 0;
    width: 7.5rem;
    box-shadow: none;
    -moz-box-shadow: none;
    -webkit-box-shadow: none;
    border: none;
  }

  .taskTitleArea li {
    margin: 0;
    width: 33.33%;
    height: .78rem;
  }

  .taskTitleArea li.cur {
    height: .76rem;
    border: none;
  }

  .taskTitleArea li em {
    display: inline-block;
    position: relative;
    left: 50%;
    transform: translateX(-50%);
    -ms-transform: translateX(-50%);
    -moz-transform: translateX(-50%);
    -webkit-transform: translateX(-50%);
    -o-transform: translateX(-50%);
  }

  .moreOption em:after {
    display: none;
  }

  .moreOption em > a {
    display: block;
    position: absolute;
    top: 50%;
    right: -.02rem;
    width: .36rem;
    height: .36rem;
    margin-top: -.18rem;
    text-indent: -999rem;
    background: url(../../../common/images/icon_arrow_down.png) no-repeat center;
    background-size: .14rem .08rem;
  }

  .moreOption.cur em > a {
    background: url(../../../common/images/icon_arrow_cf83.png) no-repeat center;
    background-size: .14rem .08rem;
  }

  .moreOption.cur em > a .arrowDown {
    background: url(../../../common/images/icon_arrow_cf83.png) no-repeat center center;
    background-size: .14rem .08rem;
  }

  .moreOption.cur em > a.arrowUp {
    background: url(../../../common/images/arrowB3.png) no-repeat center;
    background-size: .14rem .08rem;
  }

  .btn_b {
    position: fixed;
    z-index: 5;
    bottom: 0;
    left: 0;
    width: 7.5rem;
    font-size: .28rem;
    text-align: center;
    border-top: 1px solid #eeeeee;
    background: #ffffff;
  }

  .btn_b .cur a {
    color: #FE883A;
  }

  .btn_b li {
    box-sizing: border-box;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    float: left;
    width: 50%;
  }

  .btn_b li a {
    display: block;
    height: 1rem;
    line-height: 1rem;
    color: #666666;
  }

  .btn_b li:first-child {
    border-right: .02rem solid #f0f0f0;
  }
</style>
