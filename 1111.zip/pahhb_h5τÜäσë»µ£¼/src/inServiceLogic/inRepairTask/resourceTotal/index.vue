/**
* Created by chenchangwei837 on 2018/3/13.
* 推修-资源总量
*/
<template>
  <section class="box" style="background: #FFFFFF;height: 100%;">
    <pts-header title-text="资源总量" leftFlag @on-left="goMenu()"></pts-header>
    <div class="wrap insideTuixiuWrap">
      <div class="pos-rel">
        <ul class="taskTitleArea c date-tab">
          <li class="pts-b-b" :class="{'cur':activeTab==='D'}" @click.stop="changTab('D')"><em>日</em></li>
          <li class="moreOption pts-b-b" :class="{'cur':activeTab==='M'}" @click.stop="changTab('M')">
            <em>{{monthValue|chineseMonth}}月<a href="javascript:;" otype="button" otitle="展开" class="openSlect" :class="{arrowUp:showFlag}">展开</a></em>
          </li>
          <li class="pts-b-b" :class="{'cur':activeTab==='Y'}" @click.stop="changTab('Y')"><em>年</em></li>
        </ul>
      </div>
      <!-- main start -->
      <div class="mainWrap pt30">

        <div class="premiumArea premiumSpecArea">
          <div class="premiumData">
            <!-- 总部 start -->
            <ul class="premiumDataArea" v-if="innerAccountRoleType==='3'">
              <li>
                <p>
                  <em>名称</em>
                  <em>资源总量(万元)</em>
                  <em>资源集中度</em>
                  <em>推修成功率</em>
                </p>
              </li>
              <li>
                <p>
                  <em>{{JGData.name}}</em>
                  <em>{{JGData.totalResource}}</em>
                  <em>{{JGData.resourceConcentrationRatio}}</em>
                  <em>{{JGData.pushRepairSuccessRatio}}</em>
                </p>
              </li>
              <li class="selectLarArea" >
                <p @click.stop="earthData.type=!earthData.type">
                  <em><i :class="{openSelect:earthData.type}">{{earthData.name}}</i></em>
                  <em>{{earthData.totalResource}}</em>
                  <em>{{earthData.resourceConcentrationRatio}}</em>
                  <em>{{earthData.pushRepairSuccessRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:!earthData.type}">
                  <li v-for="item in earthData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.totalResource}}</em>
                    <em>{{item.data.resourceConcentrationRatio}}</em>
                    <em>{{item.data.pushRepairSuccessRatio}}</em>
                  </li>
                </ul>
              </li>
              <li class="selectLarArea" @click.stop="northData.type=!northData.type">
                <p>
                  <em><i :class="{openSelect:northData.type}">{{northData.name}}</i></em>
                  <em>{{northData.totalResource}}</em>
                  <em>{{northData.resourceConcentrationRatio}}</em>
                  <em>{{northData.pushRepairSuccessRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:!northData.type}">
                  <li v-for="item in northData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.totalResource}}</em>
                    <em>{{item.data.resourceConcentrationRatio}}</em>
                    <em>{{item.data.pushRepairSuccessRatio}}</em>
                  </li>
                </ul>
              </li>
            </ul>
            <!-- 总部 end -->

            <!-- 机构 start -->
            <ul class="premiumDataArea" v-if="innerAccountRoleType==='2'">
              <li class="selectLarArea">
                <p>
                  <em>名称</em>
                  <em>资源总量(万元)</em>
                  <em>资源集中度</em>
                  <em>推修成功率</em>
                </p>
              </li>
              <li>
                <p @click.stop="JGData.type=!JGData.type">
                  <em><i :class="{openSelect:!JGData.type}">{{JGData.name}}</i></em>
                  <em>{{JGData.totalResource}}</em>
                  <em>{{JGData.resourceConcentrationRatio}}</em>
                  <em>{{JGData.pushRepairSuccessRatio}}</em>
                </p>
                <ul class="premiumDataBox" :class="{dn:JGData.type}">
                  <li v-for="item in JGData.list">
                    <em>{{item.name}}</em>
                    <em>{{item.data.totalResource}}</em>
                    <em>{{item.data.resourceConcentrationRatio}}</em>
                    <em>{{item.data.pushRepairSuccessRatio}}</em>
                  </li>
                </ul>
              </li>
            </ul>
            <!-- 机构 end -->
          </div>

        </div>

      </div>
      <!-- main end -->


    </div>
  </section>

</template>
<script>
  import Axios from '../../../common/js/axiosConfig'
  import API from '../../../common/js/comConfig'
  import {chineseMonth} from '../../../common/filters/convertDate'
  import {NumberThere} from '../../../common/filters/convertAmount'
  import Toast from '../../../common/comComponent/toast'

  const date = new Date()
  const YEAR = date.getFullYear();
  const MONTH = date.getMonth() + 1;
  export default {
    name: 'resourceTotal',
    data() {
      return {
        activeTab: 'D',
        showFlag: false,
        innerAccountRoleType: '', //1 前线 2 后线 3 总部
        queryType: 'D',//D 日 M 月 Y 年
        monthValue: MONTH,
        JGData: {
          type: false,
          name: '全国',
          pushRepairSuccessRatio: '',//推修成功率
          totalResource: '',//资源总量
          resourceConcentrationRatio: '',//资源集中度
          list: []
        },
        earthData: {
          type: false,
          name: '东南区',
          pushRepairSuccessRatio: '',//推修成功率
          totalResource: '',//资源总量
          resourceConcentrationRatio: '',//资源集中度
          list: []
        },//东南区
        northData: {
          type: true,
          name: '西北区',
          pushRepairSuccessRatio: '',//推修成功率
          totalResource: '',//资源总量
          resourceConcentrationRatio: '',//资源集中度
          list: []
        },//西北区
      }
    },
    mounted() {
      let self = this;
      self.innerAccountRoleType = window.dealerData.innerAccountRoleType;
      window.eventAnalytics("队伍端_资源总量", "日报");
      //self.listType = self.innerAccountRoleType === '1' ? '3' : '1'; //如果前线角色进来 listType==3 后线和总部listType 为1
      let reqData = {
        listType: '1',
        queryType: self.queryType,
        statisticType: '3'
      }
      this.$nextTick(function () {
        self.getData(reqData);
      })
    },
    methods: {
      /**
       * 返回主菜单
       **/
      goMenu() {
        Native.requestHybrid({
          tagname: 'backHome'
        });
      },
      /**
       * 切换时间
       **/
      changTab(type) {
        let self = this;
        let reqData = {};
        if ((type === 'D' || type === "Y") && this.activeTab === type) {
          return
        }
        switch (type) {
          case 'D':
            window.eventAnalytics("队伍端_资源总量", "日报");
            reqData = {
              "listType": '1',
              "queryType": type,
              "statisticType": '3'
            };
            this.$nextTick(function () {
              this.getData(reqData);
            });
            break;
          case 'M':
            window.eventAnalytics("队伍端_资源总量", "月报");
            let month = date.getMonth() + 1;
            let newMonth = 12 - month === 0 ? 1 : month + 1;
            let year = date.getFullYear();
            console.log(newMonth);
            if (self.activeTab === type) {
              this.showFlag = true;
              this.$vux.datetime.show({
                value: this.yearAndMonth,
                cancelText: '取消',
                confirmText: '确定',
                format: 'YYYY-MM',
                minYear: year - 1,
                maxYear: year,
                startDate: `${year - 1}-${newMonth > 10 ? '0' + newMonth : newMonth}-01`,
                endDate: `${year}-${month > 10 ? '0' + month : month}-01`,
                onConfirm: (a) => {
                  window.eventAnalytics("队伍端_资源总量", "月报-月份选择");
                  if (this.yearAndMonth === a) return
                  // this.monthValue = a
                  this.monthValue = a.substr(a.indexOf('-') + 1)
                  // this.monthValue = this.selectMonth
                  this.yearAndMonth = a;
                  reqData = {
                    queryValue: this.monthValue,
                    listType: '1',
                    queryType: type,
                    statisticType: '3'
                  }
                  this.getData(reqData)
                },
                onShow: () => {
                  // window.eventAnalytics("队伍端_资源总量", "显示-月份选择", {'confirmBtn': '点击了切换月份的确认按钮'});
                  this.showDateTime = true;
                },
                onHide: () => {
                  this.showFlag = false;
                  // window.eventAnalytics("队伍端_资源总量", "隐藏-月份选择", {'cancelBtn': '点击了切换月份的取消按钮'});
                  this.showDateTime = false;
                }
              })
            } else {
              window.eventAnalytics("队伍端_资源总量", "月报");
              reqData = {
                queryValue: this.monthValue,
                listType: '1',
                queryType: type,
                statisticType: '3'
              }
              this.getData(reqData);
            }
            break;
          case 'Y':
            window.eventAnalytics("队伍端_资源总量", "年报");
            reqData = {
              listType: '1',
              queryType: type,
              statisticType: '3'
            };
            this.$nextTick(function () {
              this.getData(reqData);
            });
            break;
          default:
            Toast('系统繁忙,请稍后重试!');
            break;
        }
        this.activeTab = type;
      },
      /**
       * 资源总量 和 产值保费调用的一样的接口 传入的 固定两个值
       * listType ==='1' statisticType ==='3'
       * @param reqData
       */
      getData(reqData) {
        let self = this;
        Axios.post(API.getWebServiceUrls('pushRepairDataCollection'), reqData).then(res => {
          let resData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (resData.code === '0' || resData.code === 0) {
            let prodData = resData.data.collectionDataList;
            switch (~~self.innerAccountRoleType) {
              case 2:
                self.JGData['name'] = prodData[0].name;
                self.JGData['pushRepairSuccessRatio'] = prodData[0].data.pushRepairSuccessRatio;
                self.JGData['totalResource'] = prodData[0].data.totalResource;
                self.JGData['resourceConcentrationRatio'] = prodData[0].data.resourceConcentrationRatio;
                self.JGData.list = prodData[0].data.childList;
                break;
              case 3:
                self.JGData['name'] = prodData[0].name;
                self.JGData['pushRepairSuccessRatio'] = prodData[0].data.pushRepairSuccessRatio;
                self.JGData['totalResource'] = prodData[0].data.totalResource;
                self.JGData['resourceConcentrationRatio'] = prodData[0].data.resourceConcentrationRatio;
                self.northData['name'] = prodData[1].name;
                self.northData['pushRepairSuccessRatio'] = prodData[1].data.pushRepairSuccessRatio;
                self.northData['totalResource'] = prodData[1].data.totalResource;
                self.northData['resourceConcentrationRatio'] = prodData[1].data.resourceConcentrationRatio;
                self.northData.list = prodData[1].data.childList;
                self.earthData['name'] = prodData[2].name;
                self.earthData['pushRepairSuccessRatio'] = prodData[2].data.pushRepairSuccessRatio;
                self.earthData['totalResource'] = prodData[2].data.totalResource;
                self.earthData['resourceConcentrationRatio'] = prodData[2].data.resourceConcentrationRatio;
                self.earthData.list = prodData[2].data.childList;
                break;
              default:
                Toast('出错了,请稍后重试!');
                break;
            }
            console.log(resData.data.collectionDataList);
          }else{
            Toast(resData.msg||"系统繁忙,请稍后重试")
          }
        })
      }
    },
  }
</script>
<style scoped>
  @import '../css/css.css';

  body {
    background-color: #f0f0f0;
  }

  .mainWrap {
    position: relative;
  }

  .taskTitleArea {
    padding: 0;
    width: 7.5rem;
    box-shadow: none;
    -moz-box-shadow: none;
    -webkit-box-shadow: none;
    border: none;
  }

  .taskTitleArea li {
    margin: 0;
    width: 33.33%;
    height: .78rem;
  }

  .taskTitleArea li.cur {
    height: .76rem;
    border: none;
  }

  .taskTitleArea li em {
    display: inline-block;
    position: relative;
    left: 50%;
    transform: translateX(-50%);
    -ms-transform: translateX(-50%);
    -moz-transform: translateX(-50%);
    -webkit-transform: translateX(-50%);
    -o-transform: translateX(-50%);
  }

  .moreOption em:after {
    display: none;
  }

  .moreOption em > a {
    display: block;
    position: absolute;
    top: 50%;
    right: -.02rem;
    width: .36rem;
    height: .36rem;
    margin-top: -.18rem;
    text-indent: -999rem;
    background: url(../../../common/images/icon_arrow_down.png) no-repeat center;
    background-size: .17rem .14rem;
  }

  .moreOption.cur em > a {
    background: url(../../../common/images/icon_arrow_cf83.png) no-repeat center;
    background-size: .17rem .14rem;
  }

  .moreOption.cur em > a.arrowUp {
    background: url(../../../common/images/arrowB3.png) no-repeat center;
    background-size: .17rem .14rem;
  }

  .insideTuixiuWrap .premiumDataArea > li > p em:first-child {
    width: 1.5rem;
    padding-left: .25rem;
    text-align: left;
  }

  .insideTuixiuWrap .premiumDataArea > li > p em:nth-of-type(2),
  .insideTuixiuWrap .premiumDataBox li em:nth-of-type(2) {
    width: 2rem;
    margin-right: .2rem;
  }

  .insideTuixiuWrap .premiumSpecArea .premiumDataBox li em:first-child {
    width: 1rem
  }
</style>
