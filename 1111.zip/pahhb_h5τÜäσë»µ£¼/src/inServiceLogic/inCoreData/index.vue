<template>
  <section class="box insideXubaoWrap insideYejiWrap">
    <!--<div class="insideXubaoWrap insideYejiWrap">-->
    <pts-header :title-text="titleContent" leftFlag @on-left="goMenu()" :showRight="showRight">
      <div class="textBanner" slot="center" v-if="innerAccountRoleType==='1'">
        <pts-text-scroll @input="changModel"></pts-text-scroll>
      </div>
      <div slot="right" class="flexBox">
        <img :src="dealerIcon" class="allSeries" @touchstart="getIcon"/>
        <a href="javascript:;" class="dataHeard_right poa text-hidden" style="max-width: 1.45rem;"
           @click.stop="showPopuPicker=true,selecAdName();">
          {{branchName}}
        </a>
      </div>
    </pts-header>
    <div class="wrap insideXubaoWrap insideYejiWrap">
      <!-- main start -->
      <div class="mainWrap pb100 pos-rel">
        <ul class="taskTitleArea c date-tab">
          <li class="pts-b-b" :class="{'cur':activeTab==='D'}" @click.stop="changTab('D')"><em>实时</em></li>
          <li class="pts-b-b" :class="{'cur':activeTab==='A'}" @click.stop="changTab('A')"><em>日</em></li>
          <li class="moreOption pts-b-b" :class="{'cur':activeTab==='B'}" @click.stop="changTab('B')">
            <em>{{monthValue.slice(4)|chineseMonth}}月<a href="javascript:;" otype="button" otitle="展开" class="openSlect"
                                                        :class="{arrowUp:showFlag}">展开</a></em>
          </li>
          <li class="pts-b-b" :class="{'cur':activeTab==='C'}" @click.stop="changTab('C')"><em>年</em></li>
        </ul>
        <div class="yejiTabArea" style="margin-top: -1px;">
          <!-- 实时 start -->
          <div v-if="activeTab==='D'">
            <div class="dataArea pt20 mb20">
              <ul class="analyBtnArea mb20">
                <li :class="{'cur':nowData.nowType==='0'}" @click="nowData.nowType='0',changeTax('D')">税后</li>
                <li :class="{'cur':nowData.nowType==='1'}" @click="nowData.nowType='1',changeTax('D')">税前</li>
              </ul>
              <p class="timeTxt">更新时间 {{nowData.updateTime}}</p>
              <div class="mb15 c">
                <div class="chartBoxImg echart_top">
                  <!--<img src="images/img_yejidate04.jpg" alt="" class="img_w_01">-->
                  <pts-echarts-pie :options="setPieOption" ref="nowPie"></pts-echarts-pie>
                </div>
                <ul class="chartBoxTxt m_b">
                  <li class="f_c_blue">新保<em class="m_em">{{nowData.nowType==='0'?(nowData.signAndCut.newInsurancePremCutTotal/10000).toFixed(2):(nowData.signAndTax.newInsurancePremCutTotal/10000).toFixed(2)|NumberThere}}</em>
                  </li>
                  <li class="f_c_green">转保<em class="m_em">{{nowData.nowType==='0'?(nowData.signAndCut.reiInsurancePremCutTotal/10000).toFixed(2):(nowData.signAndTax.reiInsurancePremCutTotal/10000).toFixed(2)|NumberThere}}</em>
                  </li>
                  <li class="f_c_yellow">续保<em class="m_em">{{nowData.nowType==='0'?(nowData.signAndCut.renInsurancePremCutTotal/10000).toFixed(2):(nowData.signAndTax.renInsurancePremCutTotal/10000).toFixed(2)|NumberThere}}</em>
                  </li>
                </ul>
              </div>
              <div class="chartDataBox">
                <dl>
                  <dt>交强险</dt>
                  <dd>
                    <em>{{nowData.nowType==='0'?(nowData.signAndCut.compulsoryInsurancePremTotal/10000).toFixed(2):(nowData.signAndTax.compulsoryInsurancePremTotal/10000).toFixed(2)|NumberThere}}</em>
                    <em>签单量：{{nowData.nowType==='0'?nowData.signAndCut.compulsoryInsurancePremNumTotal:nowData.signAndTax.compulsoryInsurancePremNumTotal|NumberThere}}</em>
                  </dd>
                </dl>
                <dl>
                  <dt>商业险</dt>
                  <dd>
                    <em>{{nowData.nowType==='0'?(nowData.signAndCut.commercialInsurancePremTotal/10000).toFixed(2):(nowData.signAndTax.commercialInsurancePremTotal/10000).toFixed(2)|NumberThere}}</em>
                    <em>签单量：{{nowData.nowType==='0'?nowData.signAndCut.commercialInsurancePremNumTotal:nowData.signAndTax.commercialInsurancePremNumTotal|NumberThere}}</em>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <!-- 实时 end -->

          <!-- 日 start -->
          <div v-if="activeTab==='A'">
            <div class="dataArea pt20 mb20">
              <ul class="analyBtnArea mb20">
                <li :class="{cur:dayTandC.dayType==='0'}" @click.stop="dayTandC.dayType='0',changeTax('A')">税后</li>
                <li :class="{cur:dayTandC.dayType==='1'}" @click.stop="dayTandC.dayType='1',changeTax('A')">税前</li>
              </ul>
              <p class="timeTxt">{{otherData.systemDate}}</p>
              <div class="mb15 c"><!--chartBox-->
                <div class="chartBoxImg echart_top">
                  <!--<img src="images/img_yejidate04.jpg" alt="" class="img_w_01">-->
                  <pts-echarts-pie :options="setPieOption" ref="dayPie"></pts-echarts-pie>
                </div>
                <div class="ul_m">
                  <ul class="chartBoxTxt m_b">
                    <li class="f_c_blue">新保<em class="m_em">{{otherData.newInsurancePremCutTotal}}</em></li>
                    <li class="f_c_green">转保<em class="m_em">{{otherData.reiInsurancePremCutTotal}}</em></li>
                    <li class="f_c_yellow">续保<em class="m_em">{{otherData.renInsurancePremCutTotal}}</em></li>
                  </ul>
                </div>
              </div>
              <div class="chartDataBox">
                <dl>
                  <dt>交强险</dt>
                  <dd>
                    <em :class="{lin_h : dayTandC.dayCalibreType==='1'}">{{otherData.compulsoryInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:dayTandC.dayCalibreType==='1'}">签单量：{{otherData.compulsoryInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
                <dl>
                  <dt>商业险</dt>
                  <dd>
                    <em :class="{lin_h : dayTandC.dayCalibreType==='1'}">{{otherData.commercialInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:dayTandC.dayCalibreType==='1'}">签单量：{{otherData.commercialInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
              </div>
              <ul class="tuixiuUnderBtnArea c">
                <li :class="{cur:dayTandC.dayCalibreType==='0'}"
                    @click="dayTandC.dayCalibreType='0',changeTax('A')"><a href="javascript:;" otype="button"
                                                                           otitle="签单口径">签单口径</a></li>
                <li :class="{cur:dayTandC.dayCalibreType==='1'}"
                    @click="dayTandC.dayCalibreType='1',changeTax('A')"><a href="javascript:;" otype="button"
                                                                           otitle="企划口径">企划口径</a></li>
              </ul>
            </div>
          </div>
          <!-- 日 end -->

          <!-- 月 start -->
          <div v-if="activeTab==='B'">
            <div class="dataArea pt20 mb20">
              <ul class="analyBtnArea mb20">
                <li :class="{cur:monthTandC.monthType==='0'}" @click.stop="monthTandC.monthType='0',changeTax('B')">税后
                </li>
                <li :class="{cur:monthTandC.monthType==='1'}" @click.stop="monthTandC.monthType='1',changeTax('B')">税前
                </li>
              </ul>
              <p class="timeTxt">{{otherData.systemDate}}</p>
              <div class="p_g" v-if="innerAccountRoleType==='1'"><!--前线角色才显示-->
                <!--<span><x-progress :percent="percent2" :show-cancel="false"></x-progress></span>-->
                <!--<P>计划保费500万</P>-->
                <div data="" class="weui-progress">
                  <div class="weui-progress__bar">
                    <div class="weui-progress__inner-bar"
                         :style="{width: Number(targetProData.targetProgress)+'%'}"></div>
                  </div>
                </div>
                <div class="p_f_s"><span>计划保费{{targetProData.targetPremium}}万<span class="s_left">缺口{{Math.abs(targetProData.exceedPremium)}}万<i
                  class="s_left">进度{{Number(targetProData.targetProgress)}}%</i></span></span>
                </div>
              </div>
              <div class="mb15 c"><!--chartBox-->
                <div class="chartBoxImg echart_top">
                  <pts-echarts-pie ref="monthPie" :options="setPieOption"></pts-echarts-pie>
                </div>
                <div class="ul_m">
                  <ul class="chartBoxTxt m_b">
                    <li class="f_c_blue">新保<span class="f_s">月增速<i
                      :class="Number(otherData.newInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.newInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.newInsurancePremCutTotal}}</em></li>
                    <li class="f_c_green">转保<span class="f_s">月增速<i
                      :class="Number(otherData.reiInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.reiInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.reiInsurancePremCutTotal}}</em></li>
                    <li class="f_c_yellow">续保<span class="f_s">月增速<i
                      :class="Number(otherData.renInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.renInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.renInsurancePremCutTotal}}</em></li>
                  </ul>
                </div>
              </div>
              <div class="chartDataBox">
                <dl class="self">
                  <dt class="selfLeft">交强险
                    <div class="left">
                      <span class="f_s_m" ref="jqxtb" v-if="nowMonth!==monthValue.slice(4)">同比<i
                      :class="Number(otherData.yoycompulsoryGrowth)<0?'i_r':'i_g'">{{otherData.yoycompulsoryGrowth}}%</i></span>
                    </div>
                    <div class="right">
                      <span class="f_s_m" ref="jqxhb" v-if="nowMonth!==monthValue.slice(4)">环比<i
                        :class="Number(otherData.momcompulsoryGrowth)<0?'i_r':'i_g'">{{otherData.momcompulsoryGrowth}}%</i></span>
                    </div>
                  </dt>
                  <dd class="selfRight">
                    <em :class="{lin_h : monthTandC.monthCalibreType==='1'}">{{otherData.compulsoryInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:monthTandC.monthCalibreType==='1'}">签单量：{{otherData.compulsoryInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
                <dl class="self">
                  <dt class="selfLeft">商业险
                    <div class="left">
                    <span class="f_s_m" ref="syxtb" v-if="nowMonth!==monthValue.slice(4)">同比<i
                      :class="Number(otherData.yoycommercialGrowth)<0?'i_r':'i_g'">{{otherData.yoycommercialGrowth}}%</i></span>
                    </div>
                    <div class="right">
                    <span class="f_s_m" ref="syxhb" v-show="nowMonth!==monthValue.slice(4)">环比<i
                      :class="Number(otherData.momcommercialGrowth)<0?'i_r':'i_g'">{{otherData.momcommercialGrowth}}%</i></span>

                    </div>
                  </dt>
                  <dd class="selfRight">
                    <em :class="{lin_h : monthTandC.monthCalibreType==='1'}">{{otherData.commercialInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:monthTandC.monthCalibreType==='1'}">签单量：{{otherData.commercialInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
              </div>
            </div>

            <div class="dataArea dataSpeArea pb15 mb20">
              <dl class="mb10">
                <dt>保费变化(万元)</dt>
                <dd>均值</dd>
              </dl>
              <div class="chartBox">
                <pts-echarts-bar ref="monthBar" :options="setBarOptions"></pts-echarts-bar>
                <!--<img src="images/img_yejidate02.jpg" alt="" class="img_w_02">-->
              </div>
              <ul class="trendAreaTipsYeji c">
                <li style="margin-bottom:.2rem;">工作日</li>
                <li style="margin-bottom:.2rem;">非工作日</li>
              </ul>
            </div>

            <div class="dataArea dataSpeArea pb15">
              <dl class="mb10">
                <dt>保费走势</dt>
              </dl>
              <div class="chartBox">
                <!--<img src="images/img_xubaodata_04.jpg" alt="" class="img_w_03">-->
                <pts-echarts-line ref="monthLineOne" :options="setLineOptions"></pts-echarts-line>
              </div>
              <ul class="trendAreaTips c">
                <li class="f_c_blue mgBot">新保</li>
                <li class="f_c_green mgBot">转保</li>
                <li class="f_c_yellow mgBot">续保</li>
              </ul>
            </div>

            <div class="dataArea dataSpeArea pb20 dataAreaYeji mb120">
              <div class="bor_line"></div>
              <div class="chartBox">
                <!--<img src="images/img_yejidate03.jpg" alt="" class="img_w_03">-->
                <pts-echarts-line ref="monthLineTwo" :options="setLineOptions"></pts-echarts-line>
              </div>
              <ul class="trendAreaTips c">
                <li class="f_c_blue">交强险</li>
                <li class="f_c_green">商业险</li>
              </ul>
            </div>
            <ul class="tuixiuUnderBtnArea c">
              <li :class="{cur:monthTandC.monthCalibreType==='0'}"
                  @click="monthTandC.monthCalibreType='0',changeTax('B')"><a href="javascript:;" otype="button"
                                                                             otitle="签单口径">签单口径</a></li>
              <li :class="{cur:monthTandC.monthCalibreType==='1'}"
                  @click="monthTandC.monthCalibreType='1',changeTax('B')"><a href="javascript:;" otype="button"
                                                                             otitle="企划口径">企划口径</a></li>
            </ul>
          </div>
          <!--<ul class="tuixiuUnderBtnArea c">-->
          <!--<li class="cur"><a href="javascript:;" otype="button" otitle="签单口径">签单口径</a></li>-->
          <!--<li><a href="javascript:;" otype="button" otitle="企划口径">企划口径</a></li>-->
          <!--</ul>-->
          <!-- 月 end -->

          <!-- 年 start -->
          <div v-if="activeTab==='C'" class="year">
            <div class="dataArea pt20 mb20">
              <ul class="analyBtnArea mb20">
                <li :class="{cur:yearTanC.yearType==='0'}" @click.stop="yearTanC.yearType='0',changeTax('C')">税后</li>
                <li :class="{cur:yearTanC.yearType==='1'}" @click.stop="yearTanC.yearType='1',changeTax('C')">税前</li>
              </ul>
              <p class="timeTxt">{{otherData.systemDate}}</p>
              <div class="mb15 c"><!--chartBox-->
                <div class="chartBoxImg echart_top">
                  <!--<img src="images/img_yejidate05.jpg" alt="" class="img_w_01">-->
                  <pts-echarts-pie ref="yearPie" :options="setPieOption"></pts-echarts-pie>
                </div>
                <div class="ul_m">
                  <ul class="chartBoxTxt m_b">
                    <li class="f_c_blue">新保<span class="f_s">年增速<i
                      :class="Number(otherData.newInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.newInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.newInsurancePremCutTotal|NumberThere}}</em></li>
                    <li class="f_c_green">转保<span class="f_s">年增速<i
                      :class="Number(otherData.reiInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.reiInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.reiInsurancePremCutTotal|NumberThere}}</em></li>
                    <li class="f_c_yellow">续保<span class="f_s">年增速<i
                      :class="Number(otherData.renInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.renInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.renInsurancePremCutTotal|NumberThere}}</em></li>
                  </ul>
                </div>
              </div>
              <div class="chartDataBox">
                <dl>
                  <dt>交强险
                    <span class="f_s">同比<i :class="Number(otherData.yoycompulsoryGrowth)<0?'i_r':'i_g'">{{otherData.yoycompulsoryGrowth}}%</i></span>
                  </dt>
                  <dd>
                    <em :class="{lin_h : yearTanC.yearCalibreType==='1'}">{{otherData.compulsoryInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:yearTanC.yearCalibreType==='1'}">签单量：{{otherData.compulsoryInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
                <dl>
                  <dt>商业险
                    <span class="f_s">同比<i :class="Number(otherData.yoycommercialGrowth)<0?'i_r':'i_g'">{{otherData.yoycommercialGrowth}}%</i></span>
                  </dt>
                  <dd>
                    <em :class="{lin_h : yearTanC.yearCalibreType==='1'}">{{otherData.commercialInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:yearTanC.yearCalibreType==='1'}">签单量：{{otherData.commercialInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
              </div>
            </div>

            <div class="dataArea dataSpeArea pb15">
              <div style="padding-top: .3rem;">
                <ul class="analyBtnArea mb10">
                  <li :class="{cur:!insAndyear}" @click.stop="insAndyear = !insAndyear,changeTax('C')">保费走势</li>
                  <li :class="{cur:insAndyear}" @click.stop="insAndyear = !insAndyear,changeTax('C')">环比&同比</li>
                </ul>
              </div>
              <!--<dl class="mb10">-->
              <!--<dt>保费走势</dt>-->
              <!--</dl>-->
              <div class="chartBox" v-if="!insAndyear">
                <pts-echarts-line ref="yearLineOne" :options="setLineOptions"></pts-echarts-line>
              </div>
              <div class="chartBox" v-if="insAndyear">
                <span>月增速</span>
                <pts-echarts-line ref="yearLineSone" :options="setLineOptions"></pts-echarts-line>
              </div>
              <ul class="trendAreaTips c">
                <li class="f_c_blue mgBot">新保</li>
                <li class="f_c_green mgBot">转保</li>
                <li class="f_c_yellow mgBot">续保</li>
              </ul>
            </div>

            <div class="dataArea dataSpeArea pb20 dataAreaYeji">
              <div class="bor_line"></div>
              <div class="chartBox" v-if="!insAndyear">
                <pts-echarts-line ref="yearLineTwo" :options="setLineOptions"></pts-echarts-line>
              </div>
              <div class="chartBox" v-if="insAndyear">
                <span>同比</span>
                <pts-echarts-line ref="yearLineStwo" :options="setLineOptions"></pts-echarts-line>
              </div>
              <ul class="trendAreaTips c" :class="{mb120:!insAndyear}">
                <li class="f_c_blue">交强险</li>
                <li class="f_c_green">商业险</li>
              </ul>
            </div>
            <div class="dataArea dataSpeArea pb20 dataAreaYeji" v-if="insAndyear">
              <div class="bor_line"></div>
              <div class="chartBox">
                <span>环比</span>
                <pts-echarts-line ref="yearLineSthree" :options="setLineOptions"></pts-echarts-line>
              </div>
              <ul class="trendAreaTips c mb120">
                <li class="f_c_blue">交强险</li>
                <li class="f_c_green">商业险</li>
              </ul>
            </div>
            <ul class="tuixiuUnderBtnArea c">
              <li :class="{cur:yearTanC.yearCalibreType==='0'}" @click="yearTanC.yearCalibreType='0',changeTax('C')"><a
                href="javascript:;" otype="button" otitle="签单口径">签单口径</a></li>
              <li :class="{cur:yearTanC.yearCalibreType==='1'}" @click="yearTanC.yearCalibreType='1',changeTax('C')"><a
                href="javascript:;" otype="button" otitle="企划口径">企划口径</a></li>
            </ul>
          </div>
          <!-- 年 end -->
        </div>
      </div>
      <!-- main end -->

      <!-- 遮罩层 start -->
      <div class="shade dn" id="shade"></div>
      <!--月份弹窗-->
      <!-- 遮罩层 end -->
    </div>
    <!--</div>-->
  </section>
</template>

<script>
  import {XProgress} from 'vux'
  import ptsEchartsPie from '../../common/comComponent/echarts/pie.vue'
  import ptsEchartsLine from '../../common/comComponent/echarts/line.vue'
  import ptsEchartsBar from '../../common/comComponent/echarts/bar.vue'
  import Axios from '../../common/js/axiosConfig'
  import API from '../../common/js/comConfig'
  import {chineseMonth} from '../../common/filters/convertDate'
  import {NumberThere} from '../../common/filters/convertAmount'
  import {remInPx, loadEcharts, roundTwo} from '../../common/js/comUtils'
  import ptsTextScroll from '../../common/comComponent/textScroll';
  import Toast from '../../common/comComponent/toast'

  const q_green = "image://" + require('./image/QLS.png');
  const q_blue = "image://" + require('./image/QNS.png');
  const q_yell = "image://" + require('./image/QHS.png');
  const date = new Date()
  const YEAR = date.getFullYear();
  const MONTH = date.getMonth() + 1;
  export default {
    name: "inCoreData",
    data() {
      return {
        titleContent: '业绩查询',
        showFlag: false,
        branchName: '',//机构名称  默认全国
        branchCode: '',//机构code
        innerAccountRoleType: '',//角色 1,2,3
        insAndyear: false,//保费走势和同比&环比的状态
        nowData: {
          nowType: '0', //0 税后  1 税前
          signAndCut: {},//税后
          signAndTax: {},//税前
          systemDate: '',
          updateTime: ''
        },
        dayTandC: {
          dayType: '0', //0 税后  1 税前
          dayCalibreType: '0',//0 签单 1 企划
        },
        monthTandC: {
          monthType: '0', //0 税后  1 税前
          monthCalibreType: '0',//0 签单 1 企划
        },
        yearTanC: {
          yearType: '0', //0 税后  1 税前
          yearCalibreType: '0',//0 签单 1 企划
        },
        otherData: {
          signAndCut: {},//签单口径税后
          signAndTax: {},//签单口径税前
          planAndTax: {}, //企划口径税前
          planAndCut: {},// 企划口径税后
          systemDate: '',
          updateTime: '',
          growthRate: '',//增速
          commercialInsurancePremTotal: '0',   //商业险保费
          commercialInsurancePremNumTotal: '0',  //商业险保费笔数
          compulsoryInsurancePremTotal: '0',      //交强险保费
          compulsoryInsurancePremNumTotal: '0',    //交强险保费笔数
          momcommercialGrowth: '',//商业险环比
          momcompulsoryGrowth: '',//交强险环比
          yoycommercialGrowth: '',//商业险同比
          yoycompulsoryGrowth: '',//交强险同比
          newInsuranceGrowthRate: '', //新保增数
          reiInsuranceGrowthRate: '', //转保增数
          renInsuranceGrowthRate: '', //续保增数
        },
        monthValue: `${YEAR}${MONTH > 10 ? MONTH : '0' + MONTH}`,
        yearAndMonth: `${YEAR}-${MONTH > 10 ? MONTH : '0' + MONTH}`,
        nowMonth: `${MONTH > 10 ? MONTH : '0' + MONTH}`,//选择的月份与本月做对比
        dealerIcon: require('../../common/images/allCarIcon.png'),
        activeTab: 'D', //tab栏的类型
        showRight: false,//是否显示头部右边
        trademarkId: '',//车型图标ID
        //饼状图
        setPieOption: {
          title: [
            {
              text: '总保费(万元)',
              textStyle: {
                fontSize: remInPx(0.26),
                fontWeight: 'normal',
                color: '#666',
              },
              top: '35%',
              left: 'center'
            },
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.5),
                fontWeight: 'normal',
                color: '#333',
              },
              top: '44%',
              left: 'center'
            }

          ],
          color: ['#559EFF', '#60D194', '#FFDB4B'],
          grid: {
            left: '0%',
            right: '10%',
            top: '10%',
            bottom: '0%',
            containLabel: true
          }, legend: {
            data: [],
          },
          series: [
            {
              name: '其实没什么用',
              type: 'pie',
              radius: ['60%', '75%'],
              hoverAnimation: false,
              data: [
                {
                  value: '',
                  name: '新保'
                },
                {
                  value: '',
                  name: '续保'
                },
                {
                  value: '',
                  name: '转报'
                }
              ]
            }
          ]
        },
        //柱状图
        setBarOptions: {
          legend: {
            // data: ['工作日','非工作日'],
            // top: 'bottom',
            // left: 'center',
            padding: [0, 0, 0, 0],
            itemWidth: remInPx(0.1),
            itemHeight: remInPx(0.1),
            // itemGap: 20,
            textStyle: {
              fontFamily: 'Microsoft YaHei',
              fontSize: remInPx(0.24),
              color: '#666666',
              lineHeight: remInPx(0.24),
            }
          },
          grid: {
            top: '7%',
            left: '3%',
            right: '4%',
            // bottom: '8%'
          },
          xAxis: [
            {
              type: 'category',
              show: false,
              data: ['工作日', '非工作日']
            }
          ],
          yAxis: [
            {
              type: 'value',
              show: true,
              axisLine: {
                show: false,
              },
              axisTick: {
                show: false,
              },
              splitLine: {
                show: true,
                lineStyle: {
                  color: ['#DBDBDB'],
                  type: 'dotted'
                }
              },
              axisLabel: {
                color: '#999999',
                fontSize: remInPx(0.26)
              }
            }
          ],
          tooltip: {
            trigger: 'axis',
            formatter: '{b}:{c0}',
            axisPointer: {
              animation: false,
              lineStyle: {
                color: '#FE8F46'
              },
            },
            backgroundColor: '#FFE0CB',
            textStyle: {
              color: '#FF954E'
            },
          },
          series: [
            {
              // name: '增速',
              type: 'line',
              // stack: '保费',
              // name:'均值',
              yAxisIndex: 0,
              label: {
                normal: {
                  show: false,
                  position: 'top',
                }
              },
              itemStyle: {
                color: '#FFDB4B'
              },
              lineStyle: {
                color: '#FFDB4B',
                normal: {
                  // width: 3,
                  // shadowColor: 'rgba(0,0,0,0.4)',
                  // shadowBlur: 10,
                  // shadowOffsetY: 10
                }
              },

              data: []
            },
            {
              // name: '工作日',
              // barCategoryGap: '100%',
              // barGap: '-100%', // Make series be overlap
              type: 'bar',
              stack: '保费',
              barWidth: 40,
              data: [],
              label: {
                normal: {
                  position: 'top',
                  show: true,
                  textStyle: {
                    color: '#666666'
                  }
                },
              },
              itemStyle: {
                normal: {
                  position: 'top',
                  color: function (val) {
                    let colorList = ['#549DFF', '#60D194'];
                    return colorList[val.dataIndex];
                  }
                },
                // emphasis: {
                //   position: 'top',
                //   color: ['#549DFF','#60D194']
                // }
              }
            }
          ]
        },
        setLineOptions: {
          color: ['#559EFF', '#60D194', '#FFDB4B'],
          title: [
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.25),
                fontWeight: 'normal',
                color: '#999999',
              },
              top: '80%',
              left: '2%',
            },
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.25),
                fontWeight: 'normal',
                color: '#999999'
              },
              top: '80%',
              left: '78%',
            }
          ],
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              animation: false,
              lineStyle: {
                color: '#FE8F46'
              }
            },
            backgroundColor: '#FFE0CB',
            textStyle: {
              color: '#FF954E'
            }
          },
          legend: {
            // data: ['送修', '返修', '三者'],
            left: 'center',
            itemWidth: remInPx(0.1),
            itemHeight: remInPx(0.1),
            itemGap: 40,
            // bottom:20,
            textStyle: {
              fontFamily: 'Microsoft YaHei',
              fontSize: remInPx(0.22),
              color: '#666',
              lineHeight: remInPx(0.22),
            }
          },
          grid: {
            top: '10',
            bottom: '5%',
            right: '1%'
          },
          xAxis: {
            type: 'category',
            boundaryGap: false,
            show: false,
            data: [],
            axisLine: {
              show: false,
            },
            axisTick: {
              show: false,
            }
          },
          yAxis: [
            {
              splitNumber: 5,
              type: 'value',
              show: true,
              axisLine: {
                show: false,
              },
              axisTick: {
                show: false,
              },
              splitLine: {
                show: true,
                lineStyle: {
                  color: ['#DBDBDB'],
                  type: 'dotted'
                }
              },
              axisLabel: {
                color: '#999999',
                fontSize: remInPx(0.26)
              }
            }
          ],
          series: [
            {
              // name: '',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            },
            {
              // name: '',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            },
            {
              // name: '',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [],
            },
          ]
        },  //折线图
        lineYmaxOne: '',//Y轴最大值 新 转 续
        lineYmaxTwo: '', //Y轴最大值 交强 商业
        lineYMaxThree: '',//年的月增数最大值
        lineYmaxFour: '',//年的同比
        lineYmaxFive: '',//年的环比
        typeList: ['税后', '税前'],  //用于数据埋点
        caList: ['签单口径', '企划口径'],//用于数据埋点
        timeData: { //用于数据埋点
          'D': '-实时-',
          'A': '-日报-',
          'B': '-月报-',
          'C': '-年报-'
        },
        targetProData: {
          exceedPremium: '',//超出保费或者缺口保费
          targetPremium: '',//目标保费
          percent2: 15,  //完成进度
        }


      }
    },
    /**
     * 获取机构的名字和code
     *
     * */
    activated() {
      // this.$nextTick(function () {
      // })
      if (this.$route.query.adName) {
        let self = this;
        this.dealerIcon = require('../../common/images/allCarIcon.png');
        this.trademarkId = '';
        this.branchName = this.$route.query.adName || '全国';
        this.branchCode = this.$route.query.adCode;
        let reqData = {
          branchCode: this.branchCode || '',//机构编码
          queryType: this.activeTab, //查询类型
          queryValue: this.activeTab === 'B' ? self.monthValue || YEAR + `${MONTH > 10 ? MONTH : "0" + Mo}` : undefined, //类型的值
          trademarkId: this.trademarkId || ''
        }
        this.$nextTick(function () {
          //实时 网点查询
          if (this.activeTab === 'D') {
            self.getRealTime('nowPie', self.nowData.nowType, reqData);
          } else {//日月年 数据查询
            self.getData(self.activeTab, '', reqData);
          }
        })
      }
      // console.log(this.$route.query.adName +"===="+ this.$route.query.adCode);
    },
    mounted() {
      // this.trademarkId = 'BTA';//模拟数据
      this.branchName = window.dealerData.deptName || ''; //首次进来角色的机构名称
      this.branchCode = window.dealerData.deptCode || ''; //内部端 机构code
      this.innerAccountRoleType = window.dealerData.innerAccountRoleType;
      console.log(this.branchCode + "====" + this.innerAccountRoleType);
      window.eventAnalytics("队伍端_业绩查询", `${this.caList[this.dayTandC.dayType] + "-实时"}`);
      this.showRight = (window.dealerData.innerAccountRoleType === '2') || (window.dealerData.innerAccountRoleType === '3');
      let reqData = {
        branchCode: this.branchCode || '',//机构编码
        queryType: this.activeTab, //查询类型
        queryValue: this.activeTab === 'B' ? self.monthValue || MONTH : undefined, //类型的值
        trademarkId: this.trademarkId || ''
      }
      this.$nextTick(function () {
        this.getRealTime('nowPie', this.nowData.nowType, reqData);
      })
    },
    methods: {
      /**
       * 返回首页
       * */
      goMenu() {
        Native.requestHybrid({
          tagname: 'backHome'
        });
      },
      /**
       * 走马灯 选择
       **/
      changModel(val) {
        window.eventAnalytics("队伍端_业绩查询", "网点选择");
        let self = this
        this.branchCode = val;
        let reqData = {
          branchCode: this.branchCode || '',//机构编码
          queryType: this.activeTab, //查询类型
          queryValue: this.activeTab === 'B' ? self.monthValue || YEAR + `${MONTH > 10 ? MONTH : "0" + MONTH}` : undefined, //类型的值
          trademarkId: this.trademarkId || ''
        }
        //实时 网点查询
        if (this.activeTab === 'D') {
          self.getRealTime('nowPie', self.nowData.nowType, reqData);
        } else {//日月年 数据查询
          self.getData(self.activeTab, '', reqData);
        }

      },
      /**
       * 获取车行图标
       */
      getIcon() {
        window.eventAnalytics("队伍端_业绩查询", "品牌筛选");
        let self = this;
        let obj = {
          branchCode: this.branchCode || '',//机构编码
          queryType: this.activeTab, //查询类型
          queryValue: this.activeTab === 'B' ? self.monthValue || YEAR + `${MONTH > 10 ? MONTH : "0" + MONTH}` : undefined //类型的值
        };
        //console.log("开始调用。。。。")
        Native.requestHybrid({
          tagname: 'getDealerIcon',
          param: obj,
          callback: function (req) {
            //console.log("Icon:"+reqData);
            self.dealerIcon = req.data.dealerIcon || "";
            self.trademarkId = req.data.trademarkId || "";
            const reqData = {
              branchCode: self.branchCode || '',//机构编码
              queryType: self.activeTab,
              queryValue: self.activeTab === 'B' ? self.monthValue || YEAR + `${MONTH > 10 ? MONTH : "0" + MONTH}` : undefined, //类型的值
              trademarkId: self.trademarkId
            }
            //console.log("类型"+this.activeTab)
            if (self.activeTab != 'D') {
              self.getData(self.activeTab, '', reqData);
            } else {
              self.getRealTime('nowPie', self.nowData.nowType, reqData);
            }
          }
        })
      },
      /**
       * 获取网点名称
       * */
      selecAdName() {
        window.eventAnalytics("队伍端_业绩查询", "机构筛选");
        this.$router.push({path: 'selectOrganization'});
      },
      /**
       * 切换业绩查询tab栏
       * @param val
       */
      changTab(type) {
        let self = this;
        let reqData = {};
        if ((type === 'D' || type === 'A' || type === "C") && this.activeTab === type) {
          return
        }
        switch (type) {
          case 'A':
            //window.eventAnalytics("内部端业绩查询", "查看日数据");
            window.eventAnalytics("队伍端_业绩查询", `${this.caList[this.dayTandC.dayCalibreType] + this.timeData[type] + this.typeList[this.dayTandC.dayType]}`);
            reqData = {
              queryType: type,
              branchCode: this.branchCode || '',
              trademarkId: this.trademarkId || ''
            };
            this.$nextTick(function () {
              this.getData(type, "", reqData);
            });
            break;
          case 'B':
            //window.eventAnalytics("内部端业绩查询", "查看月份数据");

            let month = date.getMonth() + 1;
            let newMonth = 12 - month === 0 ? 1 : month + 1;
            let year = date.getFullYear();
            // this.yearAndMonth =
            console.log(newMonth);
            if (self.activeTab === type) {
              this.showFlag = true;
              this.$vux.datetime.show({
                value: this.yearAndMonth,
                cancelText: '取消',
                confirmText: '确定',
                format: 'YYYY-MM',
                minYear: year - 1,
                maxYear: year,
                startDate: `${year - 1}-${newMonth > 10 ? newMonth : '0' + newMonth}-01`,
                endDate: `${year}-${month > 10 ? '0' + month : month}-01`,
                onConfirm: (a) => {
                  window.eventAnalytics("队伍端_业绩查询", `${this.caList[this.monthTandC.monthCalibreType] + this.timeData[type] + '选择月份' + this.typeList[this.monthTandC.monthType]}`);
                  if (this.yearAndMonth === a) return
                  // this.monthValue = a
                  this.monthValue = a.replace('-', '');
                  // this.monthValue = this.selectMonth
                  this.yearAndMonth = a;
                  reqData = {
                    queryType: type,
                    queryValue: this.monthValue,//`${this.monthValue > 10 ? this.monthValue : '0' + this.monthValue}`,
                    branchCode: this.branchCode || '',
                    trademarkId: this.trademarkId || ''
                  }
                  this.getData(type, month, reqData);
                  this.innerAccountRoleType === '1' && this.getTargetProgress(reqData);
                  // this.getWorkData(type, month, reqData);
                },
                onShow: () => {
                  //window.eventAnalytics("内部端-业绩查询", "点击了切换月份", {'confirmBtn': '点击了切换月份的确认按钮'});
                  this.showDateTime = true;
                },
                onHide: () => {
                  this.showFlag = false;
                  //window.eventAnalytics("内部端-业绩查询", "点击了切换月份", {'cancelBtn': '点击了切换月份的取消按钮'});
                  this.showDateTime = false;
                }
              })
            } else {
              //window.eventAnalytics("内部端业绩查询", "查看实时数据");
              window.eventAnalytics("队伍端_业绩查询", `${this.caList[this.monthTandC.monthCalibreType] + this.timeData[type] + this.typeList[this.monthTandC.monthType]}`);
              reqData = {
                queryType: type,
                queryValue: this.monthValue,//year + `${month > 10 ? month : "0" + month}`,//this.monthValue > 10 ? this.monthValue : '0' + this.monthValue || month > 10 ? month : '0' + month,
                branchCode: this.branchCode || '',
                trademarkId: this.trademarkId || ''
              }
              this.getData(type, this.monthValue, reqData);
              this.innerAccountRoleType === '1' && this.getTargetProgress(reqData);
              // this.getWorkData(type, this.monthValue, reqData);
            }
            break;
          case 'C':
            // window.eventAnalytics("内部端业绩查询", "查看年数据");
            window.eventAnalytics("队伍端_业绩查询", `${this.caList[this.yearTanC.yearCalibreType] + this.timeData[type] + this.typeList[this.yearTanC.yearType]}`);
            reqData = {
              queryType: type,
              branchCode: this.branchCode || '',
              trademarkId: this.trademarkId || ''
            };
            this.$nextTick(function () {
              this.getData(type, "", reqData);
            });
            break;
          case'D':
            window.eventAnalytics("队伍端_业绩查询", `${this.typeList[this.nowData.nowType] + "-实时"}`);
            reqData = {
              queryType: type,
              branchCode: this.branchCode || '',
              trademarkId: this.trademarkId || ''
            }
            this.$nextTick(function () {
              this.getRealTime('nowPie', self.nowData.nowType, reqData);
            })
            break;
          default:
            break;
        }
        this.activeTab = type;
      },
      /**
       * 获取 税前 税后 企划 签单
       * */
      changeTax(tType) {
        let self = this;
        let pieData = {};
        if (tType === 'A') {  //日
          window.eventAnalytics("队伍端_业绩查询", `${this.caList[this.dayTandC.dayCalibreType] + this.timeData[tType] + this.typeList[this.dayTandC.dayType]}`);
          pieData = this.packPieData(this.dayTandC.dayType, this.dayTandC.dayCalibreType);
          this.getInsData(tType,pieData);
          this.getPieData('dayPie', pieData);
        } else if (tType === 'B') { //月
          window.eventAnalytics("队伍端_业绩查询", `${this.caList[this.monthTandC.monthCalibreType] + this.timeData[tType] + this.typeList[this.monthTandC.monthType]}`);
          pieData = this.packPieData(this.monthTandC.monthType, this.monthTandC.monthCalibreType);
          this.getInsData(tType,pieData);
          this.getPieData('monthPie', pieData);
          this.getBarData('monthBar', pieData);
          this.getLineData(['monthLineOne', 'monthLineTwo'], pieData);
        } else if (tType == 'C') {  //年
          window.eventAnalytics("队伍端_业绩查询", `${this.caList[this.yearTanC.yearCalibreType] + this.timeData[tType] + this.typeList[this.yearTanC.yearType]}`);
          pieData = this.packPieData(this.yearTanC.yearType, this.yearTanC.yearCalibreType);
          this.getInsData(tType,pieData);
          this.getPieData('yearPie', pieData);
          // this.getLineData(['yearLineOne', 'yearLineTwo'], pieData);
          if (this.insAndyear) {
            this.getLineInsAndYearData(['yearLineSone', 'yearLineStwo', 'yearLineSthree'], pieData);
          } else {
            this.getLineData(['yearLineOne', 'yearLineTwo'], pieData);
          }
        } else {
          window.eventAnalytics("队伍端_业绩查询", `${this.typeList[this.nowData.nowType] + "-实时"}`);
          pieData = this.nowData.nowType === '0' ? self.nowData.signAndCut : self.nowData.signAndTax;
          this.getPieData('nowPie', pieData);
        }
      },
      /**
       * 获得pieData 数据
       * ttype 税前 税后
       * ctype 口径类型
       **/
      packPieData(ttype, ctype) {
        console.log(ttype, ctype)
        let self = this;
        let pieData = {};
        if (ttype === '1') {  //税前
          pieData = ctype === '0' ? self.otherData.signAndTax : self.otherData.planAndTax;
        } else {
          pieData = ctype === '0' ? self.otherData.signAndCut : self.otherData.planAndCut;
        }
        return pieData;
      },
      /**
       * 获取实时数据
       * elem 类型
       * type 税前 税后
       **/
      getRealTime(elem, type, reqData) {
        let self = this;
        //"http://localhost:8888/postGetData"
        // "http://localhost:8888/postGetData", {
        //   "path": 'car',
        //   "file": 'queryInnerTimelyCoreData'
        // }
        //API.getWebServiceUrls('queryInnerTimelyCoreData'),reqData
        Axios.post(API.getWebServiceUrls('queryInnerTimelyCoreData'), reqData).then(res => {
          let resData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          console.log(resData);
          if (resData.code === 0 || resData.code === '0') {
            self.nowData.signAndCut = resData.data.signAndCut;//税后
            self.nowData.signAndTax = resData.data.signAndTax;//税前
            self.nowData.systemDate = resData.data.systemDate; //系统时间
            self.nowData.updateTime = resData.data.updateTime; //更新时间
            let pieData = type === '0' ? self.nowData.signAndCut : self.nowData.signAndTax;
            this.getPieData(elem, pieData);
          } else {
            Toast(resData.msg || "系统繁忙请稍后重试");
          }
        }).catch(err => {
          console.log(err);
        })
      },
      /*
       * @info 发起ajax请求 并设置图标数据的函数
       * @param type {String}  实时(A) 当月(C) or 当日(B) or 当年(D)
       * @param month {String || Number} 用户选择的月份
       * */
      getData(type, month, reqData) {
        console.log(reqData);
        let _this = this;
        //API.getWebServiceUrls('queryInnerCoreData')
        // "http://localhost:8888/postGetData", {
        //   "file": "queryInnerCoreData",
        //   "path": "car"
        // }
        //
        Axios.post(API.getWebServiceUrls('queryInnerCoreData'), reqData).then(res => {
          const resData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (resData.code === 0 || resData.code === '0') {
            //_this.otherData 日 月 年数据
            _this.otherData.systemDate = resData.data.systemDate;
            _this.otherData.updateTime = resData.data.updateTime;
            _this.otherData.yearAndMonth = resData.data.yearAndMonth;
            _this.otherData.planAndCut = resData.data.planAndCut;  //企划
            _this.otherData.planAndTax = resData.data.planAndTax;
            _this.otherData.signAndCut = resData.data.signAndCut;  //签单
            _this.otherData.signAndTax = resData.data.signAndTax;
            // _this.changeTax(type);
            if (type === "B") {
              this.changeTax(type);
              this.getWorkData(type, month, reqData);
            } else {
              _this.changeTax(type);
            }
          } else {
            Toast('系统繁忙请稍后重试');
          }
        }).catch(err => {
          console.log(err);
        })
      },
      /*
       * @info 发起ajax请求 获取工作日和非工作日数据
       * @param type {String}  实时(A) 当月(C) or 当日(B) or 当年(D)
       * @param month {String || Number} 用户选择的月份
       * */
      //"http://localhost:8888/postGetData", {
      // "file": 'queryInnerCoreDataWorking',
      // "path": 'car'
      //}
      getWorkData(type, month, reqData) {
        const _this = this;
        Axios.post(API.getWebServiceUrls('queryInnerCoreDataWorking'), reqData, {loading: false}).then(res => {
          let resData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (resData.code === 0 || resData.code === '0') {
            _this.otherData.planAndCut = Object.assign(_this.otherData.planAndCut, resData.data.planAndCut);  //企划
            _this.otherData.planAndTax = Object.assign(_this.otherData.planAndTax, resData.data.planAndTax);
            _this.otherData.signAndCut = Object.assign(_this.otherData.signAndCut, resData.data.signAndCut);  //签单
            _this.otherData.signAndTax = Object.assign(_this.otherData.signAndTax, resData.data.signAndTax);
            _this.changeTax(type);
          } else {
            Toast('系统繁忙请稍后重试');
          }
        }).catch(err => {
          console.log(err);
        });
      },
      /**
       * 商业险 交强险 环比 同比 保费 笔数等数据复制
       */
      getInsData(type, pieData) {

        if (this.type != 'D') {
          this.dayTandC.growthRate = pieData.growthRate || "0";//增速
          this.otherData.commercialInsurancePremTotal = roundTwo(pieData.commercialInsurancePremTotal);//商业险保费
          this.otherData.commercialInsurancePremNumTotal = pieData.commercialInsurancePremNumTotal;//商业险保费笔数
          this.otherData.compulsoryInsurancePremTotal = roundTwo(pieData.compulsoryInsurancePremTotal);//交强险保费
          this.otherData.compulsoryInsurancePremNumTotal = pieData.compulsoryInsurancePremNumTotal;//交强险保费笔数
          this.otherData.newInsurancePremCutTotal = roundTwo(pieData.newInsurancePremCutTotal);//新保保费
          this.otherData.reiInsurancePremCutTotal = roundTwo(pieData.reiInsurancePremCutTotal);//转保费
          this.otherData.renInsurancePremCutTotal = roundTwo(pieData.renInsurancePremCutTotal);//续保保费
          // if (this.nowMonth !== this.monthValue.slice(4)) {
          this.otherData.momcommercialGrowth = pieData.momcommercialGrowth || 0; //商业险环比
          this.otherData.momcompulsoryGrowth = pieData.momcompulsoryGrowth || 0;//交强险环比
          this.otherData.yoycommercialGrowth = pieData.yoycommercialGrowth || 0; //商业险同比
          this.otherData.yoycompulsoryGrowth = pieData.yoycompulsoryGrowth || 0; //交强想同比
          // }
          this.otherData.newInsuranceGrowthRate = pieData.newInsuranceGrowthRate || 0; //新保增速
          this.otherData.reiInsuranceGrowthRate = pieData.reiInsuranceGrowthRate || 0; //转保增速
          this.otherData.renInsuranceGrowthRate = pieData.renInsuranceGrowthRate || 0; //续保增速
        }
        // console.log((~~this.monthValue.slice(4)-1),(~~this.nowMonth-1));
        // if((~~this.monthValue.slice(4))===(~~this.nowMonth-1)){
        //   this.getElement(pieData);
        // }
      },
      /**
       * 获取同比 环比的 dom
       */
     /* getElement(pieData) {
        if (
          this.$refs.jqxtb &&
          this.$refs.jqxhb &&
          this.$refs.syxtb &&
          this.$refs.syxhb
        ) {
          let jqxtb = this.$refs.jqxtb.getElementsByTagName('i')[0]
          let jqxhb = this.$refs.jqxhb.getElementsByTagName('i')[0]
          let syxtb = this.$refs.syxtb.getElementsByTagName('i')[0]
          let syxhb = this.$refs.syxhb.getElementsByTagName('i')[0]

          jqxtb.innerHTML = pieData.yoycompulsoryGrowth + '%'
          jqxhb.innerHTML = pieData.momcompulsoryGrowth + '%'
          syxtb.innerHTML = pieData.yoycommercialGrowth + '%'
          syxhb.innerHTML = pieData.momcommercialGrowth + '%'

          jqxtb.className = ''
          jqxhb.className = ''
          syxtb.className = ''
          syxhb.className = ''

          pieData.yoycompulsoryGrowth < 0
            ? (jqxtb.className += 'i_r')
            : (jqxtb.className += 'i_g')
          pieData.momcompulsoryGrowth < 0
            ? (jqxhb.className += 'i_r')
            : (jqxhb.className += 'i_g')
          pieData.yoycommercialGrowth < 0
            ? (syxtb.className += 'i_r')
            : (syxtb.className += 'i_g')
          pieData.momcommercialGrowth < 0
            ? (syxhb.className += 'i_r')
            : (syxhb.className += 'i_g')
        }
      },*/
      /**
       * 饼状图
       * @param elem type elem string
       * @param pieData type object
       */
      getPieData(elem, pieData) {
        let self = this;
        let totalPremium = 0;//总保费
        let title = []; //圆的标题
        let realData = pieData;//type === '0' ? self.nowData.signAndCut : self.nowData.signAndTax;
        //价格先加在去两位
        //totalPremium = ((Number(realData.newInsurancePremCutTotal) + Number(realData.reiInsurancePremCutTotal) + Number(realData.renInsurancePremCutTotal)) / 10000).toFixed(2);
        //价格先取两位在加
        totalPremium = (roundTwo(Number(realData.newInsurancePremCutTotal)) + roundTwo(Number(realData.reiInsurancePremCutTotal)) + roundTwo(Number(realData.renInsurancePremCutTotal)));
        totalPremium = totalPremium.toFixed(2);
        if (this.activeTab != 'D' && this.activeTab != 'A') {
          let core_color = Number(self.dayTandC.growthRate) < 0 ? "#FE3A3A" : "#2BAF64";
          title = [
            {},
            {
              text: (function (value) {
                if (Number.isNaN(Number(value))) {
                  return value;
                }
                if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
                  return Number(value).toLocaleString();
                } else {
                  return value;
                }
              })(totalPremium)
            },
            {
              text: ((self.activeTab === 'B' ? '月增速' : '累计增速') + Number(self.dayTandC.growthRate) + "%"),//Number(self.dayTandC.growthRate) < 0 ? '' : ((self.activeTab === 'B' ? '月增速' : '累计增速') + self.dayTandC.growthRate),
              textStyle: {
                fontSize: remInPx(0.23),
                fontWeight: 'normal',
                color: core_color,
              },
              top: '60%',
              left: 'center'
            }
          ];
        } else {
          title = [
            {},
            {
              text: (function (value) {
                if (Number.isNaN(Number(value))) {
                  return value;
                }
                if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
                  return Number(value).toLocaleString();
                } else {
                  return value;
                }
              })(totalPremium)
            }, {
              text: ''
            }
          ];
        }
        // if(self.activeTab!='D'){
        // }else{
        //   totalPremium =()
        // }
        this.$nextTick(function () {
          self.$refs[elem].setData(function (echarts) {
            echarts.setOption({
              title: title,
              series: [
                {
                  data: [
                    {
                      value: realData.newInsurancePremCutTotal,
                      name: Number(realData.newInsurancePremCutTotal) === 0 ? "" : (realData.newInsurancePremCutTotal / 10000).toFixed(2),
                      label: {show: Number(realData.newInsurancePremCutTotal) === 0 ? false : true},
                      labelLine: {
                        show: Number(realData.newInsurancePremCutTotal) === 0 ? false : true,
                        length: 5,
                        length2: 10
                      },
                      itemStyle: {color: '#559EFF'}
                    },
                    {
                      value: realData.reiInsurancePremCutTotal,
                      name: Number(realData.reiInsurancePremCutTotal) === 0 ? "" : (realData.reiInsurancePremCutTotal / 10000).toFixed(2),
                      label: {show: Number(realData.reiInsurancePremCutTotal) === 0 ? false : true},
                      labelLine: {
                        show: Number(realData.reiInsurancePremCutTotal) === 0 ? false : true,
                        length: 5,
                        length2: 10
                      },
                      itemStyle: {color: '#60D194'}
                    },
                    {
                      value: realData.renInsurancePremCutTotal,
                      name: Number(realData.renInsurancePremCutTotal) === 0 ? "" : (realData.renInsurancePremCutTotal / 10000).toFixed(2),
                      label: {
                        show: Number(realData.renInsurancePremCutTotal) === 0 ? false : true,
                      },
                      labelLine: {
                        show: Number(realData.renInsurancePremCutTotal) === 0 ? false : true,
                        length: 5,
                        length2: 10
                      },
                      itemStyle: {color: '#FFDB4B'}
                    }
                  ]
                }
              ]
            })
          })

        })
      },
      getBarData(elem, pieData) {
        let self = this;
        //工作日和非工作日数据
        let insuranceAmountChange = pieData.insuranceAmountChange;
        let dayTotalArr = [], dayAvgArr = [];
        dayTotalArr = [(insuranceAmountChange.totalAmountWeekday / 10000).toFixed(2), (insuranceAmountChange.totalAmountNonWeekday / 10000).toFixed(2)];
        dayAvgArr = [(insuranceAmountChange.averageWeekday / 10000).toFixed(2), (insuranceAmountChange.averageNonWeekday / 10000).toFixed(2)];
        let maxData = Array.prototype.concat.call([], dayTotalArr);
        let maxValue = ~~Math.max.apply(Math, maxData);
        this.$nextTick(function () {
          self.$refs[elem].setData(function (echarts) {
            echarts.setOption({
              series: [{
                data: dayAvgArr
              }, {
                data: dayTotalArr,
              }],
              yAxis: {
                minInterval: Math.ceil(maxValue / 4)//+(20-Math.ceil(maxValue / 4)%10)
              },
            })
          })
        });
      },
      getLineData(elem, pieData) {
        //获得X轴数据
        let self = this;
        let xData = [];
        let arrOne = [], newInsur = [], reiInsur = [], renInsur = [];
        let arrtwo = [], compul = [], commerc = [];
        let totalArr = [];
        if (pieData.premiumQueryResults && pieData.premiumQueryResults.length > 0) {
          for (let n = 0; n < pieData.premiumQueryResults.length; n++) {
            xData.push(pieData.premiumQueryResults[n].dataTime);
            newInsur.push((pieData.premiumQueryResults[n].newInsurancePrem / 10000).toFixed(2));//新保保费
            reiInsur.push((pieData.premiumQueryResults[n].reiInsurancePrem / 10000).toFixed(2));//转保保费
            renInsur.push((pieData.premiumQueryResults[n].renInsurancePrem / 10000).toFixed(2));//续保保费

            compul.push((pieData.insPremiumResults[n].compulsoryInsurancePrem / 10000).toFixed(2));//交强险
            commerc.push((pieData.insPremiumResults[n].commercialInsurancePrem / 10000).toFixed(2));//商业险
          }
        }
        let findMaxOne = Array.prototype.concat.call([], newInsur, reiInsur, renInsur);
        this.lineYmaxOne = ~~Math.max.apply(Math, findMaxOne);
        arrOne.push({data: newInsur, type: 'line', name: '新保'}, {
          data: reiInsur,
          type: 'line',
          name: '转保',
          showSymbol: true
        }, {data: renInsur, type: 'line', name: '续保'});
        arrtwo.push({data: compul, type: 'line', name: '交强险'}, {
          data: commerc,
          type: 'line',
          name: '商业险'
        });
        let findMaxTwo = Array.prototype.concat.call([], compul, commerc);
        this.lineYmaxTwo = ~~Math.max.apply(Math, findMaxTwo);
        totalArr.push(arrOne, arrtwo);
        elem.forEach((v, i) => {
          this.$nextTick(function () {
            self.$refs[v].setData(function (echarts) {
              echarts.setOption({
                xAxis: {
                  data: xData
                },
                legend: {
                  data: [
                    {name: self.CZDA, icon: q_green},
                    {name: self.TXDA, icon: q_yell},
                    {name: self.WXDA, icon: q_blue}]
                },
                yAxis: {
                  minInterval: Math.ceil((i === 0 ? self.lineYmaxOne : self.lineYmaxTwo) / 4)
                },
                title: [
                  {
                    text: xData[0],
                    bottom: '5px'
                    //text: `01` // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                  },
                  {
                    text: xData[xData.length - 1],
                    bottom: '5px'
                    //text: `${xDatas.length > 9 ? xDatas.length : '0' + xDatas.length}` // ${~~xStart > 9 ? xStart : '0' + xStart}.${xData.length > 9 ? xData.length : '0' + xData.length}
                  }
                ],
                tooltip: {
                  trigger: 'axis',
                  formatter: function (a) {
                    let arr = [
                      a.length > 0 ? a[0].axisValue + '<br/>' : ''
                    ];
                    a.forEach(v => {
                      arr.push(`${v.seriesName}: ${v.value}<br/>`);
                    })
                    return arr.join('');
                  },
                  axisPointer: {
                    animation: false,
                    lineStyle: {
                      color: '#FE8F46'
                    }
                  },
                  backgroundColor: '#FFE0CB',
                  textStyle: {
                    color: '#FF954E'
                  }
                },
                series: totalArr[i]
              });

            });
          })
        });


      },
      /**
       * 年的月增数 同比 环比
       */
      getLineInsAndYearData(elem, pieData) {
        console.log(elem, pieData);
        //获得X轴数据
        let self = this;
        let xData = [];
        // Y 交强险 L 商业险  mom环比  yoy 同比
        //交强险的环比 交强险的同比 商业险的环比 商业险的同比
        let momYArr = [], yoyYArr = [], momLArr = [], yoyLArr = [], arrThree = [], arrFour = [];
        let newMRate = [], reiMRate = [], renMRate = [], yearInMSpeedArr = [];
        let totalArr = [];
        if (pieData.premiumQueryResults && pieData.premiumQueryResults.length > 0) {
          for (let n = 0; n < pieData.premiumQueryResults.length; n++) {
            xData.push(pieData.premiumQueryResults[n].dataTime);
            momYArr.push(pieData.insPremiumResults[n].momcompulsoryGrowth); //交强险环比
            yoyYArr.push(pieData.insPremiumResults[n].yoycompulsoryGrowth); //交强险同比
            momLArr.push(pieData.insPremiumResults[n].momcommercialGrowth); //商业险环比
            yoyLArr.push(pieData.insPremiumResults[n].yoycommercialGrowth); //商业险同比
            newMRate.push(pieData.premiumQueryResults[n].newMonGrowthRate); //年的新保月增数
            reiMRate.push(pieData.premiumQueryResults[n].reiMonGrowthRate); //年的转保月增数
            renMRate.push(pieData.premiumQueryResults[n].renMonGrowthRate); //年的续保月增数
          }
        }
        let findMaxThree = Array.prototype.concat.call([], newMRate, reiMRate, renMRate);
        this.lineYMaxThree = ~~Math.max.apply(Math, findMaxThree);
        let findMaxFour = Array.prototype.concat.call([], yoyYArr, yoyLArr);
        this.lineYmaxFour = ~~Math.max.apply(Math, findMaxFour);
        let findMaxFive = Array.prototype.concat.call([], momYArr, momLArr);
        this.lineYmaxFive = ~~Math.max.apply(Math, findMaxFive);
        //年的月增数折线图
        yearInMSpeedArr.push({data: newMRate, type: 'line', name: '新保', showSymbol: true}, {
          data: reiMRate,
          type: 'line',
          name: '转保',
          showSymbol: true
        }, {data: renMRate, type: 'line', name: '续保', showSymbol: true});
        //交强险 商业险同比
        arrThree.push({data: yoyYArr, type: 'line', name: '交强险', showSymbol: true}, {
          data: yoyLArr,
          type: 'line',
          name: '商业险',
          showSymbol: true
        });
        //交强险 商业险环比
        arrFour.push({data: momYArr, type: 'line', name: '交强险', showSymbol: true}, {
          data: momLArr,
          type: 'line',
          name: '商业险',
          showSymbol: true
        });
        totalArr.push(yearInMSpeedArr, arrThree, arrFour);
        elem.forEach((v, i) => {
          this.$nextTick(function () {
            self.$refs[v].setData(function (echarts) {
              echarts.setOption({
                xAxis: {
                  data: xData
                },
                legend: {
                  data: [
                    {name: self.CZDA, icon: q_green},
                    {name: self.TXDA, icon: q_yell},
                    {name: self.WXDA, icon: q_blue}]
                },
                yAxis: {
                  minInterval: function () {
                    switch (i) {
                      case 0:
                        return Math.ceil(self.lineYMaxThree / 4); //年月增速
                        break;
                      case 1:
                        return Math.ceil(self.lineYmaxFour / 4); //同比
                        break;
                      case 2:
                        return Math.ceil(self.lineYmaxFive / 4); //环比
                        break;
                      default:
                        break;
                    }
                  }//Math.ceil((i === 0 ? self.lineYmaxOne : self.lineYmaxTwo) / 4)
                },
                title: [
                  {
                    text: xData[0],
                    bottom: '5px'
                    //text: `01` // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                  },
                  {
                    text: xData[xData.length - 1],
                    bottom: '5px'
                    //text: `${xDatas.length > 9 ? xDatas.length : '0' + xDatas.length}` // ${~~xStart > 9 ? xStart : '0' + xStart}.${xData.length > 9 ? xData.length : '0' + xData.length}
                  }
                ],
                tooltip: {
                  trigger: 'axis',
                  formatter: function (a) {
                    let arr = [
                      a.length > 0 ? a[0].axisValue + '<br/>' : ''
                    ];
                    a.forEach(v => {
                      arr.push(`${v.seriesName}: ${v.value}%<br/>`);
                    })
                    return arr.join('');
                  },
                  axisPointer: {
                    animation: false,
                    lineStyle: {
                      color: '#FE8F46'
                    }
                  },
                  backgroundColor: '#FFE0CB',
                  textStyle: {
                    color: '#FF954E'
                  }
                },
                series: totalArr[i]
              });

            });
          })
        });


      },
      /**
       * reqData 请求参数
       * @param reqData
       * 请求进度条的百分比
       */
      //     "http://localhost:8888/postGetData", {
      //   "file": "queryTargetProgress",
      //     "path": "car"
      // }
      getTargetProgress(reqData) {
        Axios.post(API.getWebServiceUrls('queryTargetProgress'), reqData, {loading: false}).then((res) => {
          const reqData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (reqData.code === 0 || reqData.code === '0') {
            this.targetProData = reqData.data || {};
          } else {
            Toast(reaData && reaData.msg || '系统繁忙请稍后重试');
          }

        }).catch(err => {
          console.log(err)
        })
      }
    }
    ,
    beforeRouteEnter(to, from, next) {

      loadEcharts(next);
      // next(()=>{
      //   let queryName= this.$router.query;
      //   console.log(queryName);
      // });
    }
    ,
    components: {
      XProgress,
      ptsEchartsPie,
      ptsEchartsLine,
      ptsEchartsBar,
      ptsTextScroll
    }
  }
</script>

<style scoped lang="less">
  .mb120 {
    margin-bottom: 1.2rem;
  }

  .m_b {
    width: 100%;
    height: 1rem;
    line-height: 1rem;
    padding-bottom: 1.45rem;
  }

  .m_b li {
    /*border-bottom: .01rem solid #eee;*/
    /*width: 100%;*/
    height: .8rem;
    line-height: 0.8rem;
    overflow: hidden;
    padding: 0 .6rem;
    color: #333333;
    border-bottom: .02rem solid #eee;
    font-size: .28rem
  }

  .m_em {
    float: right;
    text-align: right;
    margin-right: -.3rem;
  }

  .m_b li :before {
    margin-left: .3rem;
  }

  .f_s {
    font-size: .2rem;
    color: #999999;
  }

  .f_s_m {
    font-size: .2rem;
    color: #999999;
  }
  .i_g {
    color: #2BAF64;
    margin-left: .05rem;
  }

  .i_r {
    color: #FE3A3A;
    margin-left: .05rem;
  }

  .echart_top {
    margin-top: .1rem;
  }

  .series_icon {
    position: absolute;
    top: 50%;
    right: 1.32rem;
    width: .6rem;
    height: .6rem;
    margin-top: -.3rem;
    line-height: .6rem;
    font-size: .2rem;
    color: #454545;
    text-align: center;
    border-radius: 50%;
    background: #E9E9E9;
  }

  .show_catype {
    display: none !important;
  }

  .lin_h {
    line-height: .85rem !important;
  }

  .insideYejiWrap .trendAreaTipsYeji {
    width: 4.1rem;
    margin: 0 auto;
    padding-left: .25rem;
    padding-bottom: .05rem;
  }

  /*.bar-area {*/
  /*width: 100%;*/
  /*height: 5rem !important;*/
  /*}*/
  /*.c:after {*/
  /*padding-top: .3rem;*/
  /*}*/
  .insideYejiWrap .chartBoxTxt {
    float: left;
    /* width: .8rem; */
    margin-top: .3rem;
    margin-left: 0rem;
  }

  .mb120 {
    margin-bottom: 1.2rem !important;
  }

  .mgBot {
    margin-bottom: .35rem;
  }

  .p_g {
    width: 70%;
    text-align: center;
    padding-left: 1.2rem;
  }

  .weui-progress__bar {
    height: 10px !important;
    border-radius: 4px;
  }

  /*.weui-progress{*/
  /*border-radius: 2;*/
  /*}*/
  .weui-progress__inner-bar {
    height: 100%;
    border-radius: 4px;
    background-color: #FFD07D;
  }

  .p_f_s {
    padding-top: .2rem;
    font-size: .26rem;
    color: #666666;
    line-height: .4rem;
  }

  .s_left {
    padding-left: .3rem;
  }
  .f_s_m,.f_s{
  margin-left: .4rem;
}
.self{
  display: flex;
  .selfLeft{
    flex:75;
    overflow: hidden;
    display: flex;
    .left{
      flex: 4;
      overflow: hidden;
    }
    .right{
      flex: 3;
      overflow: hidden;
      .f_s_m{
        margin: 0 .4rem 0 0;
      }
    }
  }
  .selfRight{
    flex:25;
    overflow: hidden;
  }
}
.year{
  .f_s{
    margin-left: 1.2rem
  }
}
</style>
