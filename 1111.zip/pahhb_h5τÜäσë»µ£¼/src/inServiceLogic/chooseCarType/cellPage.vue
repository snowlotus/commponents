<template>
  <div class="box" :class="isWXSHOWHEADER?'':'wx_box'">
    <pts-header :titleText="headerTitle" v-if="isWXSHOWHEADER"></pts-header>
    <div class="cellWrap">
      <ul class="cell-list" v-if="show && list.length">
        <!--  对号className: "active" -->
        <li class="cell-item pts-b-b text-hidden" v-for="(item,index) in list" :key="index" @click.prevent="goNext(item)">
          <p class="content text-hidden">{{item}}</p>
        </li>
      </ul>
      <ul class="cell-list" v-if="!show && detailList.length">
        <li class="cell-item pts-b-b" v-for="(item,index) in detailList" :key="index" @click.prevent="goIndex(item)">
          <p class="car-type text-hidden">{{item.standard_name}}</p>
          <p class="car-info text-hidden">{{item.parent_veh_name}} {{item.gearbox_name}} {{item.seat}}座
            {{item.price/10000}}万</p>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
  import loding from '../../common/comComponent/loading'
  import toast from '../../common/comComponent/toast'

  export default {
    name: "cell-page",
    data () {
      return {
        //是否显示头部
        isWXSHOWHEADER: window.PageStatus.WX_SHOW_HEADER,
        list: [],
        show: true,
        detailList: [],
        page: 1,
        headerTitle:'品牌'
      }
    },
    watch: {
      $route (to, from) {
        let flag = to.query.type === 'A';
        this.show = to.query.type !== 'E';
        this.getDataFromLocal(flag);
        this.headerTitle = to.meta.title[to.query.type];
        if (from.query.type == 'E') this.detailList = [];

        // this.getData('https://u.pingan.com/newrsupport/vehicle/model-brand')
      }
    },

    methods: {

      //A:选择品牌,B:选择具体车款,C:选择排气量,D:选择变速器(手动/自动),E:车型详情
      getData (url, params) {
        loding(true);
        let query = params || this.$route.query;

        this.$jsonp(url, query)
          .then(res => {

            if (res.code == 0 || res.code == '0') {
              setTimeout(() => {
                loding(false)
              }, 200)
              let obj, arr;
              switch (query.type) {
                case 'A':
                  // this.show = true;
                  let data = res.results.distincts.brand_name;
                  //判断车品牌下有无子品牌,如果有就显示子品牌,如果没有则直接跳转到选择车型页面
                  if (data.length > 1) {
                    this.list = res.results.distincts.brand_name;
                    obj = {
                      key: query.k,
                      data: res.results.distincts.brand_name
                    }
                    sessionStorage.setItem('A', JSON.stringify(obj));
                  } else if (data.length == 1 && data[0] != query.k) {
                    this.list = res.results.distincts.brand_name;
                    obj = {
                      key: query.k,
                      data: res.results.distincts.brand_name
                    }
                    sessionStorage.setItem('A', JSON.stringify(obj));
                  } else {
                    this.$router.push({path: '/chooseCarTypeCell', query: {k: query.k, brand_name: query.k, type: 'B'}})
                  }
                  break;
                case 'B':
                  // this.show = true;
                  this.list = res.results.distincts.family_name;
                  obj = {
                    key: query.brand_name,
                    data: res.results.distincts.family_name
                  };
                  sessionStorage.setItem('B', JSON.stringify(obj));
                  break;
                case 'C':
                  // this.show = true;
                  arr = res.results.distincts.engine_desc;

                  function carOutputSort (a, b) {
                    if (a > b) {
                      return -1
                    } else {
                      return 1
                    }
                  }

                  this.list = arr.sort(carOutputSort);
                  obj = {
                    key: query.family_name,
                    data: res.results.distincts.engine_desc
                  };
                  sessionStorage.setItem('C', JSON.stringify(obj));
                  break;
                case 'D':
                  // this.show = true;
                  this.list = res.results.distincts.gearbox_name;
                  obj = {
                    key: query.engine_desc,
                    data: res.results.distincts.gearbox_name
                  };
                  sessionStorage.setItem('D', JSON.stringify(obj));
                  break;
                case 'E':
                  // this.show = false;
                  let totalPage = res.results.pagination.pages;
                  this.detailList = this.detailList.concat(res.results.vehicles);
                  if (totalPage > 1 && this.page < totalPage) {
                    this.page++;
                    query['page'] = this.page;
                    this.getData('https://u.pingan.com/newrsupport/vehicle/model-brand', query);
                    // this.detailList = this.detailList.concat(res.results.vehicles);
                  }
                  if (totalPage <= 1 || this.page >= totalPage) {
                    obj = {
                      key: query.gearbox_name,
                      data: this.detailList
                    };
                    sessionStorage.setItem('E', JSON.stringify(obj));
                  }
                  break;
              }
            } else {
              loding(false)
              toast('无匹配车型')
            }
          })
          .catch(err => {
            setTimeout(() => {
              loding(false)
            }, 300)
            console.log(err);
          })
      },

      //点击车款选项和排气量选项进行跳转
      goNext (item) {
        let query = this.$route.query;
        if (query.type == 'A') {
          this.$router.push(
            {
              path: '/chooseCarTypeCell',
              query: {
                k: query.k,
                brand_name: item,
                type: 'B'
              }
            });
          window.eventAnalytics('快速报价','进入车型选择页面')
          return
        }
        ;

        if (query.type == 'B') {
          this.$router.push(
            {
              path: '/chooseCarTypeCell',
              query: {
                k: query.k,
                brand_name: query.brand_name,
                family_name: item,
                type: 'C'
              }
            })
          window.eventAnalytics('快速报价','进入排气量页面')
          return
        }
        ;

        if (query.type == 'C') {
          this.$router.push(
            {
              path: 'chooseCarTypeCell',
              query: {
                k: query.k,
                brand_name: query.brand_name,
                family_name: query.family_name,
                engine_desc: item,
                type: 'D'
              }
            })
          window.eventAnalytics('快速报价','进入手动/自动选择页面')
          return
        }
        ;

        this.show = false;
        this.$router.push(
          {
            path: '/chooseCarTypeCell',
            query: {
              k: query.k,
              brand_name: query.brand_name,
              family_name: query.family_name,
              engine_desc: query.engine_desc,
              gearbox_name: item,
              type: 'E'
            }
          });
        window.eventAnalytics('快速报价','进入车型详情页面')
      },

      //回到选择车型页面
      goIndex (item) {
        window.eventAnalytics('快速报价','返回选择车型页面')
        item['k'] = this.$route.query.k;
        this.$router.push(
          {
            path: '/chooseCarType',
            query: item
          }
        )
      },

      // 进入页面前尝试从sessionStorage中读取数据
      getDataFromLocal (flag) {
        let _this = this;
        let query = this.$route.query;
        let obj = {
          A () {
            let data = sessionStorage.getItem('A');
            if (!data && flag) {
              _this.$router.go(-1);
              return;
            }
            if (!data) {
              _this.getData('https://u.pingan.com/newrsupport/vehicle/brand');
              return
            }
            data = JSON.parse(data);
            if (data.key !== query.k) {
              sessionStorage.removeItem('A');
              sessionStorage.removeItem('B');
              sessionStorage.removeItem('C');
              sessionStorage.removeItem('D');
              sessionStorage.removeItem('E');
              _this.getData('https://u.pingan.com/newrsupport/vehicle/brand');
              return
            }
            _this.list = data.data;
          },
          B () {
            let data = sessionStorage.getItem('B');
            if (!data) {
              _this.getData('https://u.pingan.com/newrsupport/vehicle/model-brand');
              return
            }
            data = JSON.parse(data);
            if (data.key !== query.brand_name) {
              sessionStorage.removeItem('B');
              sessionStorage.removeItem('C');
              sessionStorage.removeItem('D');
              sessionStorage.removeItem('E');
              _this.getData('https://u.pingan.com/newrsupport/vehicle/model-brand');
              return
            }
            _this.list = data.data;
          },
          C () {
            let data = sessionStorage.getItem('C');
            if (!data) {
              _this.getData('https://u.pingan.com/newrsupport/vehicle/model-brand');
              return
            }
            data = JSON.parse(data);
            if (data.key !== query.family_name) {
              sessionStorage.removeItem('C');
              sessionStorage.removeItem('D');
              sessionStorage.removeItem('E');
              _this.getData('https://u.pingan.com/newrsupport/vehicle/model-brand');
              return
            }
            _this.list = data.data;
          },
          D () {
            let data = sessionStorage.getItem('D');
            if (!data) {
              _this.getData('https://u.pingan.com/newrsupport/vehicle/model-brand');
              return
            }
            data = JSON.parse(data);
            if (data.key !== query.engine_desc) {
              sessionStorage.removeItem('D');
              sessionStorage.removeItem('E');
              _this.getData('https://u.pingan.com/newrsupport/vehicle/model-brand');
              return
            }
            _this.list = data.data;
          },
          E () {
            let data = sessionStorage.getItem('E');
            if (!data) {
              _this.getData('https://u.pingan.com/newrsupport/vehicle/model-brand');
              return
            }
            data = JSON.parse(data);
            if (data.key !== query.gearbox_name) {
              sessionStorage.removeItem('E');
              _this.getData('https://u.pingan.com/newrsupport/vehicle/model-brand');
              return
            }
            _this.detailList = data.data;
          }
        }
        typeof obj[query.type] === 'function' && obj[query.type]();
      }
    },

    //路由第一次进入初始化数据
    created () {
      let _this = this;
      this.show = this.$route.query.type !== 'E';
      switch (this.$route.query.type) {
        case 'C':
          this.headerTitle = '排气量';
          break;
        case 'D':
          this.headerTitle = '手动/自动';
          break;
        default :
          this.headerTitle = '品牌';
          break
      }
      this.getDataFromLocal();
      // this.getData('https://u.pingan.com/newrsupport/vehicle/brand')

      //定义全局方法供Native调用返回index页面
      /*window.goIndexPage = function () {
        let query = _this.$route.query;
        _this.$router.push(
          {
            path: '/chooseCarType',
            query: {
              k: query.k,
              brand_name: query.brand_name,
              family_name: query.family_name,
              engine_desc: query.engine_desc,
              gearbox_name: query.gearbox_name,
            }
          }
        )
      };*/
    }
  }
</script>

<style scoped lang="less">
  @import "../../common/css/theme";

  .cellWrap {
    height: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    font-size: .28rem;
    .cell-list {
      background: #fff;
      .cell-item {
        margin: 0 0.3rem;
        padding: 0.3rem 0;
        color: #333;
        /* &.triangle { // 向右的箭头
           padding: 0.2rem 0.5rem 0.2rem 0.2rem;
           background: url('../../common/images/icon_arrow.png') no-repeat 95% center;
           background-size: 0.12rem 0.24rem;
         }*/
        &.active { // 对号
          padding: 0.2rem 0;
          background: url('../../common/images/icon_tick.png') no-repeat 95% center;
          background-size: 0.2rem 0.2rem;
          & > .car-type, & > .car-info {
            color: @theme-color;
          }
        }
        .content {
          width: 100%;
          font-size: 0.3rem;
        }
        .car-type {
          width: 100%;
          margin-bottom: 0.01rem;
          font-size: 0.28rem;
          color: #000;
        }
        .car-info {
          width: 100%;
          font-size: 0.26rem;
          color: #666;
        }
      }
    }
  }
</style>
