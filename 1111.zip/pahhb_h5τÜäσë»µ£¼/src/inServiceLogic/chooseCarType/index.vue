<template>
  <div class="box" :class="isWXSHOWHEADER?'':'wx_box'">
    <pts-header titleText="选择车型" leftFlag @on-left="goMenu" v-if="isWXSHOWHEADER"></pts-header>
    <div class="choose-car-type-wrap">
      <div class="title pts-b-b">车辆信息</div>
      <ul class="param-area pts-b-b">
        <li class="param-item pts-b-b active">
          <label class="param-label">品牌</label>
          <p class="param-content text-hidden" :class="{'active':brandName}" @click.prevent="goPage">{{brandName || '请选择汽车品牌'}}</p>
        </li>
        <li class="param-item pts-b-b" :class="{'active': familyName}">
          <label class="param-label">车款</label>
          <p class="param-content text-hidden" @click.prevent="goCellPage('B')" :class="{'active':familyName}">
            {{familyName || '请选择车款'}}</p>
        </li>
        <li class="param-item pts-b-b" :class="{'active':engineDesc}">
          <label class="param-label">排气量</label>
          <p class="param-content text-hidden" @click.prevent="goCellPage('C')" :class="{'active':engineDesc}">
            {{engineDesc || '请选择排气量'}}</p>
        </li>
        <li class="param-item" :class="{'active':gearboxName}">
          <label class="param-label">手动自动</label>
          <p class="param-content vtext-hidden" @click.prevent="goCellPage('D')" :class="{'active':gearboxName}">
            {{gearboxName || '请选择手动/自动'}}</p>
        </li>
      </ul>
      <div class="tips-area">
        <p class="warmth">温馨提示</p>
        <ul class="tips-list">
          <li>1.品牌型号可录入"大众 迈腾"</li>
          <li>2.行驶证上品牌型号的英文部分"SVW71611KS"</li>
        </ul>
        <div class="tipImg"></div>
      </div>
      <div class="btn-wrap">
        <button class="btn" :class="{active:brandName && familyName && engineDesc && gearboxName}"
                @click.prevent.stop="submitCarType">确定
        </button>
      </div>
    </div>
  </div>
</template>

<script>
  import toast from '../../common/comComponent/toast';
  import Axios from '../../common/js/axiosConfig';
  import API from '../../common/js/comConfig';
  import {getCookie} from './../../common/js/comUtils'

  export default {
    name: "chooseCarIndex",
    data() {
      return {
        //是否显示头部
        isWXSHOWHEADER: window.PageStatus.WX_SHOW_HEADER,
        brandName: '',
        familyName: '',
        engineDesc: '',
        gearboxName: '',
        isWx:window.__wxjs_environment //判断当前环境是从小程序进来还是原生
      }
    },
    methods: {
      goPage() {
        this.$router.push('/chooseCarTypeList');
        window.eventAnalytics('极速报价','进入品牌页面')
      },

      goMenu(){
        //回到Native主页
        if (this.isWx === 'miniprogram') {
          this.$router.replace({path:'/outside/hasteOffer'})
        } else {
          Native.requestHybrid({
            tagname:'backHome'
          })
        }
      },
      //B:进入车款页面,C:进入排气量页面,D:进入变速器页面
      goCellPage(page) {
        let query = this.$route.query;
        switch (page) {
          case 'B':
            if (!this.brandName) return
            this.$router.push({
              path: '/chooseCarTypeCell',
              query: {k: query.k, brand_name: query.brand_name, type: 'B'}
            })
            window.eventAnalytics('极速报价','进入车款页面')
            break
          case 'C':
            if (!this.brandName && !this.familyName) return
            this.$router.push({
              path: '/chooseCarTypeCell',
              query: {k: query.k, brand_name: query.brand_name, family_name: query.family_name, type: 'C'}
            })
            window.eventAnalytics('极速报价','进入排气量页面')
            break
          case 'D':
            if (!this.brandName && !this.familyName && !this.engineDesc) return
            this.$router.push({
              path: '/chooseCarTypeCell',
              query: {
                k: query.k,
                brand_name: query.brand_name,
                family_name: query.family_name,
                engine_desc: query.engine_desc,
                type: 'D'
              }
            })
            window.eventAnalytics('极速报价','进入手动/自动选择页面')
            break
        }
      },

      submitCarType() {
        //在cookie中重新取出dealerCode和内外部端
        let dealerCode = JSON.parse(decodeURIComponent(getCookie('header'))).carDeptCode
        let innerAccountRoleType = JSON.parse(decodeURIComponent(getCookie('header'))).innerAccountRoleType
        let accountType;
        const _this = this;
        window.eventAnalytics('极速报价 ','提交车型数据')
        if (!this.brandName) {
          toast('请先选择汽车品牌')
          return
        }
        if (!this.familyName) {
          toast('请选择车款')
          return
        }
        if (!this.engineDesc) {
          toast('请选择排气量')
          return
        }
        if (!this.gearboxName) {
          toast('请选择手动/自动')
          return
        }
        // console.log(dealerData.innerAccountRoleType)

        let query = this.$route.query;
        let carInfo = {
          'brandName': query.brand_name,
          'vehType': query.family_name,
          'engineDesc': query.engine_desc,
          'gearboxName': query.gearbox_name,
          'vehCode': query.parent_veh_code,
          'vehName': query.parent_veh_name,
          'price': query.price,
          'remark': query.remark,
          'seat': query.seat,
          'standardName': query.standard_name,
          'vehicleFgwCode': query.vehicle_fgw_code,

          'importFlag':query.import_flag || '',
          'marketDate':query.market_date || '',
          'vehicleId':query.vehicle_id || '',
          'vehicleType':query.vehicle_type || '',
          'wholeWeight':query.whole_weight || '',
          'tonNumber':query.ton_number || '',
          'modelName':query.model_name || '',
          'fgwBrandName':query.fgw_brand_name || '',
          'circVehicleType':query.circ_vehicle_type || '',
          'dealerCode': dealerData.carDeptCode || ''
        };

        if(innerAccountRoleType == 0 || innerAccountRoleType == '0'){
          accountType = 'submitCarType' //外部端角色
        } else {
          accountType = 'inSubmitCarType' //内部端角色
        };

        Axios.post(API.getWebServiceUrls(accountType), carInfo)
          .then(res => {
            let carData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
            if (carData.code == 0 || carData.code == '0') {
              // console.log(carData.data.carId)
              if (_this.isWx === 'miniprogram') {
                _this.$router.replace({
                  path:'/outside/hasteOffer',
                  query:{
                    carId:carData.data.carId,
                    carPrice: carData.data.carPrice,
                    carMainDesc: carData.data.carType
                  }
                })
              } else {
                Native.requestHybrid({
                  tagname: 'createCarId',
                  param: {
                    carId: carData.data.carId,
                    carPrice: carData.data.carPrice,
                    carType: carData.data.carType
                  }
                })
              }

            } else {
              toast(carData.msg)
            }
          })
          .catch(err => {
            console.log(err)
          });
      }
    },
    activated() {
      let query = this.$route.query;
      if (query) {
        this.brandName = query.brand_name;
        this.familyName = query.family_name;
        this.engineDesc = query.engine_desc;
        this.gearboxName = query.gearbox_name;
      }
    },
  }
</script>

<style scoped lang="less">
  @import "../../common/css/theme";

  .choose-car-type-wrap {
    height: 100%;
    font-size: .28rem;
    @cell-height: 0.9rem;
    .title {
      background: #fff;
      @height: @cell-height;
      height: @height;
      padding-left: 0.3rem;
      position: relative;
      line-height: @height;
      &:after {
        display: block;
        content: '';
        width: 0.1rem;
        height: 0.2rem;
        position: absolute;
        left: 0;
        top: 50%;
        margin-top: -0.1rem;
        background: @theme-color;
      }
    }
    .param-area {
      @height: @cell-height;
      width: 100%;
      background: #fff;
      .param-item {
        /*display: -webkit-box;*/
        display: flex;
        height: @height;
        margin-left: 0.3rem;
        line-height: @height;
        &.active {
          background: url('../../common/images/icon_arrow.png') no-repeat 97% center;
          background-size: 0.12rem 0.24rem;
        }
        .param-label {
          flex: 0 0 1.4rem;
          color: #666;
        }
        .param-content {
          flex: 0 0 5.26rem;
          text-align: right;
          color: #999;
          &.active {
            color: #333;
          }
        }
      }
    }
    .tips-area {
      padding: 0 0.24rem 0.2rem 0.24rem;
      color: #999;
      font-size: 0.24rem;
      .warmth {
        padding: 0.24rem 0;
      }
      .tipImg {
        width: 6.92rem;
        height: 3.88rem;
        background: url('../../common/images/p_xsz.png') no-repeat center center /100% 100%;
        margin: 0.4rem auto 0;
      }
    }
    .btn-wrap {
      width: 100%;
      padding-top: 0.3rem;
      margin-bottom: 0.5rem;
      .btn {
        @background: #ccc;
        display: block;
        width: 6.91rem;
        height: 0.92rem;
        outline-color: @background;
        margin: 0 auto;
        border-radius: 0.04rem;
        border: none;
        background: @background;
        font-size: 0.32rem;
        font-weight: normal;
        color: #fff;
        &.active {
          outline-color: @theme-color;
          background: @theme-color;
        }
      }
    }
  }
</style>
