<template>
  <div class="box" :class="isWXSHOWHEADER?'':'wx_box'">
    <pts-header titleText="品牌"  v-if="isWXSHOWHEADER"></pts-header>
    <div class="car-list-wrap">
      <div class="list-wrap" ref="wrap">
        <div class="hideScroll">
          <section class="list-area" v-for="item in carList">
            <h1 class="list-title" :ref="item.title">{{item.title}}</h1>
            <ul class="car-list">
              <li class="car-item pts-b-b" v-for="con in item.data" @click="chooseType(con)">{{con | changeName}}</li>
            </ul>
          </section>
        </div>
      </div>
      <aside class="right-nav" ref="asideElem">
        <ul class="nav-list" @touchmove.stop.prevent="navMove">
          <li class="nav-item" v-for="nav in carNav" @click="goNav(nav)" ref="navElem">{{nav}}</li>
        </ul>
      </aside>
    </div>
  </div>
</template>

<script>
  import loading from '../../common/comComponent/loading';
  import url from '../../common/js/comConfig';
  import axios from '../../common/js/axiosConfig';
  import toast from '../../common/comComponent/toast';

  export default {
    name: "car-list",
    data () {
      return {
        //是否显示头部
        isWXSHOWHEADER: window.PageStatus.WX_SHOW_HEADER,
        carList: [], // 保存全部车品牌的数组
        carNav: [], // 保存A-Z做导航使用
        scrollTopJson: {}, // 存储每个导航的滚动条高度
        navTop: 0,
        navItmeHeight: 0,
        touchIndex: 0
      }
    },
    methods: {
      // 滚动条跳转至指定的位置
      goNav (nav) {
        let wrap = this.$refs.wrap;
        let navJson = this.scrollTopJson;
        wrap.scrollTop = navJson[nav];
        toast(nav);
      },
      // 获取每一个区域的距离屏幕顶端的距离
      getScrollTop () {
        let elems = this.$refs;
        let obj = {};
        for (let key of Object.keys(elems)) {
          if (!elems[key][0]) continue;
          obj[key] = elems[key][0].offsetTop;
        }
        this.scrollTopJson = obj;
      },
      // 选中车型后执行跳转动作
      chooseType (item) {
        if (item === '雪弗兰') {
          item = '雪佛兰'
        }
        this.$router.push({path: '/chooseCarTypeCell', query: {k: item, type: 'A'}});
        window.eventAnalytics('极速报价','进入车款选择页面')
      },
      // 手指滑动切换nav
      navMove (e) {
        let asideHeight = this.navTop;
        let navItemHeight = this.navItmeHeight;
        let touch = e.touches[0].pageY;
        let index = parseInt((touch - asideHeight) / navItemHeight);
        let navItem = this.carNav[index];
        if (this.touchIndex === index || !navItem) return
        this.touchIndex = index;
        this.goNav(navItem);
      },
      getData () {
        let dataList = sessionStorage.getItem('carBrandNameList');
        let navList = sessionStorage.getItem('carBrandNavList');
        if (dataList && navList) {
          this.carNav = JSON.parse(navList);
          this.carList = JSON.parse(dataList);
          return
        }
        let _this = this;
        /*axios.post('http://localhost:8888/postGetData', {
          "file": "carType",
          "path": "car"
        })*/
        axios.post(url.getWebServiceUrls('getcarbrandindexmap'))
          .then(res => {
            let data = res.data;
            switch (data.code) {
              case 0:
                let keys, list = [];
                data = data.data;
                _this.carNav = keys = Object.keys(data);
                for (let key of keys) {
                  list.push({
                    title: key,
                    data: data[key]
                  });
                }
                sessionStorage.setItem('carBrandNameList', JSON.stringify(list));
                sessionStorage.setItem('carBrandNavList', JSON.stringify(keys));
                _this.carList = list;
                break;
              default:
                toast(data.msg);
                break;
            }
          })
          .catch(e => {
            console.log(e);
          })
      }
    },
    updated () {
      this.getScrollTop();
      this.navTop = this.$refs.asideElem.offsetTop;
      this.navItmeHeight = this.$refs.navElem[0].offsetHeight;
    },
    activated () {
      /*this.carList = [
        {
          title: 'B',
          data: ['宝马','奔驰']
        }
      ]
      this.carNav = ['B'];*/
      this.getData();
    },
    filters:{
      //后台库里面字段'雪弗兰'不对,导致无匹配车型,前端修改为'雪佛兰'
      changeName(val){
        if (val === '雪弗兰') {
          val = '雪佛兰'
        }
        return val
      }
    },
    watch: {
      $route () {
        loading(false);
      }
    }
  }
</script>

<style scoped lang="less">
  @import "../../common/css/theme";

  .car-list-wrap {
    width: 100%;
    height: 100%;
    overflow: hidden;
    position: relative;
    .list-wrap {
      width: 110%;
      height: 100%;
      overflow-x: hidden;
      overflow-y: auto;
      -webkit-overflow-scrolling: touch;
      overflow-scrolling: touch;
      .hideScroll {
        width: 91%;
      }
      .list-title {
        width: 100%;
        padding: 0.1rem 0 0.1rem 0.3rem;
        font-size: 0.3rem;
        color: #333;
      }
      .car-list {
        background: #fff;
        .car-item {
          padding: 0.3rem 0;
          margin: 0 0.3rem;
        }
      }
    }
    .right-nav {
      width: 0.54rem;
      position: absolute;
      top: 2rem;
      right: 0;
      z-index: 999;
      color: @theme-color;
      font-size: 0.2rem;
      text-align: center;
      -webkit-user-select: none;
      user-select: none;
    }
  }
</style>
