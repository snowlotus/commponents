<template>
  <div class="box bg_fff">
    <pts-header :title-text="title"></pts-header>
    <main>
      <div class="header">
        <div class="headerLeft">已确认{{totalCount}}家</div>
        <img :src="image" alt="">
        <div class="headerRight">待确认{{unTotalCount}}家</div>
      </div>
      <div>
        <div class="affirm mt">
          <span class="unaffirm">待确认</span>
          <a href="javascript:;" @click.stop="goToRemind">去提醒</a>
        </div>
        <table class="write-table">
          <thead>
            <tr>
              <th class="tl">网点名称</th>
              <th>网点整体</th>
              <th>平安整体</th>
              <th>平安新车</th>
            </tr>
          </thead>
          <tbody v-if="unDataConent.unDataList.length>0">
            <tr v-for="(item,index) in unDataConent.unDataList" :key="index">
              <td class="branchName">{{item.networkName}}</td>
              <td v-for="(items,index) in item.companyDimensionList" :key="index">{{items.vehiclesNumber}}</td>
              <td>{{item.companyDimensionList.vehiclesNumber}}</td>
              <td>{{item.companyDimensionList.vehiclesNumber}}</td>
            </tr>
          </tbody>
        </table>
        <p @click="unaffirmLoadMore" v-if="unTotalPages>1">加载更多</p>
      </div>
      <div>
        <div class="affirm">
          <span class="unaffirm">已确认</span>
        </div>
        <table class="write-table">
          <thead>
            <tr>
              <th class="tl">网点名称</th>
              <th>网点整体</th>
              <th>平安整体</th>
              <th>平安新车</th>
            </tr>
          </thead>
          <tbody v-if="dataConent.dataList.length>0">
            <tr v-for="(item,index) in dataConent.dataList" :key="index">
              <td class="branchName">{{item.networkName}}</td>
              <td v-for="(items,index) in item.companyDimensionList" :key="index">{{items.vehiclesNumber}}</td>
              <td>{{item.companyDimensionList.vehiclesNumber}}</td>
              <td>{{item.companyDimensionList.vehiclesNumber}}</td>
            </tr>
          </tbody>
        </table>
        <p @click="affirmLoadMore" v-if="totalPages>1">加载更多</p>
      </div>
    </main>
  </div>
</template>

<script>
import API from "../../../common/js/comConfig";
import Axios from "../../../common/js/axiosConfig";
import Toast from '../../../common/comComponent/toast/index';
export default {
  data() {
    return {
      title: "温度计月报详情",
      image: require("../../../common/images/detail.png"),
      dataConent: {
        dataList: [] //已确认的网点
      },
      unDataConent: {
        unDataList: [] //待确认的网点
      },
      totalCount: "", //已确认总条数
      unTotalCount: "", //待确认总条数
      pageNo: 1 ,//待确认页数，默认是第一页
      page:1,//已确认页数，默认是第一页
      totalPages:"",//已确认总页数
      unTotalPages:"",//待确认总页数
    };
  },
  methods: {
    //待确认加载更多
    unaffirmLoadMore() {
      this.pageNo++;
      if (this.pageNo > this.unTotalPages) {
        Toast('没有更多数据了');
      }
      Axios.post(API.getWebServiceUrls("monthlyDetail"), {
        "pageNo": this.pageNo || 1,
        "pageSize": 20,
        "type": 1
      })
        .then(res => {
          let resData =
            typeof res.data === "string" ? JSON.parse(res.data) : res.data;
          resData.data.forEach(v => {
            this.unDataConent.unDataList.push(v);
          });
        })
        .catch(err => {
          console.log(err);
        });
    },
    //已确认加载更多
    affirmLoadMore() {
      this.page++;
      if (this.pageNo > this.totalPages) {
        Toast('没有更多数据了');
      }
      Axios.post(API.getWebServiceUrls("monthlyDetail"), {
        "pageNo": this.page || 1,
        "pageSize": 20,
        "type": 2
      })
        .then(res => {
          let resData =
            typeof res.data === "string" ? JSON.parse(res.data) : res.data;
          // console.log(resData);
          resData.data.forEach(v => {
            this.dataConent.dataList.push(v);
          });
        })
        .catch(err => {
          console.log(err);
        });
    },
    // 已确认初次渲染
    affirmRequestData() {
      Axios.post(API.getWebServiceUrls("monthlyDetail"), {
        "pageNo": this.pageNo || 1,
        "pageSize": 20,
        "type": 2
      })
        .then(res => {
          let resData =
            typeof res.data === "string" ? JSON.parse(res.data) : res.data;
          this.totalCount = resData.totalCount;
          this.totalPages = resData.totalPages;
          resData.data.forEach(v => {
            this.dataConent.dataList.push(v);
          });
          this.companyDimensionList = resData.data.companyDimensionList;
          this.networkName = resData.data.networkName;
        })
        .catch(err => {
          console.log(err);
        });
    },
    // 待确认初次渲染
    unaffirmRequestData() {
      Axios.post(API.getWebServiceUrls("monthlyDetail"), {
        "pageNo": this.pageNo || 1,
        "pageSize": 20,
        "type": 1
      })
        .then(res => {
          let resData =
            typeof res.data === "string" ? JSON.parse(res.data) : res.data;
          console.log(resData);
          this.unTotalPages = resData.totalPages;
          this.unTotalCount = resData.totalCount;
          resData.data.forEach(v => {
            this.unDataConent.unDataList.push(v);
          });
          this.companyDimensionList = resData.data.companyDimensionList;
          this.networkName = resData.data.networkName;
        })
        .catch(err => {
          console.log(err);
        });
    },
    /**
     * 去提醒
     */
    goToRemind() {
      this.$router.push({
        path: "/inside/thermometer/VPMonthlyDetailsRemind",
        query: {
          totalCount: this.totalCount
        }
      });
    }
  },
  mounted() {
    this.$nextTick(function() {
      this.affirmRequestData();
      this.unaffirmRequestData();
    });
  }
};
</script>

<style lang="less" scoped>
main {
  .header {
    width: 7.5rem;
    height: 2.43rem;
    position: relative;
    color: #ffffff;
    font-weight: normal;
    .headerLeft {
      position: absolute;
      top: 0.98rem;
      left: 0.31rem;
      font-size: 0.24rem;
    }
    .headerRight {
      position: absolute;
      top: 0.98rem;
      right: 0.29rem;
      font-size: 0.24rem;
    }
    img {
      width: 100%;
      height: 100%;
    }
  }
  .mt {
    margin-top: -0.45rem;
  }
  p {
    text-align: center;
    height: 0.6rem;
    line-height: 0.6rem;
    font-size: 0.28rem;
    color: #fe883a;
  }
  .affirm {
    background-color: #ffffff;
    width: 100%;
    height: 0.48rem;
    line-height: 0.68rem;
    position: relative;
    font-size: 0.28rem;
    font-weight: normal;
    .unaffirm {
      margin-top: 0.1rem;
      margin-left: 0.3rem;
      &.unaffirm:after {
        display: block;
        content: "";
        position: absolute;
        top: 0.2rem;
        left: 0;
        width: 0.1rem;
        height: 0.28rem;
        margin-top: 0rem;
        background: #fe883a;
      }
    }
    a {
      position: absolute;
      right: 0.3rem;
      color: #fe883a;
    }
  }
}
.write-table {
  width: 6.9rem;
  margin: 0.2rem auto 0;
  text-align: center;
  thead {
    background-color: #f2f2f2;
    width: 6.9rem;
    height: 0.73rem;
    tr {
      th {
        font-size: 0.24rem;
        line-height: 0.24rem;
        color: #999999;
        height: 0.73rem;
        font-weight: normal;
      }
      .tl{
        text-align: left;
        padding-left: 0.28rem;
      }
    }
  }
  tbody {
    width: 100%;
    tr {
      .branchName {
        width: 2.16rem;
        height: 0.58rem;
        font-size: 0.24rem;
        line-height: 0.35rem;
        text-align: left;
        padding-left: 0.27rem;
      }
      td {
        font-size: 0.28rem;
        line-height: 0.9rem;
        color: #333333;
      }
    }
  }
}
</style>