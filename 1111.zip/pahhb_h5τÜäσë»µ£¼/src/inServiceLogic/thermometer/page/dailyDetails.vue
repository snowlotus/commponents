<template>
  <div class="box bg_fff">
    <pts-header :title-text="title" :left-flag="leftFlag" @on-left="upPage"></pts-header>
    <main>
      <x-table :dataList="dataList" :totalPages="totalPages" @loadmore="loadMore"></x-table>
    </main>
  </div>
</template>

<script>
import XTable from "../template/table.vue";
import API from "../../../common/js/comConfig";
import Axios from "../../../common/js/axiosConfig";
import Toast from '../../../common/comComponent/toast/index';
export default {
  name: "dailyDetail",
  data() {
    return {
      title: "温度计详情",
      pageNo: 1, //页数，默认显示第一页
      dataList: [], //网点数据列表
      totalPages: "", //总页数
      url: "",
      leftFlag: true,
      type: "", //类型，A代表日报，B代表年报
      activeTab: "" //传过来的值
    };
  },
  methods: {
    //跳到上一页面
    upPage() {
      this.$router.go(-1);
      console.log("回到了上一个页面");
    },
    dailyDetail() {
      let self = this;
      Axios.post(API.getWebServiceUrls("selectDailyDetails"), {
        "pageNo": this.pageNo || 1,
        "pageSize": 20,
        "type": this.type || "B"
      },{loading:false})
        .then(res => {
          console.log(res);
          let resData =
            typeof res.data === "string" ? JSON.parse(res.data) : res.data;
          console.log(resData);
          self.totalPages = resData.totalPages;
          self.dataList = resData.data;
        })
        .catch(err => {
          console.log(err);
        });
    },
    //加载更多
    loadMore(dataList) {
      this.pageNo++;
      if (this.pageNo > this.totalPages) {
        Toast('没有更多数据了');
      }
      Axios.post(API.getWebServiceUrls("selectDailyDetails"), {
        "pageNo": this.pageNo || 1,
        "pageSize": 20,
        "type": this.type || "B"
      },{loading:false})
        .then(res => {
          let resData =
            typeof res.data === "string" ? JSON.parse(res.data) : res.data;
          console.log(resData);
          resData.data.forEach(v => {
            this.dataList.push(v);
          });
          console.log(this.dataList);
        })
        .catch(err => {
          console.log(err);
        });
    },
    /* 确定是从哪里进来的页面并改变页面的逻辑 */
    init() {
      //从路由的flag 来判断 day month
      let _this = this;
      let obj = {
        day() {
          _this.leftFlag = true;
          return true;
        },
        year() {
          _this.leftFlag = false;
          return true;
        }
      };
      (this.$route.query.flag && obj[this.$route.query.flag]()) || obj.year();
    }
  },
  components: {
    XTable
  },
  activated() {
    this.init();
    let headTitle =
      this.$route.query.activeTab === "D" ? "年报详情" : "温度计详情";
    this.title = headTitle;
    let activeTab = this.$route.query.activeTab === "D" ? "B" : "A";
    this.activeTab = activeTab;
    if (this.activeTab == "B") {
      this.type = "B";
    } else {
      this.type = "A";
    }
    this.dailyDetail();
  }
};
</script>

<style lang="less" scoped>

</style>
