<template>
  <div class="box bg_fff">
    <pts-header :title-text="title">
      <div class="textBanner" slot="center">
        <pts-text-scroll @input="setTitle" :is-have-all="false" :text="titleText"></pts-text-scroll>
      </div>
    </pts-header>
    <div class="write-wrap">
      <div class="table-wrap">
        <table class="write-table" v-if="inputsValue.length">
          <thead>
          <tr>
            <th></th>
            <th>整体单量</th>
            <th>新车</th>
            <th>次新车</th>
            <th>旧车</th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="(item, index) in tdList" :keys="index">
            <td>
              <img v-if="item.imgUrl" :src="'/iCorePts-mobile' + item.imgUrl" alt="" width="80%">
              <p v-else>{{item.companyName}}</p>
            </td>
            <td v-for="(tds, tdIndex) in item.dimensionsList" :keys="tdIndex">
              <input type="tel"
                     class="js-input"
                     v-model="inputsValue[index][tds.dimensionId]"
                     :name="tds.dimensionId"
                     :placeholder="tds.isRequired===1 ?'必填':'0'"
                     @blur="validateNumber"
              >
            </td>
          </tr>
          </tbody>
        </table>
        <div class="info-wrap">
          <p>备注:</p>
          <p>1.单位：台；</p>
          <p>2.旧车台数不包含次新车台数；</p>
          <p>3.整体=新车+次新车+旧车；</p>
        </div>
      </div>
      <div class="btn-wrap" :class="{'btn-again': showAgain}">
        <button class="btn active" @click="getInputValus">提交</button>
        <a href="javascript:;" class="again-btn" v-if="showAgain" @click="getFirstInput">重新编辑</a>
      </div>
    </div>
  </div>
</template>

<script>
  import ptsTextScroll from '../../../common/comComponent/textScroll/index'
  import axios from '../../../common/js/axiosConfig'
  import url from '../../../common/js/comConfig'
  import toast from '../../../common/comComponent/toast/index'
  import titleMixin from '../mixin/titieText';

  export default {
    name: 'insideDayEdit',
    mixins: [titleMixin],
    props: {
      showWrite: Boolean
    },
    data () {
      return {
        title: '温度计',
        titleText: '',
        networkCode: '',//网点Code
        tdList: [],//接口返回的数据
        inputsValue: [], //组装数据之后返回给后端
        validateOk: true, // 判断用户输入的值是否校验通过
        showAgain: false,
        isYesterday: ''
      }
    },
    methods: {
      /* 点击提交按钮触发, 校验用户输入的数据, 并提交给后台 */
      getInputValus () {
        // 如果失去焦点的时候校验就不通过那直接提示用户;
        if (!this.validateOk) {
          return toast('请正确输入出单台数');
        }
        let self = this;
        let goNextFlag = true;
        // 拿到全部的input 循环进行校验
        let inputs = document.querySelectorAll('.js-input');
        inputs = Array.of(...inputs);
        inputs.forEach(v => {
          // 如果有一个校验不通过就不通过;
          if (!self.validateNumber(v)) goNextFlag = false;
        });
        if (goNextFlag) {
          let reqData = {
            networkCode: this.titleCode,
            companyDimensionList: this.inputsValue,
            type: this.showAgain ? '2' : '1',
            dayType: this.showAgain ? undefined : (this.isYesterday ? '2' : '1')
          };
          axios.post(url.getWebServiceUrls('submitMonthReport'), reqData)
            .then(res => {
              let resData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
              if (resData.code === '0' || resData.code === 0) {
                let headerTitle = Object.assign({}, this.$route.query); // 复制一份query 只需要改变isWrite 就可以, 避免修改原来的对象
                headerTitle.title = this.titleText;
                headerTitle.networkCode = this.titleCode;
                headerTitle.time = Date.now().toString(16);
                this.$router.replace({
                  path: '/inside/thermometer/S_MDataReport',
                  query: headerTitle
                })
              } else {
                toast(data.msg);
              }
            }).catch(e => {
            console.log(e);
          });
          // this.$emit('update:showWrite', false); //语法糖 触发父组件 关闭填写日报的组件, 显示图表

        } else {
          return toast('请正确输入出单台数');
        }
      },
      /**
       * 获取在后台配置的需要录入的项
       */
      getData (val, code) {
        this.tdList = [];
        this.inputsValue = [];
        // 当showAgain为true时说明是在编辑月份的数据
        axios.post(url.getWebServiceUrls('getMonthReport'), {
          type: this.showAgain ? '2' : '1',
          networkCode: this.titleCode,
          dayType: this.showAgain ? undefined : (this.isYesterday ? '2' : '1')
        })
          .then(res => {
            let resData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            if (resData.code === '0' || resData.code === 0) {
              this.tdList = resData.data || [];
              let list = this.tdList;
              let companyDimensionList = [];
              /*
              * 从后台拿到数据后, 将数据改变为页面需要使用的格式, 用来收集用户输入的值并发送给后台, 由下面的循环完成;
              * [
              *   companyId: 网点的ID,
              *   xx(由后台决定):  代表 新车/旧车/次新车/全部单量 之一,
              *   xx(由后台决定):  代表 新车/旧车/次新车/全部单量 之一,
              *   xx(由后台决定):  代表 新车/旧车/次新车/全部单量 之一,
              *   xx(由后台决定):  代表 新车/旧车/次新车/全部单量 之一
              * ]
              * */
              list.forEach((v) => {
                let obj = {};
                obj.companyId = v.companyId;
                v.dimensionsList.forEach(s => {
                  obj[s.dimensionId] = s.vehiclesNumber;
                });
                companyDimensionList.push(obj);
              });
              this.inputsValue = companyDimensionList;
              console.log(this.inputsValue);
            } else {
              toast(resData.msg || "系统出错请稍后重试")
            }
          }).catch(err => {
          console.log(err);
        });
        console.log(this.inputsValue);
      },
      /*
      * 校验用户输入的是否是数字, 如果不是数字就提示用户并返回false, 是的话就返回为true;
      * */
      validateNumber (e) {
        let flag = e.type === 'blur';
        let elem = flag ? e.target : e;
        let val = elem.value;
        if (val) {
          const reg = /^[0-9]*$/;
          if (reg.test(val)) {
            // console.log("校验通过");
            this.validateOk = true;
            return true;
          } else {
            flag && toast('请输入数字');
            this.validateOk = false;
            return false;
          }
        } else if (elem.getAttribute('placeholder') === '必填') {
          flag && toast('请输入必填项');
          this.validateOk = false;
          return false;
        } else {
          this.validateOk = true;
          return true;
        }
      },
      /* 编辑月份的时候, 点击重新编辑按钮触发 */
      getFirstInput () {
        let firstInput = document.querySelector('.js-input');
        firstInput.focus();
      }
    },
    activated () {
      console.log('创建input表格');
      let query = this.$route.query;

      this.showAgain = query.flag === 'month';
      this.isYesterday = query.isYesterday;
      if (this.titleCode === query.networkCode) {
        this.getData();
      } else {
        this.setTitle(query.networkCode, query.title);
      }
    },
    components: {
      ptsTextScroll
    }
  }
</script>

<style lang="less" scoped>
  .write-wrap {
    position: relative;
    height: 100%;
    overflow-Y: auto;
    padding-bottom: 2rem;
  }

  .table-wrap {
    margin-bottom: 0.2rem;
  }

  .write-table {
    width: 6.9rem;
    margin: 0.2rem auto 0;
    text-align: center;
    tr, th, td {
      border: 1px solid #EEEEEE;
      width: 1.38rem;
    }
    th {
      height: 0.74rem;
      font-size: 0.24rem;
      background: #F2F2F2;
      font-weight: normal;
      color: #999;
    }
    td {
      height: 0.9rem;
      &:first-child {
        max-width: 1rem;
        word-wrap: break-word;
      }
      input {
        display: block;
        width: 100%;
        text-align: center;
      }
    }
  }

  .info-wrap {
    margin-top: 0.3rem;
    padding: 0 0.3rem;
    font-size: 0.24rem;
    color: #999999;
    line-height: 0.4rem;
  }

  .btn-wrap {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    padding-bottom: 0.2rem;
    background: #fff;
    padding-top: 0.2rem;
    .btn {
      width: 6.9rem;
      height: 0.92rem;
      border: none;
      border-radius: 0.05rem;
      outline: none;
      margin-left: 0.3rem;
      color: #fff;
      background-color: #999;
      font-size: 0.32rem;
      &.active {
        background: @theme-color;
      }
    }
  }

  .btn-again {
    .again-btn {
      display: block;
      padding: 0.24rem 0;
      width: 100%;
      color: @theme-color;
      font-size: 0.32rem;
      text-align: center;
    }
  }
</style>
