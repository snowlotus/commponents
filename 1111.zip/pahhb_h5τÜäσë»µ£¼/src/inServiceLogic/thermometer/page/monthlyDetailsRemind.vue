<template>
  <div class="box bg_fff">
    <pts-header :title-text="title"></pts-header>
    <main>
      <div class="header">
        <div class="headerLeft">已确认{{totalCount}}家</div>
        <img :src="image" alt="">
        <div class="headerRight">待确认{{unTotalCount}}家</div>
      </div>
      <div class="affirm">
        <span class="unaffirm">待确认</span>
      </div>
      <!-- table开始 -->
      <div class="write-wrap">
        <div class="table-wrap">
          <table class="write-table">
            <thead>
              <tr>
                <th style="background-color:#fff;"></th>
                <th class="tl">网点名称</th>
                <th>网点整体</th>
                <th>平安整体</th>
                <th>平安新车</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item,index) in dataList" :key="index" v-if="dataList.length>0">
                <td>
                  <input type="checkbox" class="checkbox" :value='item.networkCode' @click="checkbox(item)">
                  <img class="iconImg icon" :src="icon_sele" alt="" v-if="item.checked">
                  <img class="iconImg icon" :src="icon_nos" alt="" v-else>
                </td>
                <td class="branchName">{{item.networkName}}</td>
                <td v-for="(items,index) in item.companyDimensionList" :key="index">{{items.vehiclesNumber}}</td>
                <td>{{item.companyDimensionList.vehiclesNumber}}</td>
                <td>{{item.companyDimensionList.vehiclesNumber}}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </main>
    <footer>
      <img class="icon" :src="icon_sele" alt="" v-if="checkedAll">
      <img class="icon" :src="icon_nos" alt="" v-else>
      <span>
        <input type="checkbox" class="checkbox" @click="changeState(checkedAll)"> 全选
      </span>
      <a href="javascript:;" id="cancel" @click="cancel">取消</a>
      <a href="javascript:;">
        <button id="button" @click="remind">确认提醒</button>
      </a>
    </footer>
    <pts-alert v-model="showRemind">
      <div class="showRemind">
        <div class="title">已经发送提醒给对方</div>
        <p @click="showRemind = false">我知道了</p>
      </div>
    </pts-alert>
  </div>
</template>

<script>
import Vue from "vue";
import API from "../../../common/js/comConfig";
import Axios from "../../../common/js/axiosConfig";
import Toast from "../../../common/comComponent/toast/index";
import ptsAlert from "../../../common/comComponent/alertWindow";
export default {
  data() {
    return {
      title: "温度计月报详情",
      image: require("../../../common/images/detail.png"),
      icon_nos: require("../../../common/images/icon_noselect@3x.png"),
      icon_sele: require("../../../common/images/icon_selected@3x.png"),
      checkedAll: false,
      checkStatus: false,
      checked: [],
      dataList: [],
      networkCodeArr: [],
      unTotalCount: "",
      totalCount: "",
      showRemind:false,
    };
  },
  methods: {
    requestData() {
      // "http://localhost:8888/postGetData",
      //   {
      //     path: "car",
      //     file: "monthlyDetails"
      //   };
      //API.getWebServiceUrls("monthlyDetails")
      Axios.post(API.getWebServiceUrls("monthlyDetail"), {
        "pageNo": this.pageNo || 1,
        "pageSize": 20,
        "type": 1
      })
        .then(res => {
          let resData =
            typeof res.data === "string" ? JSON.parse(res.data) : res.data;
          // console.log(resData);
          this.unTotalCount = resData.totalCount;
          resData.data.forEach(v => {
            v.checked = false;
            this.dataList.push(v);
          });
          this.companyDimensionList = resData.data.companyDimensionList;
          this.networkName = resData.data.networkName;
        })
        .catch(err => {
          console.log(err);
        });
    },
    // 全选
    changeState() {
      if (this.checkedAll == true) {
        this.checkedAll = false;
      } else {
        this.checkedAll = true;
      }
      this.dataList.forEach(v => {
        if (this.checkedAll == true) {
          v.checked = true;
        } else {
          v.checked = false;
        }
      });
    },
    //单选，多选
    checkbox(item) {
      this.checkStatus = !this.checkStatus;
      if (item.checked == false) {
        item.checked = true;
      } else {
        item.checked = false;
      }
      for (let i = 0; i < this.dataList.length; i++) {
        if (this.dataList[i].checked == false) {
          this.checkedAll = false;
          break;
        } else {
          this.checkedAll = true;
        }
      }
    },
    // 取消
    cancel() {
      this.checkedAll = false;
      this.dataList.forEach(item => {
        item.checked = false;
        item.checkStatus = false;
      });
    },
    // 确认提醒，把checked为true的信息以数组的形式传给后台，点击确认之后重新获取数据渲染
    remind() {
      let that = this;
      for (let i = that.dataList.length - 1; i >= 0; i--) {
        let index = that.dataList[i];
        if (index.checked) {
          that.networkCodeArr.push(that.dataList[i].networkCode);
        }
      }
      if (this.networkCodeArr.length > 0 || this.checkedAll === true) {
        Axios.post(API.getWebServiceUrls("monthlyReminding"), {
          requestList: this.networkCodeArr
        })
          .then(res => {
            let data = res.data;
            // console.log(data);
            if (data.code > 0) {
              Toast(data.msg);
              return;
            }
            this.showRemind = true;
          })
          .catch(err => {
            console.log(err);
          });
        this.networkCodeArr = [];
      } else {
        Toast("请选择其中任意一个再确认提醒");
        return;
      }
    }
  },
  mounted() {
    this.$nextTick(function() {
      this.requestData();
    });
    let totalCount = this.$route.query.totalCount;
    this.totalCount = totalCount;
  },
  components: {
    ptsAlert
  }
};
</script>

<style lang="less" scoped>
.showRemind{
  width: 4.8rem;
  height: 3.2rem;
  background-color: #fff;
  border-radius: 0.06rem;
  text-align: center;
  .title{
    font-size: 0.28rem;
    line-height: 0.28rem;
    color: #333333;
    padding-top: 1.08rem;
  }
  p{
    font-size: 0.3rem;
    line-height: 0.3rem;
    color: #fe883a;
    margin-top: 1.04rem;
  }
}
main {
  .write-wrap {
    /*display: flex;*/
    position: relative;
    height: 100%;
    overflow: hidden;
    .table-wrap {
      overflow: auto;
      .write-table {
        width: 6.9rem;
        margin: 0.2rem auto 0.5rem;
        text-align: center;
        thead {
          background-color: #f2f2f2;
          width: 6.9rem;
          height: 0.73rem;
          tr {
            th {
              font-size: 0.24rem;
              line-height: 0.24rem;
              color: #999999;
              height: 0.73rem;
              font-weight: normal;
            }
            .tl {
              text-align: left;
              padding-left: 0.28rem;
            }
          }
        }
        tbody {
          width: 100%;
          tr {
            .branchName {
              width: 2.16rem;
              height: 0.58rem;
              font-size: 0.24rem;
              line-height: 0.35rem;
              text-align: left;
              padding-left: 0.27rem;
            }
            td {
              font-size: 0.28rem;
              line-height: 0.9rem;
              color: #333333;
              position: relative;
              input {
                width: 1rem;
                height: 1rem;
                position: absolute;
                left: -0.5rem;
              }
            }
          }
        }
      }
    }
  }

  .header {
    width: 7.5rem;
    height: 2.43rem;
    position: relative;
    color: #ffffff;
    font-weight: normal;
    .headerLeft {
      position: absolute;
      top: 0.98rem;
      left: 0.31rem;
      font-size: 0.24rem;
    }
    .headerRight {
      position: absolute;
      top: 0.98rem;
      right: 0.29rem;
      font-size: 0.24rem;
    }
    img {
      width: 100%;
      height: 100%;
    }
  }
  .affirm {
    background-color: #ffffff;
    width: 100%;
    height: 0.48rem;
    line-height: 0.68rem;
    position: relative;
    margin-top: -0.45rem;
    font-size: 0.28rem;
    font-weight: normal;
    .unaffirm {
      margin-left: 0.3rem;
      &.unaffirm:after {
        display: block;
        content: "";
        position: absolute;
        top: 0.2rem;
        left: 0;
        width: 0.1rem;
        height: 0.28rem;
        margin-top: 0rem;
        background: #fe883a;
      }
    }
  }
}
.icon {
  width: 0.3rem;
  height: 0.3rem;
  margin: 0.3rem 0.12rem 0 0.3rem;
}
.iconImg {
  margin-left: -0.1rem;
}
.box {
  position: relative;
}
footer {
  width: 100%;
  height: 0.9rem;
  position: fixed;
  bottom: 0rem;
  left: 0;
  padding-top: 0.5rem;
  z-index: 999;
  background-color: #fff;
  input {
    width: 1rem;
    height: 1rem;
    position: absolute;
    left: -0.1rem;
  }
  span {
    color: #333333;
    font-size: 0.28rem;
  }
  #cancel {
    color: #fe883a;
    font-size: 0.32rem;
    line-height: 0.9rem;
    margin-left: 2.15rem;
  }
  button {
    background-color: #fe883a;
    width: 2.5rem;
    height: 0.9rem;
    color: #ffffff;
    font-size: 0.32rem;
    position: absolute;
    left: 5rem;
    bottom: 0;
    font-weight: normal;
    outline: none;
    border: none;
  }
}
</style>