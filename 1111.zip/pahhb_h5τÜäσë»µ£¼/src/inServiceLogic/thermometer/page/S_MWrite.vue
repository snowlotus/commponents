<template>
  <div class="box">
    <pts-header :title-text="title" :left-flag="leftFlag" @on-left="goMenu"></pts-header>
    <main>
      <section>
        <div class="data-null" v-if="dataNUll"></div>
        <pts-cell v-else v-for="(item, index) in list" :key="index" :item-data="item" @on-click="goNext"></pts-cell>
      </section>
    </main>
  </div>
</template>

<script>
  import ptsCell from '../template/cell.vue'
  import axios from '../../../common/js/axiosConfig'
  import url from '../../../common/js/comConfig'
  import Toast from '../../../common/comComponent/toast/index'


  export default {
    name: 'S_MWrite',
    data () {
      return {
        title: '温度计',
        list: [],
        url: '',
        leftFlag: true,
        dayOrMonth: '',
        dataNUll: false
      }
    },
    methods: {
      /**
       * 获取日表列表
       */
      getEditList () {
        /*axios.post("http://localhost:8888/postGetData", {
          "file": 'getMonthlyNetWorkStatus',
          "path": 'car'})*/
        axios.post(url.getWebServiceUrls('getDayOrMonthNetWork'), {
          type: this.dayOrMonth
        }).then(res => {
          let resData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (resData.code === 0 || resData.code === "0") {
            this.list = resData.data || '';
            this.dataNUll = false;
          } else {
            this.dataNUll = true;
            Toast(resData.msg || '系统繁忙请稍后重试');
          }
        }).catch(err => {
          this.dataNUll = true;
          console.log(err);
        })
      },
      /* 跳转编辑页面 */
      goNext (item) {
        let URL = this.dayOrMonth === '2' ? this.url : (item.status === 0 ? this.url : '/inside/thermometer/S_MDataReport');
        this.$router.push({
          path: URL,
          query: {
            title: item.networkName,
            networkCode: item.networkCode,
            flag: this.dayOrMonth === '2' ? 'month' : undefined
          }
        })
      },
      /* 确定是从哪里进来的页面并改变页面的逻辑 */
      init () {
        //从路由的flag 来判断 day month
        let _this = this;
        let obj = {
          day () {
            _this.title = '编辑日报';
            _this.url = '/inside/thermometer/writeTable';
            _this.leftFlag = true;
            _this.dayOrMonth = '1';
            return true;
          },
          month () {
            _this.title = '编辑月报';
            _this.url = '/inside/thermometer/writeTable';
            _this.leftFlag = false;
            _this.dayOrMonth = '2';
            return true;
          }
        };
        this.$route.query.flag && obj[this.$route.query.flag]() || obj.day();
      },
      /* 返回navtive首页 */
      goMenu () {
        console.log('返回Navtive首页');
        Native.requestHybrid({
          tagname: 'backHome'
        })
      }
    },
    components: {
      ptsCell
    },
    activated () {
      this.init();
      this.getEditList();
    }
  }
</script>

<style lang="less" scoped>

</style>
