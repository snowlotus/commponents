<template>
  <div class="box bg_fff">
    <pts-header :title-text="title" show-right :left-flag="isva_vp" @on-left="goMenu">
      <div class="textBanner" slot="center">
        <pts-text-scroll @input="setTitle" :is-have-all="isva_vp" :text="titleText" ref="tans"></pts-text-scroll>
      </div>
      <div class="nav-go-choose-model"
           :style="{display: (activeTab === 'C'&&Number(nowMonth)-1!==Number(monthValue)) ?'none':'block'}"
           slot="right"
           v-if="!isva_vp && activeTab !== 'D'" @click="editJob">编辑
      </div>
      <div class="nav-go-choose-model" slot="right" v-else @click.stop="getYearDetail">详情</div>
    </pts-header>
    <main class="mainWrap insideXubaoWrap pos-rel">
      <!-- VA&VP 时显示的日月年tab 开始-->
      <ul class="taskTitleArea c columnThree date-tab" v-if="isva_vp">
        <li class="pts-b-b" :class="{'cur': activeTab === 'A'}" @click="changeTab('A')"><em>当日</em></li>
        <li class="moreOption pts-b-b" :class="{'cur': activeTab === 'C'}" @click="changeTab('C')">
          <em>{{monthValue | chineseMonth}}月<a href="javascript:;" :class="{'arrowUp': showDateTime}" otype="button"
                                               otitle="展开"
                                               class="openSlect">展开</a></em>
        </li>
        <li class="pts-b-b" :class="{'cur': activeTab === 'D'}" @click="changeTab('D')"><em>当年</em></li>
      </ul>
      <!-- VA&VP 时显示的日月年tab 结束-->

      <!-- S&M 时显示的昨日, 今日, 月年tab 开始-->
      <ul class="taskTitleArea c columnThree date-tab" v-else>
        <li class="pts-b-b w25" :class="{'cur': activeTab === 'A'}" @click="changeTab('A')"><em>当日</em></li>
        <li class="pts-b-b w25" :class="{'cur': activeTab === 'B'}" @click="changeTab('B')"><em>昨日</em></li>
        <li class="moreOption pts-b-b w25" :class="{'cur': activeTab === 'C'}" @click="changeTab('C')">
          <em>{{monthValue | chineseMonth}}月<a href="javascript:;" :class="{'arrowUp': showDateTime}" otype="button"
                                               otitle="展开"
                                               class="openSlect">展开</a></em>
        </li>
        <li class="pts-b-b w25" :class="{'cur': activeTab === 'D'}" @click="changeTab('D')"><em>当年</em></li>
      </ul>
      <!-- S&M 时显示的昨日, 今日, 月年tab 结束-->

      <!--&lt;!&ndash; S&M 时显示 input 表格 开始&ndash;&gt;-->
      <!--<pts-write-page v-if="!isva_vp && showWrite && activeTab==='A'" :showWrite.sync="showWrite"></pts-write-page>-->
      <!--&lt;!&ndash; S&M 时显示 input 表格  结束&ndash;&gt;-->

      <!-- echarth 图表页面 开始 -->
      <!-- showType 是上面tab选中的值 为 A/B时显示日 C/D时显示 年月 -->
      <!-- isGetData 为true 时 代表 用户身份是S&M时 且需要录入日报的组件时,是不需要请求今日的图表数据 -->
      <pts-echarts :showType="activeTab" :month="activeMonth"
                   ref="echartsPage" :titleCode="titleCode" :time="time"></pts-echarts>
      <!-- echarth 图表页面 结束 -->
    </main>
  </div>
</template>

<script>
  import ptsTextScroll from '../../../common/comComponent/textScroll/index';
  import ptsWritePage from './writeTable.vue';
  import ptsEcharts from './echarts.vue';
  import '../../../common/filters/convertDate';
  import '../../../common/filters/convertAmount';
  import {loadEcharts} from '../../../common/js/comUtils'
  import titleMixin from '../mixin/titieText';

  const date = new Date();
  export default {
    name: 'insideThermometerS_MDataReport',
    mixins: [titleMixin],
    data () {
      return {
        title: '温度计', // 头部标题
        activeTab: 'A', // 默认为日
        showDateTime: false, // 控制月的箭头的方法 为true时向上
        nowMonth: date.getMonth() + 1,
        monthValue: date.getMonth() + 1, // 默认当前的月份
        activeMonth: `${date.getFullYear()}-${(date.getMonth() + 1 < 10) ? '0' + (date.getMonth() + 1) : date.getMonth() + 1}`, // 默认选中当前月
        isva_vp: (window.dealerData.frontLineRoleType === 'vp' || window.dealerData.frontLineRoleType === 'va'), // 是否是 va||vp
        // showWrite: true, // 是否显示录入日报 , 由于图表组件需要根据这个来判断是否需要加载今日的数据
        titleText: '全部网点', // 从上一个页面传递的titie //默认全部网点
        url: '',//点击编辑跳转url的地址
        showScroll: false,
        trans: '',
        time: '' // 时间戳 让页面进行渲染
      }
    },
    methods: {
      /* 返回navtive 首页 */
      goMenu () {
        console.log('返回Navtive首页');
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      /* 日月年切换tab
       * type A: 今日,B: 昨日, C: 月, D: 年
       * */
      changeTab (type) {
        if (type !== 'C' && this.activeTab === type) {
          return
        }
        const date = new Date();
        const year = date.getFullYear();
        let startDate = new Date();
        startDate.setMonth(date.getMonth() - 10);
        if (type === 'C') {
          if (this.activeTab === type) {
            this.$vux.datetime.show({
              value: this.activeMonth,
              cancelText: '取消',
              confirmText: '确定',
              format: 'YYYY-MM',
              minYear: year,
              maxYear: year,
              startDate: `${startDate.getFullYear()}-${startDate.getMonth() > 10 ? '0' + startDate.getMonth() : startDate.getMonth()}-01`,
              endDate: `${year}-${(date.getMonth() + 1) > 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1)}-01`,
              onConfirm: (v) => {
                if (this.activeMonth === v) return;
                this.activeMonth = v;
                this.monthValue = v.substr(v.indexOf('-') + 1);
                this.$nextTick(function () {
                  this.$refs.echartsPage.getData('C', v);
                })
              },
              onShow: () => {
                this.showDateTime = true;
              },
              onHide: () => {
                this.showDateTime = false;
              }
            })
          }
        }
        this.activeTab = type;
      },
      /**
       * 点击编辑跳转
       */
      editJob () {
        let _this = this;
        this.goToUrl();
        let headerTitle = Object.assign({}, this.$route.query);
        headerTitle.flag = _this.activeTab === 'A' || _this.activeTab === 'B' ? 'day' : 'month';
        headerTitle.title = this.titleText;
        headerTitle.networkCode = this.titleCode;
        headerTitle.isYesterday = _this.activeTab === 'B' ? 1 : undefined;
        this.$router.push({
          path: _this.url,
          query: headerTitle
        });
      },
      /**
       * 跳转Url 地址
       */
      goToUrl () {
        // let goUrl = '';
        if (this.activeTab === 'A' || this.activeTab === 'B') {
          this.url = "/inside/thermometer/writeTable";
        } else {
          this.url = "/inside/thermometer/index";
        }
      },
      /**
       * 查看年的详情
       */
      getYearDetail () {
        let path = '';
        const activeTab = this.activeTab;
        if (this.isva_vp) {
          if (activeTab === 'A' || activeTab === 'D') {
            path = '/inside/thermometer/VPDailyDetails';
          } else {
            path = '/inside/thermometer/VPMonthlyDetails'
          }
        } else {
          if (activeTab === 'D') path = '/inside/thermometer/VPDailyDetails';
        }
        this.$router.push({
          path: path,
          query: {
            activeTab: this.activeTab
          }
        })
      }
    },
    components: {
      ptsTextScroll,
      ptsWritePage,
      ptsEcharts
    },
    activated () {
      console.log('进入报表页面');
      let query = this.$route.query;
      this.time = query.time || '';
      this.setTitle(query.networkCode, query.title || '全部网点');
    },
    beforeRouteEnter (to, form, next) {
      loadEcharts(next)
    }
  }
</script>

<style lang="less" scoped>
  .nav-go-choose-model {
    position: absolute;
    top: 0;
    right: 0;
    display: block;
    width: 1.5rem;
    height: 0.8rem;
    line-height: 0.8rem;
    text-align: right;
    padding-right: 0.3rem;
    color: #333333;
    font-size: 0.28rem;
  }

  .w25 {
    width: 25% !important;
  }
</style>
