<template>
  <div class="echarts-wrap">
    <div class="time-wrap">
      <time>{{dataTime}}</time>
    </div>
    <!-- 日 开始 -->
    <section v-if="showDay">
      <div class="echarts-item">
        <div class="title">整体单量(台)</div>
        <div class="echarts-area">
          <pts-bar :options="barOption" ref="dayAllBar"></pts-bar>
        </div>
      </div>
      <div class="echarts-item">
        <div class="title">新车(台)</div>
        <div class="echarts-area">
          <pts-bar :options="barOption" ref="dayNewBar"></pts-bar>
        </div>
      </div>
      <div class="echarts-item">
        <div class="title">次新车(台)</div>
        <div class="echarts-area">
          <pts-bar :options="barOption" ref="dayNoNewBar"></pts-bar>
        </div>
      </div>
      <div class="echarts-item">
        <div class="title">旧车(台)</div>
        <div class="echarts-area">
          <pts-bar :options="barOption" ref="dayOldBar"></pts-bar>
        </div>
      </div>
    </section>

    <!-- 日 结束 -->
    <!-- 今日 开始 -->

    <!-- 今日 结束 -->
    <!-- 月 / 年 开始 -->
    <section v-else>
      <div class="tab-area">
        <span v-for="(item, index) in dimensions" :key="index"
              :class="{'active': activeTab === item.dimensionsName}"
              @click.stop="changeTab(item.dimensionsName)">{{item.dimensionsName}}</span>
      </div>
      <div class="echarts-item">
        <div class="title">整体单量(台)</div>
        <div class="echarts-area">
          <pts-bar :options="barOption" ref="allBar"></pts-bar>
        </div>
      </div>
      <div class="echarts-item">
        <div class="title">整体走势</div>
        <div class="echarts-area">
          <pts-line :options="lineOption" ref="allLine"></pts-line>
        </div>
      </div>
      <div class="echarts-item">
        <div class="title">份额走势</div>
        <div class="echarts-area">
          <pts-line :options="lineOption" ref="fenLine"></pts-line>
        </div>
      </div>
    </section>
    <!-- 月 结束 -->
    <!-- 年 开始 -->

    <!-- 年 结束 -->
  </div>
</template>

<script>
  import ptsBar from '../../../common/comComponent/echarts/bar.vue';
  import ptsLine from '../../../common/comComponent/echarts/line.vue';
  import {remInPx} from '../../../common/js/comUtils';
  import axios from '../../../common/js/axiosConfig';
  import url from '../../../common/js/comConfig';
  import toast from '../../../common/comComponent/toast';

  export default {
    props: {
      showType: String, // 是显示日 还是显示月年
      month: String, // 显示月时后台需要月份的具体值
      isGetData: Boolean, // 为true 时 代表 用户身份是S&M 且需要录入今日的日报,是不需要请求今日的图表数据
      titleCode: String, // 用户选择的网点的code
      time: String
    },
    data () {
      return {
        dataTime: '2018-09-09 00:00:00', // 后台查询的时间
        activeTab: "", // 选中的tab代表的值 后端需要name值
        barOption: {
          legend: {
            data: ['份额'],
            top: 0,
            right: '5%'
          },
          color: ['#549DFF', '#8ABCFF', '#8ABCFF'],
          xAxis: [
            {
              type: 'category',
              boundaryGap: true,
              axisLine: {
                show: false
              },
              axisLabel: {
                fontSize: remInPx(0.24),
                padding: [10, 0, 0, 0]
              },
              axisTick: {
                show: false
              },
              data: ['平安', '人保', '其他']
            }
          ],
          yAxis: [
            {
              type: 'value',
              show: true,
              axisLine: {
                show: false
              },
              axisLabel: {
                color: '#999999',
                fontSize: remInPx(0.18)
              },
              axisTick: {
                show: false
              },
              splitLine: {
                lineStyle: {
                  type: 'dash',
                  color: '#EEEEEE',
                }
              }
            },
            {
              // name: '份额',
              type: 'value',
              show: true,
              axisLine: {
                show: false
              },
              axisLabel: {
                color: '#999999',
                fontSize: remInPx(0.18)
              },
              axisTick: {
                show: false
              },
              splitLine: {
                lineStyle: {
                  type: 'dash',
                  color: '#EEEEEE',
                }
              },
              max: function (value) {
                // 为了保障折线图的点在柱状图的中间,因此会把折线图的最大值*2
                return value.max * 2;
              }
            }
          ],
          grid: {
            top: '15%',
            left: '10%'
          },
          tooltip: {
            trigger: 'item',
            formatter: "{c}",
          },
          series: [
            {
              type: 'line',
              name: '份额',
              yAxisIndex: 1, // 使用第二个Y轴
              symbol: 'circle',
              symbolSize: remInPx(0.16),
              lineStyle: {
                width: 1,
              },
              itemStyle: {
                color: '#FFDB4B',
              },
              data: [0, 0, 0],
            },
            {
              name: '平安',
              type: 'bar',
              yAxisIndex: 0, // 使用第一个Y轴
              silent: true,
              data: [0, 0, 0],
              barWidth: 40,
              label: {
                show: true,
                position: 'top',
                distance: remInPx(0.21),
                color: '#666666',
                fontSize: remInPx(0.22)
              }
            }
          ]
        }, // 柱状图配置json
        lineOption: {
          legend: {
            data: ['平安', '人保', '其他'] //, '未续'
          },
          xAxis: {
            data: []
          },
          grid: {
            left: '5%',
            right: '5%'
          },
          color: ['#60D194', '#FFDB4B', '#FE883A'],
          series: [
            {
              name: '平安',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [0]
            },
            {
              name: '人保',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [0]
            },
            {
              name: '其他',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [0]
            }
          ]
        }, // 折线图配置json
        showDay: true, // 是显示日还是显示月/年
        dimensions: []
      }
    },
    components: {
      ptsBar,
      ptsLine
    },
    methods: {
      /* 切换新车/旧车等维度的时候触发 */
      changeTab (type) {
        this.activeTab = type;
        this.getShowType(this.showType);
      },
      /* 请求数据 */
      getData (type, month) {
        let self = this;
        let data;
        axios.post(url.getWebServiceUrls('getMonthOrYearEachters'), {
          dealerCode: this.titleCode,
          dimensions: (type === 'C' || type === 'D') ? this.activeTab : undefined,
          queryType: type,
          queryValue: month
        })
        /*axios.post("http://localhost:8888/postGetData", {
          "file": 'wendijiMonth',
          "path": 'car'
        })*/
          .then(res => {
            data = res.data;

            if (data.code > 0) {
              toast(data.msg);
              self.init();
              return false;
            }
            data = data.data;
            self.dataTime = data.sysTimes;
            /* 月或年走的逻辑 */
            if (data.monthYearReportVO || type === 'C' || type === 'D') {
              data = data.monthYearReportVO;

              /* 为了保持Y轴只显示五条线需要设置Y轴的最小间隔值; */
              // 折线图Y轴最小的间隔 (为了保障折线图的点在柱状图的中间,因此会把折线图的最大值*2, 因此这里只需要除以2)
              let shareYMIn = self.getYminInterval({data: data.shareBarrel}, 2);
              // 柱状图Y轴最小间隔
              let barrelYMIn = self.getYminInterval({data: data.barrel});
              // 月份或年份柱状图数据
              let monthBarData = [
                {
                  data: data.shareBarrel // 份额折线图
                },
                {
                  data: data.barrel // 单量柱状图
                }
              ];
              // 月份或年份整体折线图数据 (trend)
              let monthAllLineData = {
                other: [],
                pingan: [],
                rb: []
              };
              // 月份或年份份额折线图数据 (shareTrend)
              let monthFenerLineData = {
                other: [],
                pingan: [],
                rb: []
              };
              // 因为份额走势的数组长度与整体走势的数组长度会一致,因此只循环一个数组即可,
              // 且 X 轴的日期也应该是一样的因此可以使用同一个X 轴的数据;
              let Xdata = [];
              data.shareTrend.forEach((v, i) => {
                let trendData = data.trend[i];
                monthAllLineData.other.push(trendData.other);
                monthAllLineData.pingan.push(trendData.pingan);
                monthAllLineData.rb.push(trendData.rb);
                monthFenerLineData.other.push(v.other);
                monthFenerLineData.pingan.push(v.pingan);
                monthFenerLineData.rb.push(v.rb);
                Xdata.push(v.dataTime);
              });
              // 改变X轴的显示格式 月显示为 MM.DD 年显示为 YYYY.MM
              Xdata = self.makeXData(Xdata, type);
              // 还需要计算出需要Y轴保持五条刻度时 刻度之间的间隔
              let monthAllLineYMin = self.getYminInterval(monthAllLineData); // 整体
              let monthFenerLineYMin = self.getYminInterval(monthFenerLineData); // 份额
              // 整体单量柱状图
              self.$refs.allBar && self.$refs.allBar.setData(echarts => {
                echarts.setOption({
                  yAxis: [
                    {
                      minInterval: barrelYMIn // 柱状图

                    },
                    {
                      minInterval: shareYMIn // 折线图
                    }
                  ],
                  series: monthBarData
                })
              });
              // 整体走势折线图
              self.$refs.allLine && self.$refs.allLine.setData((echarts) => {
                echarts.setOption({
                  title: [
                    {
                      text: Xdata[0]
                    },
                    {
                      text: Xdata[Xdata.length - 1]
                    }
                  ],
                  xAxis: {
                    data: Xdata
                  },
                  yAxis: {
                    minInterval: monthAllLineYMin
                  },
                  series: [
                    {
                      data: monthAllLineData.pingan // 平安
                    },
                    {
                      data: monthAllLineData.rb // 人保
                    },
                    {
                      data: monthAllLineData.other // 其他
                    }
                  ]
                })
              });
              // // 份额走势折线图
              self.$refs.fenLine && self.$refs.fenLine.setData((echarts) => {
                echarts.setOption({
                  title: [
                    {
                      text: Xdata[0]
                    },
                    {
                      text: Xdata[Xdata.length - 1]
                    }
                  ],
                  xAxis: {
                    data: Xdata
                  },
                  yAxis: {
                    minInterval: monthFenerLineYMin
                  },
                  series: [
                    {
                      data: monthFenerLineData.pingan // 平安
                    },
                    {
                      data: monthFenerLineData.rb // 人保
                    },
                    {
                      data: monthFenerLineData.other // 其他
                    }
                  ]
                })
              });
            }
            /* 日走的逻辑 */
            else {
              data = data.dayReportVO;
              // 整体
              this.$refs.dayAllBar && this.$refs.dayAllBar.setData((echarts) => {
                echarts.setOption({
                  yAxis: [
                    {
                      minInterval: self.getYminInterval({data: data.vo1.amount}) // 柱状图
                    },
                    {
                      minInterval: self.getYminInterval({data: data.vo1.portion}, 2) // 折线图
                    }
                  ],
                  series: [
                    {
                      data: data.vo1.portion // 折线图
                    },
                    {
                      data: data.vo1.amount // 柱状图
                    }
                  ]
                })
              });
              // 新车
              this.$refs.dayNewBar && this.$refs.dayNewBar.setData((echarts) => {
                echarts.setOption({
                  yAxis: [
                    {
                      minInterval: self.getYminInterval({data: data.vo2.amount}) // 柱状图
                    },
                    {
                      minInterval: self.getYminInterval({data: data.vo2.portion}, 2) // 折线图
                    }
                  ],
                  series: [
                    {
                      data: data.vo2.portion
                    },
                    {
                      data: data.vo2.amount
                    }
                  ]
                })
              });
              // 次新车
              this.$refs.dayNoNewBar && this.$refs.dayNoNewBar.setData((echarts) => {
                echarts.setOption({
                  yAxis: [
                    {
                      minInterval: self.getYminInterval({data: data.vo3.amount}) // 柱状图
                    },
                    {
                      minInterval: self.getYminInterval({data: data.vo3.portion}, 2) // 折线图
                    }
                  ],
                  series: [
                    {
                      data: data.vo3.portion
                    },
                    {
                      data: data.vo3.amount
                    }
                  ]
                })
              });
              // 旧车
              this.$refs.dayOldBar && this.$refs.dayOldBar.setData((echarts) => {
                echarts.setOption({
                  yAxis: [
                    {
                      minInterval: self.getYminInterval({data: data.vo4.amount}) // 柱状图
                    },
                    {
                      minInterval: self.getYminInterval({data: data.vo4.portion}, 2) // 折线图
                    }
                  ],
                  series: [
                    {
                      data: data.vo4.portion
                    },
                    {
                      data: data.vo4.amount
                    }
                  ]
                })
              })
            }
          })
          .catch(e => {
            this.init();
            toast('系统繁忙, 请稍后再试');
          })
      },
      /* 当是月份或年时,从后台拿到对应的维度(新车/旧车等) */
      getDomensionsList () {
        axios.post(url.getWebServiceUrls('getDomensionsList'))
          .then(res => {
            let data = res.data;
            if (data.code !== 0) {
              toast(data.msg);
              return false;
            }
            this.dimensions = data.data;
            this.activeTab = data.data[0].dimensionsName;
          }).catch(e => {
          console.log(e);
        })
      },
      /* 请求出错时初始化图表 */
      init () {
        // 调用对应的echarts 组件内部的init 函数做初始化;
        let elem = this.$refs;
        for (let item in elem) {
          elem[item] && typeof elem[item].init === 'function' && elem[item].init();
        }
      },
      getShowType (newV) {
        let _this = this;
        // 为true 时 代表 用户身份是S&M 且需要录入今日的日报,是不需要请求今日的图表数据
        if (this.isGetData) return;
        switch (newV) {
          case 'A': // 今日
            _this.showDay = true;
            this.$nextTick(function () {
              _this.getData(newV);
            });
            break;
          case 'B': // 昨日
            _this.showDay = true;
            _this.$nextTick(function () {
              _this.getData(newV);
            });
            break;
          case 'C': // 月
            _this.showDay = false;
            _this.$nextTick(function () {
              _this.getData(newV, _this.month);
            });
            break;
          case 'D': // 年
            _this.showDay = false;
            _this.$nextTick(function () {
              _this.getData(newV);
            });
            break;
        }
      },
      /* 生成折线图的x轴的数据
       * list 根据list确定x轴的长度
       * type C 月(03.08), D 年(2018.03)
       * */
      makeXData (list, type) {
        let arr = [];
        list.forEach(v => {
          // 截取字符串
          v = v.replace(/-/g, '.');
          v = type === 'C' ? v.substr(v.indexOf('.') + 1, 6) : v.substr(0, 7);
          arr.push(v);
        });
        return arr;
      },
      /* 计算出Y轴五条线时的刻度间隔值
       * param  ${Object} 需要计算数组的集合;
       * param  ${dividend} 需要取得倍数 默认为4;
       * return ${number} Y 轴最下的间隔值;
       * */
      getYminInterval (obj, dividend = 4) {
        let arr = [];
        let max;
        Object.keys(obj).forEach(v => {
          arr = arr.concat(obj[v]);
        });
        max = Math.max.apply(Math, arr);
        arr = null;
        return Math.ceil(max / dividend);
      },
      /*
      * 根据状态请求数据
      * */
      getDataInType () {
        this.getShowType(this.showType);
      }
    },
    watch: {
      showType: {
        handler: 'getShowType',
        immediate: false
      },
      titleCode: {
        handler: 'getDataInType',
        immediate: false
      },
      time: {
        handler: 'getDataInType',
        immediate: false
      }
    },
    mounted () {
      console.log('创建echarts');
      this.getDomensionsList();
    }
  }
</script>

<style lang="less" scoped>
  @import '../../../common/css/theme';

  .time-wrap {
    width: 100%;
    margin: 0.2rem 0;
    text-align: center;
    font-size: 0.22rem;
    color: #999999;
    letter-spacing: 0;
    line-height: 22px;
  }

  .tab-area {
    width: 6.9rem;
    height: 0.62rem;
    border-radius: 0.08rem;
    overflow: hidden;
    border: 0.01rem solid @theme-color;
    margin: 0 auto 0.2rem;
    font-size: 0;
    & > span {
      display: inline-block;
      height: 100%;
      width: 24.87%;
      font-size: 0.24rem;
      color: @theme-color;
      text-align: center;
      line-height: 0.62rem;
      border-right: 0.01rem solid #fe883a;
      &:last-child {
        border: none;
      }
      &.active {
        background: @theme-color;
        color: #fff;
      }
    }
  }

  .echarts-item {
    margin-bottom: 0.2rem;
    .title {
      font-size: 0.28rem;
      color: #333333;
      line-height: 0.28rem;
      padding-left: 0.3rem;
      margin-bottom: 0.2rem;
      position: relative;
      &:after {
        content: '';
        display: block;
        position: absolute;
        top: 0;
        left: 0;
        transform: translate(-50%);
        width: 0.08rem;
        height: 0.24rem;
        background: @theme-color;
      }
    }
  }
</style>
