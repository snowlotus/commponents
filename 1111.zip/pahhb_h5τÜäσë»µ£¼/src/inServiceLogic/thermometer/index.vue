<template>
    <div>
      <section v-if="!isva_vp">
        <pts-smcell></pts-smcell>
      </section>
      <section v-else>
        <pts-echartes-page></pts-echartes-page>
      </section>
    </div>
</template>

<script>
  import ptsSmcell from './page/S_MWrite.vue';
  import ptsEchartesPage from './page/dataReport.vue';
  import { loadEcharts,getCookie, setCookie } from '../../common/js/comUtils';
  export default {
    data () {
      return {
          isva_vp: (window.dealerData.frontLineRoleType === 'vp' || window.dealerData.frontLineRoleType === 'va')
      }
    },
    components: {
      ptsSmcell,
      ptsEchartesPage
    },
    created () {
      let self = this;
      // 当用户不是vp的时候需要弹窗
      if (window.dealerData.frontLineRoleType !== 'vp') {
        Native.requestHybrid({
          tagname: 'showAccountAlert'
        })
      }
      //此方法供Native调用,表示把自己维护成了Vp
      window.changeRoleToVp = function () {
        let header = JSON.parse(getCookie('header'));
        header.frontLineRoleType = 'vp';
        setCookie('header', JSON.stringify(header));
        window.location.reload();
      }
    },
    beforeRouteEnter(to, form, next) {
      loadEcharts(next);
    }
  }
</script>

<style lang="less">

</style>
