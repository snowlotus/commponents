<template>
  <div class="write-wrap">
    <div class="table-wrap">
      <table class="write-table">
        <thead>
          <tr>
            <th class="tl">网点名称</th>
            <th>网点整体</th>
            <th>平安整体</th>
            <th>平安新车</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item,index) in dataList" :key="index" v-if="dataList.length>0">
            <td class="branchName">{{item.netName}}</td>
            <td>{{item.salesTotal}}</td>
            <td>{{item.pinganData}}</td>
            <td>{{item.pinganNewCar}}</td>
          </tr>
        </tbody>
      </table>
      <p @click.prevent="loadMore" v-if="totalPages>1">加载更多</p>
    </div>

  </div>
</template>

<script>
import API from "../../../common/js/comConfig";
import Axios from "../../../common/js/axiosConfig";
export default {
  name: "wendujiTable",
  props: {
    dataList: Array,
    totalPages: ""
  },
  data() {
    return {
      flag: ""
    };
  },
  methods: {
    loadMore() {
      this.$emit("loadmore", this.dataList);
    }
  },
  activated() {
    this.flag = this.$route.query && this.$route.query.flag;
  },
  mounted() {}
};
</script>

<style lang="less" scoped>
.write-wrap {
  /*display: flex;*/
  position: relative;
  height: 100%;
  overflow: hidden;
  .table-wrap {
    overflow: auto;
    .write-table {
      width: 6.9rem;
      margin: 0.2rem auto 0;
      text-align: center;
      thead {
        background-color: #f2f2f2;
        width: 6.9rem;
        height: 0.73rem;
        tr {
          th {
            font-size: 0.24rem;
            line-height: 0.24rem;
            color: #999999;
            height: 0.73rem;
            font-weight: normal;
          }
          .tl {
            text-align: left;
            padding-left: 0.28rem;
          }
        }
      }
      tbody {
        width: 100%;
        tr {
          .branchName {
            width: 2.16rem;
            height: 0.58rem;
            font-size: 0.24rem;
            line-height: 0.35rem;
            text-align: left;
            padding-left: 0.27rem;
          }
          td {
            font-size: 0.28rem;
            line-height: 0.9rem;
            color: #333333;
          }
        }
      }
    }
    p {
      text-align: center;
      height: 0.6rem;
      line-height: 0.6rem;
      font-size: 0.28rem;
      color: #fe883a;
    }
  }
}
</style>
