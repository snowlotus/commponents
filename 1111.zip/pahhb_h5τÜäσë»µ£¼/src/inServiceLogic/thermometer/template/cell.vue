<template>
  <div class="cell-item pts-b-b text-hidden triangle" @click.prevent="clickEven">
    <!-- .red 字体颜色变红 -->
    <p class="content text-hidden red">{{itemData.networkName}}</p>
    <!-- .green 字体颜色变绿 -->
    <p class="type text-hidden" :class="itemData.status===0?'red':'green'">
      {{itemData.status|thermometerType(flag)}}</p>
  </div>
</template>

<script>
  import {thermometerType} from '../../../common/filters/convertPayType'


  export default {
    name: "wendujiCell",
    props: {
      itemData: Object,
    },
    data() {
      return {
        title: '温度计',
        flag: '',
      }
    },
    mounted() {

    },
    methods: {
      clickEven() {
        this.$emit('on-click', this.itemData);
      }
    },
    activated() {
      this.flag = this.$route.query && this.$route.query.flag
    }
  }
</script>

<style lang="less" scoped>
  @import "../../../common/css/theme";

  .cell-item {
    display: flex;
    padding: 0.3rem;
    color: #333;
    background: #fff;
    &.triangle { // 向右的箭头
      background: #fff url('../../../common/images/icon_arrow.png') no-repeat 95% center;
      background-size: 0.12rem 0.24rem;
    }
    &.active { // 对号
      padding: 0.2rem 0;
      background: url('../../../common/images/icon_tick.png') no-repeat 95% center;
      background-size: 0.2rem 0.2rem;
      & > .car-type, & > .car-info {
        color: @theme-color;
      }
    }
    .content {
      flex: 0 0 82%;
      font-size: 0.3rem;
    }
    .type {
      flex: 0 0 15%;
      font-size: 0.24rem;
      &.red {
        color: #FE3A3A;
      }
      &.green {
        color: #2AB768;
      }
    }
  }
</style>
