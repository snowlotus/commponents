export default {
  data () {
    return {
      titleText: "",
      titleCode: ""
    }
  },
  methods: {
    setTitle (code, text) {
      if (this.titleCode === code) return;
      this.titleText = text;
      this.titleCode = code;
      typeof this.getData === 'function' && this.getData();
      // 为了保证用户在页面修改了网点以后 进入别的页面在返回可以进入当前选择的页面需要将url中的query 替换
      let location = this.$route;
      let query = Object.assign({}, location.query);
      query.title = text;
      query.networkCode = code;
      this.$router.replace({
        path: location.path,
        query
      })
    }
  }
}
