<!-- 该组件已停止使用 -->

<template>
  <div class="wrap">
    <pts-edit show-again></pts-edit>
  </div>
</template>

<script>
  import ptsTextScroll from '../../common/comComponent/textScroll';
  import ptsEdit from './page/writeTable.vue'

  export default {
    data () {
      return {
        show: true
      }
    },
    components: {
      ptsEdit
    },
    activated () {
      this.show = !this.show;
    }
  }
</script>

<style lang="less" scoped>
  .wrap {
    width: 100%;
    height: 100%;
  }
</style>
