/**
* Created by chenchangwei837 on 2018/2/11.
*/
<template>
  <section class="box bg_f5f5f5 inClaimDetail">
    <!--<div class="newCar_top c por titleBgWhite">-->
    <!--<a href="claimList.shtml" class="navigation_arrow fl pageBack"></a>-->
    <!--<p class="friends_txt mySingle_txt fl ">案件详情</p>-->
    <!--</div>-->
    <pts-header :titleText="titleText" leftFlag @on-left="goBackHome"></pts-header>
    <div class="wrap claim">
      <!-- main start -->
      <div class="mainWrap pb30">
        <div class="fixRateArea">
          <ul class="c">
            <!-- <li class="lineRate pastRate"><i></i>报案</li>-->
            <li :class="taskStatus=='00'?'pastRate':(stateArr[0]?'lineRate pastRate':'')"><i></i>报案</li>
            <li :class="taskStatus=='01'?'pastRate':(stateArr[1]?'lineRate pastRate':'')"><i></i>定损</li>
            <li :class="taskStatus=='02'?'pastRate':(stateArr[2]?'lineRate pastRate':'')"><i></i>理算</li>
            <li :class="taskStatus=='03'?'pastRate':(stateArr[3]?'lineRate pastRate':'')"><i></i>结案</li>
          </ul>
        </div>
        <div class="taskArea reportMsgArea">
          <dl>
            <dt>报案人信息</dt>
          </dl>
          <div class="taskBox">
            <dl>
              <dt>报案人</dt>
              <dd>{{claimData.reportName}}</dd>
            </dl>
            <dl>
              <dt>案件号</dt>
              <dd>{{claimData.reportNo | fourSpace}}</dd>
            </dl>
            <dl>
              <dt>报案时间</dt>
              <dd>{{claimData.reportDate || ''}}</dd>
            </dl>
          </div>
        </div>
        <div class="taskArea detailArea">
          <dl>
            <dt>案件信息</dt>
          </dl>
          <div class="taskBox">
            <dl>
              <dt>车牌</dt>
              <dd>{{claimData.carMark || ''}}</dd>
            </dl>
            <dl>
              <dt>车型</dt>
              <dd>{{claimData.carTypeName || '*_*'}}</dd>
            </dl>
            <!-- <dl>
               <dt>推修类型</dt>
               <dd>暂无此字段</dd>
             </dl>-->
            <dl style="padding:0.08rem">
              <dt style="width:2.0rem;font-size:0.24rem;text-align:left;">预估损失金额</dt>
              <dd style="width:2.4rem;margin-left:-0.6rem;" class="f_c_FE8C41">¥{{claimData.estimateAmount | NumberThere}}</dd>
            </dl>
            <!--<dl>-->
              <!--<dt>出险时间</dt>-->
              <!--<dd>{{claimData.accidentDate || '-'}}</dd>-->
            <!--</dl>-->
            <!--<dl>-->
              <!--<dt>出险地点</dt>-->
              <!--<dd>{{claimData.accidentPlace || '-'}}</dd>-->
            <!--</dl>-->
            <dl v-if="policyDutyDataList.length>0">
              <dt>承保险别</dt>
              <dd v-for="(item,index) in policyDutyDataList" v-if="index>2?false:true"
                  :class="index===0?'moreRow':'marginLeft'">
                {{item.dutyName}}
              </dd>
              <dd class="moreRow" style="margin-left: 1.75rem;">
                <a href="javascript:;" otype="button" otitle="点击查看详情" class="checkDetail"
                   style="margin-left: -.2rem" @click.prent.stop="showDutyInfo=true">点击查看详情</a>
              </dd>
            </dl>
            <!--<dl>-->
              <!--<dt>出险经过</dt>-->
              <!--<dd>{{claimData.accidentDetail}}</dd>-->
            <!--</dl>-->
          </div>
        </div>
        <div class="taskArea detailArea">
          <dl>
            <dt>查勘信息</dt>
          </dl>
          <div class="taskBox">
            <dl>
              <dt>查勘人</dt>
              <dd>{{claimData.surveyorName}}</dd>
            </dl>
            <dl>
              <dt>查勘电话</dt>
              <dd class="f_c_508CEE"><a href="#" otype="button" otitle="" @click="callTell(claimData.surveyorMobile)">{{claimData.surveyorMobile
                | phoneType}}</a>
              </dd>
            </dl>
            <dl>
              <dt>责任系数</dt>
              <dd>{{claimData.dutyCoefficient}}</dd>
            </dl>
          </div>
        </div>
        <div class="taskArea detailArea">
          <dl>
            <dt>定损信息</dt>
          </dl>
          <div class="taskBox">
            <dl>
              <dt>定损员</dt>
              <dd>{{claimData.assessUmName}}</dd>
            </dl>
            <dl>
              <dt>定损电话</dt>
              <dd class="f_c_508CEE"><a href="#" otype="button" otitle="" @click="callTell(claimData.assessUmMobile)">{{claimData.assessUmMobile
                | phoneType}}</a>
              </dd>
            </dl>
            <dl>
              <dt>损失时间</dt>
              <dd>{{claimData.lossConfirmCompleteTime}}</dd>
            </dl>
            <dl>
              <dt>复勘状态</dt>
              <dd>{{claimData.resurveyStatus | surveyorStatusType}}</dd>
            </dl>
            <dl>
              <dt>案件状态</dt>
              <dd>{{claimData.taskStatus | inCaseStatusType}}</dd>
            </dl>
            <dl>
              <dt>定损金额</dt>
              <dd class="f_c_FE8C41">¥{{claimData.totalAgreedAmount | NumberThere}}
                <!--<a href="javascript:;" otype="button" otitle="点击查看详情" class="ml15"-->
                   <!--@click.prent.stop="showMaterialInfo=true">点击查看详情</a>-->
              </dd>
            </dl>
          </div>
        </div>
        <div class="taskArea detailArea" v-if="claimData.paymentInfoList && claimData.paymentInfoList.length>0">
          <dl>
            <dt>支付信息</dt>
          </dl>
          <div v-for="item in claimData.paymentInfoList">
            <div class="taskBox">
              <!--<dl>-->
                <!--<dt>收款方</dt>-->
                <!--<dd>{{item.clientName}}</dd>-->
              <!--</dl>-->
              <dl>
                <dt>支付对象</dt>
                <dd>{{item.clientBankName}}</dd>
              </dl>
              <!--<dl>-->
                <!--<dt>支付方式</dt>-->
                <!--<dd>{{item.collectPayApproachDesc}}</dd>-->
              <!--</dl>-->
              <dl>
                <dt>支付金额</dt>
                <dd class="f_c_fe883a">¥{{item.payAmount | NumberThere}}</dd>
              </dl>
              <dl>
                <dt>支付时间</dt>
                <dd>{{item.payDate}}</dd>
              </dl>
              <dl>
                <dt>支付状态</dt>
                <dd class="f_c_65CB91">{{item.payStatus | payStatusType}}</dd>
              </dl>
              <dl>
                <dt>备注</dt>
                <dd>{{item.remark || '-'}}</dd>
              </dl>
            </div>
            <div class="bor_line"></div>
          </div>
        </div>
      </div>
      <!-- main end -->
    </div>
    <!-- —— 遮罩层 start -->
    <div class="reMaskWrap dn"></div>
    <pts-alert v-model="showDutyInfo">
      <div class="reMaskClaim reMaskReport dn" style="display: block;">
        <a href="javascript:;" otype="button" otitle="关闭" class="closeClaimMask"
           @click.prent.stop="showDutyInfo=false">关闭</a>
        <h3>承保险别详情</h3>
        <div class="reMaskCon">
          <table border="0" cellspacing="0" cellpadding="0" width="100%">
            <tr>
              <th width="62%">承保险别</th>
              <th width="38%">保额（元）</th>
            </tr>
            <tr v-for="item in policyDutyDataList">
              <td><p>{{item.dutyName}}</p></td>
              <td>¥{{item.payLimit | NumberThere}}</td>
            </tr>
          </table>
        </div>
      </div>
    </pts-alert>
    <pts-alert v-model="showMaterialInfo">
      <div class="reMaskClaim reMaskVDE dn lossAssessment" style="display: block">
        <a href="javascript:;" otype="button" otitle="关闭" class="closeClaimMask" @click="showMaterialInfo=false">关闭</a>
        <h3>定损明细</h3>
        <div class="label">
          <div class="left">名称</div>
          <div class="right">费用（元）</div>
        </div>
        <div class="reMaskCon scrollBox">
          <div>
            <div class="line" v-for="(item,index) in materialList" :key="index">
              <div class="left">{{item.lossName}}</div>
              <div class="right">¥{{item.lossAmount | NumberThere}}</div>
            </div>
          </div>
        </div>
      </div>
    </pts-alert>
  </section>
</template>
<script>

  import Axios from '../../common/js/axiosConfig'
  import API from '../../common/js/comConfig'
  import Toast from '../../common/comComponent/toast'
  import ptsAlert from '../../common/comComponent/alertWindow'
  import {fourSpace, NumberThere} from '../../common/filters/convertAmount'
  import {
    indemnityConclusionType,
    surveyorStatusType,
    inCaseStatusType,
    payStatusType
  } from '../../common/filters/convertIdType'

  export default {
    name: 'inClaimDetail',
    data() {
      return {
        titleText: '案件详情',
        taskStatus: '00',
        stateArr: [false, false, false, false],
        showDutyInfo: false,
        showMaterialInfo: false,
        claimData: {},
        policyDutyDataList: [],
        paymentInfoList: [],
        materialList: []
      }
    },
    watch: {
      taskStatus(to, old) {
        let self = this
        if (to) {
          for (let a = 0; a < ~~to + 1; a++) {
            self.stateArr[a] = true
          }
        }
      }
    },
    mounted() {
      let reqClaimData = window.innerClaimData;
      this.$nextTick(function () {
        this.queryClaimDetail(reqClaimData)
      })
    },
    methods: {
      /**
       * 返回Native
       * @param reqData
       */
      goBackHome() {
        //回到Native主页
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      //拨打电话
      callTell(tel) {
        window.location.href = 'tel:' + tel
      },
      //查询详情
      queryClaimDetail(reqData) {
        let self = this
        //'http://localhost:8888/postGetData' , {
        //          "file": 'innerClaimInfo',
        //          "path": 'car'
        //      }
        // API.getWebServiceUrls('innerSettlementDetail'
        Axios.post(API.getWebServiceUrls('innerSettlementDetail'), reqData)
          .then(res => {
            let dataInfo =
              typeof res.data === 'string' ? JSON.parse(res.data) : res.data
            if (dataInfo.code === 0 || dataInfo.code === '0') {
              self.claimData = dataInfo.data
              self.policyDutyDataList = dataInfo.data.policyDutyDataList || [] //险种列表
              self.paymentInfoList = dataInfo.data.paymentInfoList && dataInfo.data.paymentInfoList || [] //支付列表
              self.materialList = dataInfo.data.materialAndManpowerAndOuterRepair && dataInfo.data.materialAndManpowerAndOuterRepair.materialList || [] //定损列表
              self.taskStatus = dataInfo.data.taskStatus
            } else {
              Toast(dataInfo.data.msg || '系统繁忙请稍后重试')
            }
          })
          .catch(err => {
            console.log(err)
          })
      },
      //拨打电话
      callTell(tel) {
        window.location.href = 'tel:' + tel
      }
    },
    components: {
      ptsAlert
    }
  }
</script>
<style lang="less">
  .titleBgWhite {
    background: #fff;
    color: red;
    border-bottom: 0.02rem solid #eeeeee;
  }

  .marginLeft {
    margin-left: 1.55rem;
  }

  .inClaimDetail {
    .lossAssessment {
      max-height: 7rem;
      * {
        box-sizing: border-box;
      }
      .scrollBox {
        overflow-y: scroll;
        max-height: 5rem;
      }
      .label {
        display: flex;
        & > div {
          padding: .15rem .25rem .15rem .38rem;
          font-weight: normal;
          color: #666666;
          background: #f2f2f2;
        }
        .left {
          flex: 16;
          overflow: hidden;
        }
        .right {
          flex: 9;
          overflow: hidden;
        }
      }
      .line {
        display: flex;
        & > div {
          padding: .15rem .25rem .15rem .38rem;
          font-size: .28rem;
          color: #333333;
          border-right: .02rem solid #eeeeee;
          border-bottom: .02rem solid #eeeeee;
        }
        .left {
          flex: 16;
          overflow: hidden;
        }
        .right {
          flex: 9;
          overflow: hidden;
          color: #FE8F45;
        }
      }
    }
  }
</style>

