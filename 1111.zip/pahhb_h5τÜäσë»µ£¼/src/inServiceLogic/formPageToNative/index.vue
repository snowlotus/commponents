<template>
  <div>
    <form :action="imcsUrl" method="post" id="goToImcs" ref="formElem">
      <input type="hidden" name="systemId" v-model="systemId">
      <input type="hidden" name="params" v-model="params">
      <input type="hidden" name="signData" v-model="signData">
    </form>
  </div>
</template>

<script>
    import toast from '../../common/comComponent/toast';
    import Axios from '../../common/js/axiosConfig';
    import API from '../../common/js/comConfig';
    // import ptsLoding from '../../common/comComponent/loading'

    export default {
        name: "formPageToNative",
        data () {
          return {
            imcsUrl:'',
            systemId:'',
            params:'',
            signData:''
          }
        },
        created () {
          let accountType;
          let _this = this;
          let query = _this.$route.query;
          // if (!query.age && !query.carId && !query.sex) {
          //   //回到Native主页
          //   Native.requestHybrid({
          //     tagname:'backHome'
          //   })
          //   return
          // };

          let obj = {
            "age": query.age,
            "carId": query.carId,
            "sex": query.sex,
            "channelSourceCode" : query.channelSourceCode || '',
            "channelSourceDetailCode" : query.channelSourceDetailCode || '',
            "businessSourceCode" : query.businessSourceCode || '',
            "businessSourceDetailCode" : query.businessSourceDetailCode || '',
            "channelSourceName" : query.channelSourceName || '',
            "channelSourceDetailName" : query.channelSourceDetailName || '',
            "businessSourceName" : query.businessSourceName || '',
            "businessSourceDetailName" : query.businessSourceDetailName || '',
            "agentCode" : query.agentCode || '',
            "agentName" : query.agentName || '',
            "agentAgreementNo" : query.agentAgreementNo || '',
            "supplementAgreementNo" : query.supplementAgreementNo || '',
            "brokerCode" : query.brokerCode || '',
            "dealerCode" : query.dealerCode || ''  //外部端dealerCode为空,内部端有值
          };

          if (dealerData.innerAccountRoleType == 0 || dealerData.innerAccountRoleType == '0') {
            accountType = 'formPageToNative'; //外部端角色
          } else {
            accountType = 'inFormPageToNative' //内部端角色
          };
          // ?age=18&carId=663F349085D243D7E054022128574717&sex=M
          // Axios.post('http://pqsz-l01262:9000/iCorePts-mobile/api/fastquotation/fastquotation',obj)
          Axios.post(API.getWebServiceUrls(accountType),obj)
            .then(res => {
              let info = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
              if (info.code == 0 || info.code == '0') {
                this.imcsUrl = info.data.imcsUrl;
                this.systemId = info.data.systemId;
                this.params = info.data.params;
                this.signData = info.data.signData;

                setTimeout(function () {
                  _this.$refs.formElem.submit();
                },0)
              } else {
                toast(info.msg)
              }
            })
            .catch(err => {
              console.log(err)
            })
        },

    }
</script>

<style scoped>

</style>
