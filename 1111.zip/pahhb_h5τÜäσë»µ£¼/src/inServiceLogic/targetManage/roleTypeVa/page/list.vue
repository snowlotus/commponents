<template>
  <div class="tabArea">
    <pts-scroll-ajax ref="scrollAjax" :topAjax="topAjax && !showDataNull"
                     @on-top-ajax="getFirstPage" :bottomAjax="bottomAjax && !showDataNull"
                     @on-bottom-ajax="getNextPage" v-if="flagName !='6' && active">

      <pts-task-item :flagName="flagName"
                     :showDataNull="showDataNull"
                     v-for="item in dataList"
                     :key="item.planId"
                     :datas="item"
                     @isItemAllTrue="isItemAllTrue"
                     >
      </pts-task-item>

      <!-- 页面无数据时显示的图片 -->
      <div v-if="showDataNull && flagName!=='6' " class="dataNullWrap">
        <div class="noInfoImg"></div>
        <div class="dataNullText">亲, 暂未制定计划</div>
      </div>
    </pts-scroll-ajax>

    <work-progress v-if="flagName=='6' && active"
                   :flagName="flagName"
                   :dateTimer="dateTimer">
    </work-progress>

    <!-- va审批提交按钮区域 -->
    <div class="submit-btn-wrap" v-if="flagName=='1' && !showDataNull">
      <div class="select-wrap" @click.prevent.stop="selectAll">
        <div class="select-icon" :class="{selectAll:selectAllState}"></div>
        <p>全选</p>
      </div>
      <div class="select-btn">
        <button class="btn" @click="submitAccess('2')">审批通过</button>
      </div>
    </div>

  </div>
</template>

<script>
    import toast from '../../../../common/comComponent/toast/index'
    import ptsScrollAjax from '../../../../common/comComponent/scrollAjax/index'
    import ptsTaskItem from './item.vue'
    import workProgress from './workProgress.vue'
    import Axios from '../../../../common/js/axiosConfig'
    import API from '../../../../common/js/comConfig'

    const date = new Date();
    const year = date.getFullYear();
    const month = date.getMonth()+1 >= 10 ? date.getMonth()+1 : '0'+ (date.getMonth()+1);


    export default {
      name: "vaTargetList",
      components:{
        ptsScrollAjax,
        ptsTaskItem,
        workProgress
      },
      props: {
        flagName: String, //1待审核,2已完成,3已通过,4未通过,6工作进展
        active: Boolean, //ture代表当前切换的tab页面
        tabChild: String,
        dateTimer: String,
        refresh:Boolean //判断需不需要重新刷新数据
      },
      data(){
        return {
          showDataNull:false, //页面无数据时显示的状态
          topAjax: true,
          bottomAjax: false,
          pageNo:1,//默认请求第一页
          pageSize:10, //默认一次请求10条数据
          dataList: [], //存储请求回来的数据
          maxNum: 0, //显示总条数
          selectAllState:false, //提交是否全选状态
        }
      },
      mounted(){
        this.$nextTick(function () {
          if(this.active && this.flagName !=='6'){
            this.getData(true)
          }
        })
      },
      // activated(){
      //   if (this.refresh) {
      //     this.getData(true);
      //   }
      // },
      methods:{

        getData(flag, topajax){
          const _this = this;
          if(flag){
            _this.dataList = [];
          }
          _this.showDataNull = false;

          let obj = {
            "pageNo":_this.pageNo,
            "pageSize":_this.pageSize,
            "planStatus":_this.tabChild || _this.flagName,
            "planYearMonth":year+month,
          }

          Axios.post(API.getWebServiceUrls('getDealerPlanList'),obj,{loading: !topajax})
            .then(res => {
              // console.log(res)
              let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
              switch (data.code) {
                case 0:
                  _this.maxNum = data.totalCount;

                  if (data.data && data.data.length === 0 ) {
                    if (flag) {
                      _this.showDataNull = true
                      _this.bottomAjax = false
                    } else {
                      _this.bottomAjax = false
                    }
                    _this.$refs.scrollAjax && _this.$refs.scrollAjax.reset(flag);
                    return
                  }

                  data.data.forEach(v => {
                    v.checked = false;
                    _this.dataList.push(v)
                  });

                  _this.bottomAjax = true;

                  //pageSize默认每次请求10条,两者乘积大于总条数时,禁止上拉加载
                  if (data.pageNo * data.pageSize > data.totalCount) {
                    _this.bottomAjax = false
                  }

                  //DOM 更新循环结束之后,触发
                  _this.$nextTick(function () {
                    // debugger
                    _this.$refs.scrollAjax && _this.$refs.scrollAjax.reset(flag)
                  })
                  break;
                default:
                  if (flag) {
                    _this.showDataNull = true
                  }
                  _this.$nextTick(function () {
                    _this.$refs.scrollAjax && _this.$refs.scrollAjax.reset(flag)
                  })
                  toast(data.msg || '系统繁忙,请稍后重试')
                  break;
              }
            })
            .catch(err => {
              if (flag) {
                _this.showDataNull = true;
                _this.$refs.scrollAjax && _this.$refs.scrollAjax.reset(flag)
              }
            })
        },

        /**
         * @info 请求第一页
         */
        getFirstPage(){
          this.pageNo = 1;
          this.selectAllState = false;
          this.getData(true, true);
        },

        /**
         * @info 当页面到底部时还有数据再次请求数据
         */
        getNextPage(){
          this.pageNo++;
          this.getData();
          this.selectAllState = false;
        },

        //判断列表里的item的checked是否都是true,此方法由子组件item触发
        isItemAllTrue(){
          const _this = this;
          _this.$nextTick(function () {
            for (let i = 0,length = _this.dataList.length; i < length;i++) {
              if (_this.dataList[i].checked == false) {
                _this.selectAllState = false;
                break
              } else {
                _this.selectAllState = true;
              }
            }
          })
        },

        /**
         *@info 全选按钮
         */
        selectAll(){
          const _this = this;
          _this.$nextTick(function () {
            if (this.selectAllState) {
              this.selectAllState = false;
              this.dataList.forEach(v => {
                v.checked = false;
              })
            } else {
              this.selectAllState = true;
              this.dataList.forEach(v => {
                v.checked = true;
              })
            }
          })
        },

        /**
         *
         * @param type: 1提交,2审核通过,3审核不通过
         * @info 提交审核结果
         */
        submitAccess(type){
          const _this = this;
          let arr = [];

          _this.dataList.forEach(v => {
            if (v.checked) {
              arr.push(v.planId)
            }
          })

          if (arr.length == 0) {
            toast('请至少选择一项')
            return
          }

          Axios.post(API.getWebServiceUrls('updateDealerPlanStatus'),{
            "planIdList":arr,
            "updateType":type
          }).then(res => {
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            if (data.code == 0 || data.code == '0') {
              toast('提交成功')
              _this.getData(true);
            } else {
              toast(data.msg || '系统繁忙,请稍后重试')
            }
          }).catch(err => {
            console.log(err)
          })
        }

      },
      watch:{
        //点击已完成下拉后里面的值
        tabChild(newVal,oldVal){
          this.pageNo = 1;
          this.getData(true)
        },

        //监听active值变化,值为true时tab切换请求数据,false时tab返回不请求数据
        active (to, from) {
          if (to && this.flagName !== '6') {
            this.pageNo = 1;
            this.getData(true)
          }
        },
      }

    }
</script>

<style scoped lang="less">
  .tabArea {
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    position: relative;
  }
  .submit-btn-wrap{
    @height:.9rem;
    height: @height;
    background: #ffffff;
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    .select-wrap{
      display: inline-block;
      position: relative;
      & p{
        position: absolute;
        top: .31rem;
        left: .72rem;
        width: .8rem;
        font-size: .28rem;
        line-height: .28rem;
      }
      .select-icon{
        display: inline-block;
        width: .3rem;
        height: .3rem;
        background: url("../../../../common/images/icon_noselect@3x.png") no-repeat;
        background-size: 100%;
        margin: .3rem 0 .3rem .3rem;
      }
      .selectAll{
        background: url("../../../../common/images/icon_selected@3x.png") no-repeat;
        background-size: 100%;
      }
    }
    .select-btn{
      float: right;
      .btn{
        @background: #FD9244;
        display: block;
        width: 2.5rem;
        height: 0.9rem;
        outline-color: @background;
        margin: 0 auto;
        border: none;
        background: @background;
        font-size: 0.32rem;
        font-weight: normal;
        color: #fff;
      }
    }
  }

  .dataNullWrap{
    .noInfoImg{
      background: url("../../../../common/images/icon_noMessage@3x.png") no-repeat;
      background-size: 100%;
      width: .82rem;
      height: .97rem;
      margin: 0 auto;
    }
  }
</style>
