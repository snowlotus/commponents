<template>
  <div class="boxWrap">
    <section class="item_box" @click.prevent.stop="goPlanDetail" v-if="flagName!=='6' && !showDataNull">
      <dl class="pts-b-b item_title">
        <dt class="item_center_icon"></dt>
        <dt class="item_center">{{datas.dealerName}}</dt>
        <dd class="item_status item_status_pass" v-if="datas.planStatus==2">已通过</dd>
        <dd class="item_status item_status_nopass" v-if="datas.planStatus==3">未通过</dd>
      </dl>
      <div class="item_info">
        <dl style="margin-top: .3rem">
          <dt>计划保费</dt>
          <dd>{{datas.planPremium}}万元</dd>
        </dl>
        <dl style="margin-top: .2rem">
          <dt>同期保费</dt>
          <dd>{{datas.lastYearPremium}}万元</dd>
          <dd class="item_select_icon" :class="{active:datas.checked}" @click.stop="datas.checked = !datas.checked;isTrue()" v-if="datas.planStatus==1"></dd>
        </dl>
        <dl style="margin-top: .2rem;padding-bottom: .29rem">
          <dt>同比增幅</dt>
          <dd>{{datas.premiumIncrease}}</dd>
        </dl>
      </div>
      <dl class="item_tips pts-b-t" v-if="datas.approveMark">
        <dt>领导批示: </dt>
        <dd>{{datas.approveMark}}</dd>
      </dl>
    </section>
  </div>
</template>

<script>


    export default {
      name: "vaTargetManageItem",
      props:{
        flagName:String,//1待审核,2已完成,3已通过,4未通过,6工作进展
        showDataNull:Boolean, //判断1,2,3,4情况下有无数据
        datas:Object //list组件请求后台传过来的值
      },
      data(){
        return {

        }
      },
      methods:{
        goPlanDetail(){
          this.$router.push({
            path:'/inside/targetManage/roleTypeVa/planDetail',
            query:{
              planStatus:this.datas.planStatus,
              planId:this.datas.planId
            }
          })
        },

        /**
         * @info 将当前item的checked的值取反,并触发父组件的全选判断是否当前列表的item都为true,
         *        如果都为true,则点亮全选按钮
         */
        isTrue(){
          this.$emit('isItemAllTrue')
        }
      },
    }
</script>

<style scoped lang="less">
  .boxWrap:first-child{
    margin-top:-.2rem;
  }
  .item_box{
    background: #FFffff;
    margin-top: .2rem;
    width: 100%;
    & dt,dd{
      display: inline-block;
    }
    .item_title{
      position: relative;
      height: .6rem;
      line-height: .6rem;
      margin-left: .31rem;
      & .item_center_icon{
        position: absolute;
        top: 50%;
        margin-top: -.15rem;
        background: url("../../../../common/images/icon_service_mall@3x.png") no-repeat;
        background-size: 100%;
        width: .31rem;
        height: .31rem;
      }
      & .item_center{
        position: absolute;
        margin-left: .44rem;
        font-size: .24rem;
        color: #333333;
      }
      & .item_status{
        position: absolute;
        right: .31rem;
        top: 50%;
        padding: .06rem;
        margin-top: -.2rem;
        border-radius: .02rem;
        font-size: .24rem;
        letter-spacing: 0;
        line-height: .24rem;
      }
      & .item_status_pass{
        border: 1px solid #2AB768;
        color: #2AB768;
      }
      & .item_status_nopass{
        border: 1px solid #FE3A3A;
        color: #FE3A3A;
      }
    }

    .item_info{
      margin-left: .31rem;
      @fontsize28:.28rem;
      & dl{
        position: relative;
      }
      & dt{
        font-family: PingFangSC-Regular;
        font-size: @fontsize28;
        color: #666666;
        letter-spacing: 0;
        line-height: @fontsize28;
      }
      & dd{
        font-family: PingFangSC-Regular;
        font-size: @fontsize28;
        color: #333333;
        letter-spacing: 0;
        line-height: @fontsize28;
        margin-left: .3rem;
      }
      & .item_select_icon{
        position: absolute;
        right: .29rem;
        top: 10%;
        background: url("../../../../common/images/icon_noselect@3x.png") no-repeat;
        background-size: 100%;
        width: .3rem;
        height: .3rem;
      }
      & .item_select_icon.active{
        background: url("../../../../common/images/icon_selected@3x.png") no-repeat;
        background-size: 100%;
      }
    }

    .item_tips{
      height: .6rem;
      margin-left: .3rem;
      line-height: .6rem;
      & dt{
        font-family: PingFangSC-Regular;
        font-size: .24rem;
        color: #666666;
        letter-spacing: 0;
        line-height: .24rem;
      }
      & dd{
        font-family: PingFangSC-Regular;
        font-size: .24rem;
        color: #FE3A3A;
        letter-spacing: 0;
        line-height: .24rem;
        margin-left: .1rem;
      }
    }
  }
</style>
