<template>
  <div>
    <!--计划详情-->
    <pts-header  @on-left="goBack" titleText="计划详情"></pts-header>
    <div class="add-plan-wrap">
      <ul class="param-area pts-b-b">
        <li class="param-item pts-b-b">
          <label class="param-label">网点名称</label>
          <p style="width: 5rem;line-height: .45rem">{{datas.dealerName}}</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label" style="letter-spacing: .13rem">维护人</label>
          <p style="margin-left: .3rem;">{{datas.salesManName}}</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">计划保费</label>
          <p>{{datas.planPremium}}万元</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">同期保费</label>
          <p>{{datas.lastYearPremium}}万元</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">同比增幅</label>
          <p v-if="datas.premiumIncrease">{{datas.premiumIncrease}}</p>
          <p v-else style="color: red;">去年保费为0,无法计算</p>
        </li>
      </ul>
      <div class="title">添加条件</div>
      <ul class="param-area pts-b-b">
        <li class="param-item pts-b-b">
          <label class="param-label">计划销量</label>
          <p>{{datas.planSalenumber}}台</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">计划产值</label>
          <p>{{datas.planOutputvalue}}万元</p>
        </li>
      </ul>
      <div v-if="planStatus=='1'">
        <div class="title">领导批示</div>
        <textarea placeholder="请输入你的建议或者理由" class="textarea" v-model="textVal"></textarea>
      </div>
    </div>

    <div class="access-box" v-if="planStatus=='1'">
      <button @click="submitResult('3')">不通过</button>
      <button @click="submitResult('2')">通过</button>
    </div>
  </div>
</template>

<script>
    import ptsHeader from '../../../common/comComponent/header/index'
    import Axios from '../../../common/js/axiosConfig'
    import API from '../../../common/js/comConfig'
    import toast from '../../../common/comComponent/toast'

    export default {
      name: "vaPlanDetail",
      components:{
        ptsHeader
      },
      data(){
        return {
          planStatus:'',
          planId:'',
          textVal:'', //输入区域的值
          datas:{},
        }
      },
      created(){
        let query = this.$route.query;
        this.planStatus = query.planStatus;
        this.planId = query.planId;
        this.getData();
      },
      methods:{
        //返回上一页
        goBack(){
          if(window.history.length >= 1) {
            window.history.go(-1)
          }
        },

        //提交审核结果通过或者不通过 入参2审核通过,3审核不通过
        submitResult(type){
          const _this = this;
          let planArr = [];
          planArr.push(_this.planId)
          Axios.post(API.getWebServiceUrls('updateDealerPlanStatus'),{
            "approveMark": _this.textVal || '',
            "planIdList":planArr,
            "updateType":type,
          }).then(res => {
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            if ( data.code == 0 ) {
              _this.$router.replace({
                path:'/inside/targetManage/roleTypeVa/index',
                query:{
                  "isNativeAlert":0,
                  "refresh":true
                }
              })
            } else {
              toast(data.msg || '系统繁忙,请稍后重试')
            }
          }).catch(err => {
            console.log(err)
          })
        },

        //请求数据
        getData(){
          const _this = this;
          Axios.post(API.getWebServiceUrls('getDealerPlanListDetial'),{
            "planId":_this.planId
          }).then(res => {

            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            if(data.code == 0 ) {
              _this.datas = data.data;
            } else {
              toast(data.msg || '系统繁忙,请稍后重试')
            }
          }).catch(err => {
            console.log(err)
          })
        }
      }
    }
</script>

<style scoped lang="less">
  .add-plan-wrap{
    height: 100%;
    font-size: .28rem;
    @cell-height: 0.9rem;
    .param-area{
      @height: @cell-height;
      width: 100%;
      background: #fff;
      .param-item{
        height: @height;
        line-height: @height;
        margin-left: .3rem;
        position: relative;
        .param-label{
          color: #666666;
        }
        & > p{
          display: inline-block;
          margin-left: .4rem;
        }
      }
    }
    .title{
      height: .7rem;
      line-height: .7rem;
      font-size: .24rem;
      color: #666666;
      margin-left: .3rem;
    }
    .textarea{
      box-sizing: border-box;
      padding: .3rem;
      width: 7.5rem;
      height: 1.81rem;
      resize: none;
      font-size: .28rem;
    }
  }

  .access-box{
    @height: .9rem;
    @fontsize32:.32rem;
    position: fixed;
    left: 0;
    bottom: 0;
    height: @height;

    & button{
      display: inline-block;
      width: 3.75rem;
      height: @height;
      margin: 0 auto;
      border: none;
      font-weight: normal;
      font-size: @fontsize32;
    }

    & button:nth-child(1){
      @background: #ffffff;
      outline-color: @background;
      background: @background;
      color: #FD9244;
    }
    & button:nth-child(2){
      @background: #FD9244;
      float: right;
      outline-color: @background;
      background: @background;
      color: #fff;
    }
  }
</style>
