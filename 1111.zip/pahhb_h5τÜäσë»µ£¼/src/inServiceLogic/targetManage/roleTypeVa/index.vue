<template>
  <div class="box">
    <pts-header leftFlag @on-left="goMenu" :titleText="titleText">
      <div slot="center" class="monthTitle" @click="selectMonth" v-if="index==2">
        <li>{{nowMonth | filterMonth}}月<a href="javascript:;" otype="button" otitle="展开" class="arrow-down"></a></li>
      </div>
    </pts-header>
    <div class="wrap insideXubaoWrap insideVisuWrap">
      <div class="mainWrap">
        <pts-tab :titleList="titleList" v-model="index" ref="tabElem" @on-child-change="tabChildChange" @on-change="tabChange">
          <pts-tab-item>
            <!--待审核-->
            <pts-task-list flagName="1" :active="index===0" ref="ptsList"></pts-task-list>
          </pts-tab-item>
          <pts-tab-item>
            <!--已完成-->
            <pts-task-list flagName="2" :active="index===1" :tabChild="tabChild"></pts-task-list>
          </pts-tab-item>
          <pts-tab-item>
            <!--工作进展-->
            <pts-task-list flagName="6" :active="index===2" :dateTimer="dateTimer"></pts-task-list>
          </pts-tab-item>
        </pts-tab>
      </div>
    </div>

    <!--判断进来页面需不要弹窗-->
    <!--<pts-alert v-model="showAlert">
      <div class="alertWrap" style="display: block;">
        <div class="alertTitle pts-b-b">请选择</div>
        <div class="alertContent pts-b-b">
        <dl>
          <dt>您的职务</dt>
          <dd class="dd1">M:LIUXIAO236asdsa</dd>
        </dl>
        <dl>
          <dt>您的VP</dt>
          <dd class="dd2">
            <input type="text" placeholder="请选择" @click="showDataInfo">
            <transition name="fade">
              <ul>
                <li></li>
              </ul>
            </transition>
          </dd>
        </dl>
        </div>
        <div class="btn">提交</div>
      </div>
    </pts-alert>-->
  </div>
</template>

<script>
    import ptsHeader from '../../../common/comComponent/header/index'
    import ptsTab from '../../../common/comComponent/tab/index'
    import {remInPx,loadEcharts} from "@/common/js/comUtils"

    const myDate = new Date()
    let month = myDate.getMonth() + 1 < 10 ? '0' + (myDate.getMonth() + 1) : myDate.getMonth() + 1
    const year = myDate.getFullYear()

    export default {
      name: "vaTargetManageIndex",
      components:{
        ptsHeader,
        ptsTab,
        ptsTabItem: ptsTab.Item,
        ptsTaskList: resolve => require.ensure([], () => resolve(require('./page/list.vue')), 'infoList')
      },
      data () {
        return {
          titleText:'计划目标',
          titleList: [
            {
              title: '待审核',
            },
            {
              title: '已完成',
              childs: [
                {title: '已完成', flag: '2'},
                {title: '已通过', flag: '3'},
                {title: '未通过', flag: '4'}
              ]
            },
            {
              title:'工作进展'
            }
          ],
          index: 0, //默认进来页面的时候为待审批
          tabChild: '2',
          nowMonth: myDate.getMonth() + 1, //当前显示的月份
          dateTimer: this.getNow(),//初始化的年月
          refresh:false
        }
      },
      created(){
        //每次进入页面都调用Native的弹窗
        let query = this.$route.query;

        if (query.isNativeAlert == undefined || query.isNativeAlert == 1) {
          Native.requestHybrid({
            tagname: 'showAccountAlert'
          })
        }

        window.changeRoleToVp = function () {
          //这里只供Native调用,不做任何事情
        }

      },
      activated(){
        let query = this.$route.query;
        //判断需不需要重新刷新数据
        if (query && query.refresh && this.index != 1) {
          this.$refs.ptsList && this.$refs.ptsList.getData(true)
        }
      },
      methods:{
        //回到Native主页
        goMenu () {
          Native.requestHybrid({
            tagname: 'backHome'
          })
        },

        /**
         * @param item为已完成,已通过,未通过
         * @info 将item的flag值赋给tabchild,传给list子组件作为查询类型参数
         */
        tabChildChange (item) {
          this.tabChild = item.flag;
        },

        tabChange (item) {
          // window.eventAnalytics('队伍端_目标管理',`${item.title}`)
        },

        selectMonth() {
          const _this = this
          this.$vux.datetime.show({
            cancelText: '取消',
            confirmText: '确定',
            format: 'YYYY-MM',
            minYear: year,
            maxYear: year,
            startDate: month < 12 ? `${year - 1}-${month}-01` : `${year}-01-01`,
            endDate: `${year}-${month < 10 ? '0' + month : month}-01`,
            //value: _this.nowMonth,
            onConfirm(val) {
              _this.$set(_this, 'dateTimer', val.replace('-', ''))
              let month = val.split('-')[1]
              _this.nowMonth = month
            },
            onShow() {
              _this.showDateTime = true
            },
            onHide() {
              _this.showDateTime = false
            }
          })
        },
        getNow() {
          let date = new Date()
          let timer =
            date.getFullYear() +
            (date.getMonth() + 1 > 9
              ? date.getMonth() + 1 + ''
              : '0' + (date.getMonth() + 1))
          return timer
        },

      },
      watch:{

      },
      filters: {
        filterMonth(val) {
          const v = val + ''
          if (v.length > 1) {
            if (v < 10) {
              return val.substring(1)
            } else {
              return v
            }
          } else {
            return v
          }
        }
      },
      beforeRouteEnter(to,from,next){
        loadEcharts(next)
      }
    }
</script>

<style scoped lang="less">
  .monthTitle{
    width: 6rem;
    float: left;
    height: 100%;
    line-height: 0.9rem;
  }
  .monthTitle > li {
    width: 100%;
    text-align: center;
    font-size: .34rem;
    font-family: PingFangSC-Regular;
    & .arrow-down {
      display: inline-block;
      width: 0.219rem;
      height: .25rem;
      background: url("../../../common/images/arrowdown.png") no-repeat center;
      background-size: 0.219rem 0.125rem;
      margin-left: 0.11rem;
    }
  }

  /*.alertWrap{
    width: 6.8rem;
    height: 4.8rem;
    background: #FFffff;
    border-radius: .05rem;
    .alertTitle{
      height: .9rem;
      font-size: .32rem;
      text-align: center;
      line-height: .9rem;
    }
    .alertContent{
      height: 3rem;
      dt,dd{
        display: inline-block;
        font-size: .28rem;
      }
      dt{
        padding: .6rem 0 .2rem .5rem;
      }
      .dd1{
        width: 4.5rem;
        padding-bottom: .2rem;
        border-bottom: 1px solid #eee;
        margin-left: .2rem;
      }
      .dd2{
        width: 4.5rem;
        padding-bottom: .2rem;
        border-bottom: 1px solid #eee;
        margin-left: .32rem;
      }

    }
    .btn{
      font-size: .3rem;
      color: #FD9244;
      text-align: center;
      line-height: .9rem;
    }
  }*/
</style>
