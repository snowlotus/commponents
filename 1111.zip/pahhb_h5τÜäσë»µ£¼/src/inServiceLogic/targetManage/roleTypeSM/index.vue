<template>
  <div class="box" style="overflow-x: hidden">
    <pts-header leftFlag @on-left="goMenu" :titleText="titleText" :showRight="showRight">
      <div slot="center" class="monthTitle" @click="selectMonth">
        <li>{{nowMonth | filterMonth}}月<a href="javascript:;" otype="button" otitle="展开" class="arrow-down"></a></li>
      </div>
      <a slot="right" class="nav_add_icon fr" @click.stop.prevent="goAddPlan"></a>
    </pts-header>
    <div class="wrap insideXubaoWrap insideVisuWrap" style="height:100%;">
      <div class="mainWrap" style="height:100%;">
        <pts-tab :titleList="titleList" v-model="index" ref="tabElem" @on-child-change="tabChildChange" @on-change="tabChange">
          <pts-tab-item>
            <!--未提交-->
            <pts-task-list
              v-if="index==0"
              :tabIndex="0"
              :selectAllItem="selectAllItem"
              :checkedPlanId="checkedPlanId"
              :loadingMore="loadingMore"
              :topLoaderMore="topLoaderMore"
              :listData="obj"
              :isAllChecked="isAllChecked"
              :active="index===0"
              :needLoadMore="totalCount>obj.length"
              @getData="getDealerPlanList"
              :topLoaderMoreEnd="topLoaderMoreEnd"
              :topLoaderMoreChange="topLoaderMoreChange"
            ></pts-task-list>
          </pts-tab-item>
          <pts-tab-item>
            <!--待审核-->
            <pts-task-list
              v-if="index==1"
              :tabIndex="1"
              :selectAllItem="selectAllItem"
              :checkedPlanId="checkedPlanId"
              :loadingMore="loadingMore"
              :topLoaderMore="topLoaderMore"
              :listData="obj"
              :isAllChecked="isAllChecked"
              :active="index===1"
              :needLoadMore="totalCount>obj.length"
              @getData="getDealerPlanList"
              :topLoaderMoreEnd="topLoaderMoreEnd"
              :topLoaderMoreChange="topLoaderMoreChange"
            ></pts-task-list>
          </pts-tab-item>
          <pts-tab-item>
            <!--已完成-->
            <pts-task-list
              v-if="index==2"
              :tabIndex="2"
              :selectAllItem="selectAllItem"
              :checkedPlanId="checkedPlanId"
              :loadingMore="loadingMore"
              :topLoaderMore="topLoaderMore"
              :listData="obj"
              :isAllChecked="isAllChecked"
              :active="index===2"
              :tabChild="tabChild"
              :needLoadMore="totalCount>obj.length"
              :topLoaderMoreEnd="topLoaderMoreEnd"
              :topLoaderMoreChange="topLoaderMoreChange"
            ></pts-task-list>
          </pts-tab-item>
          <pts-tab-item>
            <!--工作进展-->
            <work-progress :dateTimer="dateTimer" v-if="index==3"></work-progress>
          </pts-tab-item>
        </pts-tab>
      </div>
    </div>
  </div>
</template>

<script>
import API from '@/common/js/comConfig'
import Axios from '@/common/js/axiosConfig'
import Toast from '@/common/comComponent/toast'
import ptsPie from '../../../common/comComponent/echarts/pie'
import ptsHeader from '../../../common/comComponent/header/index'
import ptsTab from '../../../common/comComponent/tab/index'
import { remInPx, loadEcharts } from '@/common/js/comUtils'
import workProgress from '@/inServiceLogic/targetManage/roleTypeSM/page/workProgress'

const myDate = new Date()
let month =
  myDate.getMonth() + 1 < 10
    ? '0' + (myDate.getMonth() + 1)
    : myDate.getMonth() + 1
const year = myDate.getFullYear()

export default {
  name: 'smTargetManageIndex',
  components: {
    ptsHeader,
    ptsTab,
    ptsTabItem: ptsTab.Item,
    ptsTaskList: resolve => require.ensure([], () => resolve(require('./page/list.vue')), 'infoList'),
    workProgress
  },
  created() {
    const _this = this;

    /**
     * @info 每次进入页面判断需不需要调用Native的弹窗,nativeShowAlert为0不弹窗, 1弹窗
     */
    let query = _this.$route.query
    if (query.nativeShowAlert == undefined || query.nativeShowAlert == 1) {
      Native.requestHybrid({
        tagname: 'showAccountAlert'
      })
    }

    //此方法供Native调用,表示把自己维护成了Vp
    window.changeRoleToVp = function () {
      _this.$router.replace({
        path:'/inside/targetManage/roleTypeVa/index'
      })
    }

    //进来页面判断sm有无授权,从而展示不同页面 Y已授权,N未授权
    if (dealerData.planTargetAuth == 'N') {
      _this.titleList.pop(_this.titleList[3])
    }

  },
  activated(){
    //判断需不需要重新刷新数据
    let query = this.$route.query;
    if (query&&query.refresh) {
      this.topLoaderMoreFun();
    }
  },
  data() {
    return {
      titleText: '目标管理',
      showRight: true,
      showDateTime: false, //切换月份上下箭头
      isReset: true,
      nowMonth: myDate.getMonth() + 1, //当前显示的月份
      titleList: [
        {
          title: '未提交'
        },
        {
          title: '待审核'
        },
        {
          title: '已完成',
          childs: [
            { title: '已完成', index: 2 },
            { title: '已通过', index: 4 },
            { title: '未通过', index: 5 }
          ]
        },
        {
          title: '工作进展'
        }
      ],
      index: 0, //默认全部
      tabChild: 2,
      //初始化默认数据
      obj: [],
      //是否全选
      isAllChecked: false,
      //初始化的年月
      dateTimer: this.getNow(),
      //总条数
      totalCount: 0,
      //单选事件
      checkedPlanId: this.checkedPlanIdFun,
      //加载更多事件
      loadingMore: this.loadingMoreFun,
      //点击全选的事件
      selectAllItem: this.selectAllItemFun,
      //下拉刷新
      topLoaderMore: this.topLoaderMoreFun,
      topLoaderMoreEnd: false,
      topLoaderMoreChange: this.topLoaderMoreChangeFun,
    }
  },
  mounted() {
    this.getDealerPlanList(1, 0)
  },
  methods: {
    //回到Native主页
    goMenu() {
      Native.requestHybrid({
        tagname: 'backHome'
      })
    },
    //进入添加计划页面
    goAddPlan() {
      this.$router.push({
        path: '/inside/targetManage/roleTypeSM/addPlan'
      })
    },
    selectMonth() {
      const _this = this
      this.$vux.datetime.show({
        cancelText: '取消',
        confirmText: '确定',
        format: 'YYYY-MM',
        minYear: year,
        maxYear: year,
        startDate: month < 12 ? `${year - 1}-${month}-01` : `${year}-01-01`,
        endDate: `${year}-${month < 10 ? '0' + month : month}-01`,
        //value: _this.nowMonth,
        onConfirm(val) {
          _this.$set(_this, 'dateTimer', val.replace('-', ''))
          let month = val.split('-')[1]
          _this.nowMonth = month
        },
        onShow() {
          _this.showDateTime = true
        },
        onHide() {
          _this.showDateTime = false
        }
      })
    },
    getNow() {
      let date = new Date()
      let timer =
        date.getFullYear() +
        (date.getMonth() + 1 > 9
          ? date.getMonth() + 1 + ''
          : '0' + (date.getMonth() + 1))
      return timer
    },

    //查询车商计划列表
    getDealerPlanList(pageNo, planStatus) {
      let _this = this
      let reqData = {
        pageNo: pageNo ? pageNo : 1,
        pageSize: 10,
        planStatus: planStatus === undefined ? 0 : planStatus,
        planYearMonth: this.dateTimer
      }
      Axios.post(API.getWebServiceUrls('getDealerPlanList'), reqData)
        .then(res => {
          if (res.data.code === 0) {
            _this.$set(_this, 'totalCount', res.data.totalCount)
            if (pageNo == 1) {
              _this.addChecked(res.data.data, false)
            } else {
              _this.loadMore(res.data.data, false)
              return
            }
          } else if (res.data.code == 17000) {
            _this.$set(_this, 'totalCount', 0)
            _this.$set(_this, 'obj', [])
          } else {
            Toast(res.data.msg || '系统繁忙,请稍后重试')
          }
          this.$set(this, 'topLoaderMoreEnd', true)
        })
        .catch(err => {
          console.log(err)
        })
    },
    //切换已完成的子菜单的时间
    tabChildChange(item) {
      this.$set(this, 'tabChild', item.index)
    },
    //切换四个大菜单
    tabChange(item) {
      // window.eventAnalytics('队伍端_目标管理', `${item.title}`)
      if (item.index == 3) {
      } else {
        this.getDealerPlanList(
          1,
          this.index == 2
            ? this.index == this.tabChild ? this.index : this.tabChild - 1
            : this.index,
          this.dateTimer
        )
        this.$set(this, 'isAllChecked', false)
      }
    },
    //单选某一个计划
    checkedPlanIdFun(index) {
      this.$set(this.obj[index], 'isChecked', !this.obj[index].isChecked)
      this.$nextTick(() => {
        for (let i = 0; i < this.obj.length; i++) {
          if (!this.obj[i].isChecked) {
            this.$set(this, 'isAllChecked', false)
            return
          }
        }
        this.$set(this, 'isAllChecked', true)
      })
    },
    //点击全选按钮
    selectAllItemFun() {
      this.$set(this, 'isAllChecked', !this.isAllChecked)
      this.$nextTick(() => {
        this.addChecked(this.obj, this.isAllChecked)
      })
    },
    //传入数据变成带有checked的数据,默认设置false
    addChecked(list, setBool) {
      let setData = list
      let bool = setBool ? setBool : false
      for (let i = 0; i < setData.length; i++) {
        setData[i].isChecked = bool
      }
      this.$set(this, 'obj', setData)
    },
    loadMore(list, setBool) {
      this.$set(this, 'isAllChecked', false)
      let bool = setBool ? setBool : false
      for (let i = 0; i < list.length; i++) {
        list[i].isChecked = bool
        this.obj.push(list[i])
      }
    },
    //加载更多
    loadingMoreFun() {
      let planStatus =
        this.index == 2
          ? this.index == this.tabChild ? this.index : this.tabChild - 1
          : this.index
      let pageNo = Math.ceil(this.obj.length / 10) + 1
      this.getDealerPlanList(pageNo, planStatus)
    },
    //下拉刷新
    topLoaderMoreFun() {
      let planStatus =
        this.index == 2
          ? this.index == this.tabChild ? this.index : this.tabChild - 1
          : this.index
      this.getDealerPlanList(1,planStatus)
    },
    topLoaderMoreChangeFun() {
      this.$set(this, 'topLoaderMoreEnd', false)
    }
  },
  filters: {
    filterMonth(val) {
      const v = val + ''
      if (v.length > 1) {
        if (v < 10) {
          return val.substring(1)
        } else {
          return v
        }
      } else {
        return v
      }
    }
  },
  beforeRouteEnter(to, from, next) {
    loadEcharts(next)
  },
  watch: {
    //切换月份的地方
    dateTimer(newValue) {
      /*
        1.切换月份时先判断是否为已完成的情况
        2.然后判断子选项是否和父选项id是否一样
        3.一样就随便去,不一样的话需要去拿到新的未通过或者已通过的列表
        4.组件中的工作进展已经占用item.index为3的情况,所以在初始化子元素index和后台接口做了加1处理,在取出来的时候需要减1
      */
      this.getDealerPlanList(
        1,
        this.index == 2
          ? this.index == this.tabChild ? this.index : this.tabChild - 1
          : this.index,
        newValue
      )
    }
  }
}
</script>

<style scoped lang="less">
  .monthTitle{
    width: 6rem;
    float: left;
    height: 100%;
    line-height: 0.9rem;
  }
  .monthTitle > li {
    width: 100%;
    text-align: center;
    font-size: .34rem;
    font-family: PingFangSC-Regular;
    & .arrow-down {
      display: inline-block;
      width: 0.219rem;
      height: .25rem;
      background: url("../../../common/images/arrowdown.png") no-repeat center;
      background-size: 0.219rem 0.125rem;
      margin-left: 0.11rem;
    }
  }
  .nav_add_icon{
    display: inline-block;
    width: .37rem;
    height: .37rem;
    background: url("../../../common/images/add_icon@3x.png") no-repeat;
    margin-right: .31rem;
    margin-top: 0.27rem;
    background-size: 100%;
  }
  .my-swiper-wrap{
    position: absolute!important;
    top: 0!important;
    bottom: 0!important;
    width: 100%!important;
  }
  .my-tab-item{
    height: 100%;
    position: relative;
  }

</style>
