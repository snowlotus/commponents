<template>
  <div>
    <!--计划详情-->
    <pts-header  @on-left="goBack" titleText="计划详情" v-if="data.planStatus!=0"></pts-header>
    <pts-header  @on-left="goBack" titleText="计划详情" :showRight="true" v-if="data.planStatus==0">
      <a slot="right" class="fr save_draft" :class="{active:inputVal}" @click.stop.prevent="saveDraft">存草稿</a>
    </pts-header>

    <!--未审核,已通过进来的计划详情页面 start-->
    <div class="add-plan-wrap1" v-if="data.planStatus==1 || data.planStatus==2">
      <ul class="param-area pts-b-b">
        <li class="param-item pts-b-b">
          <label class="param-label">网点名称</label>
          <p style="width: 5rem;line-height: .45rem">{{data.dealerName}}</p>
        </li>
        <li class="param-item pts-b-b" v-if="haveAuthorize">
          <label class="param-label" style="letter-spacing: .14rem">维护人</label>
          <p style="margin-left: .27rem">{{data.salesManName}}</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">计划保费</label>
          <p>{{data.planPremium || 0}}万元</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">同期保费</label>
          <p>{{data.lastYearPremium}}万元</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">同比增幅</label>
          <p v-if="data.premiumIncrease">{{data.premiumIncrease}}</p>
          <p v-else style="color: red;">去年保费为0,无法计算</p>
        </li>
      </ul>
      <div class="title">添加条件</div>
      <ul class="param-area pts-b-b">
        <li class="param-item pts-b-b">
          <label class="param-label">计划销量</label>
          <p>{{data.planSalenumber || 0}}台</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">计划产值</label>
          <p>{{data.planOutputvalue || 0}}万元</p>
        </li>
      </ul>
      <div v-if="data.planStatus==1 && haveAuthorize">
        <div class="title">领导批示</div>
        <textarea placeholder="请输入你的建议或者理由" class="textarea" v-model="leaderWrite"></textarea>
      </div>
    </div>
    <!--未审核,已通过进来的计划详情页面 end-->

    <!--未提交页面进来的计划详情 start-->
    <div class="add-plan-wrap2" v-if="data.planStatus==0">
      <ul class="param-area pts-b-b">
        <li class="param-item pts-b-b">
          <label class="param-label">网点名称</label>
          <!--<input type="text" placeholder="请选择网点名称" class="param-wangdian text-hidden" disabled="true" :value="orgVal">-->
          <p style="display: inline-block;margin-left: .4rem;">{{data.dealerName}}</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">计划保费</label>
          <input type="number" placeholder="请输入保费" v-model="inputVal">
          <div class="param-unit">单位:万元</div>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">同期保费</label>
          <p style="display: inline-block;margin-left: .4rem">{{data.lastYearPremium}}万元</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">同比增幅</label>
          <p style="display: inline-block;margin-left: .4rem" :style="{color:growRate.indexOf('%')>-1?'':'red'}">{{growRate}}</p>
        </li>
      </ul>
      <div class="title">添加条件</div>
      <ul class="param-area pts-b-b">
        <li class="param-item pts-b-b">
          <label class="param-label">计划销量</label>
          <input type="number" placeholder="可选填" v-model="planSalenumber">
          <div class="param-unit">单位:台</div>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">计划产值</label>
          <input type="number" placeholder="可选填" v-model="planOutputvalue">
          <div class="param-unit">单位:万元</div>
        </li>
      </ul>
      <div class="btn-wrap">
        <button class="btn" :class="{active: inputVal}" @click="submitPlan">提交</button>
      </div>
    </div>
    <!--未提交页面进来的计划详情 end-->

    <!-- 未通过进来的计划详情页面 start -->
    <div class="add-plan-wrap2" v-if="data.planStatus==3">
      <ul class="param-area pts-b-b">
        <li class="param-item pts-b-b">
          <label class="param-label">网点名称</label>
          <!--<input type="text" placeholder="请选择网点名称" class="param-wangdian text-hidden" disabled="true" :value="orgVal">-->
          <p style="display: inline-block;margin-left: .4rem;">{{data.dealerName}}</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">计划保费</label>
          <input type="number" placeholder="请输入保费" v-model="inputVal">
          <div class="param-unit">单位:万元</div>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">同期保费</label>
          <p style="display: inline-block;margin-left: .4rem">{{data.lastYearPremium}}万元</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">同比增幅</label>
          <p style="display: inline-block;margin-left: .4rem;color: red;">{{growRate}}</p>
        </li>
      </ul>
      <div class="title">添加条件</div>
      <ul class="param-area pts-b-b">
        <li class="param-item pts-b-b">
          <label class="param-label">计划销量</label>
          <input type="number" placeholder="可选填" v-model="planSalenumber">
          <div class="param-unit">单位:台</div>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">计划产值</label>
          <input type="number" placeholder="可选填" v-model="planOutputvalue">
          <div class="param-unit">单位:万元</div>
        </li>
      </ul>
      <div class="btn-wrap">
        <button class="btn" :class="{active: inputVal}" @click.stop="reSubmit">重新提交</button>
      </div>
    </div>
    <!-- 未通过进来的计划详情页面 end -->


    <div class="access-box" v-if="data.planStatus==1 && haveAuthorize">
      <button @click.stop="submitApproveResult('3')">不通过</button>
      <button @click.stop="submitApproveResult('2')">通过</button>
    </div>
  </div>
</template>

<script>
import { PopupPicker } from 'vux'
import Toast from '@/common/comComponent/toast'
import ptsHeader from '../../../common/comComponent/header/index'
import Axios from '../../../common/js/axiosConfig'
import API from '../../../common/js/comConfig'

export default {
  name: 'smTargetManagePlanDetail',
  components: {
    ptsHeader,
    // PopupPicker
  },
  data() {
    return {
      data: {},
      inputVal: '', //输入的计划保费
      // orgVal: '', //选中的网点值
      showRight: true,
      growRate: '', //同比增幅
      planOutputvalue: '', //计划产值
      planSalenumber: '', //计划销量
      leaderWrite:'', //领导批示
      haveAuthorize:true, //判断sm有无权限,默认有
    }
  },
  created() {
    this.getData(this.$route.query.planId);

    //进来页面判断sm有无授权,从而展示不同页面 Y已授权,N未授权
    if (dealerData.planTargetAuth == 'N') {
      this.haveAuthorize = false;
    }
  },
  mounted(){

  },
  methods: {
    //返回上一页
    goBack() {
      if (window.history.length >= 1) {
        window.history.go(-1)
      }
    },

    //请求数据
    getData(planId) {
      let _this = this
      let reqData = {
        planId: planId
      }
      Axios.post(API.getWebServiceUrls('getDealerPlanListDetial'), reqData)
        .then(res => {
          if (res.data.code === 0) {
            _this.$set(_this, 'data', res.data.data)
            _this.$set(_this, 'inputVal', res.data.data.planPremium)
            _this.$set(_this, 'planOutputvalue', res.data.data.planOutputvalue)
            _this.$set(_this, 'planSalenumber', res.data.data.planSalenumber)
            // _this.$set(_this, 'orgVal', res.data.data.dealerName)
            // console.log(_this.data)
          } else {
            Toast(res.data.msg)
          }
        })
        .catch(err => {
          console.log(err)
        })
    },

    //存草稿
    saveDraft() {
      // if (!this.orgVal) {
      //   Toast('请选择网点')
      //   return
      // }
      if (!this.inputVal) {
        Toast('请输入计划保费')
        return
      }
      this.ajaxUpdata(0)
    },

    //提交
    submitPlan() {
      // if (!this.orgVal) {
      //   Toast('请选择网点')
      //   return
      // }
      if (!this.inputVal) {
        Toast('请输入计划保费')
        return
      }
      this.ajaxUpdata(1)
    },

    //未通过页的重新提交
    reSubmit(){
      if (!this.inputVal) {
        Toast('请输入计划保费')
        return
      }
      this.ajaxUpdata(1)
    },

    ajaxUpdata(isReCommit) {
      let reqData = {
        lastYearPremium: this.data.lastYearPremium,
        planId: this.data.planId,
        planOutputvalue: this.planOutputvalue,
        planPremium: this.inputVal,
        planSalenumber: this.planSalenumber,
        premiumIncrease: this.growRate.indexOf('%') > -1 ? this.growRate : '',
        isReCommit: isReCommit
      }
      Axios.post(API.getWebServiceUrls('updateDealerPlan'), reqData)
        .then(res => {
          if (res.data.code === 0) {
            Toast(res.data.msg || '提交成功')
            this.$router.replace({
              path:'/inside/targetManage/roleTypeSM/index',
              query:{
                "nativeShowAlert":0,
                "refresh":true
              }
            })
          } else {
            Toast(res.data.msg || '系统繁忙,请稍后重试')
          }
        })
        .catch(err => {
          console.log(err)
        })
    },



    /**
     * @info 提交审批结果(通过或不通过)
     * @param type 2通过 3不通过
     */
    submitApproveResult(type){
      let obj = {
        "approveMark" : this.leaderWrite,
        "planIdList" : [this.$route.query.planId],
        "updateType" :type
      }
      Axios.post(API.getWebServiceUrls('updateDealerPlanStatus'),obj)
        .then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (data.code == 0) {
            Toast('提交成功')
            this.$router.replace({
              path:'/inside/targetManage/roleTypeSM/index',
              query:{
                "nativeShowAlert":0,
                "refresh":true
              }
            })
          } else {
            Toast(data.msg || '系统繁忙,请稍后重试')
          }
        })
        .catch(err => {
          console.log(err)
        })
    }
  },
  watch: {
    //监听计划保费输入值状态,并计算同比增幅
    inputVal(newVal, oldVal) {
      if (newVal == '') {
        this.growRate = ''
        return
      };
      if (this.inputVal == '') {
        Toast('请输入计划保费')
        return
      }

      if (typeof this.lastYearPremium === 'undefined' || this.lastYearPremium == 0) {
        this.growRate = '去年保费为0,无法计算'
        return
      }

      let lastYearPremium = this.data.lastYearPremium;
      this.growRate =
        ((newVal - lastYearPremium) / lastYearPremium * 100).toFixed(2) + '%'
    }
  }
}
</script>

<style scoped lang="less">
  @import "../../../common/css/theme";

  .save_draft{
    font-size: .28rem;
    margin-top: -.4rem;
    margin-right: .3rem;
    &.active{
      color: #FE883A;
    }
  }
  .add-plan-wrap1{
    height: 100%;
    font-size: .28rem;
    @cell-height: 0.9rem;
    .param-area{
      @height: @cell-height;
      width: 100%;
      background: #fff;
      .param-item{
        height: @height;
        line-height: @height;
        margin-left: .3rem;
        position: relative;
        .param-label{
          color: #666666;
        }
        & > p{
          display: inline-block;
          margin-left: .4rem;
        }
      }
    }
    .title{
      height: .7rem;
      line-height: .7rem;
      font-size: .24rem;
      color: #666666;
      margin-left: .3rem;
    }
    .textarea{
      box-sizing: border-box;
      padding: .3rem;
      width: 7.5rem;
      height: 1.81rem;
      resize: none;
      font-size: .28rem;
    }
  }
  .add-plan-wrap2{
    height: 100%;
    font-size: .28rem;
    @cell-height: 0.9rem;
    .param-area{
      @height: @cell-height;
      width: 100%;
      background: #fff;
      .param-item{
        height: @height;
        line-height: @height;
        margin-left: .3rem;
        position: relative;
        .param-label{
          color: #666666;
        }
        .arrow_icon{
          position: absolute;
          top: 50%;
          margin-top: -.1rem;
          right: .3rem;
          background: url("../../../common/images/icon_arrow.png") no-repeat;
          width: 0.08rem;
          height: .14rem;
          background-size: 100%;
        }
        & input{
          margin-left: .4rem;
        }
        .param-wangdian{
          /*float: right;*/
          width: 4.68rem;
          margin-right: .3rem;
        }
        .param-unit{
          position: absolute;
          top: 50%;
          margin-top: -.45rem;
          right: .3rem;
          color:#999999;
          letter-spacing: 0;
        }
      }
    }
    .title{
      height: .7rem;
      line-height: .7rem;
      font-size: .24rem;
      color: #666666;
      margin-left: .3rem;
    }
    .btn-wrap{
      width: 100%;
      margin-top: 1.38rem;
      .btn{
        @background: #999999;
        display: block;
        width: 6.91rem;
        height: 0.92rem;
        outline-color: @background;
        margin: 0 auto;
        border-radius: 0.04rem;
        border: none;
        background: @background;
        font-size: 0.32rem;
        font-weight: normal;
        color: #fff;
        &.active {
          outline-color: @theme-color;
          background: @theme-color;
        }
      }
    }
  }
  .access-box{
    @height: .9rem;
    @fontsize32:.32rem;
    position: fixed;
    left: 0;
    bottom: 0;
    height: @height;

    & button{
      display: inline-block;
      width: 3.75rem;
      height: @height;
      margin: 0 auto;
      border: none;
      font-weight: normal;
      font-size: @fontsize32;
    }

    & button:nth-child(1){
      @background: #ffffff;
      outline-color: @background;
      background: @background;
      color: #FD9244;
    }
    & button:nth-child(2){
      @background: #FD9244;
      float: right;
      outline-color: @background;
      background: @background;
      color: #fff;
    }
  }
</style>
