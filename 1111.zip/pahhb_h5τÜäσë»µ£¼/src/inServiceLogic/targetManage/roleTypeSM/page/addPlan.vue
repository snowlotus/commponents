<template>
  <div>
    <!--添加计划-->
    <pts-header  @on-left="goBack" titleText="添加计划" :showRight="showRight">
      <a slot="right" class="fr save_draft" :class="{active:inputVal && orgVal}" @click.stop.prevent="submitPlan('N')">存草稿</a>
    </pts-header>
    <div class="add-plan-wrap">
      <ul class="param-area pts-b-b">
        <li class="param-item pts-b-b">
          <label class="param-label">网点名称</label>
          <div class="param-wangdian text-hidden" v-if="orgVal" @click="showSelect = true;">{{orgVal}}</div>
          <div class="param-wangdian text-hidden" v-else style="color:#999999;" @click="showSelect = true;">请选择网点名称</div>
          <div class="arrow_icon"></div>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">计划保费</label>
          <input type="number" placeholder="请输入保费" v-model="inputVal">
          <div class="param-unit">单位:万元</div>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">同期保费</label>
          <p style="display: inline-block;margin-left: .4rem">{{lastYearPremium || 0}}万元</p>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">同比增幅</label>
          <p style="display: inline-block;margin-left: .4rem;color: red;">{{growRate}}</p>
        </li>
      </ul>
      <div class="title">添加条件</div>
      <ul class="param-area pts-b-b">
        <li class="param-item pts-b-b">
          <label class="param-label">计划销量</label>
          <input type="number" placeholder="可选填" v-model="planSale">
          <div class="param-unit">单位:台</div>
        </li>
        <li class="param-item pts-b-b">
          <label class="param-label">计划产值</label>
          <input type="number" placeholder="可选填" v-model="planOutputVal">
          <div class="param-unit">单位:万元</div>
        </li>
      </ul>
      <div class="btn-wrap">
        <button class="btn" :class="{active: inputVal && orgVal}" @click="submitPlan('Y')">提交</button>
      </div>
    </div>
    <pts-select :show.sync="showSelect" @input="chooseName" :data-list="list"></pts-select>
  </div>
</template>

<script>
  import ptsHeader from '../../../../common/comComponent/header/index'
  import API from '../../../../common/js/comConfig'
  import Axios from '../../../../common/js/axiosConfig'
  import toast from '../../../../common/comComponent/toast/index'
  import ptsSelect from '../../../../common/comComponent/textScroll/selected'

  const date = new Date();
  const year = date.getFullYear();
  const month = date.getMonth()+1 >= 10 ? date.getMonth()+1 : '0'+ (date.getMonth()+1);

  export default {
    name: 'smTargetManageAddplan',
    components: {
      ptsHeader,
      ptsSelect
    },
    data() {
      return {
        inputVal: '', //输入的计划保费
        orgVal: '', //选中的网点值
        growRate: '', //同比增幅
        lastYearPremium:'', //同期保费
        planSale:'', //计划销量
        planOutputVal:'', //计划产值
        showRight: true,
        showSelect:false,
        list:[],//网点列表
        dealerCode:'', //网点代码
      }
    },
    created() {
      this.getData()
    },
    methods: {
      //返回上一页
      goBack() {
        if (window.history.length >= 1) {
          window.history.go(-1)
        }
      },

      chooseName (text) {
        this.inputVal = '';
        this.growRate = '';
        this.lastYearPremium = '';
        this.planSale = '';
        this.planOutputVal = '';

        this.orgVal = text.name;
        // this.$emit('input', text.code);
        this.dealerCode = text.code;
        //根据用户选择的网点动态请求同期保费数据
        Axios.post(API.getWebServiceUrls('getLastYearPremium'), {
          "dealerCode":text.code,
          "planYearMonth":year+month
        }).then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (data.code == 0) {
            this.lastYearPremium = data.data.planPremium;
          } else {
            toast(data.msg || '系统繁忙,请稍后重试')
          }
        }).catch(e => {
          console.log(e);
        })
      },

      //当列表弹出的时候请求网点数据
      getData() {
        const _this = this;
        Axios.post(API.getWebServiceUrls('getUserOrganization'))
          .then(res => {
            res = res.data;
            if (res.code != 0) {
              toast(res.msg);
              return;
            }
            let arr_list = [];
            arr_list = res.data.organizationList.childList;
            _this.list = arr_list;
          }).catch(e => {
          console.log(e);
        })
      },

      /**
       * @info input输入框正则判断输入的是否是纯数字
       *
       */
      validateInput(val){
        let reg = /^[1-9]\d*$|^[1-9]\d*\.\d{1,2}$|^0\.\d{1,2}$/;
        if  (!reg.test(val)){
          toast('输入格式不正确,请重新输入')
          return false;
        } else {
          return true;
        }
      },

      /**
       * @param type Y提交,N存草稿
       */
      submitPlan(type) {
        if (!this.orgVal) {
          toast('请选择网点')
          return;
        }
        if (!this.inputVal) {
          toast('请输入计划保费')
          return;
        }

        if(!this.validateInput(this.inputVal)) return

        if(this.planSale && !this.validateInput(this.planSale) || this.planOutputVal && !this.validateInput(this.planOutputVal)) return


        let obj = {
          "approveMark":'',
          "approvePermissionMark":'',
          "commit":type,
          "dealerCode":this.dealerCode,
          "dealerName":this.orgVal,
          "lastYearPremium":this.lastYearPremium || 0,
          "planId":'',
          "planOutputvalue":this.planOutputVal || '',
          "planPremium":this.inputVal,
          "planSalenumber":this.planSale,
          "planStatus":'',
          "planYearMonth":year+month,
          "premiumIncrease":this.growRate.indexOf('%') > -1 ? this.growRate : '',
          "roleMark":'',
          "salesManName":''
        }

        Axios.post(API.getWebServiceUrls('addDealerPlan'),obj)
          .then(res => {
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            if (data.code == 0) {
              toast('提交成功')
              this.$router.replace({
                path:'/inside/targetManage/roleTypeSM/index',
                query:{
                  "nativeShowAlert":0,
                  "refresh":true
                }
              })

            } else {
              toast(data.msg || '系统繁忙,请稍后重试')
            }
          })
          .catch(err => {
            console.log(err)
          })

      }
    },
    watch: {
      //监听计划保费输入值状态,并计算同比增幅
      inputVal(newVal, oldVal) {
        if (newVal == '') {
          this.growRate = ''
          return
        }
        if (this.orgVal == '') {
          toast('请先输入网点')
          return
        }
        if (typeof this.lastYearPremium === 'undefined' || this.lastYearPremium == 0) {
          this.growRate = '去年保费为0,无法计算'
          return
        }

        let a = this.lastYearPremium;
        this.growRate = ((newVal - a)/a * 100).toFixed(2) + '%'
      },
    }
  }
</script>

<style lang="less">
  @import "../../../../common/css/theme";

  input::-webkit-input-placeholder{
    color: #999999;
  }

  .save_draft{
    font-size: .28rem;
    margin-top: -.4rem;
    margin-right: .3rem;
    &.active{
      color: #FE883A;
    }
  }

  .add-plan-wrap{
    height: 100%;
    font-size: .28rem;
    @cell-height: 0.9rem;
    .param-area{
      @height: @cell-height;
      width: 100%;
      background: #fff;
      .param-item{
        height: @height;
        line-height: @height;
        margin-left: .3rem;
        position: relative;
        .param-label{
          color: #666666;
        }
        .arrow_icon{
          position: absolute;
          top: 50%;
          margin-top: -.1rem;
          right: .3rem;
          background: url("../../../../common/images/icon_arrow.png") no-repeat;
          width: 0.08rem;
          height: .14rem;
          background-size: 100%;
        }
        & input{
          margin-left: .4rem;
        }
        .param-wangdian{
          /*float: right;*/
          width: 4.68rem;
          position: absolute;
          top: 0;
          left: 1.6rem;
        }
        .param-unit{
          position: absolute;
          top: 50%;
          margin-top: -.45rem;
          right: .3rem;
          color:#999999;
          letter-spacing: 0;
        }
      }
    }
    .title{
      height: .7rem;
      line-height: .7rem;
      font-size: .24rem;
      color: #666666;
      margin-left: .3rem;
    }
    .btn-wrap{
      width: 100%;
      margin-top: 1.38rem;
      .btn{
        @background: #999999;
        display: block;
        width: 6.91rem;
        height: 0.92rem;
        outline-color: @background;
        margin: 0 auto;
        border-radius: 0.04rem;
        border: none;
        background: @background;
        font-size: 0.32rem;
        font-weight: normal;
        color: #fff;
        &.active {
          outline-color: @theme-color;
          background: @theme-color;
        }
      }
    }
  }
</style>
