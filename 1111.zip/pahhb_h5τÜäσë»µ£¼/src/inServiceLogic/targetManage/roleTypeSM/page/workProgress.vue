<template>
  <section class="work_wrap">
    <div class="swiperBox">
      <div class="tabWrap">
        <ul class="analyBtnArea">
          <li :class="{cur:pieState == 1}" @click="pieState=1">总网点</li>
          <li :class="{cur:pieState == 2}" @click="pieState=2">总保费</li>
        </ul>
      </div>
      <div style='height:4.3rem;position:relative;margin-top: .2rem;'>
        <div class="tableWrap opacity0" :class="{'class1':pieState==1}">
          <div class="tableContent" style="border-bottom: none">
            <pts-pie :options="pieOption1" ref="pie1"></pts-pie>
          </div>
        </div>
        <div class="tableWrap opacity0" :class="{'class1':pieState==2}">
          <div class="tableContent" style="border-bottom: none">
            <pts-pie :options="pieOption2" ref="pie2"></pts-pie>
          </div>
        </div>
      </div>
    </div>

    <div class="chartInfoBox" v-if="pieState==1">
      <dl class="pts-b-b">
        <dt class="dt1">已提交网点</dt>
        <dd>{{datas.committedNumBer || 0}}</dd>
      </dl>
      <dl>
        <dt class="dt2">未提交网点</dt>
        <dd>{{datas.uncommittedNumBer || 0}}</dd>
      </dl>
    </div>

    <div class="chartInfoBox" v-if="pieState==2">
      <dl class="pts-b-b">
        <dt class="dt1">已提交网点保费</dt>
        <dd>{{datas.committedTotalPremium || 0}}</dd>
      </dl>
      <dl>
        <dt class="dt2">未提交网点保费</dt>
        <dd>0</dd>
      </dl>
    </div>


    <div class="centerInfoBox">
      <div class="tabWrap">
        <ul class="analyBtnArea">
          <li :class="{cur:index == 0}" @click="getWorkProgressList(0)">已提交</li>
          <li :class="{cur:index == 1}" @click="getWorkProgressList(1)">未提交</li>
        </ul>
      </div>
      <div class="tableWrap">
        <div class="tableTitle">
          <p>网点名称</p>
          <p>姓名</p>
          <p>保费(万元)</p>
        </div>

        <div class="tableContentBox" :style="{height:isSubmitArr.length > 0 ? '9rem' : '1.8rem'}">
          <pts-scroll-ajax ref="scrollAjax" :topAjax="topAjax"
                           :bottomAjax="bottomAjax && isSubmitArr.length >= 20"
                           @on-bottom-ajax="getNextPage">

            <div class="tableContent" v-if="index==0" v-for="(item,i) in isSubmitArr" :key="i">
              <div class="contentCenter">{{item.dealerName}}</div>
              <div class="contentName">{{item.salesManName}}</div>
              <div class="contentPremium">{{item.planPremium}}</div>
            </div>

            <div class="tableContent" v-if="index==1" v-for="(item,i) in isSubmitArr" :key="i">
              <div class="contentCenter">{{item.dealerName}}</div>
              <div class="contentName">{{item.salesManName}}</div>
              <div class="contentPremium">{{item.planPremium}}</div>
            </div>
          </pts-scroll-ajax>
        </div>

      </div>
    </div>

  </section>
</template>

<script>
import API from '@/common/js/comConfig'
import Axios from '@/common/js/axiosConfig'
import Toast from '@/common/comComponent/toast'
import ptsPie from '../../../../common/comComponent/echarts/pie'
import { remInPx } from '../../../../common/js/comUtils'
import ptsScrollAjax from '../../../../common/comComponent/scrollAjax'

const colors = ['#60D194', '#FFDB4B'] //饼状图颜色

export default {
  name: 'workProgress',
  mounted() {
    this.getData();
    this.getWorkProgressList(0);
    this.$refs.scrollAjax.reset(true)
  },
  components: {
    ptsPie,
    ptsScrollAjax
  },
  data() {
    return {
      topAjax:false,
      bottomAjax:false,
      pieState: 1,
      index: 0,
      isSubmitArr:[],
      totalNum:'',
      datas:{}, //存储饼图请求回来的数据
      pageNo:1,
      pieOption1: {
        title: [
          {
            text: '总网点',
            textStyle: {
              fontSize: remInPx(0.26),
              fontWeight: 'normal',
              color: '#666666'
            },
            top: '33%',
            left: 'center'
          },
          {
            text: '0',
            textStyle: {
              fontSize: remInPx(0.6),
              fontWeight: 'normal',
              color: '#333'
            },
            top: '44%',
            left: 'center'
          }
        ],
        color: colors,
        series: [
          {
            type: 'pie',
            radius: ['75%', '90%'],
            label: {
              normal: {
                show: false
              },
              emphasis: {
                show: false
              }
            },
            hoverAnimation: false,
            data: [
              {
                value: 0,
                name: '已提交网点'
              },
              {
                value: 0,
                name: '未提交网点'
              }
            ]
          }
        ]
      },
      pieOption2: {
        title: [
          {
            text: '计划总保费(万元)',
            textStyle: {
              fontSize: remInPx(0.26),
              fontWeight: 'normal',
              color: '#666666'
            },
            top: '33%',
            left: 'center'
          },
          {
            text: '0',
            textStyle: {
              fontSize: remInPx(0.6),
              fontWeight: 'normal',
              color: '#333'
            },
            top: '44%',
            left: 'center'
          }
        ],
        color: colors[0],
        series: [
          {
            type: 'pie',
            radius: ['75%', '90%'],
            label: {
              normal: {
                show: false
              },
              emphasis: {
                show: false
              }
            },
            hoverAnimation: false,
            data: [
              {
                value: 0,
                name: '已提交网点保费'
              },
              {
                value: 0,
                name: '未提交网点保费'
              }
            ]
          }
        ]
      }
    }
  },
  methods: {
    getData() {
      let reqData = {
        "dealerCode": '',
        "planYearMonth": this.dateTimer
      }
      Axios.post(API.getWebServiceUrls('getWorkProgress'), reqData)
        .then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (data.code === 0) {
            this.datas = data.data;
            this.$nextTick(function () {
              this.$refs.pie1.setData(function (echarts) {
                echarts.setOption({
                  title:[
                    {},
                    {
                      text:(function (value) {
                        if (Number.isNaN(Number(value))) {
                          return value;
                        }
                        if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
                          return Number(value).toLocaleString();
                        } else {
                          return value;
                        }
                      })((data.data.totalDealerNumBer || 0))
                    }
                  ],
                  series: [
                    {
                      data: [
                        {value:data.data.committedNumBer || 0},
                        {value:data.data.uncommittedNumBer || 0}
                      ]
                    }
                  ]
                })
              });
              this.$refs.pie2.setData(function (echarts) {
                echarts.setOption({
                  title:[
                    {},
                    {
                      text:(function (value) {
                        if (Number.isNaN(Number(value))) {
                          return value;
                        }
                        if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
                          return Number(value).toLocaleString();
                        } else {
                          return value;
                        }
                      })((data.data.committedTotalPremium || 0))
                    }
                  ],
                  series: [
                    {
                      data: [
                        {value:data.data.committedTotalPremium || 0},
                      ]
                    }
                  ]
                })
              });
            })
          } else {
            Toast(data.msg || '系统繁忙,请稍后重试')
          }
        })
        .catch(err => {
          console.log(err)
        })
    },

    //底部tab栏提交和未提交请求的数据
    getWorkProgressList(type){
      const _this = this;
      if (_this.index != type) {
        _this.isSubmitArr = []
      }
      _this.index = type;

      let obj = {
        "dealerCode": "",
        "pageNo": _this.pageNo,
        "pageSize": 20,
        "planStatus": type || _this.index,
        "planYearMonth": _this.dateTimer
      }

      Axios.post(API.getWebServiceUrls('getWorkProgressUnSubmitList'),obj)
        .then(res => {
          // console.log(res)
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (data.code == 0) {
            _this.totalNum = data.totalCount;

            if (data.data && data.data.length === 0 ) {
              _this.bottomAjax = false
              _this.$refs.scrollAjax && _this.$refs.scrollAjax.reset(true);
              return
            }

            data.data.forEach(v => {
              _this.isSubmitArr.push(v)
            });

            _this.bottomAjax = true;

            //pageSize默认每次请求10条,两者乘积大于总条数时,禁止上拉加载
            if (data.pageNo * data.pageSize > data.totalCount) {
              _this.bottomAjax = false
            }

            //DOM 更新循环结束之后,触发
            _this.$nextTick(function () {
              // debugger
              _this.$refs.scrollAjax && _this.$refs.scrollAjax.reset(true)
            })
          } else {
            Toast(data.msg || '系统繁忙,请稍后重试')
          }
        })
        .catch(err => {
          console.log(err)
        })
    },

    /**
     * @info 当页面到底部时还有数据再次请求数据
     */
    getNextPage(){
      this.pageNo++;
      this.getWorkProgressList();
    },
  },
  props: {
    dateTimer: String
  },
  watch: {
    dateTimer(newValue) {
      this.getData();
      this.getWorkProgressList(this.index);
    }
  }
}
</script>

<style scoped lang="less">
  .work_wrap::-webkit-scrollbar{
    display: none;
  }
  .opacity0{
    opacity: 0;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    margin: 0;
  }
  .class1{
    opacity: 1;
  }

  .work_wrap{
    height: 100%;
    overflow-y: scroll;
    .swiperBox{
      background: #FFffff;
      position: relative;
    }
    .chartInfoBox dt,dd{
      display: inline-block;
    }
    .chartInfoBox{
      background: #FFffff;
      & dl{
        height: .76rem;
        line-height: .76rem;
        position: relative;
        dt{
          font-size: .28rem;
          color: #333333;
          letter-spacing: 0;
          margin-left: .61rem;
        }
        .dt1:before{
          content: "";
          display: block;
          position: absolute;
          top: 50%;
          left: .31rem;
          margin-top: -.05rem;
          width: .1rem;
          height: .1rem;
          background-color: #60D194;
        }
        .dt2:before{
          content: "";
          display: block;
          position: absolute;
          top: 50%;
          left: .31rem;
          margin-top: -.05rem;
          width: .1rem;
          height: .1rem;
          background-color: #FFDB4B ;
        }
        dd{
          position: absolute;
          right: .3rem;
        }
      }
    }

    .tabWrap{
      padding-top: .3rem;
      .analyBtnArea{
        overflow: hidden;
        width: 3.1rem;
        margin-left: auto;
        margin-right: auto;
        text-align: center;
        border: 1px solid #fe883a;
        border-radius: .08rem;
        li{
          float: left;
          height: .62rem;
          line-height: .62rem;
          width: 1.55rem;
          font-size: .24rem;
          color: #FE883A;
        }
        .cur{
          color: #FFffff;
          background: #fe883a;
        }
      }
    }
    .centerInfoBox{
      margin-top: .2rem;
      padding-bottom: .3rem;
      background: #FFffff;
      .tableWrap{
        margin: .3rem;
        .tableTitle{
          position: relative;
          height: .73rem;
          line-height: .73rem;
          background-color: #F2F2F2;
          p{
            display: inline-block;
            position: absolute;
            margin-top: .25rem;
            font-size: .24rem;
            color: #999999;
            letter-spacing: 0;
            line-height: .24rem;
          }
          p:nth-child(1){
            left: .27rem;
          }
          p:nth-child(2){
            right: 1.97rem;
          }
          p:nth-child(3){
            right:.24rem
          }
        }
        .tableContentBox{
          max-height: 9rem;
          overflow-y: scroll;
          height: 9rem;
        }
        .tableContent{
          padding: .27rem;
          border-left: 1px solid #eee;
          border-right: 1px solid #eee;
          border-bottom: 1px solid #eee;
          display: flex;
          align-items: baseline;
          font-size: .28rem;
          color: #333333;
          letter-spacing: 0;
          line-height: .4rem;
          .contentCenter{
            width: 3.64rem;
            text-align: left;
          }
          .contentName{
            flex-grow: 2;
            text-align: center;
            margin-left: -.2rem;
          }
          .contentPremium{
            flex-grow: 1;
            text-align: center;
          }
        }
      }

    }
  }
</style>
