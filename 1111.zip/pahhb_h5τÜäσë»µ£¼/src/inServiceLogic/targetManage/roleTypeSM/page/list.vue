<template>
  <div class="tabArea">
    <div class="scrollBox" :class="{haveBottom:tabIndex==0||tabIndex==1}" :style="{bottom:haveAuthorize&&tabIndex==1 ? '0.9rem' : '0rem'}">
      <pts-scroll-ajax ref="scrollAjax"
                       @on-bottom-ajax="bottomAjaxEvent"
                       :bottomAjax="needLoadMore"
                       :topAjax="listData.length != 0"
                       @on-top-ajax="topAjaxEvent">
        <pts-task-item :tabIndex="tabIndex" :checkedPlanId="checkedPlanId" :listData="listData"></pts-task-item>

        <!-- 页面无数据时显示的图片 -->
        <div class="dataNullWrap" v-if="listData&&listData.length<1">
          <div class="noInfoImg"></div>
          <div class="dataNullText">亲, 暂未制定计划</div>
        </div>
      </pts-scroll-ajax>
    </div>

    <!-- s/m未授权或已授权提交按钮区域 -->
    <div class="submit-btn-wrap" v-if="tabIndex==0&&listData.length!==0" @click.stop="clickAll">
      <div class="select-wrap">
        <div class="select-icon" :class="{selectAll:isAllChecked}"></div>
        <p>全选</p>
      </div>
      <div class="select-btn">
        <button class="btn" @click.stop="submitPlan('1')">提交</button>
      </div>
    </div>

    <!-- s/m已授权通过或不通过区域 -->
    <div class="access-btn-wrap" v-if="tabIndex==1 && haveAuthorize && listData.length!==0" @click.stop="clickAll">
      <div class="select-wrap">
        <div class="select-icon" :class="{selectAll:isAllChecked}"></div>
        <p>全选</p>
      </div>
      <div class="select-btn">
        <button class="btn1" @click.stop="submitPlan('3')">不通过</button>
        <button class="btn2" @click.stop="submitPlan('2')">通过</button>
      </div>
    </div>
  </div>
</template>

<script>
import toast from '../../../../common/comComponent/toast/index'
import ptsScrollAjax from '../../../../common/comComponent/scrollAjax/index'
import ptsTaskItem from './item.vue'
import Axios from '../../../../common/js/axiosConfig'
import API from '../../../../common/js/comConfig'

export default {
  name: 'smTargetManageList',
  components: {
    ptsScrollAjax,
    ptsTaskItem
  },
  data() {
    return {
      haveAuthorize: true //判断SM有无获得授权,默认有
    }
  },
  created() {
    //进来页面判断sm有无授权,从而展示不同页面 Y已授权,N未授权
    if (dealerData.planTargetAuth == 'N') {
      this.haveAuthorize = false
    }
  },
  methods: {
    //未提交页面提交按钮和未审核页面的通过和不通过
    submitPlan(type) {
      const _this = this
      let arr = []
      _this.listData.forEach(v => {
        if (v.isChecked) {
          arr.push(v.planId)
        }
      })
      if (arr.length == 0) {
        toast('请至少选择一项')
        return
      }
      Axios.post(API.getWebServiceUrls('updateDealerPlanStatus'), {
        planIdList: arr,
        updateType: type
      })
        .then(res => {
          let data =
            typeof res.data === 'string' ? JSON.parse(res.data) : res.data
          if (data.code == 0) {
            toast('提交成功')
            _this.$emit('getData', 1, _this.tabIndex)
          } else {
            toast(data.msg || '系统繁忙,请稍后重试')
          }
        })
        .catch(err => {
          console.log(err)
        })
    },

    bottomAjaxEvent() {
      this.loadingMore()
    },
    topAjaxEvent() {
      this.topLoaderMore()
    },
    clickAll() {
      this.selectAllItem()
    }
  },
  mounted() {
  },
  props: {
    tabIndex: Number,
    listData: Array,
    isAllChecked: Boolean,
    checkedPlanId: Function,
    loadingMore: Function,
    selectAllItem: Function,
    needLoadMore: Boolean,
    topLoaderMore: Function,
    topLoaderMoreEnd: Boolean,
    topLoaderMoreChange: Function
  },
  watch: {
    listData(newValue) {
      this.$nextTick(() => {
        if (newValue.length > 10) {
          this.$refs.scrollAjax.reset(false)
        } else {
          this.$refs.scrollAjax.reset(true)
        }
      })
    },
    topLoaderMoreEnd(newValue) {
      this.$refs.scrollAjax.reset(true)
      this.topLoaderMoreChange()
    }
  }
}
</script>

<style scoped lang="less">
  .tabArea {
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    position: relative;
    .scrollBox{
      width:100%;
      position:absolute;
      top:0;
      bottom: 0;
    }
    .haveBottom{
      bottom: 0.9rem;
    }
  }
  .submit-btn-wrap{
    @height:.9rem;
    height: @height;
    background: #ffffff;
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    .select-wrap{
      display: inline-block;
      position: relative;
      & p{
        position: absolute;
        top: .31rem;
        left: .72rem;
        width: .8rem;
        font-size: .28rem;
        line-height: .28rem;
      }
      .select-icon{
        display: inline-block;
        width: .3rem;
        height: .3rem;
        background: url("../../../../common/images/icon_noselect@3x.png") no-repeat;
        background-size: 100%;
        margin: .3rem 0 .3rem .3rem;
      }
      .selectAll{
        background: url("../../../../common/images/icon_selected@3x.png") no-repeat;
        background-size: 100%;
      }
    }
    .select-btn{
      float: right;
      .btn{
        @background: #FD9244;
        display: block;
        width: 2.5rem;
        height: 0.9rem;
        outline-color: @background;
        margin: 0 auto;
        border: none;
        background: @background;
        font-size: 0.32rem;
        font-weight: normal;
        color: #fff;
      }
    }
  }

  .access-btn-wrap{
    @height:.9rem;
    height: @height;
    background: #ffffff;
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    .select-wrap{
      display: inline-block;
      position: relative;
      & p{
        position: absolute;
        top: .31rem;
        left: .72rem;
        width: .8rem;
        font-size: .28rem;
        line-height: .28rem;
      }
      .select-icon{
        display: inline-block;
        width: .3rem;
        height: .3rem;
        background: url("../../../../common/images/icon_noselect@3x.png") no-repeat;
        background-size: 100%;
        margin: .3rem 0 .3rem .3rem;
      }
      .selectAll{
        background: url("../../../../common/images/icon_selected@3x.png") no-repeat;
        background-size: 100%;
      }
    }
    .select-btn{
      float: right;
      .btn1{
        @background: #ffffff;
        display: inline-block;
        width: 1.875rem;
        height: 0.9rem;
        outline-color: @background;
        margin: 0 auto;
        border: none;
        border-left: 1px solid #eee;
        background: @background;
        font-size: 0.32rem;
        font-weight: normal;
        color: #FD9244;
      }
      .btn2{
        @background: #FD9244;
        display: inline-block;
        width: 1.875rem;
        height: 0.9rem;
        outline-color: @background;
        margin: 0 auto;
        border: none;
        background: @background;
        font-size: 0.32rem;
        font-weight: normal;
        color: #fff;
      }
    }
  }

  .dataNullWrap{
    .noInfoImg{
      background: url("../../../../common/images/icon_noMessage@3x.png") no-repeat;
      background-size: 100%;
      width: .82rem;
      height: .97rem;
      margin: 0 auto;
    }
  }
</style>
