<template>
	<!--此页面为空白页,用来从路由跳转进来后判断账户角色是va/vp,或者是sm.

	    从而分发不同路径进入不同角色页面-->


</template>

<script>


  export default {
    name: "index",

    beforeRouteEnter(to,from,next){

      if (dealerData.frontLineRoleType == 'vp') {
        next({
          path:'/inside/targetManage/roleTypeVa/index'
        })
      } else {
        next({
          path:'/inside/targetManage/roleTypeSM/index'
        })
      }
    }
  }
</script>

<style scoped>

</style>
