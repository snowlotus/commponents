<template>
  <div class="accordion">
    <div class="parent" :class="arr.parent.parentChecked?'checkedParent':''" @click="clickParent">
      {{ arr.parent.parentName }}
      <div class="icon" :class="show?'iconAction':'iconUnAction'">
        <img :src="arrowLeft">
      </div>
    </div>
    <transition @enter="enter" @leave="leave" @before-enter="beforeEnter" @before-leave="beforeLeave">
      <div v-show="show" class="childrens">
        <div class="child" v-for="(item,index) in arr.child" @click.stop="chooseAgent(index)" :key="index">
          <div :class="item.childChecked?'checkedText':''">{{ item.childName }}</div>
          <div v-if="item.childChecked" :class="item.childChecked?'checkedIcon':''">
            <img :src="match">
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
  export default {
    props: {
      parentId: {
        type: Number,
        required: true
      },
      speed: {
        type: Number,
        default: 30
      },
      arr: {
        type: Object
      }
    },
    data() {
      return {
        //对号
        match: require('./../../../common/images/org_cph_checked.png'),
        //左箭头的引入
        arrowLeft: require('./../../../common/images/arrowLeft2.png'),
        //判断动画是否完成,避免在动画没完成之前再次触发动画
        isIng: false,
        //是否打开手风琴
        show: false,
        //初始化子元素高度
        childrenHeight: null
      }
    },
    methods: {
      //点击父元素进行伸缩
      clickParent() {
        //点击时判断是否正在执行动画
        if (this.isIng) {
          return;
        }
        //判断是否已经初始化子元素的高度
        this.setChildrenHeight();
        //通过子元素高度／每一帧收缩的高度＊20计算出一次动画所需的时间
        let timeOut = this.childrenHeight / this.speed * 20;
        //设置正在执行动画为true
        this.$set(this, 'isIng', true);
        //设置show和之前的状态取反
        this.$set(this, 'show', !this.show);
        //设置定时器执行一次动画结束时,将isIng设置为true
        setTimeout(() => {
          this.$set(this, 'isIng', false);
        }, timeOut)
      },
      setChildrenHeight() {
        //判断子元素高度是否为空
        if (this.childrenHeight === null) {
          //取出html的fontsize
          let htmlFontSize = parseFloat(document.getElementsByTagName('html')[0].style.fontSize);
          //取出这次列表的长度
          let length = this.arr.child.length;
          //两者相乘得到子元素高度
          this.$set(this, 'childrenHeight', htmlFontSize * length);
        }
      },
      beforeEnter(element) {
        this.setChildrenHeight();
      },
      enter(element, done) {
        let _this = this;
        let height = 0;
        let timer = requestAnimationFrame(function fn() {
          if (height < _this.childrenHeight) {
            height = height + _this.speed;
            element.style.height = `${height}px`;
            timer = requestAnimationFrame(fn);
          } else {
            element.style.height = `${_this.childrenHeight}px`;
            cancelAnimationFrame(timer);
            done();
          }
        })
      },
      beforeLeave(element) {
        this.setChildrenHeight();
      },
      leave(element, done) {
        let _this = this;
        let height = _this.childrenHeight;
        let timer = requestAnimationFrame(function fn() {
          if (height > 0) {
            height = height - _this.speed;
            element.style.height = `${height}px`;
            timer = requestAnimationFrame(fn);
          } else {
            element.style.height = '0px';
            cancelAnimationFrame(timer);
            done();
          }
        })
      },
      chooseAgent(index) {
        this.$emit('chooseAgent', this.parentId, index);
      }
    }
  }
</script>

<style scoped lang="less">
  .accordion {
    .checkedParent {
      color: #FE883A;
    }
    .parent {
      font-size: .3rem;
      position: relative;
      padding: .3rem .6rem;
      border-bottom: 1px solid #eee;
      z-index: 100;
      background: #fff;
      .iconAction {
        transform: rotate(270deg);
      }
      .iconUnAction {
        transform: rotate(90deg);
      }
      .icon {
        width: .154rem;
        height: .272rem;
        position: absolute;
        top: 0.42rem;
        right: 0.3rem;
        img {
          width: 100%;
          height: 100%;
        }
      }
    }
    .childrens {
      border-bottom: 1px solid #eeeeee;
      padding-left: .3rem;
      background: #fff;
      overflow: hidden;
      .child {
        position: relative;
        height: 1rem;
        box-sizing: border-box;
        font-size: .3rem;
        border-bottom: 1px solid #eee;
        padding: .3rem .6rem;
        .checkedText {
          color: #FE883A;
        }
        .checkedIcon {
          position: absolute;
          width: .42rem;
          height: .36rem;
          top: 50%;
          transform: translateY(-50%);
          right: 0.3rem;
          img {
            width: 100%;
            height: 100%;
          }
        }
      }
      .child:last-child {
        border-bottom: 0;
      }
    }
  }
</style>
