<template>
  <div class="box">
    <pts-header titleText="选择网点" leftFlag @on-left="goPrevious"></pts-header>
    <accordion :speed=20 v-for="(item,index) in arr" :key="index" @chooseAgent="chooseAgent" :parentId="index" :arr=item></accordion>
  </div>
</template>

<script>
  import eventBus from '@/common/js/eventBus'
  import accordion from './accordion.vue'
  export default {
    components: {
      accordion
    },
    data() {
      return {
        //选择的代理人索引值
        checkedArray: [0, 0],
        arr: [{
          parent: {
            parentName: '外部传入的父级',
            parentValue: 1,
            parentChecked: true
          },
          child: [{
            childName: '显示的名字1',
            childValue: 1,
            childChecked: true
          }, {
            childName: '显示的名字2',
            childValue: 2,
            childChecked: false
          }, {
            childName: '显示的名字3',
            childValue: 3,
            childChecked: false
          }, {
            childName: '显示的名字4',
            childValue: 4,
            childChecked: false
          }, {
            childName: '显示的名字5',
            childValue: 5,
            childChecked: false
          }]
        }, {
          parent: {
            parentName: '外部传入的父级2',
            parentValue: 1,
            parentChecked: false
          },
          child: [{
            childName: '显示的名字22',
            childValue: 2,
            childChecked: false
          }, {
            childName: '显示的名字23',
            childValue: 3,
            childChecked: false
          }, {
            childName: '显示的名字24',
            childValue: 4,
            childChecked: false
          }, {
            childName: '显示的名字25',
            childValue: 5,
            childChecked: false
          }]
        }],
        chooseAgent: (parentId, childId) => {
          //关闭默认选择的高亮
          this.$set(this.arr[this.checkedArray[0]].parent, 'parentChecked', false);
          this.$set(this.arr[this.checkedArray[0]].child[this.checkedArray[1]], 'childChecked', false);
          //打开选择的高亮
          this.$set(this.arr[parentId].parent, 'parentChecked', true);
          this.$set(this.arr[parentId].child[childId], 'childChecked', true);
          //更新选择的数组
          let arr = [parentId, childId];
          this.$set(this, 'checkedArray', arr);
          //通知上一级页面数据的更新
          eventBus.$emit('clickParent', this.arr[this.checkedArray[0]].parent, this.arr[this.checkedArray[0]].child[this.checkedArray[1]])
        }
      }
    },
    methods: {
      goPrevious() {
        this.$router.go(-1);
      }
    }
  }
</script>

<style scoped lang="less">

</style>
