<template>
  <div class="box">
    <!--<pts-header titleText="车险投保" leftFlag @on-left="goMenu"></pts-header>-->
    <div class="t_header">
      <div class="t_header_arrow" @click.stop="goMenu"></div>
      <div class="t_header_title">车险投保</div>
      <div class="t_header_null"></div>
    </div>
    <section class="orderDtail_wrapper con_touch">
      <!--输入车牌号 start-->
      <div class="bg_fff box_shadow">
        <table cellpadding="0" cellspacing="0" border="0" class="cph_table">
          <!-- title -->
          <tr>
            <td class="ord_label pts-b-b titleMessage" style="width: 20%;">
              网点信息
              <div class="bg"></div>
            </td>
            <td colspan="3" style="padding-left: .5rem;position:relative;" class="pts-b-b"></td>
          </tr>
          <!-- 网点 -->
          <tr>
            <td class="ord_label pts-b-b" style="width: 30%;">网点</td>
            <td colspan="3" style="padding-left: .5rem;position:relative;" class="pts-b-b" @click="showChooseNetwork">
              <!--<div style="width: 90%; font-size:0.28rem;text-align: right;">
                {{networkName}}
              </div>-->
              <!-- 2018-06-13 需求要求 网点名称过长时轮播显示 -->
              <div class="network-name-wrap" ref="textWrap">
                <div class="scroll-wrap" style="transition:none;transform: translateX(0px);" ref="text"
                     @transitionend="trsEND">
                  {{networkName}}
                </div>
              </div>
              <!-- 2018-06-13 需求要求 网点名称过长时轮播显示 -->
              <popup-picker v-show="false" ref="modelPicker" :show-name="PopupPickerOption.showName" :columns="1"
                            @on-change="PopupPickerOption.networkChange" v-model='PopupPickerOption.networkValue'
                            :data="PopupPickerOption.networkList"
                            :placeholder="PopupPickerOption.networkPlaceholder"></popup-picker>
              <div class='iconPosition'>
                <div>
                  <img :src="PopupPickerOption.arrowLeft">
                </div>
              </div>
            </td>
          </tr>

          <!-- 渠道来源 -->
          <tr v-if="PopupPickerOption.canalFrom">
            <td class="ord_label pts-b-b" style="width: 30%;">渠道来源</td>
            <td colspan="3" style="padding-left: .5rem;position:relative;" class="pts-b-b onlyTextTd">{{
              PopupPickerOption.canalFrom }}
            </td>
          </tr>
          <!-- 渠道来源细分 -->
          <tr v-if="PopupPickerOption.canalList.length>0">
            <td class="ord_label pts-b-b" style="width: 30%;">渠道来源细分</td>
            <td colspan="3" style="padding-left: .5rem;position:relative;" class="pts-b-b">
              <popup-picker :show-name="PopupPickerOption.showName" :columns="1"
                            @on-change="PopupPickerOption.canalChange" v-model='PopupPickerOption.canalValue'
                            :data="PopupPickerOption.canalList"
                            :placeholder="PopupPickerOption.canalPlaceholder"></popup-picker>

              <div class='iconPosition'>
                <div>
                  <img :src="PopupPickerOption.arrowLeft">
                </div>
              </div>
            </td>
          </tr>
          <!-- 代理人 -->
          <!--1:个人代理2:兼业代理3:专业代理4:传统经纪5:特殊经纪6:合作性临分业务9:自助卡业务D:直接业务-->
          <!-- 代理人列表数量大于0,并且businessSourceDetailCode为D. -->
          <tr v-if="PopupPickerOption.agentList.length>0&&businessSourceDetailCode!=='D'">
            <td class="ord_label pts-b-b" style="width: 30%;">
              {{ businessSourceDetailCode === '4' || businessSourceDetailCode === '5' ? '经纪人':'代理人' }}
            </td>
            <td colspan="3" style="padding-left: .5rem;position:relative;" class="pts-b-b">
              <popup-picker :show-name="PopupPickerOption.showName" :columns="1" v-model='PopupPickerOption.agentValue'
                            :data="PopupPickerOption.agentList"
                            :placeholder="PopupPickerOption.agentPlaceholder"></popup-picker>
              <div class='iconPosition'>
                <div>
                  <img :src="PopupPickerOption.arrowLeft">
                </div>
              </div>
            </td>
          </tr>
        </table>
        <div style="height:0.2rem;background: rgb(238,238,238);"></div>
        <table cellpadding="0" cellspacing="0" border="0" class="cph_table">
          <!-- title -->
          <tr>
            <td class="ord_label pts-b-b titleMessage" style="width: 20%;">
              投保信息
              <div class="bg"></div>
            </td>
            <td colspan="3" style="padding-left: .5rem;position:relative;" class="pts-b-b"></td>
          </tr>
          <!--2018-06-13 需求 不在让用户选择省市 开始-->
          <!-- 投保地区 -->
          <!--<tr>
            <td class="ord_label pts-b-b" style="width: 20%;">投保地区</td>
            <td colspan="3" style="padding-left: .5rem;position:relative;" class="pts-b-b">
              <popup-picker value-text-align='left' :show-name="PopupPickerOption.showName" :columns="2"
                            @on-change="PopupPickerOption.locationChange" v-model='PopupPickerOption.locationValue'
                            :data="PopupPickerOption.locationList"
                            :placeholder="PopupPickerOption.locationPlaceholder"></popup-picker>
              <div class='iconPosition'>
                <div>
                  <img :src="PopupPickerOption.arrowLeft">
                </div>
              </div>
            </td>
          </tr>-->
          <!--2018-06-13 需求 不在让用户选择省市 结束-->
          <!-- 车牌号码 -->
          <tr>
            <td class="ord_label" style="width: 20%;">车牌号码</td>
            <td style="padding-left:0.5rem;width:1.4rem;position:relative;" class="prefix" @click="showKeyBoard = true">
              <div>{{PopupPickerOption.prefixValue}}</div>
              <!--<popup-picker :show-name="PopupPickerOption.showName" :columns="1" value-text-align='left'
                            @on-show='PopupPickerOption.prefixShow' @on-hide='PopupPickerOption.prefixHide'
                            v-model='PopupPickerOption.prefixValue' :data="PopupPickerOption.prefixList"
                            :placeholder="PopupPickerOption.prefixPlaceholder"></popup-picker>-->
              <div class='iconPosition' style="right:.15rem;" v-if="PopupPickerOption.prefixList.length>1">
                <div :class="PopupPickerOption.prefixValueAction?'prefixValueAction':'prefixValueUnAction'">
                  <img :src="PopupPickerOption.arrowLeft">
                </div>
              </div>
            </td>
            <td>
              <input class=" input_w300" type="text" id="inputElem" :placeholder="isFlag?'不用输入车牌号':'请输入车牌号码'"
                     :readonly="isFlag" @input="carNo=carNo.toUpperCase()"
                     v-model="carNo" maxlength="6" minlength="5" style="width:2rem"/>
            </td>
            <td style="text-align:right;">
              <!--给i标签在添加“checked”样式就是选中状态-->
              <div @click.prevent="isFlag=!isFlag">
                <i class="cph_check" :class="isFlag==true?'checked':''"></i>
                <span class="cph_wsp">未上牌</span>
              </div>
            </td>
          </tr>
        </table>
      </div>
      <div class="cph_btn">
        <a v-if='true' class="cph_ljtb tac " :class="BtnFlag ? '':'closeBtn'" target="_blank" title="立即投保" otitle="立即投保"
           otype="button" @click="next">立即投保</a>
      </div>
      <!--输入车牌号 End-->
      <!--模拟form 表单提交-->
      <form :action="imcsTranData.imcsUrl" method="post" id="goToImcs" name="goToImcs" ref="formElem">
        <input type="hidden" :value="imcsTranData.params" name="params"/>
        <input type="hidden" :value="imcsTranData.signData" name="signData"/>
        <input type="hidden" :value="imcsTranData.systemId" name="systemId"/>
      </form>
    </section>
    <pts-key-board v-model="showKeyBoard" @on-input="getKeyBoardV"
                   :checkedValue="PopupPickerOption.prefixValue" input-elem-id="inputElem"></pts-key-board>
  </div>
</template>

<script>
  import Toast from '../../common/comComponent/toast'
  import API from '../../common/js/comConfig'
  import Axios from '../../common/js/axiosConfig'
  import {
    checkVehicleNumOrNo
  } from '../../common/js/comUtils'
  // 2018-06-13 不在让用户选择省市
  // import specialJson from '@/common/js/data.js'
  import ptsKeyBoard from '../../common/comComponent/keyBoard';
  import {
    PopupPicker
  } from 'vux'

  export default {
    components: {
      PopupPicker,
      ptsKeyBoard
    },
    data () {
      return {
        //是否未上牌
        isFlag: true,
        //车牌号码
        carNo: '*',
        //按钮是否可选
        BtnFlag: false,
        //这里是提交from表单时储存的数据
        imcsTranData: {
          imcsUrl: '',
          params: '',
          signData: '',
          systemId: ''
        },
        //里脊投保时传给后端的
        dealerName: '',
        //业务细分来源
        businessSourceDetailCode: '',
        /* 这里是两个picker的配置 */
        PopupPickerOption: {
          //getInnerInsure的初始化数据
          getInnerInsureData: [],
          // 左箭头的地址
          arrowLeft: require('./../../common/images/arrowLeft2.png'),
          //默认代理人
          defaultAgent: {},
          // 显示name属性还是value属性
          showName: true,
          // 城市对应的车牌前缀
          cityToPreFix: {},
          //是否获取到车牌前缀
          isFirst: true,
          //车牌前缀是否选择的状态
          prefixValueAction: false,
          //渠道来源
          canalFrom: '',
          //网点信息
          networkValue: [],
          networkList: [],
          networkPlaceholder: '请选择网点',
          networkChange: (val) => {
            getInnerInsure(this, val[0]);
          },
          //渠道来源细分
          canalValue: [],
          canalList: [],
          canalPlaceholder: '请选择渠道来源细分',
          canalChange: (val) => {
            //判断传入值是否为空
            if (val.length === 1) {
              val = val[0];
            } else {
              return;
            }
            //初始化代理人列表
            let agentListData = [];
            //取出所有数据
            let list = this.PopupPickerOption.getInnerInsureData && this.PopupPickerOption.getInnerInsureData.chooseChannelSourceVO ? this.PopupPickerOption.getInnerInsureData.chooseChannelSourceVO : [];
            for (let i = 0; i < list.length; i++) {
              if (list[i].channelbusinessDetailName === val) {
                //当businessSourceDetailCode为4，5的时候取得经纪人列表
                if (list[i].businessSourceDetailCode === '4' || list[i].businessSourceDetailCode === '5') {
                  let brokerList = list[i].brokerList || [];
                  for (let j = 0; j < brokerList.length; j++) {
                    agentListData.push({
                      name: brokerList[j] && brokerList[j].brokerName ? brokerList[j].brokerName : '',
                      value: brokerList[j] && brokerList[j].brokerCode ? brokerList[j].brokerCode : '',
                      parent: 0,
                    })
                  }
                } else {
                  let agentList = list[i].agentList || [];
                  for (let j = 0; j < agentList.length; j++) {
                    agentListData.push({
                      name: agentList[j] && agentList[j].agentName ? agentList[j].agentName : '',
                      value: agentList[j] && agentList[j].agentCode ? agentList[j].agentCode : '',
                      parent: 0,
                    })
                  }
                }
                this.$set(this, 'businessSourceDetailCode', list[i].businessSourceDetailCode);
                if (agentListData.length < 1) {
                  this.$set(this, 'businessSourceDetailCode', 'D');
                }
                break;
              }
            }
            this.$set(this.PopupPickerOption, 'agentValue', agentListData && agentListData[0] ? [agentListData[0].value] : []);
            this.$set(this.PopupPickerOption, 'agentList', agentListData);
          },
          // 代理人
          agentValue: [],
          agentList: [],
          agentPlaceholder: '请选择代理人',
          //投保地区
          locationValue: [],
          locationList: [],
          locationPlaceholder: '请选择投保地区',
          // 第二个的change方法
          locationChange: (val) => {
            //由于初始化值的value2为[],而在获取一些初始化值时会触发onchange2,此时获取城市列表的接口还没成功,导致数据有问题,报错
            if (this.PopupPickerOption.isFirst) {
              return;
            }
            //当前选中城市的值
            val = val[1];
            // 初始化value3和list3
            let prefixValue = [];
            let prefixList = [];
            //将城市的代码放到之前生成的城市对应的车牌前缀放入value3中
            prefixValue.push(this.PopupPickerOption.cityToPreFix[val][0].name);
            //取出的数组列表放进去
            prefixList = this.PopupPickerOption.cityToPreFix[val];
            this.$set(this.PopupPickerOption, 'prefixValue', prefixValue);
            this.$set(this.PopupPickerOption, 'prefixList', prefixList);
          },
          //车牌前缀
          // prefixValue: [],
          // 2018-06-13 不在让用户选择投保地区改为键盘输入车牌前面的省份简称
          prefixValue: '',
          prefixList: [],
          prefixPlaceholder: '',
          prefixShow: () => {
            this.$set(this.PopupPickerOption, 'prefixValueAction', true)
          },
          prefixHide: () => {
            this.$set(this.PopupPickerOption, 'prefixValueAction', false)
          }
        },
        showKeyBoard: false, // 显示省份简称的键盘
        networkName: '请选择网点' // 用户选择的网点的名称
      }
    },
    created () {
      let self = this;
      //获取城市列表,车牌前缀等
      // getDestination(self);
      //内部端买车险调取网点
      getNetworkOrganization(self);
      //监听选取的网点值
      self.$watch('PopupPickerOption.networkValue', function (newValue, oldValue) {
        self.canInsure();
      })
      //监听渠道来源细分
      self.$watch('PopupPickerOption.canalValue', function (newValue, oldValue) {
        self.canInsure();
      })
      //监听代理人
      self.$watch('PopupPickerOption.agentValue', function (newValue, oldValue) {
        self.canInsure();
      })
      //监听投保地区
      /*self.$watch('PopupPickerOption.locationValue', function (newValue, oldValue) {
        self.canInsure();
      })*/
      //监听车牌前缀
      self.$watch('PopupPickerOption.prefixValue', function (newValue, oldValue) {
        self.canInsure();
      })
      //监听车牌
      self.$watch('carNo', function (newValue, oldValue) {
        self.canInsure();
      })
      //监听是否未上牌
      self.$watch('isFlag', function (newValue, oldValue) {
        if (newValue) {
          window.eventAnalytics('车险投保', '点击了未上车牌');
          this.$set(this, 'carNo', '*');
        } else {
          this.$set(this, 'carNo', '');
        }
        //这里无需触发self.canInsure,他会修改carNo,那边触发.
      })
      // 判断网点的名称是否需要滚动显示
      self.$watch('networkName', function (newValue, oldValue) {
        this.$nextTick(function () {
          this.textScroll();
        });
      })
    },
    methods: {
      //回到Native主页
      goMenu () {
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      //用来判断是否可以立即投保,并且控制按钮状态
      canInsure () {
        if (this.PopupPickerOption.networkValue.length === 1) {
          if (this.PopupPickerOption.canalValue.length === 1) {
            if (this.PopupPickerOption.agentValue.length === 1 || this.businessSourceDetailCode === 'D') {
              if (this.PopupPickerOption.prefixValue.length === 2) {
                if (!this.isFlag) {
                  //选择上牌的时候
                  if (this.carNo) {
                    this.$set(this, 'BtnFlag', true);
                  } else {
                    this.$set(this, 'BtnFlag', false);
                    return '请输入车牌号!'
                  }
                } else {
                  this.$set(this, 'BtnFlag', true);
                }
              } else {
                this.$set(this, 'BtnFlag', false);
                return '请录入车牌简称!';
              }
            } else {
              this.$set(this, 'BtnFlag', false);
              return '请选择代理人!';
            }
          } else {
            this.$set(this, 'BtnFlag', false);
            return '请选择渠道来源细分!';
          }
        } else {
          this.$set(this, 'BtnFlag', false);
          return '请选择网点!';
        }
      },
      //下单
      next () {
        if (!this.BtnFlag) {
          Toast(this.canInsure());
          return;
        }
        window.eventAnalytics('车险投保', '点击了立即投保');
        if (this.carNo.includes('-')) return Toast('车牌号格式错误');
        let newCarNo = this.PopupPickerOption.prefixValue + this.carNo;
        if (checkVehicleNumOrNo(newCarNo)) {
          this.goToNext();
        } else {
          Toast('车牌号不正确,请重新输入!');
        }
      },
      //去下单
      goToNext () {
        let self = this;
        if (self.isFlag) {
          self.carNo = "*";
        }
        let CarNo = this.PopupPickerOption.prefixValue[0] + self.carNo; //组合车牌号
        //初始化立即投保的数据
        let reqData = {
          licenseNo: CarNo,
          dealerCode: this.PopupPickerOption.networkValue[0]
        }

        //选择投保区域的省市编码
        if (this.PopupPickerOption.locationValue && this.PopupPickerOption.locationValue.length == 2) {
          reqData.provinceCode = this.PopupPickerOption.locationValue[0];
          reqData.cityCode = this.PopupPickerOption.locationValue[1];
        }
        //取出所有网点下的所有数据,包括渠道细分来源,代理人等
        let list = this.PopupPickerOption.getInnerInsureData && this.PopupPickerOption.getInnerInsureData.chooseChannelSourceVO ? this.PopupPickerOption.getInnerInsureData.chooseChannelSourceVO : [];
        //初始化渠道细分来源下的数据
        let canalDetail = {};
        for (let i = 0; i < list.length; i++) {
          //取列表的每一项取出channelbusinessDetailName
          let value1 = list[i].channelbusinessDetailName ? list[i].channelbusinessDetailName : '';
          let value2 = this.PopupPickerOption.canalValue[0];
          if (value1 === value2) {
            canalDetail = list[i];
            break;
          }
        }
        reqData.channelSourceInfo = canalDetail.channelSourceInfoVO;
        //获取选中代理人的所有信息,先判断是否不为直接业务,在判断代理人选项是否有值
        if (this.businessSourceDetailCode != 'D' && this.PopupPickerOption.agentValue[0]) {
          //初始化选中代理人或经纪人
          let agentObj = {};
          //当为经纪人时,取出经纪人列表
          if (this.businessSourceDetailCode == '4' || this.businessSourceDetailCode == '5') {
            let agentList = canalDetail.brokerList;
            for (let i = 0; i < agentList.length; i++) {
              if (agentList[i].brokerCode === this.PopupPickerOption.agentValue[0]) {
                reqData.broker = agentList[i];
                break;
              }
            }
          } else {
            //当为代理人时,取出代理人
            let agentList = canalDetail.agentList;
            for (let i = 0; i < agentList.length; i++) {
              if (agentList[i].agentCode === this.PopupPickerOption.agentValue[0]) {
                reqData.agent = agentList[i];
                break;
              }
            }
          }
        }
        Axios.post(API.getWebServiceUrls('innerInsurancing'), reqData).then(res => {
          let resData = res.data;
          if (resData.code == 0) {
            self.imcsTranData['imcsUrl'] = resData.data.imcsUrl || '';
            self.imcsTranData['params'] = resData.data.params || '';
            self.imcsTranData['signData'] = resData.data.signData || '';
            self.imcsTranData['systemId'] = resData.data.systemId || '';
            setTimeout(function () {
              self.$refs.formElem.submit()
            }, 0)
          } else {
            Toast(resData.msg || '系统繁忙, 请稍后再试');
          }
        }).catch(err => {
          console.log(err);
        })
      },
      // 获取用户使用省份简称键盘输入的值
      getKeyBoardV (v) {
        this.PopupPickerOption.prefixValue = v;
      },
      // 2018-06-13 需求 网点显示不全时采用滚动方式显示
      // 点击显示选择网点弹窗
      showChooseNetwork () {
        // 根据插件popuo-pricker 的vue实例 去调用上面显示弹窗的方法
        this.$refs.modelPicker.onClick();
      },
      // 文字滚动过度完成后执行的方法 使函数再次执行
      trsEND () {
        let _this = this;
        let textElem = this.$refs.text;
        let tw = textElem.scrollWidth;
        textElem.style.transition = 'none';
        textElem.style.transform = 'translateX(' + tw + 'px)';
        setTimeout(function () {
          textElem.style.transition = 'all 10s linear';
          _this.textScroll();
        }, 0);
      },
      textScroll () {
        let wrapElem = this.$refs.textWrap;
        let textElem = this.$refs.text;
        let ww = wrapElem.offsetWidth;
        let tw = textElem.scrollWidth;
        if (tw > ww) {
          textElem.style.transform = 'translateX(' + tw + 'px)';
          setTimeout(function () {
            textElem.style.transition = 'all 10s linear';
            textElem.style.transform = 'translateX(-' + tw + 'px)';
          }, 0);
        } else {
          textElem.style.transition = 'none';
          textElem.style.transform = 'translateX(0px)';
        }
      }
    }
  }

  // 获取省市 2018-06-13 不在让用户选择省市
  /*function getDestination (_this) {
    //获取（省、市、区）操作相关API,回调函数中对数据进行处理
    Axios.post(API.getWebServiceUrls('getDestination')).then(res => {
      let data = res.data.data;
      if (res.data.code === 0) {
        // 存放第二个选择器的选项
        let locationList = [];
        // 存放城市所对应的车牌前缀
        let cityToPreFix = {};
        // 第一次循环省份，因为省份需要和市进行联动，需要设定特定的value，一边联动。而省份在项目中为最外层，所以parent设定为0
        for (let i = 0; i < data.length; i++) {
          locationList.push({
            name: data[i].provinceChineseName,
            value: data[i].provinceCode,
            parent: 0
          })
          //第二次循环是循环市级，所以需要给与parent一致的值以便联动
          for (let j = 0; j < data[i].cityList.length; j++) {
            locationList.push({
              name: data[i].cityList[j].cityChineseName,
              value: data[i].cityList[j].cityCode,
              parent: data[i].provinceCode
            })
            //将城市对应的车牌号码前缀存入到cityToNumber对象里面，有的城市有几个车牌前缀，我们以数组的方式存入
            let cityToNumberObj = [];
            //判断是否在特殊地区里面
            if (specialJson.hasOwnProperty(data[i].cityList[j].cityChineseName)) {
              let key = data[i].cityList[j].cityChineseName;
              cityToNumberObj = specialJson[key]
            } else {
              //按照vux里面传入name,value,parent的方法传入
              cityToNumberObj.push({
                name: data[i].cityList[j].vehicleLicencePrefixList[0],
                value: data[i].cityList[j].vehicleLicencePrefixList[0],
                parent: 0
              })
            }
            cityToPreFix[data[i].cityList[j].cityCode] = cityToNumberObj;
          }
        }
        //将arr设置进this中,这里将获取到的省市数据打包后放入list2中
        _this.$set(_this.PopupPickerOption, 'locationList', locationList);
        //将obj设置进this中,这里将城市对应的车牌前缀打包成{name.value,parent}的形式,方便后面展示数据时可以使用
        _this.$set(_this.PopupPickerOption, 'cityToPreFix', cityToPreFix);
        //有数据了,就把第一次的值设置为true
        _this.$set(_this.PopupPickerOption, 'isFirst', false);
      } else {
        Toast(data.msg)
      }
    }).catch(err => {
      if (err && err.msg) {
        Toast(err.msg);
      } else {
        console.log(err)
        Toast('出错了，请稍后重试')
      }
    });
  }*/

  // 获取网点信息
  function getNetworkOrganization (_this) {
    //获取列出代理人,以及初始化所有值
    Axios.post(API.getWebServiceUrls('getNetworkOrganization')).then(res => {
      let data = res.data.data;
      if (res.data.code === 0) {
        let list = data.organizationList && data.organizationList.childList ? data.organizationList.childList : [];
        let networkList = [];
        for (let i = 0; i < list.length; i++) {
          networkList.push({
            name: list[i] && list[i].name ? list[i].name : '',
            value: list[i] && list[i].code ? list[i].code : '',
            parent: 0
          })
        }
        _this.$set(_this.PopupPickerOption, 'networkList', networkList);
      } else {
        Toast(data.msg || '系统繁忙, 请稍后再试。')
      }
    }).catch(err => {
      if (err && err.msg) {
        Toast(err.msg || '系统繁忙, 请稍后再试。');
      } else {
        console.log(err)
        Toast('出错了，请稍后重试')
      }
    });
  }

  // 网点信息获取初始化信息
  function getInnerInsure (_this, dealerCode) {
    let reqData = {
      dealerCode: dealerCode
    };
    _this.PopupPickerOption.networkList.forEach(v => {
      if (v.value === dealerCode) _this.networkName = v.name
    });
    //
    //获取列出代理人,以及初始化所有值
    Axios.post(API.getWebServiceUrls('getInnerInsure'), reqData).then(res => {
      let data = res.data.data;
      if (res.data.code === 0) {
        //初始化值
        _this.$set(_this.PopupPickerOption, 'canalFrom', '');
        _this.$set(_this.PopupPickerOption, 'canalValue', []);
        _this.$set(_this.PopupPickerOption, 'canalList', []);
        _this.$set(_this.PopupPickerOption, 'agentValue', []);
        _this.$set(_this.PopupPickerOption, 'agentList', []);
        //渠道来源细分
        let channelbusinessDetailNameList = [];
        let list = data.chooseChannelSourceVO || [];
        for (let i = 0; i < list.length; i++) {
          channelbusinessDetailNameList.push({
            name: list[i] && list[i].channelbusinessDetailName ? list[i].channelbusinessDetailName : '',
            value: list[i] && list[i].channelbusinessDetailName ? list[i].channelbusinessDetailName : '',
            parent: 0
          })
        }
        //渠道来源
        _this.$set(_this.PopupPickerOption, 'canalFrom', data.channelSourceName ? data.channelSourceName : '');
        //将渠道来源细分的数据设置到list中
        _this.$set(_this.PopupPickerOption, 'canalList', channelbusinessDetailNameList);
        //将所有数据存入到getInnerInsureData中
        _this.$set(_this.PopupPickerOption, 'getInnerInsureData', data);
        //设置dealerName
        _this.$set(_this.PopupPickerOption, 'dealerName', data.dealerName);
      } else {
        Toast(res.data.msg || '系统繁忙, 请稍后再试。')
      }
    }).catch(err => {
      if (err && err.msg) {
        Toast(err.msg || '系统繁忙, 请稍后再试。');
      } else {
        console.log(err)
        Toast('出错了，请稍后重试')
      }
    });
  }
</script>

<style lang="less">
  .box {
    .t_header {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: .88rem;
      background: #FFffff;
      box-sizing: border-box;
      color: #eee;
      display: flex;
      .t_header_arrow {
        /*flex: 1;*/
        width: .8rem;
        height: .8rem;
        background: url(../../common/images/nav_arrow.png) no-repeat center 60%;
        background-size: 10px 18px;
      }
      .t_header_title {
        flex: 6;
        font-size: .34rem;
        color: #333;
        /*margin-top: .18rem;*/
        line-height: .88rem;
        text-align: center;
      }
      .t_header_null {
        flex: 1;
      }
    }
    .t_header:before {
      content: " ";
      position: absolute;
      left: 0;
      bottom: 0;
      right: 0;
      height: 1px;
      border-bottom: 1px solid #eee;
      color: #eee;
      -webkit-transform-origin: 0 100%;
      transform-origin: 0 100%;
      transform: scaleY(0.5);
    }

    .iconPosition {
      width: .077rem;
      height: .136rem;
      position: absolute;
      right: .3rem;
      top: 50%;
      transform: translateY(-50%);
      & > div,
      img {
        width: 100%;
        height: 100%;
        position: absolute;
        left: 0;
      }
      .prefixValueAction {
        transform: rotate(270deg);
      }
      .prefixValueUnAction {
        transform: rotate(90deg);
      }
    }
    .maskBox {
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      z-index: 2;
      background: transparent;
    }
    .onlyTextTd {
      text-align: right;
      padding-right: 0.5rem;
      font-size: 0.28rem;
      color: #333;
    }
    .titleMessage {
      color: #000;
      position: relative;
      .bg {
        position: absolute;
        width: 0.08rem;
        height: 0.2rem;
        background: @themeC;
        left: -0.2rem;
        top: 50%;
        transform: translateY(-50%);
      }
      .gap {
        position: absolute;
        width: 7.5rem;
        height: 0.2rem;
        top: -0.2rem;
        left: -0.2rem;
        background: rgba(236, 236, 236, 1);
      }
    }
    .vux-cell-box:before {
      border: 0 !important;
      height: 0 !important;
    }
    .weui-cell {
      font-size: .28rem;
      padding: 0 0.5rem 0 0 !important;
      .vux-popup-picker-select {
        max-width: 4rem;
        overflow-x: scroll;
        .vux-cell-value {
          color: #333;
          display: block;
          word-break: keep-all;
          white-space: nowrap;
        }
      }
      .weui-cell_access .weui-cell__ft:after {
        border-color: #ccc;
      }
      .weui-cell__ft {
        display: none;
      }
    }
    .prefix {
      .weui-cell {
        padding: 0 !important;
      }
    }
    .vux-cell-box:before {
      border: 0;
    }
  }

  .closeBtn {
    background: #ccc;
  }

  /* 2018-06-13 网点名称过长时轮播显示 */
  .network-name-wrap {
    display: inline-block;
    width: 89%;
    overflow: hidden;
    vertical-align: top;
    .scroll-wrap {
      text-align: right;
      white-space: nowrap;
      -ms-text-overflow: unset;
      text-overflow: unset;
      font-size: 0.28rem;
    }
  }
</style>
