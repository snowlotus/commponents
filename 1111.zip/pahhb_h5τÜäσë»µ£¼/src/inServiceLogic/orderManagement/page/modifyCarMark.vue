<template>
  <div class="carMark_wrap">
    <pts-header titleText="修改车牌" leftFlag @on-left="goBack" :showRight="showRight">
      <div slot="right" class="fr carMark_submit" href="javaScript:;"
           @click.stop.prevent="submit">提交
      </div>
    </pts-header>
    <div class="carMark_box">
      <ul>
        <li>
          <div>旧车牌</div>
          <div class="old_carMark">{{oldCarMark}}</div>
        </li>
        <li>
          <div>新车牌</div>
          <div class="new_carMark" @click.stop="value=!value;upArrow=true;">
            <span>{{newCarMark.substring(0,2)}}</span>
            <span class="arrow" :class="{upArrow:upArrow && value}"></span>
          </div>
          <div class="carMark_input">
            <input type="text" placeholder="请输入车牌号" maxlength="6" minlength="5" id="inputBox" ref="inputBox" v-model="licenseNo">
          </div>
        </li>
      </ul>
    </div>

    <key-board v-model="value" :inputElemId="inputElemId" :checkedValue="oldCarMark"
               @on-input="changeCarMark"></key-board>
  </div>
</template>

<script>
  import ptsHeader from '../../../common/comComponent/header'
  import Axios from '../../../common/js/axiosConfig'
  import API from '../../../common/js/comConfig'
  import toast from '../../../common/comComponent/toast'
  import keyBoard from '../../../common/comComponent/keyBoard'

  export default {
    name: "inModifyCarMark",
    components: {
      ptsHeader,
      keyBoard
    },
    data() {
      return {
        showRight: true,
        upArrow: false, //向上箭头
        oldCarMark: '', //旧车牌号
        newCarMark: '', //新车牌区域号(eg:粤B)
        licenseNo: '', //新输入的车牌后五位
        value: false, //键盘的关闭与隐藏,默认隐藏
        inputElemId: '',
      }
    },
    created() {
      let query = this.$route.query;
      this.oldCarMark = query.carMark;
      this.newCarMark = query.carMark;
    },
    mounted() {
      this.inputElemId = this.$refs.inputBox.id;
    },
    methods: {
      //返回上一页
      goBack() {
        if (window.history.length >= 1) {
          window.history.go(-1)
        }
      },
      //修改车牌的区域号,由子组件触发
      changeCarMark(val) {
        this.newCarMark = val;
      },

      //提交新车牌
      submit() {
        let area = this.newCarMark.substring(0, 2);
        if (!this.validateCarMark(this.licenseNo)) return
        let licenseNo = this.licenseNo.toUpperCase();

        if (area+'-'+licenseNo == this.oldCarMark) {
          toast('新车牌号与旧车牌号一致,无需批改')
          return
        };

        let query = this.$route.query;
        let obj = {
          "flowId": query.flowId,
          "policyNo": query.policyNo,
          "vehicleLicenceCode": area + '-' +licenseNo
        };
        Axios.post(API.getWebServiceUrls('innerChangeCarMark'), obj)
          .then(res => {
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            if (data.code == 0) {
              this.$router.replace({
                path: '/inside/orderList'
              })
            } else {
              toast(data.msg || '系统繁忙,请稍后重试')
            }
          })
          .catch(err => {
            console.log(err)
          })
      },

      //车牌校验
      validateCarMark(val) {
        let v = val.toUpperCase();
        if (v.length == 0) {
          toast('车牌号不能为空')
          return
        };
        if (v.indexOf(' ') > -1) {
          toast('车牌号不能存在空格')
          return
        };
        if (v.indexOf('I') > -1 || v.indexOf('O') > -1) {
          toast('车牌号输入错误')
          return
        };
        if (!/^[A-Za-z0-9]+$/.test(v) || v.length < 5) {
          toast('车牌号格式错误')
          return
        };
        return true;
      }
    },
  }
</script>

<style scoped lang="less">
  .carMark_submit {
    position: absolute;
    font-size: .28rem;
    line-height: .88rem;
    right: .3rem;
    color: #FF8208;
  }

  .carMark_box {
    background: #FFffff;
    & ul > li:first-child {
      border-bottom: 1px solid #eee;
    }
    & ul > li {
      height: .9rem;
      font-size: .28rem;
      line-height: .9rem;
      margin-left: .3rem;
      position: relative;
      div {
        display: inline-block;
        position: absolute;
      }
    }
    .old_carMark {
      color: #666666;
      right: .3rem;
    }
    .new_carMark {
      left: 3.9rem;
      .arrow {
        width: .14rem;
        height: .08rem;
        margin-bottom: .08rem;
        display: inline-block;
        margin-left: .03rem;
        background: url("../../../common/images/icon_arrow_down.png") no-repeat;
        background-size: 100%;
      }
      .upArrow{
        background: url("../../../common/images/icon_arrow_c343_up.png") no-repeat;
        background-size: 100%;
      }
    }
    .carMark_input {
      right: .3rem;
      input {
        width: 1.68rem;
        text-transform: uppercase;
      }
    }

  }
</style>
