<template>
  <div class="insurance_wrap">
    <pts-header leftFlag titleText="险种明细" @on-left="goBack"></pts-header>
    <div class="insurance_box">
      <div class="insurance_title">
        <div>险种</div>
        <div>保费金额(万元)</div>
        <div>保费(元)</div>
      </div>
      <div class="insurance_content">
        <ul class="main">
          <li v-for="(item,index) in main" :key="index">
              <div>{{item.dutyName}}</div>
              <div><em>¥</em>{{item.totalInsuredAmount}}</div>
              <div><em>¥</em>{{item.totalActualPremium}}</div>
          </li>
        </ul>
        <ul class="ignore" v-if="ignore.length">
          <li v-for="(item,index) in ignore" :key="index">
            <div>{{item.dutyName}}</div>
            <div></div>
            <div><em>¥</em>{{item.totalActualPremium}}</div>
          </li>
        </ul>
      </div>
    </div>
    <div class="insurance_total">
      <div class="fr" style="margin-right: .3rem">
        <span>商业险总金额: </span>
        <span>¥</span>
        <span>{{totalPremium | third}}</span>
      </div>
    </div>
  </div>
</template>

<script>
  import ptsHeader from '../../../common/comComponent/header'
  import Axios from '../../../common/js/axiosConfig'
  import API from '../../../common/js/comConfig'
  import toast from '../../../common/comComponent/toast'

  export default {
    name: "innerInsuranceDetail",
    components: {
      ptsHeader
    },
    data(){
      return {
        totalPremium:'', //总保费金额
        main:[], //主险
        ignore:[], //附加险(不计免赔)
      }
    },
    created(){
      let query = this.$route.query;
      let obj = {
        "applyPolicyNo":'',
        "policyNo":'',
      };
      //如果投保单号和保单号都有,说明有保单,就取保单号;如果只有投保单就取投保单号
      if (query.bApplyPolicyNo && query.bPolicyNo) {
        obj.policyNo = query.bPolicyNo;
      } else {
        obj.applyPolicyNo = query.bApplyPolicyNo;
      }
      this.getData(obj);
    },
    methods: {
      //返回上一页
      goBack() {
        if (window.history.length >= 1) {
          window.history.go(-1)
        }
      },

      getData(params){
        Axios.post(API.getWebServiceUrls('innerInsuranceDetail'),params).then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (data.code == 0) {
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            this.insuranceSort(data.data)
          } else {
            toast(data.msg || '系统繁忙,请稍后重试')
          }
        }).catch(err => {
          console.log(err)
        })
      },

      //将主险和不计免赔附加险分类
      insuranceSort(ajaxData){
        let a = 0;
        ajaxData.forEach(v => {
          a += Number(v.totalActualPremium);
          if (v.dutyName.indexOf('不计免赔') > -1) {
            this.ignore.push(v)
          } else {
            this.main.push(v)
          }
        })
        this.totalPremium = a.toFixed(2);
      }
    },
    filters:{
      //给金额每三位添加一位逗号
      third(val){
        let newStr = '';
        let c = '';
        let count = 0;

        if (val.indexOf('.') > -1) {
          let index = val.indexOf('.');
          c = val.substring(index);
          val = val.substring(0,index);
        }
        for (let i = val.length-1; i >= 0; i--) {
          if ( count % 3 == 0 && count != 0) {
            newStr = val.charAt(i) + "," + newStr;
          } else {
            newStr = val.charAt(i) + newStr;
          }
          count++;
        }
        return newStr + c
      }
    }
  };
</script>

<style scoped lang="less">
  .insurance_box {
    .insurance_title {
      background: #FAFAFA;
      box-sizing: border-box;
      height: .9rem;
      line-height: .9rem;
      position: relative;
      font-size: .24rem;
      color: #999999;
      & > div {
        position: absolute;
      }
      & > div:nth-child(1) {
        left: .3rem;
      }
      & > div:nth-child(2) {
        right: 1.89rem;
      }
      & > div:nth-child(3) {
        right: .3rem;
      }
    }

    .insurance_content {
      overflow-y: scroll;
      height: 10.7rem;
      .main,.ignore {
        background: #FFffff;
        font-size: .28rem;
        & > li {
          margin-left: .3rem;
          padding: .24rem 0;
          border-bottom: 1px solid #eee;
          position: relative;
          & > div em {
            font-size: .22rem;
          }
          & > div {
            display: inline-block;
            color: #FE883A;
          }
          & > div:nth-child(1) {
            color: #333333;
            width: 3.6rem;
          }
          & > div:nth-child(2) {
            position: absolute;
            right: 1.9rem;
            width: 1.6rem;
            text-align: center;
          }
          & > div:nth-child(3) {
            position: absolute;
            right: .3rem;
          }
        }
      }
      .ignore{
        margin-top: .2rem;
      }
    }
  }
  .insurance_total{
    width: 100%;
    height: .9rem;
    background: #FFffff;
    position: fixed;
    left: 0;
    bottom: 0;
    line-height: .9rem;
    @color:#FF8208;
    & div>span:nth-child(1){
      font-size: .28rem;
    }
    & div>span:nth-child(2){
      font-size: .26rem;
      color: @color;
    }
    & div>span:nth-child(3){
      font-size: .36rem;
      color: @color;
    }
  }
</style>
