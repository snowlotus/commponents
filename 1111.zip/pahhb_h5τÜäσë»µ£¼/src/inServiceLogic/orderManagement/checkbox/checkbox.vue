<template>
  <div class="checkbox-wrap">
    <transition name="actionsheet-mask">
      <div class="icx_layerMask" v-if="showCheckbox"></div>
    </transition>
    <transition name="bounce">
      <div class="choice_plan" v-if="showCheckbox">
        <p class="choice_plan_title">选择险种</p>
        <p class="insurance_cont c" @click.stop.prevent="force = !force" v-if="forcePremium !== -1"><span
          class="insurance_txt marLeft30 fl"
        >交强险 ¥<span>{{ forcePremium | NumberThere}}</span></span><i
          class="marRight30 fr" :class="{'selecte_box_checked': force, 'selecte_box_check': !force}"></i></p>
        <p class="insurance_cont marTop23 c" v-if="bizPremium !== -1" @click.stop.prevent="biz = !biz"><span
          class="insurance_txt marLeft30 fl">商业险 ¥<span>{{bizPremium | NumberThere}}</span></span><i
          class="marRight30 fr" :class="{'selecte_box_checked': biz, 'selecte_box_check': !biz}"></i></p>
        <p class="determine_btn" @click.stop.prevent="showContents">确定</p>
      </div>
    </transition>
  </div>
</template>

<script>
  import '../../../common/filters/convertAmount.js'
  import toast from 'pts/toast'
  export default {
    name: "checkbox",
    props: {
      showContent: Boolean,
      datas: {
        type: Object
      }
    },
    data () {
      return {
        showCheckbox: false,
        biz: false,
        force: false,
        forcePremium: -1,
        bizPremium: -1
      }
    },
    mounted () {
      let data = this.datas;
      this.forcePremium = data.F && data.F.premium > 0 ? data.F.premium : -1;
      this.bizPremium = data.B && data.B.premium > 0 ? data.B.premium : -1;
      this.biz = data.B && data.B.checked;
      this.force = data.F && data.F.checked
    },
    methods: {
      showContents () {
        if (!this.force && !this.biz) {
          toast('请至少选择一个险种');
          return
        }
        let data = this.datas;
        this.showCheckbox = !this.showCheckbox;
        data.B ? data.B.checked = this.biz : '';
        data.F ? data.F.checked = this.force : '';
        setTimeout(function () {
          this.$emit('on-updata', this.showCheckbox)
        }.bind(this), 500)
      }
    },
    watch: {
      'showContent': {
        handler: function (val) {
          setTimeout(function () {
            this.showCheckbox = val
          }.bind(this), 0) // 时间差 出现动画效果
        },
        immediate: true
      }
    }
  }
</script>

<style>

  .bounce-enter-active {
    animation: fadeInUp .5s;
  }

  .bounce-leave-active {
    animation: fadeOutDown .5s;
  }

  @-webkit-keyframes fadeInUp {
    from {
      opacity: 0;
      -webkit-transform: translate3d(0, 100%, 0);
      transform: translate3d(0, 100%, 0);
    }

    to {
      opacity: 1;
      -webkit-transform: none;
      transform: none;
    }
  }

  @keyframes fadeInUp {
    from {
      opacity: 0;
      -webkit-transform: translate3d(0, 100%, 0);
      transform: translate3d(0, 100%, 0);
    }

    to {
      opacity: 1;
      -webkit-transform: none;
      transform: none;
    }
  }

  @-webkit-keyframes fadeOutDown {
    from {
      opacity: 1;
    }

    to {
      opacity: 0;
      -webkit-transform: translate3d(0, 100%, 0);
      transform: translate3d(0, 100%, 0);
    }
  }

  @keyframes fadeOutDown {
    from {
      opacity: 1;
    }

    to {
      opacity: 0;
      -webkit-transform: translate3d(0, 100%, 0);
      transform: translate3d(0, 100%, 0);
    }
  }

  .actionsheet-mask-leave-active {
    opacity: 0;
  }

  .actionsheet-mask-enter-active {
    transition: opacity 500ms !important;
  }
</style>
