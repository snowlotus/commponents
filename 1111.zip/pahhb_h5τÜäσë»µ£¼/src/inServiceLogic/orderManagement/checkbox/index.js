/**
 * Created by LIKANGDE925 on 2017/10/13.
 */
import checkbox from './checkbox.vue'
export default checkbox
