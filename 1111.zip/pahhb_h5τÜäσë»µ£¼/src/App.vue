<template>
  <div id="app">
    <!-- QA keep alive 的用法 -->
    <keep-alive exclude="login,chooseCar,repairTaskInfo,taskList,repairShowImage,
    inContinueInfo,outContinueInfo,claimInfo,cell-page,selectOrganization,inRepairTaskInfo,inTaskList,
    inRepairShowImage,vaPlanDetail,vaTargetList,smTargetManageAddplan,smTargetManagePlanDetail,
    smTargetManageList,inElectronPayment,inPrintCode,electronPayment,printCode,innerInsuranceDetail,insuranceDetail">

      <router-view></router-view>
    </keep-alive>
  </div>
</template>

<script>

  export default {
    name: "App",
    data () {
      return {}
    }
  }
</script>

<style lang="less">
  @import url('./common/css/newCarOutOfTheSingleOne.css');
  @import './common/css/1px.less';
  /*1px border 开始*/
  /* 下border */
  .pts-b-b {
    .pts-1px-b(#eee);
  }

  /* 上border */
  .pts-b-t {
    .pts-1px-t(#eee);
  }

  /* 左border */
  .pts-b-l {
    .pts-1px-l(#eee);
  }

  /* 右border */
  .pts-b-r {
    .pts-1px-r(#eee);
  }

  /* 全部border */
  .pts-b {
    .pts-1px(#eee);
  }

  /*1px border 结束*/
  #app {
    overflow-x: hidden;
    position: relative;
  }

  .bgurl(@url: '') {
    background-image: url('./common/images/@{url}-2x.png');
    @media (-webkit-min-device-pixel-ratio: 3),(min-device-pixel-ratio: 3) {
      background-image: url('./common/images/@{url}-3x.png');
    }
  }

  .box {
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    padding-top: 0.88rem;
    overflow: auto;
    position: relative;
    & > .newCar_top {
      position: fixed !important;
      top: 0;
      left: 0;
      /*z-index: 9999;*/
    }
  }

  .wx_box {
    padding-top: 0rem;
  }

  .show {
    width: 100%;
    height: 50%;
    overflow: scroll;
  }

  /*阻止原生长按选择*/
  .stopSelect {
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    user-select: none;
  }

  /* 列表页数据为空时显示的样式 */
  .dataNullWrap {
    padding-top: 2.32rem;
    .imgWrap {
      width: 1.2rem;
      height: 1.44rem;
      .bgurl('nodata');
      background-repeat: no-repeat;
      background-position: center center;
      background-size: 100% 100%;
      margin: 0 auto;
    }
    .imgYear {
      width: 1.2rem;
      height: 1.44rem;
      .bgurl('imgYear');
      background-repeat: no-repeat;
      background-position: center center;
      background-size: 100% 100%;
      margin: 0 auto;
    }
    .dataNullText {
      margin-top: 0.2rem;
      font-size: 0.28rem;
      color: #999999;
      text-align: center;
    }
  }

  .data-null {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 10;
    background: url("./common/images/data-null.png") no-repeat center center;
  }

  .hidden {
    width: 1.2rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    text-align: right;
  }

  /*  .titleAllCar {
      display: block;
      position: absolute;
      top: .14rem;
      left: 5.0rem;
      width: .6rem;
      height: .6rem;
      line-height: .6rem;
      font-size: .2rem;
      color: #454545;
      text-align: center;
      border-radius: 50%;
      background: #e9e9e9;
    }*/

  /* 列表数据加载完成时 文字的样式 */
  .list-data-over {
    padding: 0.5rem 0;
    text-align: center;
    color: #999999;
  }

  /*报表 日月年 头部固定*/
  .bt_top {
    position: fixed;
    width: 100%;
    z-index: 2;
    background-color: #ffffff;
  }

  /* 头部跑马灯文字样式 开始*/

  .textBanner {
    width: 6rem;
    float: left;
    height: 100%;
    line-height: 0.9rem;
  }

  /* 头部跑马灯文字样式 结束*/
  /* 报表头部下方的选中border-bottom 开始 */
  .date-tab {
    border: none;
    .cur {
      height: .78rem !important;
      .pts-1px-b(@theme-color);
      color: @theme-color;
    }
    .on {
      border: none !important;
      .pts-1px-b(@theme-color);
      color: @theme-color;
    }
  }

  .nav-search-icon {
    display: block;
    width: 0.58rem;
    height: 0.8rem;
    float: left;
    background: url("./common/images/icon-search.png") no-repeat center 70%;
    background-size: 0.47rem 0.43rem;
  }

  .nav-go-choose-model {
    position: absolute;
    top: 0;
    right: 0;
    display: block;
    width: 1.5rem;
    height: 0.8rem;
    line-height: 0.8rem;
    text-align: right;
    padding-right: 0.3rem;
    & > span {
      display: inline-block;
    }
    .nav-text {
      max-width: 1.2rem;
      font-size: 0.24rem;
      color: #444;
      text-align: left;
      vertical-align: top;
    }
    .arrow {
      width: 0.13rem;
      height: 100%;
      background: url("./common/images/arrowLeft.png") no-repeat right center;
      background-size: 0.13rem 0.24rem;
    }

  }

</style>
