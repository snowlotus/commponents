/**
 * Created by LIKANGDE925 on 2017/12/22.
 */
import axios from './axiosConfig';
import {getCookie, setCookie} from './comUtils'
const head = {  //供本地测试
  // 'X-Requested-With': 'XMLHttpRequest',
  "deviceid": "1111-2222-3333-4444",
  "apptype": "1",
  "devicetype": "2",
  "appversion": "1.0.1"
};
let innerAccountRoleType = '';
let dealerCode = '',dealerName='',dealerType='',frontLineRoleType='';
if (!window.urlHeader || window.urlHeader&&!window.urlHeader.deviceid) {
  window.urlHeader = head;
}
/*
 * 可用的账号:
 * 'pahhb-' +  '00001' ~ '00008' || '00010'  || '00011'
 * 'fjcs-' + '00010' || '00011'
 * checc-00006
 * 数据多的账号
 * pahhb-00008 || fjcs-00010 || fjcs-00011
 *13533333333 13511113333  13522222222 外部端
 *
 * 13855559966  18566249628 内部端 总部 18566249624
 * 13633339966 17724702122 内部端 后线 18566249624
 * 13577889966 13689852111  13900001111 内部端 前线
 * 13689852111
 * 13599999999
 *
 * */

//内部端账号
const user = {
  "username": "18566249628",
  "password": "aaaaa888"
}

// let URL = 'https://30.5.103.83/iCorePts-mobile';
 let URL = 'https://test-icore-pts-mobile.pingan.com.cn/iCorePts-mobile';
// 使用用户名获取token
function updataToken () {
  axios.post(URL + '/api/usermgr/applogin.do', user).then((res) => {
    if (res.data.code === 0) {
      console.log('userinfo',res.data.data.userInfoVO);
      innerAccountRoleType = res.data.data.userInfoVO.innerAccountRoleType;
      dealerCode = res.data.data.userInfoVO.dealerCode;
      dealerName = res.data.data.userInfoVO.dealerName;
      dealerType = res.data.data.userInfoVO.dealerType;
      frontLineRoleType = res.data.data.userInfoVO.frontLineRoleType;
      console.log('获得到token成功');
      console.log(res.data)
      head.token = res.headers.token;
      window.urlHeader = head;
      verifyTokenOnce();
    } else {
      console.log('获得到token失败, 原因: ');
      console.log(res.data);
    }
  }).catch((err) => {
    console.log('获得到token失败, 原因: ');
    console.log(err);
  })
}

// 验证token
function verifyTokenOnce () {
  axios.post(URL + '/api/usermgr/firstSetGestures.do', user).then((res) => {
    if (res.data.code === 0) {
      console.log('校验第一次token成功');
      verifyTokenSecond();
    } else {
      console.log('校验第一次token失败, 原因: ');
      console.log(res.data);
    }
  }).catch((err) => {
    console.log('校验第一次token失败, 原因:');
    console.log(err);
  })
}

// 第二次验证token
function verifyTokenSecond () {
  axios.post(URL + '/api/usermgr/getAccountInfo', user).then((res) => {
    if (res.data.code === 0) {
      console.log('校验第二次token成功');
      console.log('token更新成功, 请刷新页面');
      head.deptName = res.data.data.userInfoVO.deptName;
      head.innerAccountRoleType = innerAccountRoleType; // 添加内部端用户账号类型
      head.dealerCode = dealerCode;
      head.dealerName = dealerName;
      head.dealerType = dealerType;
      head.frontLineRoleType = frontLineRoleType;
      setCookie('header', JSON.stringify(head));
      console.log('设置的cookie为 / ' + JSON.stringify(head));
      console.log('更新token成功, 自动刷新页面');
      window.location.reload();
    } else {
      console.log('校验第二次token失败, 原因: ');
      console.log(res.data);
    }
  }).catch((err) => {
    console.log('校验第二次token失败, 原因:');
    console.log(err);
  })
}

if (!getCookie('header')) {
  updataToken();
}
Object.defineProperty(window, 'ut', {
  get: function () {
    updataToken();
    return '开始执行更新Token程序...'
  }
});
export default updataToken;
