'use strict'
/**
 * [config 公用请求地址配置]
 */
const DEV_EVN = 0 //判断是否本地环境 或是开发环境、测试环境（0,1,2）
const configUrl = {
  getWebServiceUrls: function(name) {
    let _hostname = window.location.hostname, //地址
      _protocol = window.location.protocol, //协议
      _origin = window.location.origin, //域名
      host = ''
    if (_hostname.indexOf('localhost') > -1) {
      // /^[127,'localhost']/.test(_hostname)
       //host = _protocol+'//PQSZ-D00698:9000/iCorePts-mobile' //李凯吊毛
      // host = 'https://30.5.103.83/iCorePts-mobile' //内网联调测试
      host = 'https://test-icore-pts-mobile.pingan.com.cn/iCorePts-mobile' //外网调试测试
      //host = _protocol + "//localhost:8888/iCorePts-mobile"
    } else {
      //host=_protocol+"//PQSZ-L01302:9000";
      host = _origin + '/iCorePts-mobile'
    }
    /*if(/^[10,127,'localhost']/.test(_hostname)){
     host = _protocol+"//localhost:9000/iCorePts-mobile"; //联调测试
     }else{
     host = _origin+ '/iCorePts-mobile';
     }*/
    return host + this.doaminLists[name]
  },
  /**
   * [doaminLists 所有接口参数映射]
   * @type {Object}
   */
  //QA 调用接口时为何是API.getWebServiceUrls('orderList') 而不是API.getWebServiceUrls(doaminLists.orderList)
  doaminLists: {
    pageData: '/index', // 开发测试
    orderList: '/api/acceptinsurance/orderList.do', // 查询订单列表
    toPayOrderList: '/api/acceptinsurance/toPayOrderList.do', // 去支付
    updateOrderList: '/api/acceptinsurance/updateOrderList.do', // 修改订单
    deleteOrderList: '/api/acceptinsurance/deleteOrderList.do', // 删除订单
    contactCustomerList: '/api/pushRepair/contactCustomerList', // 查询推修任务列表
    contactCustomerDetail: '/api/pushRepair/contactCustomerDetail', // 查询推修任务详情
    applysecurityphonenumber: '/api/onekeycall/applysecurityphonenumber', // 推修任务获取呼叫号码
    contactresult: '/api/onekeycall/contactresult', // 推修任务打电话后的结果记录
    contactAnalysis: '/api/recommendedRepair/contactAnalysis.do', // 联系分析数据
    flowDirectionAnalysis: '/api/recommendedRepair/flowDirectionAnalysis.do', //流向分析
    repairAnalysis: '/api/recommendedRepair/repairAnalysis.do', // 推修分析
    renewalList: '/api/renewalInquiry/renewalList', // 续保列表
    renewaInfo: '/api/renewalInquiry/renewalListDetail', // 续保详情
    oneKeyRenewal: '/api/renewalInquiry/oneKeyRenewal', // 一键续保
    getOutSideAgent: '/api/renewalInquiry/getSaleAgentInfoByUmCode', // 续保获取代理人
    renewalReport: '/api/renewalInquiry/renewalReport', // 续保报表
    rennewalConReport: '/api/renewalInquiry/renewalReport/contactAnalysis', // 续保报表联系分析
    submitResult: '/api/renewalInquiry/submitResult', // 续保打电话后记录电话结果
    touchHistory: '/api/renewalInquiry/touchHistory', // 续保接触历史
    persona: '/api/renewalInquiry/getPersona', // 续保用户画像
    getCall: '/api/renewalInquiry/call', // 续保获取要拨打的电话号
    setCall: '/api/renewalInquiry/confirmCall', // 续保设置电话号
    getCallNumber: '/api/renewalInquiry/getCallNumber', // 续保获取拨打号码
    setCallMsg: '/api/renewalInquiry/submitResult', // 续保电话号记录电话结果
    settlementDetail: '/api/claimscase/settlementDetail.do', //理赔查询详情
    settlementList: '/api/claimscase/settlementList.do', //理赔查询列表
    billList: '/api/coreDate/billList', //榜单排行榜
    queryOrganized: '/api/coreDate/queryOrganized', //机构列表查询
    queryPreamData: '/api/coreDate/queryPreamData', //获取核心数据报表数据
    queryOuterTimelyCoreData: '/api/coreDate/queryOuterTimelyCoreData', //获取外部端业绩查询实时
    queryOuterPreamData: '/api/coreDate/queryOuterPreamData', //获取外部端业绩查询 日 月 年
    queryOuterCoreDataWorking: '/api/coreDate/queryOuterCoreDataWorking', //获取外部端业绩查询 月 工作日和非工作日

    /* 外部端保单管理 start */
    shareBdLink:'/api/acceptinsurance/queryElectricPolicyInfo.do', //外部端电子保单分享
    shareTbLink:'/api/acceptinsurance/queryElectricInsuranceApplicationInfo.do', //外部端电子投保单分享
    checkCar:'/api/acceptinsurance/checkAcessor.do', //外部端验车接口
    printCode:'/api/acceptinsurance/getPrintCode', //外部端打印码和分享
    areaSwitch:'/api/acceptinsurance/queryPrintCodeAreaSwitch.do', //外部端查询地区开关
    insuranceDetail:'/api/acceptinsurance/queryApplyPolicyPlanInfo.do', //外部端商业险种明细
    /* 外部端保单管理 end */

    //新车出单,立即投保
    getDestination: '/api/area/getDestination.do', //地区（省、市、区）操作相关API
    createindex: '/api/acceptinsurance/createindex.do', //外部端投保首页（新车出单）
    insurancing: '/api/acceptinsurance/insurancing.do', //外部端下单（立即投保）
    getNetworkOrganization: '/api/personalcenter/getOrganizationInfo', //内部端买车险调取网点(初始化网点信息)
    getInnerInsure: '/api/inner/acceptinsurance/getSaleAgentInfoByDealerCode', //内部端投保首页(根据网点信息取得初始化值)
    innerInsurancing: '/api/inner/acceptinsurance/insurancing', //内部端下单（立即投保）

    /*==========================对内部端接口=========================*/
    // 用户网点数据查询
    getUserOrganization: '/api/personalcenter/getOrganizationInfo', // 查询角色下的网点数据
    // 理赔
    getOrganizationInfo: '/api/personalcenter/getOrganizationInfo', //获取机构列表
    submitCarType: '/api/fastquotation/savecarband', //外部端提交新增车型数据
    inSubmitCarType: '/api/innerFastquotation/innerSavecarband', //内部端提交新增车型数据
    getcarbrandindexmap: '/api/fastquotation/getcarbrandindexmap', // 获取所有品牌列表【带字母检索】
    innerSettlementDetail: '/api/claimscase/innerSettlementDetail.do', //理赔查询详情
    // 内部快速报价
    formPageToNative: '/api/fastquotation/fastquotation', //外部端供native使用form表单提交接口
    inFormPageToNative: '/api/innerFastquotation/innerFastquotation', //内部端供native使用form表单提交接口
    //内部推修模块
    pushRepairList: '/api/inner/pushRepair/pushRepairList', //推修任务列表
    pushRepairDetail: '/api/inner/pushRepair/pushRepairDetail', //推修任务详情
    pushRepairCaseImage: '/api/usermgr/getHeadImage', //获取推修案件图片(内外部端共用此接口)
    pushRepairContactAnalyse: '/api/inner/pushRepair/contactAnalysis', //联系分析
    pushRepairOutputValAnalyse: '/api/inner/pushRepair/outputValueAnalysis', //产值分析
    // 内部续保
    getContinList: '/api/inner/renewalquiry/renewalList', // 续保列表数据
    getInsideInfo: '/api/inner/renewalquiry/renewalListDetail', //续保获取详情
    getPersona: '/api/inner/renewalquiry/getPersona', // 续保获取用户画像
    getPhoneNum: '/api/renewal/renewalListToCall.do', // 续保获取电话号列表
    setRemarkMsg: '/api/inner/renewalquiry/inner/submitResult', // 续保设置电话备注信息
    getInsideHistory: '/api/inner/renewalquiry/inner/touchHistory', // 续保获取用户接触历史
    setInsideHistory: '/api/inner/renewalquiry/inner/submitResult', // 续保添加用户接触历史
    getAgentList: '/api/inner/renewalquiry/getSaleAgentInfoByDealerCode', // 续保获取代理人列表
    getDealerInfoList: '/api/renewal/getDealerInfoList.do', // 获取业务员或渠道管理员下网点的名称与续保模式
    getApproveList: '/api/renewal/approveRenewalModeList.do', // 获取待审批续保模式的列表
    approveRenewalMode: '/api/renewal/approveRenewalMode.do', // 渠道管理员审核模式修改
    getInitiateCount: '/api/renewal/getInitiateCount.do', // 获取业务员剩余审批次数
    setRenewalModel: '/api/renewal/selectRenewalMode.do', // 续保模式选择(修改)
    setConvering: '/api/renewal/renewalProcessCoveringInfo.do', // 续保回补信息查询Api:（包含：放弃，回补，回补记录功能页面展示数据）
    getqueryConvering: '/api/renewal/renewalQueryCoveringInfo.do', //续保回补信息查询Api:（查询功能页面展示数据）
    getInsideCon: '/api/inner/renewalquiry/inner/renewalReport/contactAnalysis', // 续保报表获取联系分析数据
    getInsideContinue: '/api/inner/renewalquiry/inner/renewalReportList', // 续保报表回去续保分析数据
    pushRepairDataCollection: '/api/inner/pushRepair/pushRepairDataCollection', //推修模块产值保费查询
    // 内部端核心数据
    queryInnerTimelyCoreData: '/api/innerCoreDate/queryInnerTimelyCoreData', //内部端核心数据查询
    queryInnerCoreData: '/api/innerCoreDate/queryInnerCoreData', //内部端核心数据日月年数据查询
    queryInnerCoreDataWorking: '/api/innerCoreDate/queryInnerCoreDataWorking', //内部端核心数据工作日和非工作日
    /* 内部保单管理 start */
    innerDeleteOrder: '/api/acceptinsurance/innerDeleteOrderList.do', // 删除订单
    innerPullOrder: '/api/acceptinsurance/innerOrderList.do', // 查询订单列表
    innerGoPay: '/api/acceptinsurance/innerToPayOrderList.do', // 订单去支付
    innerUpdateOrder: '/api/acceptinsurance/innerUpdateOrderList.do', // 订单修改
    innerwxPayOrder: '/api/acceptinsurance/innerwxPayOrderList.do', // 订单分享到微信支付
    innerShareBdLink:'/api/acceptinsurance/queryInnerElectricPolicyInfo.do', //内部端电子保单分享
    innerShareTbLink:'/api/acceptinsurance/queryElectricInsuranceApplicationInfo.do', //内部端电子投保单分享
    inspectCar:'/api/acceptinsurance/checkAcessor.do', //内部端验车接口
    checkCarStatus:'/api/acceptinsurance/checkAcessorStatus.do', //内外部端验车状态
    innerPrintCode:'/api/acceptinsurance/getInnerPrintCode', //内部端打印码和分享
    innerAreaSwitch:'/api/acceptinsurance/queryInnerPrintCodeAreaSwitch.do', //内部端查询地区开关
    innerChangeCarMark:'/api/acceptinsurance/innerSelfEdrApplyRiskVehicle.do', //内部端修改车牌
    innerInsuranceDetail:'/api/acceptinsurance/innerQueryApplyPolicyPlanInfo.do', //内部端查看险种明细
    /* 内部保单管理 end */

    // 内部端温度计
    selectDailyDetails:'/api/dailyPaper/selectDailyDetails',//温度计日报&年报详情接口
    monthlyDetail:'/api/inner/monthly/monthlyDetail',//温度计月报详情接口
    monthlyReminding:'/api/inner/monthly/monthlyReminding', // 月报提醒功能
    getDomensionsList: '/api/inner/report/queryDimensionsList', // 获取维度接口(指新车/旧车/次新车等);
    getMonthOrYearEachters: '/api/inner/report/queryReportData', // 获取日或月或年的图表数据;
    getYearReport: '/api/inner/report/queryYearReportDetail', // 获取年维度的网点详情;
    getDayOrMonthNetWork: '/api/inner/monthly/getMonthlyNetWorkStatus', // 获取日份/月份的网点确认状态的列表
    submitMonthReport: '/api/inner/monthly/monthlyDataSubmit', // 提交网点月份的数据
    getMonthReport: '/api/inner/monthly/monthlyEditInit', // 获取网点的月份或当日的出单数据, 用来让用户编辑;
    //H5登录接口
    getVerification: '/phonecheck/createcheck', //获取验证码的接口
    login: '/api/usermgr/weixinLogin.do', //验证码手机号去登录
    verifyTokenSecond: '/api/usermgr/getAccountInfo',//获取账户信息
    
    //小程序h5-登出接口
    logout:'/api/usermgr/logout.do',//用户登出

    //H5极速报价接口
    hasteOfferGetOrganizationInfo:'/api/personalcenter/getOrganizationInfo',//获取网点列表
    hasteOfferGetCarList:'/api/fastquotation/getcarbrandandmodellist',//外部端获取车型
    hasteOfferDeleteCarList: '/api/fastquotation/deleteCarbrand',//外部端删除车型
    hasteofferGetUserOrganizationInsuranceInfo:'/api/fastquotation/getUserOrganizationInsuranceInfo',//外部端获取代理人，渠道来源细分
    hasteOfferFastquotation:'/api/fastquotation/fastquotation',//外部端为爱车报价

    //内部端业绩查询进度条
    queryTargetProgress:'/api/innerCoreDate/queryTargetProgress',


    //内部端目标管理接口
    addDealerPlan: '/api/inner/planTarget/addDealerPlan', //添加车商计划
    getLastYearPremium: '/api/inner/planTarget/getLastYearPremium', //获取网点的去年同期保费
    getDealerPlanList: '/api/inner/planTarget/getDealerPlanList', //查询车商计划列表
    getDealerPlanListDetial: '/api/inner/planTarget/getDealerPlanListDetial', //查询车商计划列表详情
    getWorkProgress: '/api/inner/planTarget/getWorkProgress', //查询工作进展
    getWorkProgressUnSubmitList: '/api/inner/planTarget/getWorkProgressUnSubmitList', //查询工作进展已提交/未提交列表
    updateDealerPlan: '/api/inner/planTarget/updateDealerPlan', //修改车商计划(重新提交)
    updateDealerPlanStatus: '/api/inner/planTarget/updateDealerPlanStatus', //修改车商计划状态

  }
}
export default configUrl
