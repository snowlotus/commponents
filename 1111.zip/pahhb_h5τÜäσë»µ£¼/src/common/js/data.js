let specialJson = {
  '天津市': [{
    name: '津A',
    value: '津A',
    parent: 0
  }, {
    name: '津B',
    value: '津B',
    parent: 0
  }, {
    name: '津C',
    value: '津C',
    parent: 0
  }, {
    name: '津D',
    value: '津D',
    parent: 0
  }, {
    name: '津E',
    value: '津E',
    parent: 0
  }, {
    name: '津F',
    value: '津F',
    parent: 0
  }, {
    name: '津G',
    value: '津G',
    parent: 0
  }, {
    name: '津O',
    value: '津O',
    parent: 0
  }],
  '北京市': [{
      name: '京A',
      value: '京A',
      parent: 0
    },
    {
      name: '京B',
      value: '京B',
      parent: 0
    },
    {
      name: '京C',
      value: '京C',
      parent: 0
    },
    {
      name: '京E',
      value: '京E',
      parent: 0
    },
    {
      name: '京F',
      value: '京F',
      parent: 0
    },
    {
      name: '京G',
      value: '京G',
      parent: 0
    },
    {
      name: '京H',
      value: '京H',
      parent: 0
    },
    {
      name: '京J',
      value: '京J',
      parent: 0
    },
    {
      name: '京K',
      value: '京K',
      parent: 0
    },
    {
      name: '京N',
      value: '京N',
      parent: 0
    },
    {
      name: '京P',
      value: '京P',
      parent: 0
    },
    {
      name: '京Q',
      value: '京Q',
      parent: 0
    }
  ],
  '上海市': [{
    name: '沪A',
    value: '沪A',
    parent: 0
  }, {
    name: '沪B',
    value: '沪B',
    parent: 0
  }, {
    name: '沪D',
    value: '沪D',
    parent: 0
  }, {
    name: '沪E',
    value: '沪E',
    parent: 0
  }],
  '重庆市': [{
    name: '渝A',
    value: '渝A',
    parent: 0
  }, {
    name: '渝B',
    value: '渝B',
    parent: 0
  }, {
    name: '渝C',
    value: '渝C',
    parent: 0
  }, {
    name: '渝D',
    value: '渝D',
    parent: 0
  }, {
    name: '渝F',
    value: '渝F',
    parent: 0
  }, {
    name: '渝G',
    value: '渝G',
    parent: 0
  }, {
    name: '渝H',
    value: '渝H',
    parent: 0
  }],
  '哈尔滨市': [{
    name: '黑A',
    value: '黑A',
    parent: 0
  }, {
    name: '黑L',
    value: '黑L',
    parent: 0
  }],
  '合肥市': [{
    name: '皖A',
    value: '皖A',
    parent: 0
  }, {
    name: '皖Q',
    value: '皖Q',
    parent: 0
  }],
  '南昌市': [{
    name: '赣A',
    value: '赣A',
    parent: 0
  }, {
    name: '赣M',
    value: '赣M',
    parent: 0
  }],
  '青岛市': [{
    name: '鲁B',
    value: '鲁B',
    parent: 0
  }, {
    name: '鲁U',
    value: '鲁U',
    parent: 0
  }],
  '淮坊市': [{
    name: '鲁G',
    value: '鲁G',
    parent: 0
  }, {
    name: '鲁V',
    value: '鲁V',
    parent: 0
  }],
  '烟台市': [{
    name: '鲁F',
    value: '鲁F',
    parent: 0
  }, {
    name: '鲁Y',
    value: '鲁Y',
    parent: 0
  }],
  '佛山市': [{
    name: '粤E',
    value: '粤E',
    parent: 0
  }, {
    name: '粤X',
    value: '粤X',
    parent: 0
  }, {
    name: '粤Y',
    value: '粤Y',
    parent: 0
  }],
  '福州市': [{
    name: '闽A',
    value: '闽A',
    parent: 0
  }, {
    name: '闽K',
    value: '闽K',
    parent: 0
  }],
  '桂林市': [{
    name: '桂C',
    value: '桂C',
    parent: 0
  }, {
    name: '桂H',
    value: '桂H',
    parent: 0
  }],
  '海口市': [{
    name: '琼A',
    value: '琼A',
    parent: 0
  }, {
    name: '琼C',
    value: '琼C',
    parent: 0
  }],
  '南宁市': [{
    name: '桂A',
    value: '桂A',
    parent: 0
  }, {
    name: '桂F',
    value: '桂F',
    parent: 0
  }]
}

export default specialJson;
