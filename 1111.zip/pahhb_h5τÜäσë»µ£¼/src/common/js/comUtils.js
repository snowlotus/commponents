import Axios from '../../common/js/axiosConfig'
import API from '../../common/js/comConfig'

/**
 * 格式化数据,把结构数组格式化为url格式传参格式
 * @param {object} data
 * format {name:"leo",age:23}
 * @return {string}  name=leo&age=123
 */
function parseData(data) {
  let str = ''
  if (typeof data == 'object') {
    for (key in data) {
      if (typeof data[key] == 'object') {
        str += parseData(data[key])
      } else if (data[key]) {
        //stz+ 有值才加入参数

        str += key + '=' + data[key] + '&'
      }
    }
  }
  str = str.replace(/(&$)/g, '')
  return str
}

/**
 * 获取URL参数
 * @return {String} name
 */
function getmtParams(name) {
  let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i')
  let r = window.location.search.substr(1).match(reg)
  if (r) {
    return decodeURI(r[2])
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
  }
  return null
}

function getmtParam(name) {
  let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i')
  let r = window.location.hash
    .substr(window.location.hash.indexOf('?') + 1)
    .match(reg)
  if (r) {
    return decodeURI(r[2])
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
  }
  return null
}

function getHash(name) {
  let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i')
  let r = window.location.hash.substr(3).match(reg)
  if (r) {
    return decodeURI(r[2])
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
  }
  return null
}

/**
 * 日期格式化 如：yyyy-MM-dd
 *  @param {object} date [时间]
 *  @param {string} dateFmt [格式] 如:"-","/"
 *  @return {String} date
 */
function dateFormat(date, dateFmt) {
  if (date instanceof Date != true) {
    date = new Date()
  }

  let year = date.getFullYear(),
    month = date.getMonth() + 1
  month = month < 10 ? '0' + month : month
  let d = date.getDate()
  d = d < 10 ? '0' + d : d
  let hour = date.getHours()
  hour = hour < 10 ? '0' + hour : hour
  let minutes = date.getMinutes()
  minutes = minutes < 10 ? '0' + minutes : minutes
  let seconds = date.getSeconds()
  seconds = seconds < 10 ? '0' + seconds : seconds
  let milliseconds = date.getMilliseconds()

  dateFmt = dateFmt ? dateFmt : 'yyyy-MM-dd'

  if (/yyyy/.test(dateFmt)) {
    dateFmt = dateFmt.replace('yyyy', year)
  }
  if (/MM/.test(dateFmt)) {
    dateFmt = dateFmt.replace('MM', month)
  }
  if (/dd/.test(dateFmt)) {
    dateFmt = dateFmt.replace('dd', d)
  }
  if (/hh/.test(dateFmt)) {
    dateFmt = dateFmt.replace('hh', hour)
  }
  if (/HH/.test(dateFmt)) {
    dateFmt = dateFmt.replace('HH', hour)
  }
  if (/mm/.test(dateFmt)) {
    dateFmt = dateFmt.replace('mm', minutes)
  }
  if (/ss/.test(dateFmt)) {
    dateFmt = dateFmt.replace('ss', seconds)
  }
  if (/SS/.test(dateFmt)) {
    dateFmt = dateFmt.replace('SS', milliseconds)
  }

  return dateFmt
}

/**
 * 获取一个没有缓存的URL(通过追加时间戳参数)
 * @param {String} url [url链接]
 * @return {String}
 */
function getUrlNoCache(url) {
  if (url.indexOf('?') == -1) {
    url += '?_t='
  } else {
    url += '&_t='
  }
  return url + new Date().getTime()
}

/*
 * 获取滚动条高度
 */
function getPageScroll() {
  let yScroll
  let self = window
  if (self.pageYOffset) {
    yScroll = self.pageYOffset
    //xScroll = self.pageXOffset;
  } else if (document.documentElement && document.documentElement.scrollTop) {
    yScroll = document.documentElement.scrollTop
  } else if (document.body) {
    yScroll = document.body.scrollTop
  }
  return yScroll
}

function getCalcDate(d, n, typeDate) {
  var da
  if (typeof d == 'object') {
    da = d
  } else {
    da = d.replace(/-/g, '/')
  }
  var t = new Date(da) //复制并操作新对象，避免改动原对象
  if (typeDate == 'y') {
    t.setFullYear(t.getFullYear() + n)
  } else if (typeDate == 'm') {
    t.setMonth(t.getMonth() + n)
    if (t.getDate() != new Date(d).getDate()) {
      t.setDate(0)
    }
  } else {
    t.setDate(t.getDate() + n)
  }

  return t
}

/**
 *  金额元与万互相转换
 *  @param {[number]} [amount] [金额]
 */
function transAmount(amount) {
  if (amount >= 10000) {
    return parseFloat(amount / 10000) + '万元'
  } else {
    return amount + '元'
  }
}

/**
 * 获取一个月多少天
 * @param year
 * @param month
 * @returns {number|*}
 */
function days(year, month) {
  var dayCount, now
  now = new Date(year, month, 0)
  dayCount = now.getDate()
  return dayCount
}

/**
 *   根据出生年月日获取相对于指定日期的年龄，如果没有指定日期默认是相对于今天
 *   获得年龄岁数
 *   @param     {[string]}        birthDay  [出生日期]
 *   @param     {[string]}        fixedDate [指定日期]
 *   @return    {[number]}          age[返回年龄]
 */
function getAgeLim(birthDay, fixedDate) {
  let fixedDateObj = fixedDate ? strToDate(fixedDate) : new Date(),
    bArr = birthDay.split('-'),
    fixDate = fixedDateObj.getDate(),
    fixMonth = fixedDateObj.getMonth(),
    fixYear = fixedDateObj.getFullYear()

  let age = fixYear - bArr[0]

  if (bArr[1] == fixMonth + 1 && bArr[2] <= parseInt(fixDate)) {
    age = age
  } else {
    if (bArr[1] <= fixMonth) {
      age = age
    } else {
      age = age - 1
    }
  }
  return age
}

/**
 *   将####-##-##格式的日期字符串转化为日期对象
 *   @param     {[string]}        sDateString  [出生日期]
 *   @return    {[string]}          oNewDate   [返回时间兑现]
 */
function strToDate(sDateString) {
  if (/^(\d){4}(\-|\/)(\d){1,2}(\-|\/)(\d){1,2}$/.test(sDateString)) {
    // 简单校验一下
    return new Date(sDateString.replace(/\-|\//g, '/'))
  }
  return null
}

/**
 *获取两个日期相差多少天
 *   @param     {[string]}        strDateStart  [开始日期]
 *   @param     {[number]}        strDateEnd  [结束日期]
 *   @return    {[string]}        iDays   [天数]
 *
 */

function getDays(strDateStart, strDateEnd) {
  var strSeparator = '-' //日期分隔符
  var oDate1
  var oDate2
  var iDays
  oDate1 = strDateStart.split(strSeparator)
  oDate2 = strDateEnd.split(strSeparator)
  var strDateS = new Date(oDate1[0] + '-' + oDate1[1] + '-' + oDate1[2])
  var strDateE = new Date(oDate2[0] + '-' + oDate2[1] + '-' + oDate2[2])
  iDays = parseInt(Math.abs(strDateS - strDateE) / 1000 / 60 / 60 / 24) //把相差的毫秒数转换为天数
  return iDays
}

/**
 * [getUrlValue 获取URL参数]
 * @param  {[type]} url [url地址]
 * @return {[type]}     [然会问号后面参数]
 */
function getUrlValue(url = window.location.hash) {
  let variable = url.replace(/^#\//, '').split('?')[1]
  if (!variable) {
    return {}
  } else {
    let value = {}
    variable = variable.split('&')
    for (let i = 0, m = variable.length; i < m; i++) {
      let tempv = variable[i].split('=')[1]
      if (tempv) {
        if (tempv == 'null') tempv = ''
        tempv = decodeURIComponent(tempv)
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
        value[variable[i].split('=')[0]] = tempv
      }
    }
    return value
  }
}

/**
 * 获取保险止期
 * @param  {string} begindate [保险起期]
 * @param  {string} 期限    ['1y','3d']
 * @param  {boolean} 返回数据类型 true返回日期对象，false返回格式化的日期字符串
 * @return {string} [保险止期]
 */
function toEndDate(begindate, period, returnObj) {
  let unit = period.slice(-1),
    num = Number(period.slice(0, -1)),
    beginDate = !!begindate ?
    new Date(begindate.replace(/\-/g, '/')) :
    new Date(),
    year = beginDate.getFullYear(),
    month = beginDate.getMonth(),
    // date = (num > 0) ?(beginDate.getDate() - 1) : (beginDate.getDate());
    date = beginDate.getDate()
  if (unit == 'y') {
    year = year + num
  }
  if (unit == 'd') {
    date = date + num
  }
  return returnObj ?
    new Date(year, month, date, 0, 0, 0) :
    dateFormat(new Date(year, month, date, 0, 0, 0))
}

/**
 * / 获取年龄
 * @param  {string} begindate 保险起期
 * @param  {string} birthdate 生日
 * @return {object}           年龄
 */
function getAgeCode(birthdate, begindate) {
  var beginDate = !!begindate ?
    new Date(begindate.replace(/\-/g, '/')) :
    new Date()
  var birthDate = new Date(birthdate.replace(/\-/g, '/'))
  var begin_y = beginDate.getFullYear()
  var birth_y = birthDate.getFullYear()
  var begin_m = beginDate.getMonth()
  var birth_m = birthDate.getMonth()
  var begin_d = beginDate.getDate()
  var birth_d = birthDate.getDate()

  var y, m, d
  d = begin_d - birth_d
  m = begin_m - birth_m
  y = begin_y - birth_y
  if (d < 0) {
    d = Math.abs(d)
    m -= 1
  }
  if (m < 0) {
    m = Math.abs(m)
    y -= 1
  }
  y = y < 0 ? 0 : y

  return {
    year: y,
    month: m,
    date: d
  }
}

/** 身份证带出生日和性别
 *@param {string} [id] [身份证]
 *@return {object} [生日，性别]
 */
function transformIdNo(idNo) {
  var obj = {}
  if (idNo.length === 15 || idNo.length === 18) {
    if (idNo.length === 15) {
      var pre = idNo.slice(0, 6)
      var last = idNo.slice(-3)
      var birth = '19' + idNo.slice(6, -3)
      idNo = pre + birth + last
    }
    obj.birthYear = idNo.slice(6, 10)
    obj.birthMonth = idNo.slice(10, 12)
    obj.birthDay = idNo.slice(12, 14)
    obj.sex = idNo.slice(14, 17) % 2 == 1 ? 'M' : 'F'
    obj.birth = obj.birthYear + '-' + obj.birthMonth + '-' + obj.birthDay
  }

  return obj
}

/**
 * 获取编码后的参数字符串
 * @param {string} url 传入的URL
 * @param {Array}  encodeParam 指定的需要编码的参数
 */
function encodeParams(url, encodeParam) {
  var pairs = [],
    map = [],
    str = '',
    value
  pairs = url.split('&')
  for (var i = 0, len = pairs.length; i < len; i++) {
    value = pairs[i].charAt(0) == '?' ? pairs[i].replace(/\?/, '') : pairs[i]
    //map = pairs[i].split('=');
    //获得参数键值对
    map[0] = value.substr(0, value.indexOf('='))
    map[1] = value.substr(value.indexOf('=') + 1, value.length)
    //对指指定参数进行编码
    for (var k = 0, aLen = encodeParam.length; k < aLen; k++) {
      if (map[0] === encodeParam[i]) {
        map[1] = encodeURIComponent(map[1])
      }
    }
    //拼接参数串
    if (map[0] && i < len - 1) {
      str += map[0] + '=' + map[1] + '&'
    } else {
      str += map[0] + '=' + map[1]
    }
  }

  return '?' + str
}

//校验车牌号包括未取得车牌号格式
function checkVehicleNumOrNo(vehicleNo) {
  if (vehicleNo == null) return true
  let a = [
    'WJ',
    '军',
    '海',
    '空',
    '北',
    '沈',
    '兰',
    '济',
    '南',
    '广',
    '成',
    '警'
  ]
  for (let i = 0; i < a.length; i++) {
    if (vehicleNo.indexOf(a[i]) == 0) {
      return false
    }
  }
  let regex = /^([\u4e00-\u9fa5]|(WJ)){1}([A-Z]){1}(((-){0,1}([0-9A-Z]){5,6})|(\*){1})$/
  return regex.test(vehicleNo)
}

function setCookie(name, value) {
  var Days = 30
  var exp = new Date()
  exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000)
  document.cookie = name + '=' + escape(value) + ';expires=' + exp.toGMTString()
}

function getCookie(name) {
  var arr,
    reg = new RegExp('(^| )' + name + '=([^;]*)(;|$)')
  if ((arr = document.cookie.match(reg))) return unescape(arr[2])
  else return null
}

function delCookie(name) {
  var exp = new Date()
  exp.setTime(exp.getTime() - 1)
  var cval = getCookie(name)
  if (cval != null)
    document.cookie = name + '=' + cval + ';expires=' + exp.toGMTString()
}

/*
 * 将rem转为px
 * @param rem {number} 需要计算的rem
 * @return {string} 返回计算后的px值
 * */
function remInPx(rem) {
  return document.documentElement.clientWidth / 7.5 * rem
}

/**
 * 加载echarts
 */
function loadEcharts(next) {
  /* 进页面时加载依赖echarts */
  const environment =
    window.location.hostname === 'localhost' ||
    window.location.hostname === '127.0.0.1'
  const echartsScript = document.querySelector('#echartsScript')
  if (!window.echarts) {
    if (echartsScript) {
      echartsScript.onload = function () {
        console.log('下载完毕')
        typeof next === 'function' && next()
      }
      return
    }
    const scriptElem = document.createElement('script')
    scriptElem.id = 'echartsScript'
    scriptElem.src = environment
      ? './static/echarts.min.js'
      : 'https://cdn.bootcss.com/echarts/4.1.0/echarts.min.js'
    document.body.appendChild(scriptElem)
    scriptElem.onload = function () {
      console.log('加载完毕')
      typeof next === 'function' && next()
    }
    return
  }
  console.log('也许已经存在')
  typeof next === 'function' && next()
}

function toFour(val) {
  if (typeof val !== 'number') {
    val = Number(val)
  }
  let newVal =
    Number((val / 10000).toFixed(4)) === 0 ?
    0 :
    Number((val / 10000).toFixed(4))
  return newVal
}

function toTwo(val) {
  if (typeof val !== 'number') {
    val = Number(val)
  }
  let newVal =
    Number((val / 10000).toFixed(2)) === 0 ?
    0 :
    Number((val / 10000).toFixed(2))
  return newVal
}

function roundTwo(val) {
  if (typeof val !== 'number') {
    val = Number(val)
  }
  let newVal = val < 1 && val > 0 ? val.toFixed(2) :
    Math.round(val / 100) / 100 === 0 ? 0 : Math.round(val / 100) / 100;
  // console.log(newVal);
  return newVal;
}

/*
 * @info 查找指定的子组件, 并返回查找到的子组件(由于子组件存在复用的情况, 因此会有多个)
 * @param context {Vue}  当前的vue实例
 * @param childName {String} 子组件的name
 * @return {Array} 查找到的子组件
 * */

function findChild(context, childName, childrens = []) {
  const childs = context.$children
  childs.length &&
    childs.forEach(v => {
      let name = v.$options.name
      let child = v.$children
      let grandSon = []
      if (name === childName) childrens.push(v)
      if (child.length) grandSon = findChild(v, childName)
      if (grandSon.length) childrens.push(grandSon)
    })
  return childrens
}

/*
 * @info 根据name 查找指定的父vue组件
 * @param context {Vue}  当前的vue实例
 * @param parensName {String}   父组件的name
 * */
function findParent(context, parensName) {
  let parent = context.$options.parent
  let patentName = parent.$options.name
  while (patentName !== parensName && patentName !== 'App') {
    parent = parent.$options.parent
    patentName = parent.$options.name
  }
  if (patentName === parensName) {
    return parent
  } else {
    return false
  }
}

/*
 * @info 将数字1000 转化为 1,000 的形式
 * @param number {number} 需要转换的数字
 * */
function numberShowType(number) {
  if (Number.isNaN(Number(number))) {
    return number
  }
  if (
    (typeof number === 'string' && number.length > 3) ||
    (typeof number === 'number' && number >= 1000)
  ) {
    return Number(number).toLocaleString()
  } else {
    return number
  }
}

//获取 年月日 时分秒
function getNow() {
  let date = new Date()
  let timer = `${date.getFullYear()}-${
    date.getMonth() + 1 > 9 ? date.getMonth() + 1 : '0' + (date.getMonth() + 1)
    }-${date.getDate() > 9 ? date.getDate() : '0' + date.getDate()} ${
    date.getHours() > 9 ? date.getHours() : '0' + date.getHours()
    }:${date.getMinutes() > 9 ? date.getMinutes() : '0' + date.getMinutes()}:${
    date.getSeconds() > 9 ? date.getSeconds() : '0' + date.getSeconds()
    }`
  return timer
}

//判断是否小程序
function isMiniProgram() {
  return (window.__wxjs_environment === 'miniprogram')
}

export {
  parseData,
  getHash,
  getmtParam,
  getmtParams,
  dateFormat,
  getUrlNoCache,
  getPageScroll,
  transAmount,
  getAgeLim,
  strToDate,
  getDays,
  getUrlValue,
  toEndDate,
  getAgeCode,
  encodeParams,
  checkVehicleNumOrNo,
  getCalcDate,
  setCookie,
  getCookie,
  delCookie,
  remInPx,
  days,
  loadEcharts,
  toFour,
  findChild,
  findParent,
  numberShowType,
  toTwo,
  roundTwo,
  getNow,
  isMiniProgram
}
