import {isMiniProgram} from '@/common/js/comUtils'

window.Native = {
  _getHybridUrl: function (params) {
    let k, paramStr = '',
      url = 'hybrid://',
      flag = '?';
    url += params.tagname; //时间戳，防止url不起效

    if (params.callback) {
      flag = '&';
      url += '?callback=' + params.callback;
      //delete params.callback;
    }
    if (params.param) {
      paramStr = typeof params.param == 'object' ? JSON.stringify(params.param) : params.param;
      url = url + flag + 'param=' + encodeURIComponent(paramStr);
    }
    return url;
  },

  loadURL: function (url) {
    var iFrame;
    iFrame = document.createElement('iframe');
    iFrame.setAttribute('src', url);
    iFrame.setAttribute('style', 'display:none');
    iFrame.setAttribute('height', '0px');
    iFrame.setAttribute('width', '0px');
    document.body.appendChild(iFrame);

    setTimeout(function () {
      iFrame.parentNode.removeChild(iFrame);
      iFrame = null;
    }, 1000);
  },

  bridgePostMsg: function (params) {
    var url = this._getHybridUrl(params);
    //兼容ios6
    //var ifr = $('<iframe style="display: none;" src="' + url + '"/>');
    //console.log(params.tagname + '-hybrid请求发出-' + new Date().getTime() + 'url: ' + url)
    let ua = navigator.userAgent.toLowerCase();
    if (ua.indexOf("android") != -1) {
      prompt(decodeURIComponent(url));
    } else {
      this.loadURL(url);
    }
    /*
     if ($.os.android) {
     //Android情况协议发的太快会有问题
     setTimeout(function() {
     $('body').append(ifr);
     })
     } else {
     $('body').append(ifr);
     }

     //这样会阻断第二次请求
     //window.location = url;

     setTimeout(function() {
     ifr.remove();
     ifr = null;
     }, 1000);
     */
  },

//02 H5与Native基本交互
  requestHybrid: function (params) {
    if (!params.tagname) {
      alert('必须包含tagname');
    }
    //生成唯一执行函数，执行后销毁
    var tt = (new Date().getTime());
    var t = 'hybrid_' + params.tagname + '_' + tt;
    var tmpFn;
    //处理有回调的情况
    if (params.callback) {
      tmpFn = params.callback;
      params.callback = t;
      window.Hybrid[t] = function (data) {
        tmpFn(data);
        //delete window.Hybrid[t];
      }
    }

    this.bridgePostMsg(params);
  },

  hybridCB: function (cbParams) {
    //console.log("cbParams:"+cbParams)
    var paramsObject = typeof cbParams === 'string' ? JSON.parse(cbParams) : cbParams
    var callBackId = paramsObject.callback;
    if (callBackId) {
      //console.log("callBackId获取回调函数:"+callBackId);
      var fromNativeCallback = window.Hybrid[callBackId];
      if (typeof(fromNativeCallback) == 'function') {
        fromNativeCallback({
          data: paramsObject.data,
          errCode: paramsObject.errCode,
          errMsg: paramsObject.errMsg
        });
      }
    }
  },

  /**
   * example 调用native
   * @type {*}
   */
// requestHybrid({
//   tagname:'test',
//   param: {
//     paramTest1:"a",
//   },
//   callback: function(resData) {
//     // alert('requestHybrid');
//     console.log('requestHybrid callback');
//     console.log('requestHybrid data='  + resData.data);
//     console.log('requestHybrid errno=' + resData.errno);
//     console.log('requestHybrid msg='   + resData.msg);
//     // alert('resData=' + resData);
//   }
// });

// window.hybridCB = hybridCB
}
/*======================调用talkingData begin================================*/
/**
 * 参数
 * eventId:"登录"  //事件 id 一级
 * eventLabel:"QQ登录" //事件 二级
 * parameters:{       // 具体的埋点描述
 *  "description":"13723451727” //描述
 * }
 *
 */
window.eventAnalytics = function (eventId, eventLabel, parameters) {
  if (parameters && typeof parameters !== 'object') {
    parameters = {description: parameters}
  }
  let ua = navigator.userAgent.toLowerCase();
  if (!isMiniProgram()) {
    Native.requestHybrid({
      tagname: 'eventAnalytics',
      param: {
        eventId: eventId,
        eventLabel: eventLabel,
        parameters: parameters
      }
    });
  } else {
    console.log('调用h5的埋点');
    let objParams = (parameters && typeof parameters !== 'object') && parameters.description || {};
    let obj = Object.assign({}, window._MD_OPTONS, objParams);
    SKAPP.onEvent(eventId, eventLabel, obj);
  }
}
/*======================调用talkingData end================================*/
window.Hybrid = window.Native.Hybrid || {};
window.hybridCB = window.Native.hybridCB
export default Native;
