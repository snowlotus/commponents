/*用来兼容某些手机对于es6兼容性的差异, 对es6 方法补充的js 文件*/
if (String.prototype.includes === undefined) {
  String.prototype.includes = function (value) {
    return this.indexOf(value) > -1;
  }
}
