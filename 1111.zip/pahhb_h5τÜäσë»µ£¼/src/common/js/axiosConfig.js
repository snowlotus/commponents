import axios from 'axios'
import Loading from '../comComponent/loading/index.js'
import Toast from '../comComponent/toast/index.js'
import Vue from 'vue'
import {
  getCookie,
  delCookie
} from '@/common/js/comUtils'

let loading = true
axios.interceptors.request.use(
  function (config) {
    if (location.hostname == 'localhost') {
      //判断本地环境
      config.headers.common = Object.assign({},
        config.headers.common,
        window.urlHeader
      )
    } else {
      config.headers.common = Object.assign({},
        config.headers.common,
        window.urlHeader
      )
    }
    /* 判断是否显示loading动画 */
    if (!config.hasOwnProperty('loading') ||
      (config.hasOwnProperty('loading') && config.loading)
    ) {
      setTimeout(() => {
        Loading(true)
      }, 0)
    } else {
      loading = false
    }
    return config
  },
  function (error) {
    setTimeout(() => {
      Loading(false)
      Toast('系统繁忙，请稍后重试！')
    }, 200)
    loading = true
    // 对请求错误做些什么
    return Promise.reject(error)
  }
)

// 添加响应拦截器
axios.interceptors.response.use(
  function (response) {
    // 对响应数据做点什么
    if (loading) {
      setTimeout(() => {
        Loading(false)
      }, 0)
    } else {
      loading = true
    }
    // console.log(loading);
    //如果token 失效调转到登录
    if (response.data.code == 1002) {
      console.warn('token 失效, 请更新token')
      if (window.__wxjs_environment === 'miniprogram') {
        delCookie('header')
        delCookie('header')
        setTimeout(() => {
          history.go(0)
          delCookie('header')
          delCookie('header')
          window.location.reload()
        }, 1000)
      } else {
        Native.requestHybrid({
          tagname: 'goLogin',
          param: {
            msg: response.data.msg
          }
        })
        delCookie('header')
        setTimeout(() => {
          location.href = location.href
        }, 100)
      }

    }
    // 如果是接口返回错误消息，展示错误，直接抛出错误。
    /*  if (response.data.resultCode && response.data.resultCode != 'Z0101001' && response.data.resultCode != '0' && response.data.resultCode != 'Y') {
    let errMsg = Mapping.resultCodes[response.data.resultCode] ? Mapping.resultCodes[response.data.resultCode] : '系统错误！请稍后重试'
    Toast(errMsg)
    return Promise.reject(response)
  }*/
    return response
  },
  function (error) {
    if (!error.response ||
      (error.response.status < 200 || error.response.status > 400)
    ) {
      Toast('系统繁忙，请稍后重试！')
    }
    if (loading) {
      setTimeout(() => {
        Loading(false)
      }, 0)
    } else {
      loading = true
    }
    // console.log(loading);
    // 对响应错误做点什么
    return Promise.reject(error)
  }
)

export default axios
