function addEvent (element, eType, handle, bol) {
  if (element.addEventListener) {
    element.addEventListener(eType, handle, bol)
  } else if (element.attachEvent) {
    element.attachEvent('on' + eType, handle)
  } else {
    element['on' + eType] = handle
  }
}

function removeEvent (element, eType, handle, bol) {
  if (element.addEventListener) {
    element.removeEventListener(eType, handle, bol)
  } else if (element.attachEvent) {
    element.detachEvent('on' + eType, handle)
  } else {
    element['on' + eType] = null
  }
}

function getStyle (obj, attr) { // 获取样式
  return obj.currentStyle ? obj.currentStyle[attr] : getComputedStyle(obj)[attr]
}

/*
* 轮播图逻辑函数
* <div class="swiper-wrap"> 相对定位
    <div class="swiper-box clear" ref="bannerList"> 绝对定位
      <div class="swiper-item">1</div>
      <div class="swiper-item">2</div>
      <div class="swiper-item">3</div>
      <div class="swiper-item">4</div>
    </div>
  </div>
* */
// 配置项
// new Banner({
//   box: that.$refs.banner, *
//   ul: that.$refs.bannerList,*
//   liWidth: Boolean  是否需要插件自己计算ul 下的子元素的宽度 默认true
//   callback: function(index) // 返回当前是第几张图片;
// })
let Banner = (function () {
  'use strict';
  let num = 0; // 当前在第几个位置
  let lis = 0; // ul 下的子元素
  let startTouch = 0; // 手指接触的位置
  let moveTouch = 0; // 手指移动时上一次停留的位置
  let a = function (obj) {
    if (typeof obj !== 'object' || !obj.box || !obj.ul) {
      console.error('CANDER:　没有父元素');
      return false
    }
    this.box = obj.box;
    this.ul = obj.ul;
    this.liWidth = typeof obj.liWidth === 'undefined' || obj.liWidth;
    this.callback = obj.callback;
    this.init();
  };
  a.prototype = {
    constructor: a,
    init: function (obj) {
      this.li = this.ul.children;
      lis = this.li.length;
      this.ul.style.width = lis * 100 + '%';
      if (this.liWidth) {
        let d = 100 / lis;
        for (let i = 0; i < lis; i++) {
          this.li[i].style.width = d + '%'
        }
      }
      num = 0;
      addEvent(this.ul, 'touchstart', this.touchStart.bind(this));
      addEvent(this.ul, 'touchmove', this.touchMove.bind(this));
      addEvent(this.ul, 'touchend', this.touchEnd.bind(this));
    },
    flash: function (obj, attr, target) {
      clearInterval(obj.timer);
      obj.timer = setInterval(function () {
        let speed = (target - parseInt(getStyle(obj, attr))) / 8; // 设置速度，随着图片滚动，速度越来越小
        speed = speed > 0 ? Math.ceil(speed) : Math.floor(speed);

        if (parseInt(getStyle(obj, attr)) === target) {
          clearInterval(obj.timer)
        } else {
          obj.style[attr] = parseInt(getStyle(obj, attr)) + speed + 'px'
        }
      }, 30)
    },
    move: function () {
      if (num === this.li.length) { // 当图片到最后一张的时候，将this.ul的left值设为0重新开始
        num = this.li.length - 1;
      } else if (num === -1) {
        num = 0
      }
      typeof this.callback === 'function' && this.callback(num);
      this.flash(this.ul, 'left', -num * this.li[0].offsetWidth);
    },
    touchStart: function (e) {
      startTouch = e.changedTouches[0].pageX;
    },
    touchMove: function (e) {
      let left = moveTouch === 0 ? parseInt(e.changedTouches[0].pageX - startTouch) : parseInt(e.changedTouches[0].pageX - moveTouch);
      moveTouch = e.changedTouches[0].pageX;
      this.ul.style.left = parseInt(getStyle(this.ul, 'left')) + left + 'px';
    },
    touchEnd: function (e) {
      let endTouch = e.changedTouches[0].pageX;
      let step = parseInt(endTouch - startTouch);
      if (step > 40) {
        num--;
        this.move();
      } else if (step < -40) {
        num++;
        this.move();
      } else {
        this.move();
      }
      startTouch = 0;
      moveTouch = 0;
    },
    goPage: function (index) {
      num = index;
      this.move();
    }
  };
  a.fn = a.prototype;
  return a
})();
export default Banner;
