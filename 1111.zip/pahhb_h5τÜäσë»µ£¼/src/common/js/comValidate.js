'use strict';
/**
 *  公共方法校验
 */

/**
 * [ComRegexp 公用的验证正则]
 * @type {Regexp}
 */
const commonValidate = {
  pattern: {
    regName: /^(([\u4e00-\u9fa5.]+[a-zA-Z\.·]*){2,10}|([a-zA-Z\s]{4,10}))$/,
    regMail: /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/i,
    regMobile: /^1[345789]\d{1}(\*{4}\d{4}|\d{8})$/,
    regGangao: /^(\([a-zA-Z\d*]*[a-zA-Z\d]{4}\)|[a-zA-Z\d*]*[a-zA-Z\d]{4})$/,
    regFixedTelephone: new RegExp('^0[\\d]{9,11}$') // 固定电话
  },
  /**
   *
   * [checkName 校验姓名]
   * @param  {[string]} name [姓名]
   * @return {[boolean]} [验证姓名]
   */
  checkName: function (name) {
    if (!name || name.trim().length === 0) {
      return "姓名不能为空！";
    } else if (!this.pattern.regName.test(name)) { //字符逐个判断
      return "姓名需为2-10个中文字符或4-10个英文字符,请您重新检查！";
    }
    return true;
  },
  /**
   * [email 验证邮箱]
   * @param     {[string]}        mail [邮箱]
   * @return    {[boolean]}          [验证信息]
   */
  checkEmail: function (mail) {
    if (!mail || mail.trim().length === 0) {
      return '邮箱不能为空。';
    }
    if (this.pattern.regMail.test(mail))
      return true;
    else {
      return 'E-mail格式不正确，请重新填写。参照格式：myname@hotmail.com。';
    }
  },
  /**
   * [mobile 验证手机]
   * @param     {[string]}        mobile [手机]
   * @return    {[boolean]}          [验证信息]
   */
  checkMobile: function (mobile) {
    //去除全部空格
    mobile = mobile.replace(/\D/g, '');
    let mes = [true, '手机号不能为空！', '手机号码不合规范,请您重新检查！', '手机号码为11位数字,请您重新检查！'];
    if (!mobile || mobile.trim().length === 0) {
      return mes[1];
    }
    if (!this.pattern.regMobile.test(mobile)) {
      return mes[2];
    }
    return mes[0];
  },
  /*
   * [mobile 验证固定电话号]
   * @param {string} mobile 固定电话号
   * @return {boolean|string} 验证为真时返回true 验证为false 时返回文字信息
   * */
  checkFixedPhone: function (mobile) {
    const msg = [
      true,
      '请输入电话号',
      '请输入正确的电话号'
    ];
    if (!mobile || isNaN(Number(mobile))) {
      return msg[1];
    }
    if (!this.pattern.regFixedTelephone.test(mobile)) {
      return msg[2];
    }
    return msg[0];
  },
  // 证件号码校验
  checkCertificateNumber(idNo, idType, insType, index) {
    let pre = '';
    let checkResult = undefined;
    let msg = "";
    index = index || "";

    if (insType === undefined) {
      insType = '';
    } else {
      insType += index;
    }

    if (idType === '01') {
      pre = '身份证号码';
    } else {
      pre = '证件号码';
    }

    msg = insType + pre + '不符合规范，请正确填写。';

    if (idNo.trim() === "") {
      return insType + pre + '不能为空。';
    }
    if (idType === '01') { //身份证
      checkResult = this.checkIdCard(idNo);
      return checkResult === true ? true : (insType + pre + checkResult);
    } else if (idType === '02' && !this.byteLengthCheck(idNo, 3, 18)) { //护照
      return msg;
    } else if (idType === '03' && !this.byteLengthCheck(idNo, 6, 18)) { //军官证/士兵证
      return msg;
    } else if (idType === '06') { //港澳台回乡证或台胞证
      checkResult = this.checkGangao(idNo);
      return checkResult === true ? true : (insType + pre + checkResult);
    } else if (!this.byteLengthCheck(idNo, 1, 18)) { //默认
      return msg;
    }
    return true;
  },

  /**
   * [身份证号码校验]
   * @param  {[String]} idcard [证件号码]
   * @return {[Boolean]}       [是否正确]
   */
  checkIdCard: function (idcard) {


    /*if(idcard=="321123197911250068"){//前端临时对身份证号如下的人员进行屏蔽处理
     return "非常抱歉，您的投保人或被保人中存在不能满足我司投保条件的人员，故无法承保。请谅解！";
     }*/
    var Errors = [
      true,
      "身份证号码位数不对，请正确填写。",
      "身份证号码出生日期超出范围或含有非法字符，请正确填写。",
      "身份证号码校验错误，请正确填写。",
      "身份证号码地区非法，请正确填写。",
      "身份证号码出生日期只能在当前日期之前!",
      "身份证号码不能为空。"
    ];
    if (!idcard || idcard.trim().length === 0) {
      return Errors[6];
    }
    idcard = idcard.toUpperCase();
    var area = {
      11: "\u5317\u4eac",
      12: "\u5929\u6d25",
      13: "\u6cb3\u5317",
      14: "\u5c71\u897f",
      15: "\u5185\u8499\u53e4",
      21: "\u8fbd\u5b81",
      22: "\u5409\u6797",
      23: "\u9ed1\u9f99\u6c5f",
      31: "\u4e0a\u6d77",
      32: "\u6c5f\u82cf",
      33: "\u6d59\u6c5f",
      34: "\u5b89\u5fbd",
      35: "\u798f\u5efa",
      36: "\u6c5f\u897f",
      37: "\u5c71\u4e1c",
      41: "\u6cb3\u5357",
      42: "\u6e56\u5317",
      43: "\u6e56\u5357",
      44: "\u5e7f\u4e1c",
      45: "\u5e7f\u897f",
      46: "\u6d77\u5357",
      50: "\u91cd\u5e86",
      51: "\u56db\u5ddd",
      52: "\u8d35\u5dde",
      53: "\u4e91\u5357",
      54: "\u897f\u85cf",
      61: "\u9655\u897f",
      62: "\u7518\u8083",
      63: "\u9752\u6d77",
      64: "\u5b81\u590f",
      65: "\u65b0\u7586",
      71: "\u53f0\u6e7e",
      81: "\u9999\u6e2f",
      82: "\u6fb3\u95e8",
      91: "\u56fd\u5916"
    };
    var Y, JYM;
    var S, M;
    var idcard_array = new Array();
    idcard_array = idcard.split("");
    if (area[parseInt(idcard.substr(0, 2))] == null) {
      return Errors[4];
    }
    let ereg
    switch (idcard.length) {
      case 15:
        if ((parseInt(idcard.substr(6, 2)) + 1900) % 4 == 0 || ((parseInt(idcard.substr(6, 2)) + 1900) % 100 == 0 && (parseInt(idcard.substr(6, 2)) + 1900) % 4 == 0)) {
          ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$/
        } else {
          ereg = /^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$/
        }
        if (ereg.test(idcard)) {
          var birthYear = idcard.substr(6, 2);
          var birthMonth = idcard.substr(8, 2);
          var birthDay = idcard.substr(10, 2);
          var oTodayMS = new Date();
          var oToday = new Date(oTodayMS.getFullYear(), oTodayMS.getMonth(), oTodayMS.getDate());
          var oUserBirth = new Date(birthYear, parseInt(birthMonth, 10) - 1, birthDay);
          if ((Date.parse(oUserBirth) - Date.parse(oToday)) >= 0) {
            return Errors[5];
          }
          return Errors[0];
        } else {
          return Errors[2];
        }
        break;
      case 18:
        if (parseInt(idcard.substr(6, 4)) % 4 == 0 || (parseInt(idcard.substr(6, 4)) % 100 == 0 && parseInt(idcard.substr(6, 4)) % 4 == 0)) {
          ereg = /^[1-9][0-9]{5}(19|20)[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$/
        } else {
          ereg = /^[1-9][0-9]{5}(19|20)[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$/
        }
        if (ereg.test(idcard)) {
          S = (parseInt(idcard_array[0]) + parseInt(idcard_array[10])) * 7 + (parseInt(idcard_array[1]) + parseInt(idcard_array[11])) * 9 + (parseInt(idcard_array[2]) + parseInt(idcard_array[12])) * 10 + (parseInt(idcard_array[3]) + parseInt(idcard_array[13])) * 5 + (parseInt(idcard_array[4]) + parseInt(idcard_array[14])) * 8 + (parseInt(idcard_array[5]) + parseInt(idcard_array[15])) * 4 + (parseInt(idcard_array[6]) + parseInt(idcard_array[16])) * 2 + parseInt(idcard_array[7]) * 1 + parseInt(idcard_array[8]) * 6 + parseInt(idcard_array[9]) * 3;
          Y = S % 11;
          M = "F";
          JYM = "10X98765432";
          M = JYM.substr(Y, 1);
          if (M == idcard_array[17]) {
            var birthYear = idcard.substr(6, 4);
            var birthMonth = idcard.substr(10, 2);
            var birthDay = idcard.substr(12, 2);
            var oTodayMS = new Date();
            var oToday = new Date(oTodayMS.getFullYear(), oTodayMS.getMonth(), oTodayMS.getDate());
            var oUserBirth = new Date(birthYear, parseInt(birthMonth, 10) - 1, birthDay);
            if ((Date.parse(oUserBirth) - Date.parse(oToday)) >= 0) {
              return Errors[5];
            }
            return Errors[0];
          } else {
            return Errors[3]
          }
        } else {
          return Errors[2];
        }
        break;
      default:
        return Errors[1];
        break;
    }
    return true
  },
  /**
   * [gangao 验证港澳回乡证或台胞证输入有误]
   * @param     {[string]}        value [证件号码]
   * @return    {[boolean]}          [验证信息]
   */
  checkGangao: function (value) {
    let errTxt = ['港澳回乡证或台胞证不能为空！', '港澳回乡证或台胞证位数不对！', '港澳回乡证或台胞证不符合规范'];
    if (!value || value.trim().length === 0) {
      return errTxt[0];
    }
    value = value.toUpperCase();
    if (value.length < 8) {
      return errTxt[1];
    } else if (!this.pattern.regGangao.test(value)) {
      // /^(\([a-zA-Z\d]*\)|[a-zA-Z\d])*$/
      // /^(\([a-zA-Z\d*]*[a-zA-Z\d]{4}\)|[a-zA-Z\d*]*[a-zA-Z\d]{4})$/ 支持 前面*号掩码后四位明文
      return errTxt[2];
    }
    return true;
  },

  /**
   *   校验字符字节长度
   */
  byteLengthCheck(str, minlen, maxlen) {
    if (!str) return false;
    var l = str.length;
    var blen = 0;
    for (let i = 0; i < l; i++) {
      if ((str.charCodeAt(i) & 0xff00) != 0) {
        blen++;
      }
      blen++;
    }
    if (blen > maxlen || blen < minlen) {
      return false;
    }
    return true;
  }
}
export default commonValidate;
