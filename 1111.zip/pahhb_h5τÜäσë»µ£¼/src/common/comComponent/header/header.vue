<template>
  <div class="po newCar_top c b-b" :class="{'titleWrap':!titleText}">
    <a class="navigation_arrow fl" href="javascript:;" @click.prevent="leftEvent"></a>
    <section v-if="titleText" style="height: 100%;margin-left: 0.8rem;">
      <slot name="center">
        <p class="friends_txt fl ">{{titleText}}</p>
      </slot>
      <slot name="right" v-if="showRight">
        <a class="nav_search_btn fr" href="javascript:;" @click.prevent="rightEvent"></a>
      </slot>
    </section>
    <div class="entryBox" v-else @click.prevent="gotoSearch">
      <input type="text" readonly :placeholder="inputPlh">
    </div>
  </div>
</template>

<script>
  export default {
    name: "my-header",
    props: {
      showRight: {
        type: Boolean,
        default: false
      },
      titleText: String,
      leftFlag: {
        type: Boolean,
        default: false
      },
      inputPlh: {
        type: String,
        default: '请输入搜索的内容（案件号、车牌)'
      },
      flagName: {
        type: String,
        default: 'taskList'
      },
      stopEvery: Boolean
    },
    methods: {
      leftEvent () {
        if (this.stopEvery || window.PageStatus.headerStop) {
          return
        }
        if (!this.leftFlag) {
          window.history.go(-1)
        } else {
          this.$emit('on-left')
        }
      },
      rightEvent () {
        if (this.stopEvery || window.PageStatus.headerStop) {
          return
        }
        this.$emit('on-right')
      },
      gotoSearch () {
        if (this.stopEvery || window.PageStatus.headerStop) {
          return
        }
        if (this.flagName === 'claimList') {
          this.$router.push({path: '/claimSearch', query: {flag: this.flagName}})
          return
        }
        this.$router.push({path: '/search', query: {flag: this.flagName}})
      }
    }
  }
</script>

<style lang="less" scoped>
  @import "../../../common/css/1px.less";

  .po {
    position: relative;
    top: 0;
    left: 0;
    z-index: 999;
  }

  .b-b {
    box-sizing: border-box;
    .pts-1px-b(#eee);
  }
</style>
