import header from './header.vue'
export default header
