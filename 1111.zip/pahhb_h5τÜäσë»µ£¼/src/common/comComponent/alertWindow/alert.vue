<template>
  <div class="alert-wrap" v-show="showWrap">
    <transition name="actionsheet-mask">
      <div class="mask" v-if="show" @touchstart.stop="start" @touchmove.stop="move" @touchend.stop="end"></div>
    </transition>
    <transition name="zoom">
      <div class="alert-cotent" v-if="show">
        <slot></slot>
      </div>
    </transition>
  </div>
</template>

<script>
  export default {
    name: "pta-alert",
    props: {
      value: Boolean
    },
    data () {
      return {
        show: false,
        showWrap: false
      }
    },
    methods: {
      hidden () {
        this.show = false
        setTimeout(function () {
          this.showWrap = false
          this.$emit('input', false)
        }.bind(this), 500)
      },
      start () {
      },
      move () {
      },
      end () {
      }
    },
    watch: {
      value (to) {
        if (to) {
          this.showWrap = to
          this.$nextTick(function () {
            this.show = this.value
          })
        } else {
          this.hidden()
        }
        window.PageStatus.tabhidden = to // 阻止tab切换
      }
    }
  }
</script>

<style lang="less" scoped>
  .alert-wrap {
    .mask {
      position: fixed;
      z-index: 1000;
      top: 0;
      right: 0;
      left: 0;
      bottom: 0;
      background: rgba(0, 0, 0, .6);
    }
    .alert-cotent {
      position: fixed;
      z-index: 5000;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
  }

  .actionsheet-mask-enter, .actionsheet-mask-leave-active {
    opacity: 0;
  }

  .actionsheet-mask-leave-active, .actionsheet-mask-enter-active {
    transition: opacity 300ms;
  }

  .zoom-enter-active, .zoom-leave-active {
    opacity: 1;
    transition-duration: 400ms;
    transform: translate(-50%, -50%) scale(1) !important;
    transition-property: transform, opacity !important;
  }

  .zoom-leave-active {
    transition-duration: 300ms;
  }

  .zoom-enter {
    opacity: 0;
    transform: translate(-50%, -50%) scale(1.185) !important;
  }

  .zoom-leave-active {
    opacity: 0;
    transform: translate(-50%, -50%) scale(0.85) !important;
  }
</style>
