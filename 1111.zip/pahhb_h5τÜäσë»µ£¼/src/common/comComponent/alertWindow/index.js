import alert from './alert.vue';
export default alert;
