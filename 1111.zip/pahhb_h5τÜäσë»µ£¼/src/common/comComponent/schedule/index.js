/*
* @info 进度条动画
* 调用show() 方法显示 在70% 的地方播放完毕,
* 调用hide() 方法结束
* */

class Schedule {

  show () {
    clearTimeout(this.loadingTimeout);
    this.divStyle.display = 'block';
    this.add();
  }

  hide () {
    clearTimeout(this.loadingTimeout);
    this.divStyle.transition = 'width 500ms';
    this.divStyle.width = '100%';
    setTimeout(() => {
      this.divStyle.display = 'none';
      this.divStyle.width = '0%';
    }, 500);
  }

  add (width = 0, timeout = 17, max = 70, callback) {
    let widths = width;
    let addWidth = () => {
      widths++;
      this.divStyle.width = widths + '%';
      if (widths >= max) {
        typeof callback === 'function' ? callback() : null;
        return
      }
      this.loadingTimeout = setTimeout(addWidth, timeout)
    };
    addWidth();
  }


  constructor () {
    const divElem = document.createElement('div');
    divElem.style.height = '2px';
    divElem.style.width = '0%';
    divElem.style.background = '#FE883A';
    divElem.style.position = 'fixed';
    divElem.style.top = '0.88rem';
    divElem.style.left = '0px';
    divElem.style.zIndex = '999999999';
    divElem.style.transition = 'none';
    this.divStyle = divElem.style;
    document.body.appendChild(divElem)
  }
}

export default  new Schedule();
