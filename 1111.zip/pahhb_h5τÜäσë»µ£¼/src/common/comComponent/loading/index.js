/**
 * example
 * ①import Loading from '../../components/loading/index.js'
 * Loadding(state) {booloean}  是否显示loading动画
 */

import canvasloading from './canvasIndex';

let Loading = (flag) => {
  if (flag) {
    canvasloading.show();
  } else {
    canvasloading.hide();
  }
}

export default Loading
