import Vue from 'vue'

const LoadingConstructor = Vue.extend(require('./loading.vue'))

let loadingPool = []


let returnAnInstance = instance => {
	if (instance) {
		loadingPool.push(instance)
	}
}

LoadingConstructor.prototype.close = function() {
	this.state = false
	// document.body.removeChild(this.$el)
	returnAnInstance(this)
}

LoadingConstructor.prototype.load = function() {
	// this.state = true
	document.body.appendChild(this.$el)
}


let getAnInstance = () => {
	if (loadingPool.length > 0) {
		let instance = loadingPool[0];
		loadingPool.splice(0, 1);
		return instance
	}
	return new LoadingConstructor({
		el: document.createElement('div')
	})
}

let Loading = () => {
	let instance = getAnInstance()
	return instance
}

export default Loading