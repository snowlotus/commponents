/**
 * example
 * ①import Loading from '../../components/loading/index.js'
 * Loadding(state) {booloean}  是否显示loading动画
 */


import Vue from 'vue'
import canvasloading from './canvasIndex';
const LoadingConstructor = Vue.extend(require('./loading.vue'))

let loadingPool = []

let returnAnInstance = instance => {
  if (instance) {
    loadingPool.push(instance)
  }
}

LoadingConstructor.prototype.load = function (flag) {
  this.state = flag
  !this.state && this.$el.parentNode.removeChild(this.$el)
  returnAnInstance(this)
}

let getAnInstance = () => {
  if (loadingPool.length > 0) {
    let instance = loadingPool[0];
    loadingPool.splice(0, 1);
    return instance
  }
  return new LoadingConstructor({
    el: document.createElement('div')
  })
}

let Loading = (flag) => {
  if (flag) {
    canvasloading.show();
  } else {
    canvasloading.hide();
  }
  /*let instance = getAnInstance()
   document.body.appendChild(instance.$el)
   instance.$nextTick(function() {
   instance.load(flag)
   })
   return instance*/
}

export default Loading
