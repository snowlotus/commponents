/**
 * Created by LIKANGDE925 on 2018/1/3.
 */
let divElem, canvasElem, canvasFarther, width, height, ctx, background, lineColor, deg, startDeg, endDeg, startStep, endStep, timeout,
  radius, lineWidth,
  flag;
class CanvasLoading {
  constructor () {
    // 遮罩层 div
    divElem = document.createElement('div');
    // canvas 动画在移动端会存在模糊的情况, 因此canvas的实际大小是 当前的大小的倍数, 这个倍数是根据移动端的像素比.
    // 因此这样canvas会很大. 就需要有一层div来约束它.
    canvasFarther = document.createElement('div');
    canvasElem = document.createElement('canvas');
    width = height = parseInt(document.documentElement.style.fontSize) * (window.devicePixelRatio || 2);
    divElem.style.display = 'none';
    divElem.style.width = '100%';
    divElem.style.height = '100%';
    divElem.style.position = 'fixed';
    divElem.style.left = '0';
    divElem.style.top = '0';
    divElem.style.zIndex = '99999999';
    canvasFarther.style.width = canvasFarther.style.height = parseInt(document.documentElement.style.fontSize) + 'px';
    canvasFarther.style.position = 'absolute';
    canvasFarther.style.top = '50%';
    canvasFarther.style.left = '50%';
    canvasFarther.style.borderRadius = 0.1 * width + 'px';
    canvasFarther.style.transform = 'translate(-50%)';
    canvasFarther.style.overflow = 'hidden';
    canvasElem.width = width;
    canvasElem.height = height;
    canvasElem.style.width = canvasElem.style.height =  '100%'; // 使用css 来约束canvas的现实大小

    ctx = canvasElem.getContext('2d');
    background = 'rgba(0, 0, 0, 0.7)';
    lineColor = '#fff';
    deg = (Math.PI * 2) / 360;
    endDeg = startDeg = 270;
    flag = false;
    startStep = 3;
    endStep = 6;

    radius = Math.ceil(0.38 * width);
    lineWidth = Math.ceil(0.04 * width);

    document.body.appendChild(divElem);
    divElem.appendChild(canvasFarther);
    canvasFarther.appendChild(canvasElem);
  }

  run () {
    function start () {
      startDeg += startStep;
      endDeg += endStep;
      if (endDeg >= 360) {
        endDeg = 360 - endDeg;
      }
      if (startDeg >= 360) {
        startDeg = 360 - startDeg;
      }

      if ((endDeg - startDeg === -30) && !flag) {
        // startStep += 6;
        startStep = 6;
        endStep = 3;
        flag = true;
      }

      if ((endDeg - startDeg === 30) && flag) {
        // startStep -= 6;
        startStep = 3;
        endStep = 6;
        flag = false;
      }
      /* 当圈数达到二十多的时候, 会重叠在一起, 从新跑 */
      if (endDeg - startDeg === 0) {
        flag = false;
        startStep = 3;
        endStep = 6;
        endDeg = startDeg = 270;
      }
      ctx.clearRect(0, 0, width, height);

      ctx.beginPath();
      ctx.fillStyle = background;
      ctx.fillRect(0, 0, height, width);
      ctx.fill();
      ctx.closePath();

      ctx.beginPath();
      ctx.strokeStyle = lineColor;
      ctx.lineWidth = lineWidth;
      ctx.lineCap = 'round';
      ctx.arc(width / 2, height / 2, radius, startDeg * deg, endDeg * deg);
      ctx.stroke();
      ctx.closePath();
    }
    start();
    clearInterval(timeout);
    timeout = setInterval(start, 17);
  }

  show () {
    divElem.style.display = 'block';
    endDeg = startDeg = 270;
    startStep = 3;
    endStep = 6;
    this.run();
  }

  hide () {
    divElem.style.display = 'none';
    clearInterval(timeout);
  }
}

export default new CanvasLoading();
