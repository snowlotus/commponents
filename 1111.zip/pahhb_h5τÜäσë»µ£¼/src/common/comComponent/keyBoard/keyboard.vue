<template>
  <div class="keyboard-wrap js-write" :class="{'show-key': value}">
    <section class="chinese-key-area js-write">
      <button class="key-item js-write" v-for="(item,index) in chineseKey" :key="index"
              @click="clickChineseItem(item)">
        {{item}}
      </button>
    </section>
    <section class="english-key-area js-write">
      <div class="english-row js-write" v-for="(item, index) in EnglishKey" :key="index">
        <button class="key-item english js-write" v-for="(keyItem, keyIndex) in item" :key="keyIndex"
                @click="clickEnglishItem(keyItem)">
          {{keyItem}}
        </button>
      </div>
      <button class="next-btn active js-write" v-if="values[0] && values[1]" @click="nextStep">下一步</button>
      <button class="next-btn js-write" v-else>下一步</button>
    </section>
  </div>
</template>

<script>
  const chineseKey = ["京", "津", "沪", "渝", "冀", "晋", "辽", "豫", "吉", "黑", "苏", "浙", "皖", "闽", "赣", "湘", "粤", "琼", "川", "贵", "云", "陕", "甘", "青", "藏", "桂", "蒙", "宁", "新", "鄂", "鲁"];
  const EnglishKey = [
    ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
    ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
    ['Z', 'X', 'C', 'V', 'B', 'N', 'M']
  ];

  export default {
    props: {
      value: {
        type: Boolean
      },
      checkedValue: String,
      inputElemId: String
    },
    name: "",
    data () {
      return {
        chineseKey,
        EnglishKey,
        values: ['', '']
      }
    },
    methods: {
      /* 点击汉字字母的键盘触发 替换 values 中 索引为0 的值 */
      clickChineseItem (item) {
        this.values.splice(0, 1, item);
        this.$emit('on-input', this.values.join(''));
      },
      /* 点击英文字母的键盘触发 替换 values 中 索引为1 的值 */
      clickEnglishItem (item) {
        this.values.splice(1, 1, item);
        this.$emit('on-input', this.values.join(''));
      },
      /* 点击别的位置让键盘消失, 由watch "value" props变化时触发 */
      clickDocHideKeyBoard (nv, ov) {
        if (nv) {
          this.bindDocClick();
        }
      },
      /* 给document 添加绑定或移除事件 */
      bindDocClick (clearEvent) {
        let self = this;

        /* 使用函数表达式可以顺利的移除绑定的点击事件 */
        document.querySelector('#app').addEventListener('click', function dc (e) {
          if (e.target.classList.contains('js-write')) return;
          if (self.value) self.$emit('input', false);
          this.removeEventListener('click', dc);
        });
      },
      /* 点击下一步按钮触发 */
      nextStep () {
        this.$emit('input', false);// 关闭键盘
        if (!this.inputElemId) return;
        this.$nextTick(function () {
          // 由于input不一定会在dom中显示出来因此采用每次再去查找的方式获取到input框;
          let inputElem = document.querySelector('#' + this.inputElemId);
          inputElem && inputElem.focus && inputElem.focus();
        })
      }
    },
    mounted () {
      this.values = this.checkedValue.length > 0 ? this.checkedValue.split('') : ['', '']
    },
    watch: {
      value: {
        handler: 'clickDocHideKeyBoard'
      }
    }
  }
</script>

<style scoped lang="less">
  .keyboard-wrap {
    position: fixed;
    bottom: -100%;
    left: 0;
    transition: all 500ms;
    z-index: 999;
    &.show-key {
      bottom: 0rem;
    }
    .chinese-key-area {
      padding-left: 0.08rem;
      padding-bottom: 0.08rem;
      background: #AAB2C3;
    }
    .english-key-area {
      padding-bottom: 0.08rem;
      background: #CFD3DB;
      .next-btn {
        position: absolute;
        bottom: 0.15rem;
        right: 0.1rem;
        width: 1.02rem;
        height: 0.82rem;
        border: none;
        outline: none;
        box-shadow: 0 0.02rem 0 0 rgba(0, 0, 0, 0.50);
        border-radius: 0.1rem;
        background: #A8AFBC;
        color: #767C86;
        &.active {
          background: #fff;
          color: #000;
        }
      }
    }
    .key-item {
      width: 0.66rem;
      height: 0.62rem;
      margin: 0.08rem 0.08rem 0 0;
      border-radius: 0.1rem;
      background: #fff;
      border: none;
      outline: none;
      font-size: 0.4rem;
      user-select: none;
      box-shadow: 0 0.02rem 0 0 rgba(0, 0, 0, 0.50);
      &.english {
        display: inline-block;
        width: 0.66rem;
        height: 0.82rem;
        margin: 0.08rem 0.08rem 0.08rem 0;
      }
    }
    .english-row {
      text-align: center;
    }
  }
</style>
