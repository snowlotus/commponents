<template>
  <section v-show="show">
    <popup-picker
      :show="show"
      title="titleText" :show-cell="false" :data="insDataList" :columns="3"
      show-name @on-shadow-change="onShadowChange" @on-hide="onHide"></popup-picker>
  </section>
</template>

<script>
  import {PopupPicker} from 'vux'
  import axios from '../../../common/js/axiosConfig'
  import API from '../../../common/js/comConfig'
  import Toast from '../toast/index'

  export default {
    name: 'linkageMenu',
    data() {
      return {
        insDataList: [],
        msg: {
          cityName: '',
          cityCode: '',
          provicesName: '',
          provicesCode: '',
          dealerCode: '',
          dealerName: ''
        }
      }
    },
    props: {
      titleText: {
        type: String,
        default: '机构选择'
      },
      dataList: Array,
      show: {
        type: Boolean,
        default: false
      },
      trademarkId: {
        type: String,
        default: ''
      },
      queryValue: {
        type: String,
        default: ''
      },
      queryType: {
        type: String,
        default: 'D'
      }
    },
    components: {
      PopupPicker
    },
    methods: {
      onShadowChange(ids, name) {
        this.msg = {
          provicesName: name[0],
          provicesCode: ids[0],
          cityName: name[1],
          cityCode: name[1] === '暂不选择' ? undefined : ids[1],
          dealerCode: name[2] === '暂不选择' ? undefined : ids[2],
          dealerName: name[2]
        };
        this.$emit('on-shadow-change', ids, name)
      },
      onHide(closeFlag) {
        const msg = closeFlag ? this.msg : undefined;
        this.$emit('on-hide', closeFlag, msg);
      },
      /**
       *获取机构数据
       **/
      getInstitutionData(reqData) {
        const _this = this;
        //'http://localhost:8888/index?id=queryOrganized&path=car&dateFrom=20171030'API.getWebServiceUrls('queryOrganized')
        axios.post(API.getWebServiceUrls('queryOrganized'), reqData, {"loading": false}).then(res => {
          const insData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          let cityList = [], dealerCodeList = [], proviceList = [];
          if (insData.code === 0 || insData.code === '0') {
            cityList = insData.data.cityList || [];
            dealerCodeList = insData.data.dealerCodeList || [];
            proviceList = insData.data.proviceList || [];
            //console.log(cityList.push.apply(cityList,dealerCodeList));
            cityList.push.apply(cityList, dealerCodeList);
            proviceList.push.apply(proviceList, cityList);
            _this.insDataList = proviceList;
//            console.log(_this.insDataList);
          } else {
            Toast(insData.msg);
          }
        }).catch(e => {
          Toast('出错了,请稍后重试')
        })
      },
    },
    mounted() {
      let reqData = {};
      this.$nextTick(function () {
        if (this.$route.path === '/coreData') {
          reqData = {
            trademarkId: this.trademarkId,
            queryValue: '',
            queryType: this.queryType
          }
        } else {
          reqData = {};
        }
        this.getInstitutionData(reqData);
      })
    },
    watch: {
      trademarkId(val, oldVal) {
        if (val === oldVal) return;
        let reqData = {
          trademarkId: val,
          queryValue: this.queryValue,
          queryType: this.queryType
        };
        this.getInstitutionData(reqData);
      },
      queryValue(val, oldVal) {
        if (val === oldVal) return;
        let reqData = {
          trademarkId: this.trademarkId,
          queryValue: val,
          queryType: this.queryType
        };
        this.getInstitutionData(reqData);
      },
      queryType(val, oldVal) {
        if (val === oldVal) return;
        let reqData = {
          trademarkId: this.trademarkId,
          queryValue: this.queryValue,
          queryType: val
        };
        this.getInstitutionData(reqData);
      }
    }
  }
</script>

<style lang='less'>

</style>
