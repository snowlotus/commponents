import linkageMenu from './linkageMenu.vue'
export default linkageMenu
