/**
 * example
 * ①import Toast from '../../components/toast/index.js'
 * Toast(txt) {string}	提示的内容
 * Toast({message: xt, duration: 2500}) {object}	接收一个字典类型
 */



import Vue from 'vue'

const ToastConstructor = Vue.extend(require('./toast.vue'))

let toastPool = []

let returnAnInstance = instance => {
  if (instance) {
    toastPool.push(instance)
  }
}

let getAnInstance = () => {
	if (toastPool.length > 0) {
		let instance = toastPool[0];
		toastPool.splice(0, 1);
		return instance
	}
	return new ToastConstructor({
		el: document.createElement('div')
	})
}

ToastConstructor.prototype.close = function(){
	this.show = false
	this.$el.parentNode.removeChild(this.$el)
	returnAnInstance(this)
}

let Toast = (options) => {
	let instance = getAnInstance()
	clearTimeout(instance.timer)
	instance.message = typeof options === 'string' ? options : options.message;
	document.body.appendChild(instance.$el)
	Vue.nextTick(function() {
		instance.show = true
		instance.timer = setTimeout(function() {
			instance.close()
		}, options.duration || 2500)
	})
	return instance
}

export default Toast
