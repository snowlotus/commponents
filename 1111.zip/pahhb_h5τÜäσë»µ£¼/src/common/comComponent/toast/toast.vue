<template>
  <div class="notes" v-show="show">
    <span class="text">{{message}}</span>
  </div>
</template>
<script>

  export default {
    name: 'toast',
    data () {
      return {
        show: false
      }
    },
    props: {
      message: {
        type: String,
        default: ''
      }
    }
  }
</script>
<style>
  .notes {
    position: fixed;
    left: 50%;
    top: 50%;
    z-index: 99999999999999;
    max-width: 80%;
    min-width: 50%;
    /*margin-left:-25%;*/
    transform: translate(-50%);
    padding: 10px;
    border-radius: 5px;
    background: rgba(0, 0, 0, .7);
    color: #fff;
    box-sizing: border-box;
    text-align: center;
    text-align: justify;
  }

  .text {
    font-size: 14px;
    display: block;
    text-align: center;
  }

</style>
