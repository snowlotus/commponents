<template>
  <div>
    <ul class="selected-wrap" :class="{'showWrap': show}">
      <li class="selected-item pts-b-b text-hidden" :class="{'active':activeIndex === index}"
          v-for="(item,index) in dataList"
          @click="selectedItem(item, index)">
        {{item.name}}
      </li>
    </ul>
    <div class="selected-mask" v-if="show" @click="hideSelected"></div>
  </div>
</template>

<script>
  export default {
    name: "selected",
    props: {
      show: {
        type: Boolean,
        default: false
      },
      dataList: Array,
      text: String
    },
    data () {
      return {
        activeIndex: 0
      }
    },
    methods: {
      selectedItem (item, index) {
        if (item.code === 'loading+++') {
          return
        }
        this.activeIndex = index;
        this.$emit('input', item);
        this.$emit('update:show', false);
      },
      hideSelected () {
        this.$emit('update:show', false);
      },
      changeDataList () {
        if (!this.text && !this.dataList.length)  return;
        this.dataList.forEach((v, i) => {
          if (v.name === this.text) {
            this.activeIndex = i;
          }
        })
      }
    },
    watch: {
      dataList: {
        handler: 'changeDataList',
        immediate: true
      }
    }
  }
</script>

<style scoped lang="less">
  @import "./style";
</style>
