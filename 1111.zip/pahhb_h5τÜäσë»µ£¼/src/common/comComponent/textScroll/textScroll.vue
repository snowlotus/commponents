<template>
  <section style="width: 100%;height: 100%">
    <div class="text-scroll-box" @click="clickEven">
      <div class="text-scroll-wrap" ref="textWrap">
        <div class="scroll-wrap" style="transition:none;transform: translateX(0px);" ref="text" @transitionend="trsEND">
          {{name}}
        </div>
      </div><div class="arrow-down"></div>
    </div>
    <pts-selcet :show.sync="show" @input="chooseName" :data-list="list" :text="text"></pts-selcet>
  </section>
</template>

<script>
  import ptsSelcet from './selected';
  import axios from '../../../common/js/axiosConfig';
  import url from '../../../common/js/comConfig';
  import toast from '../../../common/comComponent/toast';

  export default {
    name: "text-scroll",
    props: {
      text: String,
      isHaveAll: {
        type: Boolean,
        default: true
      }
    },
    data () {
      return {
        show: false,
        name: '全部网点',
        list: [],
        timeout: null // 延迟五秒拉取
      }
    },
    methods: {
      textScroll () {
        let wrapElem = this.$refs.textWrap;
        let textElem = this.$refs.text;
        let ww = wrapElem.offsetWidth;
        let tw = textElem.scrollWidth;
        if (tw > ww) {
          textElem.style.transform = 'translateX(' + tw + 'px)';
          setTimeout(function () {
            textElem.style.transition = 'all 10s linear';
            textElem.style.transform = 'translateX(-' + tw + 'px)';
          }, 0);
        } else {
          textElem.style.transition = 'none';
          textElem.style.transform = 'translateX(0px)';
        }
      },
      trsEND () {
        let _this = this;
        let textElem = this.$refs.text;
        let tw = textElem.scrollWidth;
        textElem.style.transition = 'none';
        textElem.style.transform = 'translateX(' + tw + 'px)';
        setTimeout(function () {
          textElem.style.transition = 'all 10s linear';
          _this.textScroll();
        }, 0);
      },
      clickEven () {
        if (this.list.length) {
          this.show = true;
        } else {
          this.list.push({
            code: 'loading+++',
            name: '网点数据加载中...'
          });
          clearTimeout(this.timeout);
          this.getData();
          this.show = true;
        }
      },
      chooseName (text) {
        this.name = text.name;
        this.$emit('input', text.code, text.name);
        this.$nextTick(function () {
          this.textScroll();
        });
      },
      getData () {
        let _this = this;
        axios.post(url.getWebServiceUrls('getUserOrganization'), {}, {loading: false})
          .then(res => {
            res = res.data;
            if (res.code != 0) {
              toast(res.msg);
              return;
            }
            let arr_list = [];
            arr_list = res.data.organizationList.childList;
            // 加入全部网点选项
            if (this.isHaveAll){
              arr_list.unshift({
                name: '全部网点',
                code: res.data.organizationList.code
              });
            }
            _this.list = arr_list;
          }).catch(e => {
          console.log(e);
        })
      }
    },
    mounted () {
      this.timeout = setTimeout(function () {
        this.getData();
      }.bind(this), 800);
      this.name = this.text || '全部网点';
      this.textScroll();
    },
    watch: {
      text () {
        this.name = this.text;
        this.$nextTick(function () {
          this.textScroll();
        });
      }
    },
    components: {
      ptsSelcet
    }
  }
</script>

<style scoped lang="less">
  @import "./style";
</style>
