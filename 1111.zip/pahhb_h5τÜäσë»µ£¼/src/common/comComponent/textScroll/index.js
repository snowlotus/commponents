import textScroll from './textScroll';
export default textScroll;
