<template>
  <div class="bar-area" ref="barArea"></div>
</template>

<script>
  import objacc from './utils';
  import {remInPx} from '../../../common/js/comUtils'

  export default {
    name: "barFlow",
    props: {
      options: Object
    },
    data () {
      return {
        myBar: null
      }
    },
    methods: {
      setData (callback) {
        callback(this.myBar)
      },
      init () {
        const fontFamily = "Arial";
        try {
          /*const options = this.options
          if (!options.textStyle || !options.textStyle.fontFamily) {
            console.log('成功设置bar字体为=>' + fontFamily)
            options.textStyle = {
              fontFamily
            }
          }*/
          const option = {
            legend: {
              textStyle: {
                fontSize: remInPx(0.22),
                color: '#666'
              },
              bottom: 0,
              itemWidth: remInPx(0.1),
              itemHeight: remInPx(0.1),
            },
            textStyle: {
              fontFamily: fontFamily
            },
            grid: {
              left: '0%',
              right: '10%',
              top: '2%',
              bottom: '3%',
              containLabel: true
            }
          };
          const options = objacc(this.options, option);
          this.myBar.setOption(options)
        } catch (e) {
          console.log('myBar' + e)
        }
      }
    },
    mounted () {
      this.myBar = echarts.init(this.$el)
      this.init();
    }
  }
</script>

<style lang="less" scoped>
  .bar-area {
    width: 100%;
    height: 5rem;
  }
</style>
