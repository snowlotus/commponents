<template>
  <div class="bar-area" ref="barArea" @touchend.stop="touchend"></div>
</template>

<script>
  import objacc from './utils';
  import {remInPx} from '../../../common/js/comUtils'

  export default {
    name: "barFlow",
    props: {
      options: Object
    },
    data () {
      return {
        myLine: null
      }
    },
    methods: {
      setData (callback) {
        callback(this.myLine)
      },
      touchend () {
        /* 手指离开, 让提示框消失 */
        this.myLine.dispatchAction({
          type: 'hideTip'
        })
      },
      init () {
        const fontFamily = "Arial";
        try {
          /*const options = this.options;
           if (!options.textStyle || !options.textStyle.fontFamily) {
           console.log('成功设置line字体为=>' + fontFamily)
           options.textStyle = {
           fontFamily
           }
           }
           if (options.tooltip && !options.tooltip.position) {
           options.tooltip.position = function (point, params, dom, rect, size) {
           let areaWidth = size.viewSize[0]; // 整个区域的宽度
           let toolWidth = size.contentSize[0]; // 提示框的宽度
           let touchDot = point[0]; // 手指的位置
           let flag = areaWidth - touchDot > toolWidth ? 10 : -(10 + toolWidth);
           let positionValue = touchDot + flag;
           return {
           left: positionValue,
           top: '0%'
           };
           }
           }*/
          const option = {
            textStyle: {
              fontFamily: fontFamily
            },
            title: [
              {
                text: '',
                textStyle: {
                  fontSize: remInPx(0.25),
                  fontWeight: 'normal',
                  color: '#666666'
                },
                top: '85%',
                left: '4%'
              },
              {
                text: '',
                textStyle: {
                  fontSize: remInPx(0.25),
                  fontWeight: 'normal',
                  color: '#666666'
                },
                top: '85%',
                left: 'right'
              }
            ],
            tooltip: {
              trigger: 'axis',
              axisPointer: {
                lineStyle: {
                  color: '#FE8F46'
                }
              },
              backgroundColor: '#FFE0CB',
              textStyle: {
                color: '#FF954E'
              },
              position: function (point, params, dom, rect, size) {
                let areaWidth = size.viewSize[0]; // 整个区域的宽度
                let toolWidth = size.contentSize[0]; // 提示框的宽度
                let touchDot = point[0]; // 手指的左右位置
                let flag = areaWidth - touchDot > toolWidth ? 10 : -(10 + toolWidth);
                let positionValue = touchDot + flag;
                return {
                  left: positionValue,
                  top: '0%'
                };
              },
              formatter: function (a, b, c) {
                let arr = [
                  a.length > 0 ? a[0].axisValue + '<br/>' : ''
                ];
                a.forEach(v => {
                  arr.push(`${v.seriesName}: ${v.value} <br/>`);
                })
                return arr.join('');
              }
            },
            legend: {
              textStyle: {
                fontSize: remInPx(0.22),
                color: '#666'
              },
              itemWidth: remInPx(0.1),
              itemHeight: remInPx(0.1),
              itemGap: 80,
              bottom: 0
            },
            grid: {
              left: '0%',
              right: '2%',
              top: '5%',
              bottom: '10%',
              containLabel: true
            },
            xAxis: {
              show: false,
              type: 'category',
              boundaryGap: false,
              data: []
            },
            yAxis: {
              type: 'value',
              splitLine: {
                show: true,
                lineStyle: {
                  type: 'dashed',
                  color: '#eee'
                }
              },
              axisLine: {
                show: false
              },
              axisTick: {
                show: false
              },
              axisLabel: {
                color: '#999999',
                fontSize: remInPx(0.26)
              }
            },
          };
          const options = objacc(this.options, option);
//        console.log(options);
          this.myLine.setOption(options)
        } catch (e) {
          console.log('myline' + e)
        }
      }
    },
    mounted () {
      this.myLine = echarts.init(this.$el)
      this.init();
    }

  }
</script>

<style lang="less" scoped>
  .bar-area {
    width: 100%;
    height: 5rem;
  }
</style>
