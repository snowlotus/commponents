<template>
  <div class="other-area" ref="barArea"></div>
</template>

<script>
  export default {
    name: "other",
    props: {
      options: Object
    },
    data () {
      return {
        myBar: null
      }
    },
    methods: {
      setData (callback) {
        callback(this.myBar)
      }
    },
    mounted () {
      // console.log(this.options);
      this.myBar = echarts.init(this.$el);
      this.myBar.setOption(this.options);
    }
  }
</script>

<style scoped lang="less">
  .other-area {
    width: 100%;
    height: 5rem;
  }
</style>
