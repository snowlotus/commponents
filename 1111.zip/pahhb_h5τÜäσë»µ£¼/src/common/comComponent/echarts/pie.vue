<template>
  <div class="bar-area" ref="barArea"></div>
</template>

<script>
  import objacc from './utils';
  import {remInPx} from '../../../common/js/comUtils'

  export default {
    name: "pieFlow",
    props: {
      options: Object
    },
    data () {
      return {
        myPie: null
      }
    },
    methods: {
      setData (callback) {
        callback(this.myPie)
      },
      init () {
        const fontFamily = "Arial";
        try {
          const option = {
            textStyle: {
              fontFamily: fontFamily
            },
            grid: {
              left: '0%',
              right: '0%',
              top: '0%',
              bottom: '0%',
              containLabel: false
            }
          };
          const options = objacc(this.options, option);
          this.myPie.setOption(options);
        } catch (e) {
          console.log('mypie' + e)
        }
      }
    },
    mounted () {
      this.myPie = echarts.init(this.$el);
      this.init();
    }
  }
</script>

<style lang="less" scoped>
  .bar-area {
    width: 100%;
    height: 4rem;
  }
</style>
