/**
 * Created by LIKANGDE925 on 2017/12/7.
 */
/*
 * @info 两个对象合并, 已obj1为主, obj2 为辅. 当两个对象同一个key中的值不一样时已obj1的值为主
 * @params obj1 Object
 * @params obj2 Object
 * @return Object  合并后的对象
 * */
function ObjAcc (obj1, obj2) {
  let a = Object.keys(obj1).concat(Object.keys(obj2));
  let b = unique(a);
  let obj = {};
  for (let v of b) {
    obj[v] = null;
    if (obj1[v] !== undefined && obj2[v] !== undefined) {
      let pro1 = Object.prototype.toString.call(obj1[v]);
      let pro2 = Object.prototype.toString.call(obj2[v]);
      if (pro1 === pro2 && pro1 === '[object Object]') {
        obj[v] = ObjAcc(obj1[v], obj2[v]);
      } else {
        obj[v] = obj1[v];
      }
    } else if (obj1[v] !== undefined) {
      obj[v] = obj1[v]
    } else {
      obj[v] = obj2[v]
    }
  }
  return obj;
}
/*
 * @info 数组去冲 仅限数组内部元素都是字符串使用
 * */
function unique (arr) {
  let obj = {};
  for (let v of arr) {
//      console.log(v);
    obj[v] = '';
  }
  return Object.keys(obj);
}
export default ObjAcc;
