<template>
  <div class="bar-area" ref="barArea"></div>
</template>

<script>
  import objacc from './utils';
  import {remInPx} from '../../../common/js/comUtils'
  export default {
    name: "radar",
    props: {
      options: Object
    },
    data () {
      return {
        myRadar: null
      }
    },
    methods: {
      setData (callback) {
        callback(this.myRadar)
      }
    },
    mounted () {
      const fontFamily = "Arial";
      try {
        /*const options = this.options
        if (!options.textStyle || !options.textStyle.fontFamily) {
          console.log('成功设置bar字体为=>' + fontFamily)
          options.textStyle = {
            fontFamily
          }
        }*/
        // const option = {};
        // const options = objacc(this.options, option);
        this.myRadar = echarts.init(this.$el);
        this.myRadar.setOption(this.options);
      } catch (e) {
        console.log('myBar' + e)
      }
    }
  }
</script>

<style lang="less" scoped>
  .bar-area {
    width: 100%;
    height: 5rem;
  }
</style>
