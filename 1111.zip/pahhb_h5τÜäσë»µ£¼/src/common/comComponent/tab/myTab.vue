<template>
  <div class="my-tab-item"><!--:style="{'height': SwiperHieght}"-->
    <div class="my-table-titles b-b" ref="tabTitle" :style="{zIndex: showTitleChild  ? 1000 : 1}">
      <div class="table-title" v-for="(item, num) in titleList"
           :class="{'active': num === index}"
           @click.prevent="changePage(num)">
        <span
          :class="{'red-dot': item.isRed && !item.childs, 'red-dot-right': item.isRed && item.childs, 'childs': item.childs, 'childs-on': item.childs && showTitleChild}">
          {{titleChildActicveText && item.childs ? titleChildActicveText : item.title}}
        </span>
        <transition name="bounce">
          <ul class="title-child" v-if="item.childs && showTitleChild">
            <li v-for="(child, index) in item.childs"
                class="child-item"
                :class="{'cur': titleChildActicve === index}"
                @click="chooseChild(child, index)">
              <div>{{child.title}}</div>
            </li>
          </ul>
        </transition>
      </div>
      <div class="line" :style="lineStyle" @transitionend="transitionend"></div>
    </div>
    <slot name="boardList"></slot>
    <div class="my-swiper-wrap" ref="swiperElem" :style="heights">
      <div class="reMaskWrap" v-if="showTitleChild" @click="chooseChild()"></div>
      <div class="my-swiper-list" :style="listStyles" v-finger:swipe="swiper"
           v-finger:touch-end="touchEnd"
           @transitionend="transitionend">
        <slot></slot>
      </div>
    </div>
  </div>
</template>
<script>
  import {findChild} from '../../js/comUtils'
  let touchStep = 0
  export default {
    name: 'swiper',
    props: {
      value: {
        type: [Number, String],
        default: 0
      },
      titleList: Array,
      height: [String, Number]
    },
    data () {
      return {
        listStyles: {
          left: 0,
          transition: 'none',
          width: 0
        },
        childs: 0, // tab-item 的个数
        swiperWidth: 0, // 外层的总宽度
        index: 0, // 当前选中的title的索引
        lineStyle: { // 下面选中线的样式
          left: 0,
          transition: 'none',
          width: 0
        },
        lineStep: 0, // 每次线移动的距离
        lineLeftStart: 0, // 线左边的距离
        titleHeight: 0, // 选项卡的高度
        SwiperHieght: 0, // 区域的高度
        childActive: -1, // 选中的title的索引 当它与title本身索引一致的时候
        titleChildActicve: 0, // 选中的二级菜单的索引, 用来添加对号
        titleChildActicveText: '', // 选中的二级菜单的文字
        showTitleChild: false,
        borderListHeight: 0 // title 下面插槽的dom高度
      }
    },
    computed: {
      heights () {
        return {
          'height': this.height ? Number(this.height) - this.borderListHeight - this.titleHeight + 'px' : parseInt(this.SwiperHieght) - this.borderListHeight - this.titleHeight + 'px'
        }
      }
    },
    mounted () {
      let index = this.index = ~~this.value;
      this.borderListHeight = this.$slots.boardList && this.$slots.boardList[0] ? this.$slots.boardList[0].elm.offsetHeight : 0;
//      console.log(this.borderListHeight)
      const windowHeight = document.body.clientHeight; // 获取屏幕的可见高度
      const swipetHeight = this.scrollOffsetTop = this.$el.offsetTop; // 获取swiper的容器距离头部的距离
      this.SwiperHieght = this.height ? this.height + 'px' : windowHeight - swipetHeight + 'px';
//      console.log(this.SwiperHieght)
      const swiperItem = this.childs = this.titleList.length;
      const swiperWidth = this.swiperWidth = this.$refs.swiperElem.clientWidth;
      this.listStyles.width = swiperItem * swiperWidth + 'px';
      this.lineStep = Math.ceil(swiperWidth / this.titleList.length);
//      this.lineStyle.left = this.lineLeftStart = Math.ceil(this.lineStep) / 2 - 30 + 'px'
      this.lineStyle.width = this.lineStep + 'px';
      this.listStyles.left = this.swiperWidth * index * -1 + 'px';
      this.lineStyle.left = this.lineStep * index + (parseInt(this.lineLeftStart)) + 'px';
      this.childActive = this.titleList[index].childs ? index : -1;
      this.titleHeight = this.$refs.tabTitle.offsetHeight;
    },
    methods: {
      swiper (evt) {
        if (window.PageStatus.tabhidden) {
          return
        }
        switch (evt.direction) {
          case 'Right':
            if (this.index === 0) {
              return
            }
            this.goPage(--this.index)
            break
          case 'Left':
            if (this.index === this.childs - 1) {
              return
            }
            this.goPage(++this.index)
            break
        }
      },
      touchEnd (){
        if (touchStep > 3 || touchStep < -3) {
          return
        }
        this.listStyles.transition = '300ms'
        this.lineStyle.transition = '300ms'
        this.listStyles.left = this.swiperWidth * this.index * -1 + 'px'
        this.lineStyle.left = this.lineStep * this.index + (parseInt(this.lineLeftStart)) + 'px'
      },
      transitionend () {
        this.listStyles.transition = 'none'
        this.lineStyle.transition = 'none'
      },
      goPage (num) {
        let obj = {};
        this.listStyles.transition = '500ms'
        this.lineStyle.transition = '500ms'
        this.listStyles.left = this.swiperWidth * num * -1 + 'px'
        this.lineStyle.left = this.lineStep * num + (parseInt(this.lineLeftStart)) + 'px'
        this.$emit('input', num)
        obj.title = this.titleList[num].title
        obj.index = num
        this.$emit('on-change', obj);
      },
      changePage (num) {
        if (window.PageStatus.tabhidden) {
          return
        }
        this.index === num ? '' : this.goPage(num);
        this.showTitleChild = (this.childActive === num)
        this.index = num
        this.childActive = (this.titleList[num].childs ? (this.childActive === num ? -1 : num) : -1)
      },
      chooseChild (item, index) {
        if (!item && !index) {
          index = this.index
          this.changePage(index)
          return
        }
        if (this.titleChildActicve === index) {
          return
        }
        this.titleChildActicveText = item.title
        this.titleChildActicve = index
        this.$emit('on-child-change', item)
        this.$emit('on-change', item);
      }
    }
  }
</script>
<style lang="less" scoped>
  @import '../../../common/css/theme';
  @import "../../../common/css/1px.less";

  .b-b {
    .pts-1px-b(#eee);
  }

  .my-table-titles {
    display: flex;
    flex-wrap: nowrap;
    justify-content: space-around;
    width: 100%;
    height: 0.88rem;
    line-height: 0.88rem;
    background: #fff;
    position: relative;
    .table-title {
      flex: 1;
      padding: 0 10px;
      text-align: center;
      font-size: 0.28rem;
      & > span {
        color: #333;
      }
      .title-child {
        width: 100%;
        height: auto;
        position: absolute;
        top: 100%;
        left: 0;
        background: #fff;
        .child-item {
          width: 6.85rem;
          height: .8rem;
          padding: 0 0 0 .65rem;
          font-size: .28rem;
          text-align: left;
          color: #777;
          &.cur {
            color: #FE883A;
            background: #FFffff url(../../../common/images/icon_tick.png) no-repeat 6.85rem center;
            background-size: .21rem .18rem;
          }
          & > div {
            width: 100%;
            border-top: 1px solid #eee;
          }
          &:first-child > div {
            border-top: none;
          }
        }
      }
      &.active > .childs {
        color: @themeC;
        &:after {
          background-image: url(../../../common/images/icon_arrow_cf83.png);
        }
      }
      &.active > span{
        color: @themeC;
      }
      .red-dot {
        position: relative;
        &:before {
          display: block;
          height: 0.14rem;
          width: 0.14rem;
          background: #FF4400;
          border-radius: 50%;
          content: '';
          position: absolute;
          top: 0;
          right: -0.2rem;
        }
      }
      .red-dot-right {
        &:before {
          display: block;
          height: 0.14rem;
          width: 0.14rem;
          background: #FF4400;
          border-radius: 50%;
          content: '';
          position: absolute;
          top: 0;
          right: -0.45rem;
        }
      }
      .childs {
        position: relative;
        &:after {
          display: block;
          content: "";
          position: absolute;
          top: 50%;
          right: -0.34rem;
          width: .19rem;
          height: .14rem;
          margin-top: -0.06rem;
          background: url(../../../common/images/icon_arrow_c343.png) no-repeat 0 0;
          background-size: .14rem .08rem;
        }
      }
      .childs-on {
        position: relative;
        &:after {
          display: block;
          content: "";
          position: absolute;
          top: 50%;
          right: -0.32rem;
          width: .19rem;
          height: .14rem;
          transform: rotate(180deg);
          margin-top: -0.06rem;
          background: url(../../../common/images/icon_arrow_c343.png) no-repeat 0 0;
          background-size: .14rem .08rem;
        }
      }
    }
    .line {
      width: 60px;
      height: 1px;
      position: absolute;
      bottom: 0px;
      left: 0;
      background: @themeC;
    }
  }

  .my-swiper-wrap {
    width: 100%;
    position: relative;
    overflow: hidden;
    .my-swiper-list {
      height: 100%;
      position: absolute;
      top: 0;
      &:after {
        display: block;
        width: 0;
        height: 0;
        content: '';
        clear: both;
      }
    }
  }

  /* 过渡动画开始 */
  .bounce-enter-active {
    animation: scrollBottomIn 100ms;
  }
  .bounce-leave-active{
    animation: scrollTopOut 100ms;
  }
  @keyframes scrollBottomIn {
    from {
      transform-origin: top;
      transform: scaleX(1) scaleY(0);
    }
    to {
      transform-origin: top;
      transform: scaleX(1) scaleY(1);
    }
  }

  @keyframes scrollTopOut {
    from {
      transform-origin: top;
      transform: scaleX(1) scaleY(1);
    }
    to {
      transform-origin: top;
      transform: scaleX(1) scaleY(0);
    }
  }

  /* 过渡动画结束 */
</style>
