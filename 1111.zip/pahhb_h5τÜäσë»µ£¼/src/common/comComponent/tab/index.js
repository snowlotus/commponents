import tab from './myTab.vue'
import tabItem from './tab-item.vue'
tab.Item = tabItem
export default tab
