<template>
  <div class="my-swiper-child" :style="styles">
    <slot></slot>
  </div>
</template>
<script>
  export default {
    name: 'swiper-item',
    data () {
      return {
        styles: {
          width: 0
        }
      }
    },
    mounted () {
      const _this = this
      setTimeout(function () {
        const parent = _this.$options.parent
        if (parent.$options.name === 'swiper') {
          _this.styles.width = 100 / (parent.childs) + '%'
        }
      }, 0)
    }
  }
</script>
<style lang="less" scoped>
  .my-swiper-child {
    float: left;
    height: 100%;
    overflow: hidden;
  }
</style>
