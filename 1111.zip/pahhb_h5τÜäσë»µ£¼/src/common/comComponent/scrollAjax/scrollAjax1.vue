<template>
  <div class="scroll-wrap">
    <div class="scroll-content" ref="contentElem" @touchstart.stop="start($event)"
         @touchmove.prevent.stop="move($event)"
         @touchend.stop="end($event)"
         @transitionend.prevent.stop="transitionend">
      <header class="scroll-header" ref="header" v-show="topAjax">
        <div class="loading-box">
          <div class="loading-img"></div>
          <div class="loading-text">数据加载中...</div>
        </div>
      </header>
      <main class="scroll-main">
        <slot></slot>
      </main>
      <footer class="scroll-footer" ref="footer" v-show="bottomAjax && lsBottom"> <!--v-show="bottomAjax && lsBottom"-->
        <div class="loading-box">
          <div class="loading-img"></div>
          <div class="loading-text">数据加载中...</div>
        </div>
      </footer>
    </div>
  </div>
</template>
<script>
  export default{
    name: 'scrollAjax',
    props: {
      bottomAjax: {
        type: Boolean,
        default: false
      },
      topAjax: {
        type: Boolean,
        default: false
      },
      overflow: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {
        wrapStyle: null,
        wrapElem: null,
        startY: 0,
        startTop: 0,
        startTime: 0,
        wrapHeight: 0,
        contentHeight: 0,
        acceleration: 0,
        timeOut: null,
        headerTop: '',
        isScroll: false,
        lsBottom: false,
        isAjax: true
      }
    },
    methods: {
      /*
       * @info 手指开始接触函数
       * */
      start (e) {
        if (this.overflow) {
          return
        }
        clearInterval(this.timeOut);
        this.startTop = parseInt(this.wrapStyle.top) || 0;
        this.startY = e.changedTouches[0].pageY;
        this.startTime = e.timeStamp || Date.now();
      },
      /*
       * @info 手指移动函数
       * */
      move (e) {
        if (this.overflow) {
          return
        }
        let moveStep = 0 - (this.startY - e.changedTouches[0].pageY);
        let moveDistance = this.startTop + moveStep,
          bottom = this.wrapElem.getBoundingClientRect().bottom, // 页面距离窗口底部的距离
          bottomStep = bottom - this.wrapHeight;
        if (!this.isScroll && moveDistance < 0) return;
        if (moveDistance > 0) {
          moveDistance = parseInt(moveDistance / 4);
        }
        if (this.bottomAjax && bottomStep < 100 && this.isAjax) {
          this.$emit('on-bottom-ajax')
          this.isAjax = false
          this.isScroll = false
//          console.log('下拉加载 => move')
        }
//        console.log('移动 ' + moveDistance);
        this.wrapStyle.top = moveDistance + 'px';
      },
      /*
       * @info 手指移开函数
       * */
      end (e) {
        if (this.overflow) {
          return
        }
        let endTime = e.timeStamp || Date.now(), // 手指离开的时间
          endY = e.changedTouches[0].pageY, // 手指离开的距离
          distance = endY - this.startY, // 手指移动的距离
          time = parseInt(endTime - this.startTime), // 手指在屏幕上移动的时间
          flag;
        flag = this.over();
        if (!this.isScroll && this.wrapStyle.top === this.headerTop) return;
        this.acceleration = (distance / time);// 计算的速度

        if (Math.abs(this.acceleration) < 2 || !flag) {
          // console.log('没有惯性');
          return
        }
        this.timeOut = setInterval(this.motion, 10);
      },
      /*
       * @info 页面缓动函数
       * */
      motion () {
        this.acceleration *= 0.9;
        let stepV = Math.round(this.acceleration * 40),
          top = parseInt(this.wrapStyle.top),
          bottom = this.wrapElem.getBoundingClientRect().bottom, // 页面底部距离窗口顶部的距离
          bottomStep = bottom - this.wrapHeight;
        let topV = stepV + top;
        this.wrapStyle.top = topV + 'px';
//        console.log(topV);
        if (Math.abs(stepV) <= 0 || topV > 100 || bottomStep < 100) {
          clearInterval(this.timeOut);
          this.over();
        }
      },
      /*
       * @info 判断是否到底或者到顶, 并返回页面边缘 且 触发对应的方法的函数;
       * */
      over () {
        let bottom = this.wrapElem.getBoundingClientRect().bottom, // 页面底部距离窗口顶部的距离
          bottomStep = bottom - this.wrapHeight, // 页面距离底部的距离观察是否到底;
          contentHeigtFlag = this.contentHeight - this.wrapHeight > 0, // 判断页面是否需要滚动
          wrapStyle = this.wrapStyle,
          contentTop = parseInt(wrapStyle.top); // 页面顶部的距离 观察是否到顶;
//        console.log(contentTop)
        if (contentTop < 0 && contentTop > parseInt(this.headerTop)) {
          wrapStyle.transition = 'all 500ms';
          wrapStyle.top = this.headerTop;
          return false;
        }
        if (contentTop > 0) {
          wrapStyle.transition = 'all 500ms';
          wrapStyle.top = 0;
          if (this.topAjax && this.isAjax) {
            setTimeout(() => {
              this.lsBottom = false;
              this.isAjax = false;
              this.$emit('on-top-ajax')
            }, 500);
          }
          return false;
        }
        if (contentHeigtFlag && bottomStep < 0) {
          wrapStyle.transition = 'all 500ms';
          wrapStyle.top = -1 * (this.contentHeight - this.wrapHeight) + 'px';
          if (this.bottomAjax && this.isAjax) {
            setTimeout(() => {
//              console.log('下拉加载 => end')
              this.$emit('on-bottom-ajax');
              this.isAjax = false;
            }, 500);
          }
          return false;
        }
        if (bottomStep < 100 && this.bottomAjax && this.isAjax) {
          this.$emit('on-bottom-ajax')
          this.isAjax = false;
//          console.log('下拉加载 => end + <100')
          return false;
        }
        return true;
      },
      /*
       * @info ajax完成后的回调函数
       * @param flag {Boolean} 第一次请求或下拉刷新时需传入true 会将头部动画收回 同时显示下面加载动画;
       * */
      reset (flag) {
        this.isAjax = true;
        this.contentHeight = this.wrapElem.offsetHeight;
        this.wrapHeight = this.$el.offsetHeight;
        this.isScroll = this.contentHeight > this.wrapHeight;
        if (flag) {
          if (this.wrapStyle.top !== this.headerTop) {
            this.wrapStyle.transition = 'all 500ms';
            this.wrapStyle.top = this.headerTop;
          }
          this.lsBottom = true;
        }
      },
      /*
       * @info 过渡完的回调函数
       * */
      transitionend () {
        this.wrapStyle.transition = 'none';
      }
    },
    mounted () {
      const wrapElem = this.$refs.contentElem;
      const headerHeight = this.topAjax ? this.$refs.header.offsetHeight : 0;
      this.headerTop = -1 * headerHeight + 'px';
      wrapElem.style.top = this.headerTop;
      wrapElem.style.transition = 'none';
      this.wrapElem = wrapElem;
      this.wrapStyle = wrapElem.style;
      this.footerElem = this.$refs.footerElem;
    },
    watch: {
      topAjax (to, from) {
        if (to) {
          this.$nextTick(function () {
            this.wrapStyle.top = this.headerTop = this.$refs.header.offsetHeight * -1 + 'px';
          });
        } else {
          this.wrapStyle.top = this.headerTop = '0px';
        }
      },
      bottomAjax (to, from) {
        this.$nextTick(function () {
          this.contentHeight = this.wrapElem.offsetHeight;
        })
      }
    }
  }
</script>
<style lang="less" scoped>
  .scroll-wrap {
    width: 100%;
    height: 100%;
    overflow: hidden;
    position: relative;
    .scroll-content {
      width: 100%;
      position: absolute;
      left: 0;
    }
  }

  .loading-box {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 50px;
    .loading-img {
      width: 0.34rem;
      height: 0.34rem;
      background: url('../../../common/images/loading.png') no-repeat center center / 100% 100%;
      animation: loading 1s linear infinite;
      margin-right: 0.1rem;
    }
  }

  @keyframes loading {
    form {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }

</style>
