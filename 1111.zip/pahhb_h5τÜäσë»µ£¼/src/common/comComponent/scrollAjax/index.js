import scrollAjax from './scrollAjax1.vue'
export default scrollAjax
