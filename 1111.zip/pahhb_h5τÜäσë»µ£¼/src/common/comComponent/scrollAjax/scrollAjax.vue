<template>
  <div class="scroll-ajax-wrap" ref="scrollWrap" @touchmove.stop="touchMove" @touchstart.stop="start"
       @touchend.stop="touchEnd">
    <header class="top-msg msg" ref="topElem">
      <span v-if="showLoading">下拉刷新数据</span>
      <span v-else>加载数据中...</span>
    </header>
    <main class="content-area" ref="contentElem">
      <slot></slot>
    </main>
    <footer class="bottom-msg msg" ref="bottomElem">
      <span v-if="showLoading">上拉加载数据</span>
      <span v-else>加载数据中...</span>
    </footer>
  </div>
</template>
<script>
  import {findParent} from '../utils'
  export default {
    name: 'myscrollAjax',
    props: {
      topAjax: {
        type: Boolean,
        default: false
      },
      bottomAjax: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        /*wrapStyle: {
          paddingTop: '0px',
          transition: 'none',
          overflowY: 'scroll'
        },
        topStyle: {
          height: '0px',
          transition: 'none',
          lineHeight: '0px'
        },
        contentStyle: {
          position: 'static',
          bottom: '0px',
          left: '0px',
          transition: 'none'
        },
        bottomStyle: {
          position: 'static',
          bottom: '0px',
          left: '0px',
          lineHeight: '0px',
          height: 0,
          transition: 'none'
        },*/
        startY: 0,
        startScroll: 0,
        showLoading: true,
        showBottom: false,
        tabVue: null,
        topElem: null,
        bottomElem: null,
        contentElem: null,
        wrapElem: null
      }
    },
    methods: {
      start(e) {
        if (!this.topAjax && !this.bottomAjax) {
          return
        }
        let elem = this.wrapElem;
        let content = this.contentElem.style
        let bottom = this.bottomElem.style
        this.startY = e.targetTouches[0].pageY
        this.startScroll = elem.scrollTop || 0;
        if (this.bottomAjax && (elem.scrollTop + elem.clientHeight) >= elem.scrollHeight) {
          this.showBottom = true
          content.position = 'relative'
          bottom.position = 'absolute'
        } else {
          this.showBottom = false
          content.position = bottom.position = 'static'
        }
      },
      touchMove(e) {
        if (!this.topAjax && !this.bottomAjax) {
          return
        }
        let moverNum = e.targetTouches[0].pageY - this.startY - this.startScroll;
        let top = this.topElem.style, bottom = this.bottomElem.style;
        if (this.startScroll === 0) {
          let wrap = this.wrapElem.style;
          let step = parseInt(moverNum / 4)
          top.lineHeight = top.height = wrap.paddingTop = moverNum > 0 ? step + 'px' : top.height
        }
        let bottomMove = moverNum + this.startScroll
        if (this.showBottom && bottomMove < 0) {
          let content = this.contentElem.style;
          bottom.lineHeight = bottom.height = content.bottom = bottomMove / 4 * -1 + 'px'
        }
      },
      reset(flag) {
        let elem = this.$el,
          elemHeight = elem.offsetHeight, // 可是区域的高度, 就是div本身的高度
          elemScrollHeight = elem.scrollHeight; // div的实际高度
//        console.log(elemScrollHeight)
        this.bottomElem.style.bottom = (elemScrollHeight - elemHeight) * -1 + 'px'
        if (flag) {
          let top = this.topElem.style,
            wrap = this.wrapElem.style;
          top.transition = wrap.transition = '500ms'
          top.lineHeight = top.height = wrap.paddingTop = '0px'
          setTimeout(function () {
            top.transition = wrap.transition = 'none'
            this.showLoading = true
            wrap.overflowY = 'scroll'
          }.bind(this), 500)
        } else {
          let content = this.contentElem.style,
            bottom = this.bottomElem.style,
            wrap = this.wrapElem.style;
          bottom.transition = content.transition = 'none'
          bottom.lineHeight = bottom.height = content.bottom = '0px'
          this.showLoading = true
          wrap.overflowY = 'scroll'
        }
      },
      touchEnd(e) {
        if (!this.topAjax && !this.bottomAjax) {
          return
        }
        let top = this.topElem.style,
          wrap = this.wrapElem.style,
          content = this.contentElem.style,
          bottom = this.bottomElem.style,
          endX = e.changedTouches[0].pageX,
          endY = e.changedTouches[0].pageY,
          dy = this.startY - endY,
          dx = endX - this.startX;
        if (Math.abs(dx) < 2 && Math.abs(dy) < 2) {
          console.log("滑动距离太短")
          return;
        }
        if (parseInt(top.height) > 40) {
          top.transition = wrap.transition = '500ms'
          top.lineHeight = top.height = wrap.paddingTop = '50px'
          this.showLoading = false
          setTimeout(function () {
            top.transition = wrap.transition = 'none'
            wrap.overflowY = 'hidden'
            this.$emit('on-top-ajax')
          }.bind(this), 500)
        } else if (parseInt(top.height) !== 0) {
          top.transition = wrap.transition = '500ms'
          top.lineHeight = top.height = wrap.paddingTop = '0px'
          setTimeout(function () {
            top.transition = wrap.transition = 'none'
          }.bind(this), 500)
        }
        if (this.showBottom && parseInt(bottom.height) > 40) {
          bottom.transition = content.transition = '500ms'
          bottom.lineHeight = bottom.height = content.bottom = '50px'
          this.showLoading = false
          setTimeout(function () {
            bottom.transition = content.transition = '500ms'
            wrap.overflowY = 'hidden'
            this.$emit('on-bottom-ajax')
          }.bind(this), 500)
        } else if (this.showBottom && parseInt(bottom.height) !== 0) {
          bottom.transition = content.transition = '500ms'
          bottom.lineHeight = bottom.height = content.bottom = '0px'
          setTimeout(function () {
            bottom.transition = content.transition = 'none'
          }.bind(this), 500)
        }
      }
    },
    mounted () {
      this.tabVue = findParent(this, 'swiper')
      this.topElem = this.$refs.topElem
      this.contentElem = this.$refs.contentElem
      this.bottomElem = this.$refs.bottomElem
      this.wrapElem = this.$el
    }
  }
</script>
<style lang="less">
  .scroll-ajax-wrap {
    width: 100%;
    height: 100%;
    overflow-x: hidden;
    overflow-y: scroll;
    -webkit-overflow-scrolling: touch;
    box-sizing: border-box;
    position: relative;
    .msg {
      text-align: center;
    }
    .top-msg {
      position: absolute;
      top: 0;
      left: 0;
      height: 0%;
      width: 100%;
      overflow: hidden;
    }
    .bottom-msg {
      height: 0px;
      width: 100%;
      line-height: 0px;
      overflow: hidden;
    }
  }
</style>
