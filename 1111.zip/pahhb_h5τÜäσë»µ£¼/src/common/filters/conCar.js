import Vue from 'vue';
/* 新车无车牌时 显示*_* */
Vue.filter('vehicleFrameNoHidden', function (value) {
  if (!value) return value
  if (value.indexOf('*') > -1) {
    return '*_*'
  } else {
    return value
  }
})
