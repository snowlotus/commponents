import Vue from 'vue';
/* 电话号隐藏中间四位 *_* */
Vue.filter('phoneNum', function (value) {
  if (!value) return value
  if (Number.isNaN(Number(value))) return value;
  let arr_num = value.split("");
  arr_num.splice(4, 4, '****');
  return arr_num.join('');
})
