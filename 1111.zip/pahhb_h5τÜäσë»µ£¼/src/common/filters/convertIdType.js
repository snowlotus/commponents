
/**
 * example
 * <!-- '01' => '身份证' -->
 * <span v-text="certificateType | convertIdType"></span>
 */

import Vue from 'vue'

Vue.filter('convertIdType', function(value) {
  let certificateTypeMap = {
    '01': '身份证',
    '02': '护照',
    '03': '军官证',
    '05': '驾驶证',
    '06': '港澳回乡证或台胞证',
    '07': '组织机构代码证',
    '99': '其它'
  }
  return certificateTypeMap[value]
})
Vue.filter('taskStatusType', function(value) {
  let taskStatusTypeMap = {
    '00': '报案',
    '01': '定损',
    '02': '理算',
    '03': '结案'

  }
  return taskStatusTypeMap[value]
})
//赔付结论 00:赔付 01:零结 02:商业险拒赔 03:整案拒赔 04:注销 ,
Vue.filter('indemnityConclusionType', function(value) {
  let indemnityConclusionTypeMap = {
    '1': '赔付',
    '2': '零结',
    '3': '商业险拒赔',
    '4': '整案拒赔',
    '5': '注销',
  }
  return indemnityConclusionTypeMap[value]
})
//赔付结论 1:单方 2:多方
Vue.filter('threaAdvice', function(value) {
  let threaAdviceMap = {
    '1': '单方事故',
    '2': '多方事故'
  }
  return threaAdviceMap[value]
})
//是否有人受伤
Vue.filter('isInjured',function (value) {
  let isInjuredMap = {
    'Y' : '(有人伤)',
    'N' : ''
  }
  return isInjuredMap[value];
})

//surveyorStatus (string, optional): 复勘任务状态 00:无 01:待复勘 02:已复勘 ,
Vue.filter('surveyorStatusType', function(value) {
  let surveyorStatusTypeMap = {
    '00': '无',
    '01': '待复勘',
    '02': '已复勘'
  }
  return surveyorStatusTypeMap[value]
})
//caseStatus (string, optional),任务状态 00:报案 01:定损 02:核损 03:理算 04:已结案 ,
Vue.filter('inCaseStatusType', function(value) {
  let caseStatusTypeMap = {
    '00': '报案',
    '01': '定损',
    '02': '理算',
    '03': '已结案'
  }
  return caseStatusTypeMap[value]
})
//caseStatus (string, optional),任务状态 00:报案 01:定损 02:核损 03:单证齐全 04:已结案 ,
Vue.filter('caseStatusType', function(value) {
  let caseStatusTypeMap = {
    '00': '报案',
    '01': '定损',
    '02': '核损',
    '03': '单证齐全',
    '04': '已结案'
  }
  return caseStatusTypeMap[value]
})
//"支付状态  00:待开单 01:支付异常 02:待支付(待抽档) 03:待支付(已抽档)  04:待支付(已送盘) 05:待支付 06:支付成功 07:作废 08:退回待修改下发
Vue.filter('payStatusType', function(value) {
  let payStatusTypeMap = {
    '00': '待开单',
    '01': '支付异常',
    '02': '待支付(待抽档)',
    '03': '待支付(已抽档)',
    '04': '待支付(已送盘)',
    '05': '待支付',
    '06': '支付成功',
    '07': '作废',
    '08': '退回待修改下发'
  }
  return payStatusTypeMap[value]
})
//手机号码格式化
Vue.filter('phoneType', function(value) {
    if (!value) {
      return value
    }
    let arr = (value + '').split('')
    if (arr.length > 3) {
      arr.splice(3, 0, '-')
    }
    if (arr.length > 7) {
      arr.splice(8, 0, '-')
    }
    return arr.join('')
})

