/**
 * example
 * <!-- 'F' => '女' -->
 * <span v-text="sex | convertSex"></span>
 */
import Vue from 'vue'

Vue.filter('convertSex', function (value) {
	let sexMap = {
			"M": "男",
			"F": "女"
		}
  return sexMap[value]
})