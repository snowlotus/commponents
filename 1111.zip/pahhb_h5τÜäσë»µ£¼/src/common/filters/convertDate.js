/**
 * example
 * <!-- 'M' => '月' -->
 * <span v-text="termUnit | convertDate"></span>
 */
import Vue from 'vue'

Vue.filter('convertDate', function (value) {
  let dateMap = {
    'M': '月',
    'D': '天'
  }
  return dateMap[value]
})
Vue.filter('formatMonth', function (value) {
  if (typeof value == 'string') {
    let month = ~~value;
    return month < 10 ? '0' + month : month
  } else {
    return value < 10 ? '0' + value : value
  }
})
Vue.filter('chineseMonth', function (value) {
  let num = Number(value)
  if (isNaN(num)) {
    return value
  }
  let chinese = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二']
  return chinese[num]
})
