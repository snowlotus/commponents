
/**
 * example
 * <!-- '01' => '身份证' -->
 * <span v-text="certificateType | convertIdType"></span>
 */

import Vue from 'vue'

Vue.filter('thermometerType', function(value,flag) {
  let thermometerType
  if(flag&&flag==='month'){
    thermometerType = {
      '0': '未确认',
      '1': '已确认',
    }
  }else{
    thermometerType = {
      '0': '未填写',
      '1': '已填写',
    }
  }

	return thermometerType[value]
})

