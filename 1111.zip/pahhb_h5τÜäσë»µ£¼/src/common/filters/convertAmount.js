/**
 * example
 * <!-- '10000' => '1万' -->
 * <!-- '5000' => '0.5万' -->
 * <span v-text="termUnit | convertDate"></span>
 */
import Vue from 'vue'

Vue.filter('convertAmount', function (value) {
  if (Number.isNaN(Number(value))) {
    return value
  }
  if (Number(value) >= 1000) {
    return Number(value) / 10000 + '万'
  }
  if (Number(value) < 1000) {
    return Number(value)
  }
})
Vue.filter('Amount', function (value) {
  if (Number.isNaN(Number(value))) {
    return value;
  }
  if (Number(value) / 10000 >= 1) {
    return Number(value / 10000) + '万'
  } else {
    return value;
  }
})
// 数字每三位加一个逗号
Vue.filter('NumberThere', function (value) {
  if (Number.isNaN(Number(value))) {
    return value;
  }
  if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
    return Number(value).toLocaleString();
  } else {
    return value;
  }
})

Vue.filter('fourSpace', function (v) {
  if (!v) return v
  let arr = v.split('');
  for (let i = 0; i < arr.length; i++) {
    if (i % 5 === 0) {
      arr.splice(i, 0, ' ')
    }
  }
  return arr.join('')
})

Vue.filter('thereSpace', function (value) {
  if (!value) {
    return value
  }
  let arr = (value + '').split('')
  if (arr.length > 3) {
    arr.splice(3, 0, ' ')
  }
  if (arr.length > 7) {
    arr.splice(8, 0, ' ')
  }
  return arr.join('')
})
