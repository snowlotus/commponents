/**
 * example
 * <!-- '9' => '其他' -->
 * <span v-text="relationshipWithInsurer | convertRelation"></span>
 */
import Vue from 'vue'

Vue.filter('convertRelation', function(value) {
	let relationMap = {
		'1': '本人',
		'2': '配偶',
		'3': '父子',
		'4': '父女',
		'A': '母子',
		'B': '母女',
		'H': '雇佣',
		'9': '其它',
		'5': '父母',
		'6': '子女'
	}
	return relationMap[value]
})