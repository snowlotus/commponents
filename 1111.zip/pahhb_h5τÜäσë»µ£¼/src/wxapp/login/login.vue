<template>
  <div class="box">
    <div class="login">
      <div class="logo">
        <div>
          <img :src="logoUrl"/>
        </div>
      </div>
      <div class="message">
        <div class="label">
          <div class="icon">
            <img :src="iconPerson">
          </div>
          <div class="inputBox inputPhone">
            <input
              class="phone"
              type="tel"
              placeholder="输入手机号码"
              v-model="phone"
              oninput="if(value.length>13){value=value.slice(0,13)};"
            />
            <div class="clase" v-if="phoneClase" @click.stop="clase('phone')">
              <img :src="iconClose">
            </div>
          </div>
        </div>
        <div class="label">
          <div class="icon">
            <img :src="iconVerification">
          </div>
          <div class="inputBox inputVerification">
            <div class="input">
              <input
                class="verification"
                type="number"
                placeholder="输入验证码"
                v-model="verification"
                oninput="if(value.length>6){value=value.slice(0,6)};"
              />
              <div class="clase" v-if="verificationClase" @click.stop="clase('verification')">
                <img :src="iconClose">
              </div>
            </div>
            <div class="getVerificationButton" @click.stop="getVerification"
                 :class="phoneBool?'activeGetVerificationButton':''">
              <div class="borderLeft"></div>
              {{ verificationText }}
            </div>
          </div>
        </div>
      </div>
      <div class="loginButton" :class="isCanLogin?'activeLoginButton':''" @click.stop="login">
        登录
      </div>
    </div>
  </div>
</template>

<script>
  var wx = require('weixin-js-sdk')
  
  import allValidate from '@/common/js/comValidate'
  import Toast from '../../common/comComponent/toast'
  import API from '../../common/js/comConfig'
  import Axios from '../../common/js/axiosConfig'
  import ptsHeader from '../../common/comComponent/header'
  import {setCookie, getNow} from '@/common/js/comUtils'
  import {getCookie} from '../../common/js/comUtils'
  import Visibility from 'visibilityjs'

  let timer;
  let openIdData, toPath
  export default {
    name: 'login',
    components: {
      ptsHeader
    },
    data() {
      return {
        //好伙伴logo
        logoUrl: require('./../../common/images/icon_app_haohuoban.png'),
        //手机号码图标
        iconPerson: require('./../../common/images/loginPhone.png'),
        //验证码图标
        iconVerification: require('./../../common/images/loginVerification.png'),
        //清除按钮
        iconClose: require('./../../common/images/clase.png'),
        //手机号码
        phone: '',
        //手机号码是否通过正则
        phoneBool: false,
        //手机号码的清除输入按钮显示
        phoneClase: false,
        //验证码
        verification: '',
        //验证码是否为6位的验证码
        verificationBool: false,
        //手机号码的清除输入按钮显示
        verificationClase: false,
        //登录按钮的状态
        isCanLogin: false,
        //验证码文字
        verificationText: '获取验证码',
        //是否第一次获取验证码
        firstGetVerification: true,
        //倒计时时间
        second: 50
      }
    },
    created() {
      let self = this
    },
    watch: {
      //监听phone的变化
      phone: function (newValue) {
        //格式化电话号码
        var value = newValue.replace(/\D/g, '').substring(0, 11)
        var valueLen = value.length
        if (valueLen > 3 && valueLen < 8) {
          value = `${value.substr(0, 3)} ${value.substr(3)}`
        } else if (valueLen >= 8) {
          value = `${value.substr(0, 3)} ${value.substr(3, 4)} ${value.substr(7)}`
        }
        this.$set(this, 'phone', value)
        //显示可以清除电话号码的按钮
        if (newValue.length > 0) {
          this.$set(this, 'phoneClase', true)
        } else {
          this.$set(this, 'phoneClase', false)
        }
        //校验手机号码
        if (allValidate.checkMobile(newValue) === true) {
          this.$set(this, 'phoneBool', true)
          this.canLogin(true, this.verificationBool)
          return
        }
        this.$set(this, 'phoneBool', false)
        this.canLogin(false, this.verificationBool)
      },
      verification: function (newValue) {
        if (newValue.length > 0) {
          this.$set(this, 'verificationClase', true)
        } else {
          this.$set(this, 'verificationClase', false)
        }
        if (newValue.length === 6) {
          this.$set(this, 'verificationBool', true)
          this.canLogin(this.phoneBool, true)
          return
        }
        this.$set(this, 'verificationBool', false)
        this.canLogin(this.phoneBool, false)
      }
    },
    mounted() {
      //内部端
      //this.$set(this,'phone','185 6624 9624')
      //外部端
      //this.$set(this, 'phone', '135 2222 2222')
      //this.$set(this, 'verification', '123123')
    },
    methods: {
      //判断下面登录按钮是否可以点击
      canLogin: function (phoneBool, verificationBool) {
        if (phoneBool && verificationBool) {
          this.$set(this, 'isCanLogin', true)
          return
        }
        this.$set(this, 'isCanLogin', false)
      },
      //获取验证码
      getVerification: function () {
        let self = this
        if (self.phoneBool) {
          if (self.firstGetVerification) {
            let reqData = {
              mobilePhone: self.phone.replace(/\D/g, ''),
              checkType: '01'
            }
            Axios.post(API.getWebServiceUrls('getVerification'), reqData)
              .then(res => {
                if (res.data.code === 0) {
                  Toast('发送成功')
                  self.$set(self, 'firstGetVerification', false)
                  
                  timer=Visibility.every(1000,1000, function () {
                      self.countdown();
                  });

                } else {
                  Toast(res.data.msg)
                }
              })
              .catch(err => {
                console.log(err)
              })
          } else {
            Toast('验证码已发送,请注意查收')
          }
        }
      },
      countdown(){
        let self =this;
        // timer = window.setInterval(function () {
          if (self.second > -1) {
            let second = self.second
            self.$set(self, 'verificationText', second + 's')
            second--
            self.$set(self, 'second', second)
          } else {
            self.$set(self, 'verificationText', '获取验证码')
            self.$set(self, 'second', 120)
            self.$set(self, 'firstGetVerification', true)
            Visibility.stop(timer)
          }
        // }, 1000)
      },
      //清除输入框
      clase: function (value) {
        this.$set(this, value, '')
      },
      //登录
      login: function () {
        let self = this
        openIdData = self.$route.query.openIdData
          ? self.$route.query.openIdData
          : getCookie('openIdData') ? getCookie('openIdData') : 'qubudao'
        toPath = self.$route.query.toPath ? self.$route.query.toPath : '/'
        if (this.phoneBool && this.verificationBool) {
          let reqData = {
            username: self.phone.replace(/\D/g, ''),
            messageCode: self.verification,
            idPtsWechatAccInfo: openIdData ? openIdData : ''
          }
          updataToken(reqData)
        }
      }
    }
  }
  const head = {
    deviceId: '1111-2222-3333-4444',
    appType: '1',
    deviceType: '4',
    appVersion: '1.0.1'
  }
  window.urlHeader = head
  let cookies = {
    deviceId: '1111-2222-3333-4444',
    appType: '1',
    deviceType: '4',
    appVersion: '1.0.1'
  }
  let dealerCode = '',
    dealerName = '',
    dealerType = '',
    innerAccountRoleType = ''

  //登录
  function updataToken(reqData) {
    Axios.post(API.getWebServiceUrls('login'), reqData)
      .then(res => {
        if (res.data.code === 0) {
          head.token = res.headers.token
          cookies.token = res.headers.token
          window.urlHeader = cookies
          verifyTokenSecond()
        } else {
          console.log('获得到token失败, 原因: ')
          Toast(res.data.msg)
        }
      })
      .catch(err => {
        console.log('获得到token失败, 原因: ')
        console.log(err)
      })
  }

  // 获取账户信息
  function verifyTokenSecond() {
    Axios.post(API.getWebServiceUrls('verifyTokenSecond'))
      .then(res => {
        if (res.data.code === 0) {
          let userInfo = res.data.data.userInfoVO
          head.innerAccountRoleType = userInfo.innerAccountRoleType //内部端账户的角色类型
          head.dealerType = userInfo.dealerType //车商类型
          head.dealerCode = userInfo.dealerCode //车商名代码
          head.dealerName = userInfo.dealerName //车商名称
          head.deptName = userInfo.deptName //机构名称
          head.deptCode = userInfo.deptCode //机构代码
          setCookie('header', JSON.stringify(head))
          //准备埋点数据
          let obj = {};
          obj = {
            用户账号: userInfo.dealerName + '_' + userInfo.cellphone + "_" + userInfo.name,
          };
          if (!userInfo.dealerName) {
            obj['车商名称'] = userInfo.dealerName;
          } else if (!userInfo.dealerCode) {
            obj['车商编码'] = userInfo.dealerCode;
          } else if (!userInfo.deptCode) {
            obj['机构编码'] = userInfo.deptCode;
          }
          window._MD_OPTONS = obj
          let setObj = obj
          setObj['名字'] = userInfo.name
          setObj['登录时间'] = getNow()
          window.eventAnalytics('手机号登录', '登录成功', setObj)
          //当前没有回退路径了则在登录成功后回到小程序主页 add by snowdrop
          if(toPath==='/' && window.__wxjs_environment === 'miniprogram'){
            wx.miniProgram.switchTab({url: '/pages/index/index'})
          }else{
            //拼接路径跳转
            let url = `${location.href.split('#')[0]}#${toPath}`
            window.location.replace(url)
          }
          
        } else {
          console.log('校验第二次token失败, 原因: ')
          Toast(res.data.msg)
        }
      })
      .catch(err => {
        console.log('校验第二次token失败, 原因:')
        console.log(err)
      })
  }
</script>

<style lang="less">
  .login {
    * {
      box-sizing: border-box;
    }
    position: absolute;
    width: 100%;
    top: 0;
    bottom: 0;
    background: #fff;
    overflow-x: hidden;
    overflow-y: scroll;
    .logo {
      position: relative;
      width: 100%;
      height: 4rem;
      & > div {
        width: 1.3rem;
        height: 1.3rem;
        position: absolute;
        top: 1.8rem;
        left: 3.1rem;
        overflow: hidden;
        & > img {
          width: 100%;
          height: 100%;
        }
      }
    }
    .message {
      .label {
        line-height: 0.7rem;
        margin: 0 0.55rem;
        padding: 0.1rem 0;
        height: 0.9rem;
        border-bottom: 1px solid #eee;
        display: flex;
        .icon {
          width: 0.6rem;
          height: 0.7rem;
          img {
            height: 100%;
            width: 100%;
          }
        }
        .inputBox {
          flex: 1;
          overflow: hidden;
          padding-left: 0.4rem;
          position: relative;
          input {
            width: 100%;
            height: 100%;
            font-size: 0.28rem;
          }
          .clase {
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            width: 0.4rem;
            img {
              width: 0.3rem;
              height: 0.3rem;
              position: absolute;
              left: 50%;
              top: 50%;
              transform: translate(-50%, -50%);
            }
          }
        }
        .inputPhone {
          padding-right: 0.4rem;
        }
        .inputVerification {
          display: flex;
          .input {
            position: relative;
            padding-right: 0.4rem;
            flex: 7;
            overflow: hidden;
          }
          .getVerificationButton {
            flex: 3;
            overflow: hidden;
            text-align: right;
            color: #ccc;
            position: relative;
            .borderLeft {
              position: absolute;
              width: 0.02rem;
              height: 0.5rem;
              left: -0.02rem;
              top: 0.1rem;
              background: #ccc;
            }
          }
          .activeGetVerificationButton {
            text-align: right;
            color: #FE883A;
          }
        }
      }
    }
    .loginButton {
      font-size: 0.32rem;
      margin: 20px 20px 0;
      height: 0.9rem;
      text-align: center;
      line-height: 0.9rem;
      background: #ccc;
      color: #ffffff;
      border-radius: 3px;
    }
    .activeLoginButton {
      background: #FE883A;
    }
  }
</style>
