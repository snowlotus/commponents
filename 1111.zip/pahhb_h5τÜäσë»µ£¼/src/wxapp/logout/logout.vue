<template>
    <div class="menuList ">
		<div class="menu menu2  "   @click="logout">
			<div class="leftIcon">
				<img class="image"  :src="logoutIcon"/>
			</div>
			<div class="midText">退出登录</div>
			<div class="rightIcon">
				<img class="image" :src="rightIcon"/>
			</div>
		</div>
	</div>
</template>

<script>
import API from '../../common/js/comConfig'
import Axios from '../../common/js/axiosConfig'
import Toast from '../../common/comComponent/toast'

import {delCookie,setCookie, getCookie} from '../../common/js/comUtils'

export default {
    data(){
        return{
            rightIcon:require('../../common/images/right_arrow.png'),
            logoutIcon:require('../../common/images/icon_logout.png')
        }
    },
    created(){
        this.logout();
    },
    methods:{
        logout(){
            Axios.post(API.getWebServiceUrls('logout'))
            .then(res=>{
                if(res.data){
                    if (window.__wxjs_environment === 'miniprogram') {
                        let openId=getCookie('openIdData')||this.getParameterByName('openIdData'),
                            href=openId?'#/login?openIdData='+openId:'#/login';
                        delCookie('header')
                        location.href=href;
                    }
                }
            })
        },
        getParameterByName(name) {
            name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.href);
            return results == null ? "": decodeURIComponent(results[1]);
        }
    }
}
</script>

<style lang="less" scoped>
    .menuList {
        padding: 0 0 0 .3rem;
        background: #fff;
        margin-top: .2rem;
    }
    .menuList .menu {
        height: 1rem;
        position: relative;
        box-sizing: border-box;
    }
    .menuList .menu .leftIcon {
        width: .35rem;
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        img{
            width: 100%;
            height: 100%;
        }
    }
    .menuList .menu .midText {
        padding: 0 .6rem;
        line-height: 1rem;
        font-family: PingFangSC-Medium;
        font-size: .28rem;
        color: #333333;
    }
    .menuList .menu .rightIcon {
        width: .2rem;
        height: .28rem;
        position: absolute;
        right: .3rem;
        top: 50%;
        transform: translateY(-50%);
    }
    .menuList .menu .rightIcon .image {
        position: absolute;
        top: 0;
        left: 0;
        width:100%;
        height: 100%;
    }
</style>

