<template>
  <div class="box" :class="isWXSHOWHEADER?'':'wx_box'">
    <pts-header titleText="极速报价" v-if="isWXSHOWHEADER"></pts-header>
    <div class="hasteOffer">
      <div class="label">
        <div class="line headerLine">
          <div class="point"></div>
          车辆信息
        </div>
        <div class="line">
          <div class="left">车型</div>
          <div class="right" @click="chooseCarType">
            <span>{{car.carMainDesc?car.carMainDesc:'请选择车型'}}</span>
            <i>
              <img :src="arrowLeft"/>
            </i>
          </div>
        </div>
        <div class="line">
          <div class="left">新车购置价</div>
          <div class="right">{{car.carPrice?car.carPrice:''}}</div>
        </div>
      </div>
      <div class="label" v-if="list.length>0">
        <div class="line headerLine">
          <div class="point"></div>
          代理人信息
        </div>
        <div class="line">
          <div class="left">代理人</div>
          <div class="right">
            <popup-picker 
              :data="list" 
              v-model="value"
              :columns="1"
              :show-name="true"
            ></popup-picker>
          </div>
        </div>
      </div>
      <div class="label">
        <div class="line headerLine">
          <div class="point"></div>
          车主基本信息
        </div>
        <div class="line">
          <div class="left">年龄</div>
          <div class="right">
            <input 
              type="number" 
              v-model="age" 
              class="age"
						  oninput="if(value.length>2){value=value.slice(0,2)};"
            />
          </div>
        </div>
        <div class="line">
          <div class="left">性别</div>
          <div class="right">
            <div class="gender man" @click="checkGender(1)">
              <div>
                <div class="iconGender"><img :src="gender===1?activeIcon:unActiveIcon"></div>男</div>
            </div>
            <div class="gender women" @click="checkGender(0)">
              <div>
                <div class="iconGender"><img :src="gender===0?activeIcon:unActiveIcon"></div>女</div>
              </div>
            </div>
            <!-- <div class="gender man" @click="checkGender(1)">
              <div v-if="gender===1"><div class="iconGender"><img :src="activeIcon"></div>男</div>
              <div v-else><div class="iconGender"><img :src="unActiveIcon"></div>男</div>
            </div>
            <div class="gender women" @click="checkGender(0)">
              <div v-if="gender===0"><div class="iconGender"><img :src="activeIcon"></div>女</div>
              <div v-else><div class="iconGender"><img :src="unActiveIcon"></div>女</div>
            </div>
          </div> -->
        </div>
      </div>
      <div class="button" @click.stop="hasteOffer" :class="isHasteOffer?'isHasteOffer':''">
        极速报价
      </div>
      <form :action="imcsTranData.imcsUrl" method="post" id="goToImcs" name="goToImcs" ref="formElem">
        <input type="hidden" :value="imcsTranData.params" name="params" />
        <input type="hidden" :value="imcsTranData.signData" name="signData" />
        <input type="hidden" :value="imcsTranData.systemId" name="systemId" />
      </form>
    </div>
  </div>
</template>

<script>
import Toast from '../../common/comComponent/toast'
import API from '../../common/js/comConfig'
import Axios from '../../common/js/axiosConfig'
import ptsHeader from '../../common/comComponent/header'
import { isLogin } from '@/common/js/comUtils'
import { PopupPicker } from 'vux'
export default {
  created() {},
  components: {
    ptsHeader,
    PopupPicker
  },
  data() {
    return {
      // 左箭头的地址
      arrowLeft: require('@/common/images/arrowLeft2.png'),
      //选中性别按钮
      activeIcon: require('@/common/images/icon_cnState.png'),
      //未选中性别按钮
      unActiveIcon: require('@/common/images/Select_box_check.png'),
      //年龄
      age: 36,
      //性别
      gender: 1,
      //车辆信息
      car: {},
      //是否可以点击
      isHasteOffer: false,
      //是否显示头部
      isWXSHOWHEADER: window.PageStatus.WX_SHOW_HEADER,
      //代理人|经纪人类型
      type: '',
      //代理人|经纪人列表
      list: [],
      //代理人|经纪人值
      value: [],
      //from表单提交的数据
      imcsTranData: {}
    }
  },
  methods: {
    //性别切换
    checkGender: function(value) {
      this.$set(this, 'gender', value)
    },
    //跳转选择车型
    chooseCarType: function() {
      this.$router.push({ path: '/outside/chooseCar' })
    },
    //极速报价的接口
    hasteOffer: function() {
      let _this = this
      if (this.isHasteOffer) {
        let reqData = {
          age: _this.age,
          carId: _this.car.carId,
          sex: _this.gender == 1 ? 'M' : 'F'
        }
        if (_this.type == 'agent') {
          for (let i = 0; i < _this.list.length; i++) {
            if (_this.list[i].value == _this.value[0]) {
              reqData.agentCode = _this.list[i].value
              reqData.agentName = _this.list[i].name
              reqData.agentAgreementNo = _this.list[i].conferNo
              reqData.supplementAgreementNo = _this.list[i].subConferNo
            }
            break
          }
        } else if (_this.type == 'broker') {
          reqData.brokerCode = _this.value[0]
        }
        Axios.post(API.getWebServiceUrls('hasteOfferFastquotation'), reqData)
          .then(res => {
            let resData = res.data
            if (resData.code == 0) {
              _this.$set(_this,'imcsTranData',resData.data)
              setTimeout(function() {
                _this.$refs.formElem.submit()
              }, 10)
            } else {
              Toast(res.data.msg)
            }
          })
          .catch(err => {
            console.log(err)
          })
      }
    },
    //获取代理|经纪人列表
    getUserOrganizationInsuranceInfo: function() {
      let _this = this
      Axios.post(
        API.getWebServiceUrls('hasteofferGetUserOrganizationInsuranceInfo')
      )
        .then(res => {
          if (res.data.code === 0) {
            let list,
              type,
              setList = []
            if (res.data.data.agentList && res.data.data.agentList.length > 0) {
              list = res.data.data.agentList
              type = 'agent'
              _this.$set(_this, 'type', 'agent')
            } else if (
              res.data.data.brokerList &&
              res.data.data.brokerList.length > 0
            ) {
              list = res.data.data.brokerList
              type = 'broker'
              _this.$set(_this, 'type', 'broker')
            }
            if (list) {
              for (let i = 0; i < list.length; i++) {
                setList.push({
                  name: list[i][`${type}Name`],
                  value: list[i][`${type}Code`],
                  conferNo: list[i]['conferNo'],
                  subConferNo: list[i]['subConferNo'],
                  parent: 0
                })
              }
              _this.$set(_this, 'list', setList)
              _this.$set(_this, 'value', [list[0][`${type}Code`]])
            }
          } else {
            Toast(res.data.msg)
          }
        })
        .catch(err => {
          console.log(err)
        })
    }
  },
  activated() {
    if (sessionStorage.getItem('car')) {
      let car = JSON.parse(sessionStorage.getItem('car'))
        ? JSON.parse(sessionStorage.getItem('car'))
        : {}
      sessionStorage.removeItem('car')
      this.$set(this, 'car', car)
      this.getUserOrganizationInsuranceInfo()
    } else if (this.$route.query.carId) {
      this.$set(this, 'car', this.$route.query)
      this.getUserOrganizationInsuranceInfo()
    }
  },
  watch: {
    'car.carMainDesc': function(newValue) {
      this.$set(this, 'isHasteOffer', true)
    }
  }
}
</script>

<style lang="less">
.overwrite{
	overflow: hidden;
	text-overflow:ellipsis;
	white-space: nowrap;
}
  .hasteOffer{
    width: 100%;
    height: 100%;
    overflow-x: hidden;
    overflow-y: scroll; 
    position: relative;
    font-size: 0.28rem;
    .label{
      margin-bottom: 0.2rem;
      background: #fff;
      .line{
        color: #666;
        box-sizing: border-box;
        overflow: hidden;
        padding: 0 0.3rem;
        height: 0.88rem;
        position: relative;
        border-bottom: 0.01rem solid #eee;
        line-height: 0.88rem;
        display: flex;
        .left{
          flex: 3;
          overflow: hidden;
        }
        .right{
          flex: 7;
          overflow: hidden;
          text-align: right;
          position: relative;
          .vux-cell-box{
            position: absolute;
            top: 50%;
            left:0;
            right: -0.3rem;
            transform: translateY(-50%);
          }
          .vux-cell-box:before{
            height: 0;
            border: 0;
          }
          span{
            display: block;
            .overwrite;
            padding-right: 0.2rem;
          }
          i{
            display: block;
            position: absolute;
            top: 50%;
            right: 0;
            width: .077rem;
            height: .136rem;
            overflow: hidden;
            transform: translateY(-50%);
            img{
              width: 100%;
              height: 100%;
              position: absolute;
              top: 0;
              left: 0;
            }
          }
          input{
            text-align: right;
            color: #666;
          }
          .gender{
            position: absolute;
            width: 0.7rem;
            height: 100%;
            .iconGender{
              position: absolute;
              top: 50%;
              transform: translateY(-50%);
              width: 0.3rem;
              height: 0.3rem;
              img{
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
              }
            }
          }
          .man{
            right: 1.1rem;
          }
          .women{
            right: 0;
          }
        }
      }
      .headerLine{
        color: #000;
        .point{
          position: absolute;
          left: 0;
          top: 0.34rem;
          width: 0.08rem;
          height: 0.2rem;
          background: #FE883A;
        }
      }
    }
    .button{
      font-size: 0.32rem;
      width: 6.9rem;
      height: 0.92rem;
      background: #ccc;
      color: #fff;
      margin: 0.75rem auto 0;
      text-align: center;
      line-height: 0.92rem;
    }
    .isHasteOffer{
      background: #FE883A;
    }
  }
</style>
