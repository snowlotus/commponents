<template>
  <div class="box" @touchstart.stop="out">
		<div class="chooseCarTopHeader">
			<div class="left">
				<div>好伙伴</div>
			</div>
			<div class="right" @click="addCar">
				添加车型
			</div>
		</div>
		<div class="chooseCarHeader">
			<div class="select">
				<popup-picker 
					:data="brandList" 
					value-text-align="center"
					inline-desc="品牌:"
					v-model="brandValue"
					placeholder="选择品牌"
					:columns="1"
					@on-change="brandChange"
				></popup-picker>
			</div>
      <div class="select">
				<popup-picker 
					:data="vehicleList" 
					v-model="vehicleValue"
					placeholder="选择车型"
					value-text-align="center"
					inline-desc="车款:"
					:columns="1"
					@on-change="vehicleChange"
				></popup-picker>
			</div>
		</div>
    <div class="chooseCar">
    <scroller lock-x height="100%" ref="scrollerEvent">
			<div class="list">
				<div class="listItem" :key="index" v-for="(item,index) in carList">
					<swipeout-item transition-mode="follow" :ref="`swiper${index}`" @on-open="swiperItem(`swiper${index}`)">
						<div slot="right-menu">
							<swipeout-button style="position:relative;z-index:99;" @click.native.stop="deleteCarBrand(item)" type="warn">删除</swipeout-button>
						</div>
						<div slot="content" class="content vux-1px-t" @click.stop="chooseCar(item)">
							<div class="top">{{item.carMainDesc}}</div>
							<div class="bottom">{{item.carConfigDesc}}</div>
							<div class="checked">
								<img :src="checked" />
							</div>
						</div>
					</swipeout-item>
				</div>
			</div>
    </scroller>
    </div>
  </div>
</template>

<script>
import Toast from '@/common/comComponent/toast'
import API from '@/common/js/comConfig'
import Axios from '@/common/js/axiosConfig'
import ptsHeader from '@/common/comComponent/header'
import { getCookie } from '@/common/js/comUtils'
import {
  Scroller,
  PopupPicker,
  Swipeout,
  SwipeoutItem,
  SwipeoutButton
} from 'vux'
export default {
  name: 'chooseCar',
  created() {
		//登录信息存入userinfo中
    this.$set(this, 'userInfo', JSON.parse(getCookie('header')))
    //取出默认的dealerCode
    let dealerCodeObj = {
      dealerCode: JSON.parse(getCookie('header')).dealerCode
    }
    GetCarList(this, dealerCodeObj)
  },
  components: {
    ptsHeader,
    PopupPicker,
    Swipeout,
    SwipeoutItem,
    SwipeoutButton,
    Scroller
  },
  data() {
    return {
      //用户信息
      userInfo: {},
      //选中的时的勾
      checked: require('@/common/images/icon_tick.png'),
      //品牌的列表
      brandList: [],
      //选择品牌的值
      brandValue: [],
      //车款的列表
      vehicleList: [],
      //车款的值
      vehicleValue: [],
      //车辆信息
      carList: [],
      //上一个被滑动的swiperItem
      preSwiperItemRef: '',
      //获取接口的全部数据
			allData: {},
			//是否是第一次进来
      isFirst: true
    }
  },
  methods: {
    //点击了删除的按钮
    deleteCarBrand: function(item) {
      this.$set(this, 'preSwiperItemRef', '')
      deleteCarBarand(this, item)
    },
    //将上一个划出的删除按钮关闭
    out: function() {
      if (this.preSwiperItemRef) {
        this.$refs[this.preSwiperItemRef][0].close()
      }
    },
    //记录下将谁划出来了
    swiperItem: function(ref) {
      this.$set(this, 'preSwiperItemRef', ref)
    },
    //品牌切换
    brandChange: function(val) {
      this.$set(this, 'vehicleValue', [])
      this.$set(this, 'vehicleList', this.getVehicle(val[0]))
      if (this.isFirst) {
        this.$set(this, 'isFirst', false)
        this.$set(this, 'carList', this.getAllCar())
      } else {
        this.$set(this, 'carList', this.getAllCar(val[0]))
      }
    },
    //车款切换
    vehicleChange: function(val) {
      this.$set(this, 'carList', this.getAllCar(this.brandValue[0], val[0]))
    },
    //获取所有车列表,接收两个参数分别为品牌名称和选择车型.返回选择条件下的所有车辆
    getAllCar: function(brandName, vehicleName) {
      let data = this.allData
      let vehicleList = [],
        carList = []
      if (brandName) {
        for (let item1 = 0; item1 < data.length; item1++) {
          if (data[item1].carBrand == brandName) {
            vehicleList = data[item1].carModelResultVOList
            if (vehicleName) {
              for (
                let item2 = 0;
                item2 < data[item1].carModelResultVOList.length;
                item2++
              ) {
                if (
                  data[item1].carModelResultVOList[item2].carModel ==
                  vehicleName
                ) {
                  carList = data[item1].carModelResultVOList[item2].detailList
                  return carList
                }
              }
            }
            break
          }
        }
      }
      if (vehicleList.length > 0) {
        for (let item3 = 0; item3 < vehicleList.length; item3++) {
          for (
            let item4 = 0;
            item4 < vehicleList[item3].detailList.length;
            item4++
          ) {
            carList.push(vehicleList[item3].detailList[item4])
          }
        }
        return carList
      }
      for (let i = 0; i < data.length; i++) {
        for (
          let item1 = 0;
          item1 < data[i].carModelResultVOList.length;
          item1++
        ) {
          for (
            let item2 = 0;
            item2 < data[i].carModelResultVOList[item1].detailList.length;
            item2++
          ) {
            carList.push(data[i].carModelResultVOList[item1].detailList[item2])
          }
        }
      }
      return carList
    },
    //获取车款的方法,传入品牌获取车款并且返回数据格式为popuppicker
    getVehicle: function(brandName) {
      let data = this.allData
      let vehicleList = []
      for (let i = 0; i < data.length; i++) {
        if (data[i].carBrand == brandName) {
          for (let j = 0; j < data[i].carModelResultVOList.length; j++) {
            vehicleList.push({
              name: data[i].carModelResultVOList[j].carModel,
              value: data[i].carModelResultVOList[j].carModel,
              parent: 0
            })
          }
          return vehicleList
        }
      }
		},
		//选择车型
    chooseCar: function(item) {
      sessionStorage.setItem('car', JSON.stringify(item))
      history.go(-1)
    },
    //在视图中删除车型
    delectCar: function(_this, item) {
      //删除显示列表里面的
      for (let i = 0; i < _this.carList.length; i++) {
        if (_this.carList[i].carId == item.carId) {
          _this.carList.splice(i, 1)
          _this.$nextTick(() => {
            _this.$refs.scrollerEvent.reset()
          })
          break
        }
      }
      //删除所有数据里面的数据
      for (let i = 0; i < _this.allData.length; i++) {
        if (_this.allData[i].carBrand == item.carBrand) {
          for (
            let j = 0;
            j < _this.allData[i].carModelResultVOList.length;
            j++
          ) {
            if (
              _this.allData[i].carModelResultVOList[j].carModel == item.carModel
            ) {
              for (
                let n = 0;
                n < _this.allData[i].carModelResultVOList[j].detailList.length;
                n++
              ) {
                if (
                  _this.allData[i].carModelResultVOList[j].detailList[n]
                    .carId == item.carId
                ) {
                  _this.allData[i].carModelResultVOList[j].detailList.splice(
                    n,
                    1
                  )
                  _this.$nextTick(() => {
                    _this.$refs.scrollerEvent.reset()
                  })
                  break
                }
              }
              break
            }
          }
          break
        }
      }
    },
    addCar:function(){
      this.$router.push({ path: '/chooseCarType' })
    }
  },
  mounted() {}
}
//初始化数据
function GetCarList(_this, reqData) {
  Axios.post(API.getWebServiceUrls('hasteOfferGetCarList'), reqData)
    .then(res => {
      if (res.data.code === 0) {
        let data = res.data.data
        _this.$set(_this, 'allData', data)
        //初始化的品牌
        let brandList = []
        //调出所有的车
        let carList = []
        //循环取出品牌列表
        for (let i = 0; i < data.length; i++) {
          brandList.push({
            name: data[i].carBrand,
            value: data[i].carBrand,
            parent: 0
          })
        }
        _this.$set(_this, 'brandList', brandList)
        _this.$set(_this, 'brandValue', [brandList[0].value])
      } else {
        Toast(res.data.msg)
      }
    })
    .catch(err => {
      console.log(err)
    })
}
//删除车型
function deleteCarBarand(_this, item) {
	let reqData = {
		idPtsVehicleInfo: item.carId
	}
  Axios.post(API.getWebServiceUrls('hasteOfferDeleteCarList'), reqData)
    .then(res => {
      if (res.data.code === 0) {
				Toast('删除车型成功')
        _this.delectCar(_this, item)
      } else {
        Toast(res.data.msg)
      }
    })
    .catch(err => {
      console.log(err)
    })
}
</script>

<style lang="less">
.overwrite{
	overflow: hidden;
	text-overflow:ellipsis;
	white-space: nowrap;
}
.vuxPopupChange{
		.weui-cell{
			padding: 0 0.3rem;
		}
		.vux-cell-box{
			position: relative;
			top: 50%;
      transform: translateY(-50%);
		}
		.vux-cell-box:before{
			display: none;
		}
		.vux-cell-primary{
			overflow: hidden;
		}
		.vux-label-desc{
			font-size: 12px;
		}
		.weui-cell__ft{
			transform: translateY(-50%);
			position: absolute;
			top: 50%;
			right: 2px;
		}
		.vux-cell-value{
			color: #000;
		}
}
.chooseCarTopHeader{
	padding: 0 0.3rem;
	line-height: 0.88rem;
	height: 0.88rem;
	background: #fff;
	position: absolute;
	top: 0;
	width: 100%;
	box-sizing: border-box;
	border-bottom: 1px solid #eee;
	display: flex;
	&>div{
		overflow: hidden;
		color: #333;
	}
	.left{
		flex:1;
		text-align: center;
		.vuxPopupChange;
	}
	.right{
		flex:1;
		text-align: center;
	}
}
.chooseCarHeader{
	height: 0.8rem;
	background: #fff;
	display: flex;
  position: absolute;
  width: 100%;
  top: 0.88rem;
	border-bottom: 1px solid #eee;
	box-sizing: border-box;
	.select{
		flex: 1;
		overflow: hidden;
		.vuxPopupChange;
	}
}
  .chooseCar{
    overflow: hidden;
    position: absolute;
		width: 100%;
		top: 1.68rem;
		bottom: 0;
		font-size: 0.28rem;
		.listItem:nth-child(1){
			.vux-1px-t:before{
				height: 0;
				border: 0;
			}
		}
		.list{
			.listItem{
				.content{
					height: 1.4rem;
					background: #fff;
					padding: 0 0.3rem;
					position: relative;
					overflow: hidden;
					.top,.bottom{
						color: #000;
						line-height: 0.7rem;
						padding-right: 0.5rem;
						font-size: 0.28rem;
						.overwrite;
					}
					.bottom{
						font-size: 0.26rem;
						color: #666;
					}
					.checked{
						display: none;
						position: absolute;
						right: 0.3rem;
						top: 50%;
						transform: translateY(-50%);
						width: 0.28rem;
						height: 0.28rem;
						img{
							width: 100%;
							height: 100%;
							position: absolute;
							top: 0;
							left: 0;
						}
					}
				}
			}
			.checkItem{
				&>div{
					color: #FE883A!important;
				}
				.checked{
					display: block!important;
				}
			}
		}
  }
</style>
