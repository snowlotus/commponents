<template>
<div></div>
</template>

<script>
var wx = require('weixin-js-sdk')
import Toast from '../../common/comComponent/toast'
export default {
  created() {
    Toast('加载小程序')
    if (!window.WeixinJSBridge || !WeixinJSBridge.invoke) {
      document.addEventListener('WeixinJSBridgeReady', function () {
        wx.miniProgram.navigateBack()
      }, false)
    } else {
      wx.miniProgram.navigateBack()
    }
  }
}
</script>

<style lang="less">
</style>
