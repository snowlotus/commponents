import Vue from 'vue'
import Router from 'vue-router'
// import Vuex from 'vuex'
// 测试beign
const main = resolve => require.ensure([], () => resolve(require('../test/main.vue')), 'main')
const getIcon = resolve => require.ensure([], () => resolve(require('../test/getIcon.vue')), 'getIcon')
// const inCoreData = resolve => require.ensure([], () => resolve(require('../test/inCoreData.vue')), 'inCoreData')
const index = resolve => require.ensure([], () => resolve(require('../test/index.vue')), 'index')
// 测试end
//二维码
const qrcode = resolve => require.ensure([], () => resolve(require('../test/qrcode.vue')), 'qrcode')
// 买车险
const CarInsure = resolve => require.ensure([], () => resolve(require('../outServcieLogic/newCarIss/carInsure.vue')), 'carInsure')
const InCarInsure = resolve => require.ensure([], () => resolve(require('../inServiceLogic/newCarIss/carInsure.vue')), 'InCarInsure')
const chooseAgent = resolve => require.ensure([], () => resolve(require('../inServiceLogic/newCarIss/chooseAgent/chooseAgent.vue')), 'chooseAgent')
// 买车险结束
// 保单管理
const OrderList = resolve => require.ensure([], () => resolve(require('../outServcieLogic/orderManagement')), 'orderList')
// 订单详情
const OrderInfo = resolve => require.ensure([], () => resolve(require('../outServcieLogic/orderManagement/om_info.vue')), 'orderInfo')
//外部端电子保单详情
const electronicOrderInfo = resolve => require.ensure([], () => resolve(require('../outServcieLogic/orderManagement/page/electronPayment')), 'electronicOrderInfo')
//外部端保单打印码
const OrderPrintCode = resolve => require.ensure([], () => resolve(require('../outServcieLogic/orderManagement/page/printCode')), 'OrderPrintCode')
//外部端保单险种明细
const outInsuranceDetail = resolve => require.ensure([], () => resolve(require('../outServcieLogic/orderManagement/page/insuranceDetail')), 'outInsuranceDetail')


// 推修数据首页
// const pushIndex = resolve => require.ensure([], () => resolve(require('../outServcieLogic/visualMend/pushIndex.vue')), 'pushIndex')
// 流向分析
//const pushDataFlow = resolve => require.ensure([], () => resolve(require('../outServcieLogic/visualMend/pushDataFlow')), 'pushDataFlow')
// 联系分析
const pushDataCon = resolve => require.ensure([], () => resolve(require('../outServcieLogic/visualMend/pushDataCon')), 'pushDataCon')
//产值分析
const pushDataVsiual = resolve => require.ensure([], () => resolve(require('../outServcieLogic/visualMend/pushDataVsiual')), 'pushDataVsiual')
// 推修任务
const repairTask = resolve => require.ensure([], () => resolve(require('../outServcieLogic/repairTask')), 'repairTask')
// 推修详情
const repairTaskInfo = resolve => require.ensure([], () => resolve(require('../outServcieLogic/repairTask/info.vue')), 'repairTaskInfo')
//外部端推修详情轮播图
const repairShowImage = resolve => require.ensure([], () => resolve(require('../outServcieLogic/repairTask/page/showImage')), 'repairShowImage');
// 搜索页面
const searchIndex = resolve => require.ensure([], () => resolve(require('../outServcieLogic/search')), 'search')
//理赔案件查询
const claimList = resolve => require.ensure([], () => resolve(require('../outServcieLogic/claim/claimList.vue')), 'claimList')
//理赔案件查询搜索页面
const claimSearch = resolve => require.ensure([], () => resolve(require('../outServcieLogic/claim/template/claimSearch.vue')), 'claimSearch')
//理赔案件详情
const claimInfo = resolve => require.ensure([], () => resolve(require('../outServcieLogic/claim/claimInfo.vue')), 'claimInfo')
// 续保跟踪
const continueIndex = resolve => require.ensure([], () => resolve(require('../outServcieLogic/continue')), 'continueIndex')
// 续保详情
const continueInfo = resolve => require.ensure([], () => resolve(require('../outServcieLogic/continue/con_info.vue')), 'continueInfo')
// 续保选择代理人
const continuehooseAgent = resolve => require.ensure([], () => resolve(require('../outServcieLogic/continue/chooseAgent.vue')), 'continuehooseAgent')
// 续保报表
const continueDataReport = resolve => require.ensure([], () => resolve(require('../outServcieLogic/continue/dataReport.vue')), 'continueDataReport')
// 业绩查询
const coreData = resolve => require.ensure([], () => resolve(require('../outServcieLogic/coreData/')), 'coreData');

/********************* 以下为内部端需求的路由  begin*******************************/

// 选择车型表单页面
const chooseCarType = resolve => require.ensure([], () => resolve(require('../inServiceLogic/chooseCarType/')), 'chooseCarType');
// 选择车款与排气量页面
const chooseCarTypeCell = resolve => require.ensure([], () => resolve(require('../inServiceLogic/chooseCarType/cellPage')), 'chooseCarTypeCell');
// 选择汽车品牌界面
const chooseCarTypeList = resolve => require.ensure([], () => resolve(require('../inServiceLogic/chooseCarType/carList')), 'chooseCarTypeList');
// 续保列表
const insideContinueIndex = resolve => require.ensure([], () => resolve(require('../inServiceLogic/continue/')), 'insideContinueIndex');
// 续保列表搜索
const insideContinueSearch = resolve => require.ensure([], () => resolve(require('../inServiceLogic/continue/search')), 'insideContinueSearch');
// 续保详情
const insideContinueInfo = resolve => require.ensure([], () => resolve(require('../inServiceLogic/continue/con_info')), 'insideContinueInfo');
// 续保报表
const insideContinueDataReport = resolve => require.ensure([], () => resolve(require('../inServiceLogic/continue/dataReport')), 'insideContinueDataReport');
// 续保用户画像详情
const insideContinuePersona = resolve => require.ensure([], () => resolve(require('../inServiceLogic/continue/persona')), 'insideContinuePersona');
// 续保模式更改
const insideContinueChooseModel = resolve => require.ensure([], () => resolve(require('../inServiceLogic/continue/chooseModel')), 'insideContinueChooseModel');
// 续保用户画像详情
const insideContinueApproveModel = resolve => require.ensure([], () => resolve(require('../inServiceLogic/continue/approveModel')), 'insideContinueApproveModel');
// 续保客户信息回补
const insideContinueUserRemakeAdd = resolve => require.ensure([], () => resolve(require('../inServiceLogic/continue/userRemakeAdd')), 'insideContinueUserRemakeAdd');
// 续保选择代理人
const insideContinueChooseAgent = resolve => require.ensure([], () => resolve(require('../inServiceLogic/continue/chooseAgent')), 'insideContinueChooseAgent');
//理赔详情
const inClaimDetail = resolve => require.ensure([], () => resolve(require('../inServiceLogic/inClaim/inClaimDetail.vue')), 'inClaimDetail');
//创建空白页供native使用
const formPageToNative = resolve => require.ensure([], () => resolve(require('../inServiceLogic/formPageToNative/index')), 'formPageToNative');
//内部端推修任务
const inRepairTask = resolve => require.ensure([], () => resolve(require('../inServiceLogic/inRepairTask')), 'inRepairTask');
//内部端推修详情
const inRepairTaskInfo = resolve => require.ensure([], () => resolve(require('../inServiceLogic/inRepairTask/info')), 'inRepairTaskInfo');
//内部端推修详情轮播图
const inRepairShowImage = resolve => require.ensure([], () => resolve(require('../inServiceLogic/inRepairTask/page/showImage')), 'inRepairShowImage');
//内部端推修搜索页
const inSearch = resolve => require.ensure([], () => resolve(require('../inServiceLogic/inRepairTask/page/search')), 'inSearch');
//内部端推修联系分析
const inContactAnalyse = resolve => require.ensure([], () => resolve(require('../inServiceLogic/inDataAnalysis/inContactAnalyse')), 'inContactAnalyse');
//内部端推修产值分析
const inOutputValAnalyse = resolve => require.ensure([], () => resolve(require('../inServiceLogic/inDataAnalysis/inOutputValAnalyse')), 'inOutputValAnalyse');


//核心数据
const inCoreData = resolve => require.ensure([], () => resolve(require('../inServiceLogic/inCoreData/index')), 'inCoreData')
//选择机构
const selectOrganization = resolve => require.ensure([], () => resolve(require('../inServiceLogic/selectOrganization')), 'selectOrganization');
//推修产值保费
const prodPremium = resolve => require.ensure([], () => resolve(require('../inServiceLogic/inRepairTask/prodPremium')), 'prodPremium');
//资源总量
const resourceTotal = resolve => require.ensure([], () => resolve(require('../inServiceLogic/inRepairTask/resourceTotal/index')), 'resourceTotal');
// 保单管理
const insideOrderList = resolve => require.ensure([], () => resolve(require('../inServiceLogic/orderManagement')), 'insideOrderList');
// 订单详情
const insideOrderInfo = resolve => require.ensure([], () => resolve(require('../inServiceLogic/orderManagement/om_info.vue')), 'insideOrderInfo');
// 订单搜索
const insideOrderSearch = resolve => require.ensure([], () => resolve(require('../inServiceLogic/orderManagement/search')), 'insideOrderSearch');
//内部端电子保单详情
const electronPayment = resolve => require.ensure([], () => resolve(require('../inServiceLogic/orderManagement/page/electronPayment')), 'electronPayment');
//内部端保单打印码
const printCode = resolve => require.ensure([], () => resolve(require('../inServiceLogic/orderManagement/page/printCode')), 'printCode');
//内部端修改车牌
const inModifyCarMark = resolve => require.ensure([], () => resolve(require('../inServiceLogic/orderManagement/page/modifyCarMark')), 'inModifyCarMark');
//内部端险种明细
const insuranceDetail = resolve => require.ensure([], () => resolve(require('../inServiceLogic/orderManagement/page/insuranceDetail')), 'insuranceDetail');


/* 登录模块 */
const login = resolve => require.ensure([], () => resolve(require('../wxapp/login/login')), 'login');
const logout = resolve => require.ensure([], () => resolve(require('../wxapp/logout/logout')), 'logout');

/* 急速报价 */
const hasteOffer = resolve => require.ensure([], () => resolve(require('../wxapp/outsideHasteOffer/hasteOffer')), 'hasteOffer');
const chooseCar = resolve => require.ensure([], () => resolve(require('../wxapp/outsideHasteOffer/chooseCar')), 'chooseCar');

/* 内部端目标管理模块 start */
//此路由根据不同角色分发不同角色显示的页面
const slotTargetManage = resolve => require.ensure([], () => resolve(require('../inServiceLogic/targetManage/index')), 'slotTargetManage');
//角色为sm的路由
const smTargetManage = resolve => require.ensure([], () => resolve(require('../inServiceLogic/targetManage/roleTypeSM/index')), 'smTargetManage');
const smAddPlan = resolve => require.ensure([], () => resolve(require('../inServiceLogic/targetManage/roleTypeSM/page/addPlan')), 'smAddPlan');
const smPlanDetail = resolve => require.ensure([], () => resolve(require('../inServiceLogic/targetManage/roleTypeSM/planDetail')), 'smPlanDetail');
//角色为va/vp的路由
const vaTargetManage = resolve => require.ensure([], () => resolve(require('../inServiceLogic/targetManage/roleTypeVa/index')), 'vaTargetManage');
const vaPlanDetail = resolve => require.ensure([], () => resolve(require('../inServiceLogic/targetManage/roleTypeVa/planDetail')), 'vaPlanDetail');
/* 内部端目标管理模块 end */

//关闭小程序的WebView
const closeWebView = resolve => require.ensure([], () => resolve(require('../wxapp/closeWebView/closeWebView')), 'closeWebView');

// 温度计 开始
// 首页
const insideThermometerIndex = resolve => require.ensure([], () => resolve(require('../inServiceLogic/thermometer/index.vue'), 'insideThermometerIndex'));
// S&M 图标页面
const insideThermometerS_MDataReport = resolve => require.ensure([], () => resolve(require('../inServiceLogic/thermometer/page/dataReport.vue'), 'insideThermometerS_MDataReport'));
// 选着网点编辑页面
const insideChooseOrganization = resolve => require.ensure([], () => resolve(require('../inServiceLogic/thermometer/page/S_MWrite.vue'), 'insideChooseOrganization'));
// 月份编辑数据页面
const insideMonthEdit = resolve => require.ensure([], () => resolve(require('../inServiceLogic/thermometer/monthEdit.vue'), 'insideChooseOrganization'));
//VP/VA日报详情
const insideThermometerVPDailyDetails = resolve => require.ensure([], () => resolve(require('../inServiceLogic/thermometer/page/dailyDetails.vue'), 'insideThermometerVPDailyDetails'));
//VP/VA月报详情
const insideThermometerVPMonthlyDetails = resolve => require.ensure([], () => resolve(require('../inServiceLogic/thermometer/page/monthlyDetails.vue'), 'insideThermometerVPMonthlyDetails'));
//VP/VA月报详情去提醒
const insideThermometerVPMonthlyDetailsRemind = resolve => require.ensure([], () => resolve(require('../inServiceLogic/thermometer/page/monthlyDetailsRemind.vue'), 'insideThermometerVPMonthlyDetailsRemind'));
//S&M 编辑日报
const insideDayEdit = resolve=>require.ensure([], () => resolve(require('../inServiceLogic/thermometer/page/writeTable.vue'), 'insideDayEdit'));
// 温度计 结束
Vue.use(Router);

export default new Router({
  routes: [
    /* 登录 */
    {
      path: '/login',
      name: 'login',
      meta: {
        title: '微信登录'
      },
      component: login
    },
    /* 退出登录 */
    {
      path: '/logout',
      name: 'logout',
      meta: {
        title: '退出登录'
      },
      component: logout
    },
    /* 急速报价 */
    {
      path: '/outside/hasteOffer',
      name: 'hasteOffer',
      component: hasteOffer
    },
    {
      path: '/outside/chooseCar',
      name: 'chooseCar',
      component: chooseCar
    },
    {
      path: '/closeWebView',
      name: 'closeWebView',
      component: closeWebView
    },
    /****测试 begin******/
    {
      path: '/',
      name: 'main',
      component: main
    },
    {
      path: '/index',
      name: 'index',
      component: index
    },
    {
      path: '/getIcon',
      name: 'getIcon',
      component: getIcon
    },
    {//二维码
      path: '/qrcode',
      name: 'qrcode',
      component: qrcode
    },
    // {
    //   path: '/inCoreData',
    //   name: 'inCoreData',
    //   component: inCoreData
    // },
    /****测试 end******/
    {
      path: '/repairTask',
      name: 'repairTask',
      meta: {
        title: '推修任务'
      },
      component: repairTask
    }, {
      path: '/repairTaskInfo',
      name: 'repairTaskInfo',
      meta: {
        title: '推修详情'
      },
      component: repairTaskInfo
    }, {
      path:'/repairShowImage',
      name:'repairShowImage',
      meta:{
        title:'推修案件图片'
      },
      component:repairShowImage
    },
    /*{
      path: '/pushindex',
      name: 'pushindex',
      meta: {
        title: '推修首页'
      },
      component: pushIndex
    },*/
    {
      path: '/carinsure',
      name: 'carinsure',
      meta: {
        title: '车险投保'
      },
      component: CarInsure
    },
    {
      path: '/Order-list',
      name: 'OrderList',
      meta: {
        title: '保单管理'
      },
      component: OrderList
    }, {
      path: '/Order-info',
      name: 'OrderInfo',
      meta: {
        title: '保单详情'
      },
      component: OrderInfo
    },{
      path:'/electronicOrderInfo',
      name:'electronicOrderInfo',
      component:electronicOrderInfo,
      mata:{
        title:'保单详情'
      }
    },{
      path:'/OrderPrintCode',
      name:'OrderPrintCode',
      component:OrderPrintCode,
      mata:{
        title:'保单打印码'
      }
    },{
      path:'/outInsuranceDetail',
      name:'outInsuranceDetail',
      component:outInsuranceDetail,
      meta:{
        title:'险种明细'
      }
    },
    /*{
      path: '/pushDataFlow',
      name: 'pushDataFlow',
      meta: {
        title: '流向分析'
      },
      component: pushDataFlow
    }, */
    {
      path: '/pushDataCon',
      name: 'pushDataCon',
      meta: {
        title: '联系分析'
      },
      component: pushDataCon
    }, {
      path: '/pushDataVsiual',
      name: 'pushDataVsiual',
      meta: {
        title: '产值分析'
      },
      component: pushDataVsiual
    }, {
      path: '/coreData',
      name: 'coreData',
      meta: {
        title: '业绩查询'
      },
      component: coreData
    }, {
      path: '/search',
      name: 'search',
      meta: {
        title: '搜索'
      },
      component: searchIndex
    }, {
      path: '/claimList',
      name: 'claimList',
      meta: {
        title: '理赔查询'
      },
      component: claimList
    }, {
      path: '/claimSearch',
      name: 'claimSearch',
      meta: {
        title: '案件查询'
      },
      component: claimSearch
    }, {
      path: '/claimInfo',
      name: 'claimInfo',
      meta: {
        title: '案件详情'
      },
      component: claimInfo
    }, {
      path: '/continueIndex',
      name: 'continueIndex',
      meta: {
        title: '续保跟踪'
      },
      component: continueIndex
    }, {
      path: '/continueInfo',
      name: 'continueInfo',
      meta: {
        title: '续保详情'
      },
      component: continueInfo
    }, {
      path: '/continuehooseAgent',
      name: 'continuehooseAgent',
      meta: {
        title: '选择网点'
      },
      component: continuehooseAgent
    }, {
      path: '/continueDataReport',
      name: 'continueDataReport',
      meta: {
        title: '续保报表'
      },
      component: continueDataReport
    },
    /*************** 以下为内部端需求路由 *******************/

    {
      path: '/chooseCarType',
      name: 'chooseCarType',
      meta: {
        title: '选择车型'
      },
      component: chooseCarType
    }, {
      path: '/chooseCarTypeList',
      name: 'chooseCarTypeList',
      meta: {
        title: '品牌'
      },
      component: chooseCarTypeList
    }, {
      path: '/chooseCarTypeCell',
      name: 'chooseCarTypeCell',
      meta: {
        title: {
          A: '品牌',
          B: '车款',
          C: '排气量',
          D: '手动/自动',
          E: '车型'
        }
      },
      component: chooseCarTypeCell
    }, {
      path: '/inside/chooseAgent',
      name: 'chooseAgent',
      meta: {
        title: '选择代理人'
      },
      component: chooseAgent
    }, {
      path: '/inside/InCarInsure',
      name: 'InCarInsure',
      meta: {
        title: '买车险'
      },
      component: InCarInsure
    }, {
      path: '/inside/continueInfo',
      name: 'insideContinueInfo',
      meta: {
        title: '续保详情'
      },
      component: insideContinueInfo
    }, {
      path: '/inside/continueIndex',
      name: 'insideContinueIndex',
      meta: {
        title: '续保列表'
      },
      component: insideContinueIndex
    }, {
      path: '/inside/continueSearch',
      name: 'insideContinueSearch',
      meta: {
        title: '续保搜索'
      },
      component: insideContinueSearch
    }, {
      path: '/inside/continueDataReport',
      name: 'insideContinueDataReport',
      meta: {
        title: '续保报表'
      },
      component: insideContinueDataReport
    }, {
      path: '/inside/persona',
      name: 'insideContinuePersona',
      meta: {
        title: '用户属性'
      },
      component: insideContinuePersona
    }, {
      path: '/inside/chooseModel',
      name: 'insideContinueChooseModel',
      meta: {
        title: '续保模式更改'
      },
      component: insideContinueChooseModel
    }, {
      path: '/inside/approveModel',
      name: 'insideContinueApproveModel',
      meta: {
        title: '续保模式确认'
      },
      component: insideContinueApproveModel
    }, {
      path: '/inside/userRemakeAdd',
      name: 'insideContinueUserRemakeAdd',
      meta: {
        title: '客户信息回补'
      },
      component: insideContinueUserRemakeAdd
    }, {
      path: '/inside/continueChooseAgent',
      name: 'insideContinueChooseAgent',
      meta: {
        title: '选择网点'
      },
      component: insideContinueChooseAgent
    }, {
      path: '/inside/inClaimDetail',
      name: 'insideInClaimDetail',
      meta: {
        title: '理赔详情'
      },
      component: inClaimDetail
    },
    {
      path: '/formPageToNative',
      name: 'insideFormPageToNative',
      component: formPageToNative,
    },
    {
      path: '/inside/inRepairTask',
      name: 'inRepairTask',
      component: inRepairTask,
      meta: {
        title: '推修任务'
      }
    },
    {
      path: '/inside/inRepairTaskInfo',
      name: 'inRepairTaskInfo',
      component: inRepairTaskInfo,
      meta: {
        title: '推修详情'
      }
    },
    {
      path: '/inside/inRepairShowImage',
      name: 'inRepairShowImage',
      component: inRepairShowImage,
      meta: {
        title: '推修详情轮播图'
      }
    },
    {
      path: '/inside/inSearch',
      name: 'inSearch',
      component: inSearch,
      meta: {
        title: '搜索页'
      }
    },
    {
      path: '/inside/inContactAnalyse',
      name: 'inContactAnalyse',
      component: inContactAnalyse,
      meta: {
        title: '联系分析'
      }
    },
    {
      path: '/inside/inOutputValAnalyse',
      name: 'inOutputValAnalyse',
      component: inOutputValAnalyse,
      meta: {
        title: '产值分析'
      }
    },
    {
      path: '/inside/selectOrganization',
      name: 'selectOrganization',
      component: selectOrganization,
      meta: {
        title: '选择机构'
      }
    }, {
      path: '/inside/inCoreData',
      name: 'inCoreData',
      component: inCoreData,
      meta: {
        title: '核心数据'
      }
    }, {
      path: '/inside/prodPremium',
      name: 'prodPremium',
      component: prodPremium,
      meta: {
        title: '产值保费'
      }
    }, {
      path: '/inside/resourceTotal',
      name: 'resourceTotal',
      component: resourceTotal,
      meta: {
        title: '资源总量'
      }
    }, {
      path: '/inside/orderList',
      name: 'insideOrderList',
      component: insideOrderList,
      meta: {
        title: '保单管理'
      }
    }, {
      path: '/inside/orderInfo',
      name: 'insideOrderInfo',
      component: insideOrderInfo,
      meta: {
        title: '保单详情'
      }
    }, {
      path: '/inside/electronPayment',
      name: 'electronPayment',
      component: electronPayment,
      meta: {
        title: '电子保单详情'
      }
    },{
      path: '/inside/printCode',
      name: 'printCode',
      component: printCode,
      meta: {
        title: '保单打印码'
      }
    },{
      path:'/inside/inModifyCarMark',
      name:'inModifyCarMark',
      component:inModifyCarMark,
      meta:{
        title:'保单修改车牌'
      }
    },{
      path:'/inside/insuranceDetail',
      name:'insuranceDetail',
      component:insuranceDetail,
      meta:{
        title:'险种明细'
      }
    },{
      path: '/inside/OrderSearch',
      name: 'insideOrderSearch',
      component: insideOrderSearch,
      meta: {
        title: '保单搜索'
      }
    },
    /* 内部端目标管理模块 start */
    {
      path:'/inside/targetManage/index',
      name:'slotTargetManage',
      component:slotTargetManage
    },
    //角色为sm的路由
    {
     path:'/inside/targetManage/roleTypeSM/index',
     name:'smTargetManage',
     component:smTargetManage,
     meta: {
       title:'目标管理'
     }
    },{
      path:'/inside/targetManage/roleTypeSM/addPlan',
      name:'smAddPlan',
      component:smAddPlan,
      meta: {
        title:'添加计划'
      }
    },{
      path:'/inside/targetManage/roleTypeSM/planDetail',
      name:'smPlanDetail',
      component:smPlanDetail,
      meta:{
        title:'计划详情'
      }
    },
    //角色为va的路由
    {
      path:'/inside/targetManage/roleTypeVa/index',
      name:'vaTargetManage',
      component:vaTargetManage,
      meta: {
        title:'目标管理'
      }
    },{
      path:'/inside/targetManage/roleTypeVa/planDetail',
      name:'vaPlanDetail',
      component:vaPlanDetail,
      meta:{
        title:'计划详情'
      }
    },
    /* 内部端目标管理模块 end */
    // 温度计 开始
    {
      path:'/inside/thermometer/index',
      name:'insideThermometerIndex',
      component:insideThermometerIndex,
      meta:{
        title:'温度计'
      }
    },
    {
      path:'/inside/thermometer/S_MDataReport',
      name:'insideThermometerS_MDataReport',
      component:insideThermometerS_MDataReport,
      meta:{
        title:'S_M报表页面'
      }
    },
    {
      path:'/inside/thermometer/writeTable',
      name:'insideDayEdit',
      component:insideDayEdit,
      meta:{
        title:'日报编辑'
      }
    },
    {
      path:'/inside/thermometer/ChooseOrganization',
      name:'insideChooseOrganization',
      component:insideChooseOrganization,
      meta:{
        title:'选择网点编辑'
      }
    },{
      path:'/inside/thermometer/MonthEdit',
      name:'insideMonthEdit',
      component:insideMonthEdit,
      meta:{
        title:'月份网点编辑数据'
      }
    },
      {
      path:'/inside/thermometer/VPDailyDetails',
      name:'insideThermometerVPDailyDetails',
      component:insideThermometerVPDailyDetails,
      meta:{
        title:'温度计详情'
      }
    },
    {
      path:'/inside/thermometer/VPMonthlyDetails',
      name:'insideThermometerVPMonthlyDetails',
      component:insideThermometerVPMonthlyDetails,
      meta:{
        title:'VP月报详情'
      }
    },
    {
      path:'/inside/thermometer/VPMonthlyDetailsRemind',
      name:'insideThermometerVPMonthlyDetailsRemind',
      component:insideThermometerVPMonthlyDetailsRemind,
      meta:{
        title:'VP月报详情去提醒'
      }
    },
    // 温度计 结束
    {
      path: '/test',
      name: 'test',
      component: (res) => {
        require(['../test/test'], res)
      }
    }
  ]
})
