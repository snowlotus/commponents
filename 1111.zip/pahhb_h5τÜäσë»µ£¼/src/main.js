// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set` in webpack.base.conf with an alias.
import Vue from 'vue';
import './common/js/comES6';
// import Vuex from 'vuex'
// import FastClick from 'fastclick';
import router from './router';
import App from './App.vue';
import AlloyFinger from 'alloyfinger/alloy_finger'; // 引入 alloyfinger 手势库
import alloyfingerVue from 'alloyfinger/vue/alloy_finger.vue'; // 引入 alloyfinger 手势库
import {
  DatetimePlugin,
  ConfirmPlugin
} from 'vux';
import './common/js/native'; //引入native文件
import {
  getCookie,
  delCookie,
  setCookie
} from './common/js/comUtils';
import ptsHeader from './common/comComponent/header';
// import schedule from './common/comComponent/schedule';
import VueJsonp from 'vue-jsonp';
/*=====================加载天眼数据begin================================*/
let skyEyeOptions = {
  testH5Param: {
    appid: 'D3CED0321B244F8388A1A96EA2D0F3B2',
    requestUrl: 'https://dn-mailattachments.qbox.me/h5sdk001.js',
    vc: '好伙伴H5test',
    vn: '1.0.0'
  },
  h5Param: {
    appid: '31A88E05BBB14D6581A0DB5D0CBC99FB',
    requestUrl: 'https://dn-mailattachments.qbox.me/h5sdk001.js',
    vc: '好伙伴H5',
    vn: '1.0.0'
  }
}
let params = (document.domain === 'icore-pts-mobile.pingan.com.cn') ? skyEyeOptions['h5Param'] : skyEyeOptions['testH5Param'];
//初始化天眼所需参数
window.pingan_sdk_appid = params.appid;
window.pingan_sdk_vc = params.vc;
window.pingan_sdk_vn = params.vn;
//加载天眼的js
require('./common/js/SKAPP')
// let head = document.getElementsByTagName('head')[0];
// let script = document.createElement('script');
// script.type = 'text/javascript';
// script.src = params.requestUrl;
// head.appendChild(script);
// document.body.appendChild(script);
/*=========================加载天眼数据end================================*/
if (window.location.host.includes('localhost')) {
  // 移动端页面调试 生产包请注释下面两行
  require('./common/js/getTestLoginToken.js');
}
if (window.location.host.includes('test-icore-pts-mobile')) {
  let VConsole = require('vconsole');
  const vconsole = new VConsole();
}

// import App from './App'
// FastClick.attach(document.body)

//QA what is productionTip 
Vue.config.productionTip = false;
// Vue.use('Vuex');
Vue.use(alloyfingerVue, {
  AlloyFinger
});

Vue.use(DatetimePlugin);
Vue.use(ConfirmPlugin);
Vue.use(VueJsonp);
/*
 *@info window.status是全局部分组件的状态管理 涉及的组件控制有 header && tab
 * */
window.PageStatus = {
  headerStop: false, // 为true时阻止头部的一切行为
  tabhidden: false, // 为true时阻止tab页面切换
}

window.del = delCookie;
/*
 * @info 页面公用事件
 * */
//QA 什么场景下防止用户关闭？
window.PageEvent = {
  /* 阻止用户关闭页面 */
  stopBackNative() {
    console.log('阻止用户关闭');
    Native.requestHybrid({
      tagname: 'stopBackNative'
    })
  },
  /* 允许用户关闭页面 */
  allowBackNative() {
    console.log('允许用户关闭');
    Native.requestHybrid({
      tagname: 'allowBackNative'
    })
  }
};
// 路由变化前修改页面的title 加载进度条
// let firstIn = 0;
let nextFunction, toPath
router.beforeEach((to, from, next) => {
  nextFunction = next
  toPath = to.path
  let titleData = to.meta && to.meta.title || '好伙伴';
  let titleText = typeof titleData === 'string' ? titleData : titleData[to.query.type];
  Native.requestHybrid({
    tagname: 'setNativeTitle',
    param: {
      title: titleText
    }
  });
  let titleElem = document.getElementsByTagName('title')[0];
  titleElem.innerText = titleText;
  if (navigator.userAgent.toLowerCase().indexOf('micromessenger') != "-1") {
    if (!window.WeixinJSBridge || !WeixinJSBridge.invoke) {
      document.addEventListener('WeixinJSBridgeReady', function (to, from, next) {
        WeixinJSBridgeReadyFunction(to, from, next)
      }, false)
    } else {
      WeixinJSBridgeReadyFunction(to, from, next)
    }
  } else {
    WeixinJSBridgeReadyFunction(to, from, next)
  }
});

function WeixinJSBridgeReadyFunction(to, from, next) {
  if (window.__wxjs_environment === 'miniprogram') {
    window.PageStatus.WX_SHOW_HEADER = false;
    //判断登录,当没有登录时跳转到登录页面
    if (!getCookie('header') && to.name != 'login') {
      if (location.href.indexOf('openIdData=') != "-1") {
        setCookie('openIdData',location.href.split('openIdData=')[1].substr(0, 32))
        nextFunction({
          path: '/login',
          query: {
            openIdData: location.href.split('openIdData=')[1].substr(0, 32),
            toPath: toPath
          }
        })
      }else{
        nextFunction({
          path: '/login',
          query: {
            toPath: toPath
          }
        })
      }
      return;
    }
    nextFunction();
  } else {
    window.PageStatus.WX_SHOW_HEADER = true;
    nextFunction();
  }
}

//QA 此次获取到这些cookie后把它赋值到window.dealerData 中 为何又将它从cookie中删除

// window.setCookie("dealerName",'pingAn保险');
// window.setCookie("dealerCode",'112233');
let header = getCookie('header') || '{}';
console.log('得到的获取cookie=》' + header + '>>');
let headerJSON = JSON.parse(header);
window.dealerData = {
  innerAccountRoleType: headerJSON.innerAccountRoleType, // 内部端账户的角色类型1：前线2：后线3：总部
  deptName: headerJSON.deptName, //内部端机构名称
  deptCode: headerJSON.deptCode, //内部端机构code
  carDeptCode: headerJSON.carDeptCode || '', //外部端选车型机构code
  dealerName: headerJSON.dealerName || '',
  dealerCode: headerJSON.dealerCode || '',
  dealerType: headerJSON.dealerType || '', //headerJSON.dealerType  0 网点 1 集团
  frontLineRoleType: headerJSON.frontLineRoleType || '', //前线角色类型s、m、va、vp(只有内部端账户前线角色这个字段有值)
  haveVp: headerJSON.haveVp || '', //是否已维护VP Y:已维护 N:未维护
  planTargetAuth: headerJSON.planTargetAuth || '' //目标计划授权 Y:已授权N:未授权
};
//调用理赔详情需要的参数
window.innerClaimData = {
  carMark: headerJSON.carMark || '',
  carRackNo: headerJSON.carRackNo || '',
  reportNo: headerJSON.reportNo || ''
};
//QA 从token判断有没有登录？？？
if (headerJSON && headerJSON.token) {
  delete headerJSON['content-Type'];
  delete headerJSON['deptName'];
  delete headerJSON['deptCode'];
  delete headerJSON['innerAccountRoleType'];
  delete headerJSON['Content-Type'];
  delete headerJSON['dealerName'];
  delete headerJSON['dealerCode'];
  delete headerJSON['dealerType'];
  delete headerJSON['carMark'];
  delete headerJSON['carRackNo'];
  delete headerJSON['frontLineRoleType'];
  delete headerJSON['haveVp'];
  delete headerJSON['planTargetAuth'];
  //QA 最后cookie只留下apptype、appversion、deviceid、devicetype 这几个值 为何？
  window.urlHeader = headerJSON
}
console.log('得到dealerData' + dealerData.dealerName + '>>' + dealerData.dealerCode);
/*window.urlHeader.dealerName='pingAn保险';
 window.urlHeader.dealerCode = '112233';*/
Vue.component('ptsHeader', ptsHeader); // 全局注册头部组件 就不需要在组件内一遍遍的引入
new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: {
    App
  }
});
