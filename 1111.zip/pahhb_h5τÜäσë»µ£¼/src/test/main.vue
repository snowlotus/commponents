/**
* Created by chenchangwei837 on 2018/1/22
*/
<template>
  <section :class="{'box':showHead}">
    <pts-header titleText="测试页生产版本测试" v-if="showHead"></pts-header>
    <div style="margin-top: 1rem;">
      <div class="bt_top">
        <ul class="ytdDate" style="width: 100%; border-bottom: 1px solid #EEEEEE;">
          <li :class="{on:leftFlag}" @click="rightFlag=false,leftFlag=!leftFlag">外部端</li>
          <li :class="{on:rightFlag}" @click="leftFlag=false,rightFlag=!rightFlag">内部端</li>
        </ul>
      </div>
      <div v-if="leftFlag" style="padding-top: .8rem;">
        <group>
          <cell is-link link="/carinsure" title="新车出单"></cell>
        </group>
        <group>
          <cell is-link link="/Order-list" title="保单管理"></cell>
        </group>
        <group>
          <cell is-link link="/repairTask" title="推修任务"></cell>
        </group>
        <group>
          <cell is-link link="/pushDataVsiual" title="产值分析"></cell>
        </group>
        <group>
          <cell is-link link="/pushDataCon" title="联系分析"></cell>
        </group>
        <group>
          <cell is-link link="/claimList" title="理赔案件查询"></cell>
        </group>
        <group>
          <cell is-link link="/continueIndex" title="续保查询"></cell>
        </group>
        <group>
          <cell is-link link="/continueDataReport" title="续保报表"></cell>
        </group>
        <group>
          <cell is-link link="/coreData" title="业绩查询"></cell>
        </group>
        <group>
          <cell is-link link="/chooseCarType" title="选中车型"></cell>
        </group>
      </div>
      <div v-if="rightFlag">
        <group>
          <cell is-link link="/inside/InCarInsure" title="新车出单"></cell>
        </group>
        <group>
          <cell is-link link="/inside/inClaimDetail" title="理赔详情"></cell>
        </group>
        <group>
          <cell is-link link="/inside/inCoreData" title="业绩查询"></cell>
        </group>
        <group>
          <cell is-link link="/inside/continueIndex" title="续保列表"></cell>
        </group>
        <group>
          <cell is-link link="/inside/continueDataReport" title="续保报表"></cell>
        </group>
        <group>
          <cell is-link link="/inside/chooseModel" title="续保模式更改"></cell>
        </group>
        <group>
          <cell is-link link="/inside/approveModel" title="续保模式确认"></cell>
        </group>
        <group>
          <cell is-link link="/inside/userRemakeAdd" title="客户信息回补"></cell>
        </group>
        <group>
          <cell is-link link="/inside/inRepairTask" title="推修任务"></cell>
        </group>
        <group>
          <cell is-link link="/inside/inContactAnalyse" title="联系分析"></cell>
        </group>
        <group>
          <cell is-link link="/inside/inOutputValAnalyse" title="产值分析"></cell>
        </group>
        <group>
          <cell is-link link="/inside/selectOrganization" title="选择机构"></cell>
        </group>
        <group>
          <cell is-link link="/inside/prodPremium" title="产值保费"></cell>
        </group>
        <group>
          <cell is-link link="/inside/resourceTotal" title="资源总量"></cell>
        </group>
        <group>
          <cell is-link link="/inside/orderList" title="保单管理"></cell>
        </group>
        <group>
          <cell is-link link="/inside/targetManage/index" title="目标管理"></cell>
        </group>
        <group>
          <cell is-link link="/inside/thermometer/index" title="温度计"></cell>
        </group>
        <group>
          <div class="triangleBottom"></div>
          <button @touchstart="clickOne" style="margin-bottom: 25px;">点击1</button>
          <cell>{{dealerIcon}}</cell>
          <input type="button" value="点击" @touchstart="showAPI"/>
        </group>
        <group>
          <!--<img :src='images'/>-->
        </group>
      </div>
    </div>

  </section>
</template>

<script>
  import {Divider, Cell, Group} from 'vux'
  import API from '../common/js/comConfig.js'
  import axios from '../common/js/axiosConfig.js'
  //const a =require('./loading.gif');
  //  import Native from '../common/js/native'
  export default {
    name: 'hello',
    components: {
      Divider,
      Cell,
      Group
    },
    data() {
      return {
        msg: 'Welcome to Your Vue.js App',
        checkOS: '1212',
        dealerIcon: '',
        leftFlag: true,
        rightFlag: false,
        showHead: window.PageStatus.WX_SHOW_HEADER
        //images:a
      }
    },
    created() {
      // console.log('wx', window.__wxjs_environment);
      //  if (!window.WeixinJSBridge || !WeixinJSBridge.invoke) {
      //    document.addEventListener('WeixinJSBridgeReady', this.checkWx, false);
      //  } else {
      //    this.checkWx();
      //  }
      console.log('wxen', window.__wxjs_environment);
      let ua = navigator.userAgent.toLowerCase();
      this.checkOS = ua.indexOf("iphone os") != -1 ? 'IOS' : '其他';
    },
    mounted() {
      this.$nextTick(function () {
        if (window.__wxjs_environment === 'miniprogram') {
          this.showHead = false;
        } else {
          this.showHead = true;
        }

      })
      // alert(wx.miniProgram.getEnv(function(res) {
      //   console.log(res.miniprogram) // true
      // }));
    },
    methods: {
      // checkWx() {
      //   console.log('checkWx',window.__wxjs_environment === 'miniprogram') // true
      // },
      showAPI() {
//    	//API.getWebServiceUrls('appLogin')
//      //console.log(getNativeData);
        axios.get('https://u.pingan.com/newrsupport/vehicle/brand?k=%E5%AE%9D%E9%A9%AC&page=1').then(res => {
          console.log(res)
        }).catch(err => {
          console.log(err)
        })
      },

      clickOne() {
//    	Promise.resolve().then(function(){
//        Native.showOne();
//        console.log("hello world!!!")
//      }).then(function () {
//        this.checkOS = Native.show();
//      }).catch(err=>{
//      	console.log(err)
//      })
//      Native.showOne();
        let self = this;
        Native.requestHybrid({
          tagname: 'getDealerIcon',
          param: {'dealerCode': '10001'},
          callback: function (reqData) {
            console.log(reqData.data)
            this.dealerIcon = reqData.data.dealerIcon;
          }
        })

//        Native.requestHybrid(
//          {
//            tagname: 'test',
//            param: {'name': 'liyue'},
//            callback: function (resData) {
//              if (resData.errCode && resData.errCode == '200') {
//                console.log(resData.data);
//                self.checkOS = resData.data;
//              } else {
//                console.log("hello world!!!" + resData.errMsg)
//                this.checkOS = '未获取到Native的值' + resData.errMsg;
//              }
//            }
//          });
        console.log('Native end .......')

      },

    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  * {
    margin: 0%;
    padding: 0%;
  }

  .plugin {
    padding: 10px 10px;
    text-align: center;
    font-size: 12px;
    margin-left: 50px;

  }

  h1, h2 {
    font-weight: normal;
  }

  ul {
    list-style-type: none;
    padding: 0;
  }

  li {
    display: inline-block;
    margin: 0 10px;
  }

  a {
    color: #42b983;
  }

  .bt_top {
    position: absolute;
    width: 100%;
    z-index: 2;
    background-color: #ffffff;
  }

  .ytdDate li {
    width: 50%;
    height: .82rem;
    font-size: .28rem;
    line-height: .8rem;
    text-align: center;
    color: #333;
    float: left;
    margin: 0 0;
  }

  .ytdDate li.on {
    color: #FE883A;
    border-bottom: 1px solid #FE883A;
  }

  li {
    display: inline-block;
    margin: 0 10px;
  }

  .on {
    background: #FE883A;
    color: #ffffff !important;
  }
</style>

