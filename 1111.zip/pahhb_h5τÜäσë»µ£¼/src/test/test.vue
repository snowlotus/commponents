<template>
  <section>
    <div class="input-wrap js-write" @click="checkedInput">
      {{text}}
    </div>
    <pts-key-board v-model="isChecked" @on-input="chooseValue"></pts-key-board>
  </section>
</template>

<script>
  import ptsKeyBoard from '../common/comComponent/keyBoard/keyboard';

  export default {
    name: "test",
    data () {
      return {
        isChecked: false,
        text: ''
      }
    },
    methods: {
      checkedInput (item) {
        this.isChecked = true;
      },
      chooseValue (v) {
        this.text = v;
      }
    },
    components: {
      ptsKeyBoard
    },
    mounted () {
    }
  }
</script>

<style scoped lang="less">
  .input-wrap {
    width: 90%;
    height: 0.5rem;
    border: 1px solid red;
    position: relative;
    .light-biao {
      display: inline-block;
      height: 90%;
      width: 1px; // 0.01rem;
      background: #09c;
      margin: 0 1px; //0.02rem;
      animation: show-or-hide 1s ease-in-out infinite;
    }
  }

  @keyframes show-or-hide {
    from {
      opacity: 1;
    }
    to {
      opacity: 0;
    }
  }
</style>
