/**
* Created by chenchangwei837 on 2018/2/11.
*/
<template>
  <div class="box bg_fff">
    <pts-header titleText="选择机构"></pts-header>
    <div class="wrap insideXubaoWrap">
      <!-- main start -->
      <div class="mainWrap">
        <div class="analyWrap" v-if="innerAccountRoleType==='3'">
          <h3 class="analyArea " :class="{'selectCur':JGData.name===adName}"
              @click.stop="selected =false;adName='';showAdName(JGData)">{{JGData.name}}</h3>
          <!--<div v-if="showQG">-->
          <!--<div class="analyArea" :class="{'selectCur':selected}" @click="selected =!selected;adName='';JGCode">-->
          <!--<h4>全部</h4>-->
          <!--</div>-->
          <div class="analyArea">
            <h4 class="openSelect" :class="{'arrowUp':!earthData.earthAd}"
                @click.stop="earthData.earthAd =!earthData.earthAd">{{earthData.earthName}}</h4>
            <div class="analyBox" :class="{'dn':!earthData.earthAd}">
              <ul>
                <li v-for="(item,index) in earthData.earthList"
                    @click.stop="showAdName(item);selected = false;"
                    :class="{'selectCur':item.name===adName &&item.code===adCode&& earthData.earthAd}">{{item.name}}
                </li>
              </ul>
            </div>
          </div>
          <div class="analyArea">
            <h4 class="openSelect" :class="{'arrowUp':!northData.northAd}"
                @click.stop="northData.northAd=!northData.northAd">{{northData.northName}}</h4>
            <div class="analyBox" :class="{'dn':!northData.northAd}">
              <ul>
                <li v-for="item in northData.northList" @click.stop="showAdName(item);selected=false"
                    :class="{'selectCur':item.name===adName &&item.code===adCode&& northData.northAd}">{{item.name}}
                </li>
              </ul>
            </div>
          </div>
          <!--</div>-->
        </div>
        <div class="analyWrap" v-else-if="innerAccountRoleType==='2'">
          <h3 class="openSelect" :class="{'arrowUp':!showQG}" @click.stop="showQG=!showQG">{{JGData.name}}</h3>
          <div v-if="showQG">
            <!--<div class="analyArea" :class="{'selectCur':selected}" @click="selected =!selected;adName='';JGCode">-->
            <!--<h4>全部</h4>-->
            <!--</div>-->
            <div class="analyArea">
              <div class="analyBox" :class="{'dn':laterData.laterAd}">
                <ul>
                  <li v-for="(item,index) in laterData.laterList"
                      @click.stop="showAdName(item);selected = false;"
                      :class="{'selectCur':item.name===adName && !laterData.laterAd}">{{item.name}}
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- main end -->

    </div>
  </div>
</template>

<script>
  import Axios from '../common/js/axiosConfig'
  import API from '../common/js/comConfig'
  import Toast from '../common/comComponent/toast'

  export default {
    name: "index",
    data() {
      return {
        selected: true,
        innerAccountRoleType: '',//角色类型
        showQG: false,
        earthData: {
          earthName: '',
          earthCode: '',
          earthAd: false,
          earthList: ['全部', '杭州分公司', '浙江分公司'],
        },//东南区
        northData: {
          northName: '',
          northCode: '',
          northAd: false,
          northList: ['全部', '西安分公司', '甘肃分公司'],
        },
        laterData: {
          /* northName: '',
           northCode: '',*/
          laterAd: false,
          laterList: []
        },
        JGData: {
          name: '全国',
          code: 'QG',
        },
        adName: '全国',
        adCode: 'QG',
        organData: {}, //机构数据
        beforeName:''//上一个路由名字
      }
    },
    props: {

    },
    mounted() {
      // this.$nextTick(function () {
      this.innerAccountRoleType = window.dealerData.innerAccountRoleType||'3';//innerAccountRoleType||'';//前线 1; 后线 2;总部 3;
      let self = this;
      //"http://localhost:8888/postGetData"
      /**
       * {
        "file": 'getOrganizationInfo',
        "path": 'car'
      }
       */
      Axios.post(API.getWebServiceUrls('getOrganizationInfo')).then(res => {
        let reqData = typeof  res.data === 'string' ? JSON.parse(res.data) : res.data;
        if (reqData.code === 0 || reqData.code === '0') {
          self.organData = reqData.data.organizationList;
          self.childList = reqData.data.organizationList.childList || [];

          console.log(self.organData)
          switch (self.innerAccountRoleType) {
            case '1':
              break;
            case '2':
              self.showQG = true;
              self.JGData.name = reqData.data.organizationList.name;
              self.JGData.code = reqData.data.organizationList.code;
              self.laterData['laterList'] = self.childList;
              break;
            case '3':
              self.showQG = true;
              self.JGData.name = reqData.data.groupList.name;
              self.JGData.code = reqData.data.groupList.code;
              self.earthData['earthName'] = self.childList[0].name;
              self.earthData['earthCode'] = self.childList[0].code;
              self.earthData['earthList'] = self.childList[0].childList || [];
              self.earthData['earthList'].splice(0, 0, {'code': '1', 'name': '全部'});
              self.northData['northName'] = self.childList[1].name;
              self.northData['northCode'] = self.childList[1].code;
              self.northData['northList'] = self.childList[1].childList || [];
              self.northData['northList'].splice(0, 0, {'code': '2', 'name': '全部'});
              break;
            default:
              Toast('未识别用户角色,无法展示网点!');
              break;
          }
        } else {
          Toast(reqData.msg || "系统麻烦请稍后重试");
        }
      }).catch(err => {
        console.log(err);
      })
      // });
    },
    methods: {
      showList() {
        console.log('显示写来列表.....')
      },
      showNorth(val) {
        console.log("这是西北区的" + val)
      },
      showAdName(val) {
        this.adName = val.name;
        this.adCode = val.code;
        console.log('这是东南区的');
        console.log(val.name + "====" + val.code);
        this.$router.push({name:this.beforeName,query:{adName:this.adName,adCode:this.adCode}})
      }
    },
    beforeRouteEnter(to,from,next){
      next(vm=>{
        vm.beforeName = from.name
      });
    }
  }
</script>

<style scoped>

</style>
