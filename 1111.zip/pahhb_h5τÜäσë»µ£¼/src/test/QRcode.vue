<template>
  <div class="box bg_fff">
    <header>
      <a href="#">
        <img src="../common/images/icon_app_haohuoban.png" alt="">
      </a>
      <h2>平安好伙伴</h2>
    </header>
    <main>
      <div class="img">
        <!-- 用v-if或者用三元表达式，判断是否本地环境 或是开发环境, 显示不同的图片-->
        <img :src="prdImg+prdAndroidImg" alt="" v-if="downloadUrl == 'https://icore-pts-mobile.pingan.com.cn/iCorePts-mobile'">
        <img :src="stgImg+stgAndroidImg" alt="" v-else>
        <h2>Android</h2>
      </div>
      <div class="img">
        <img :src="prdImg+prdIosImg" alt="" v-if="downloadUrl == 'https://icore-pts-mobile.pingan.com.cn/iCorePts-mobile'">
        <img :src="stgImg+stgIosImg" alt="" v-else>
        <h2>IOS</h2>
      </div>
    </main>
    <footer>
      <h3>请点击右上角按钮，然后在弹出的菜单中，点击在浏览器中打开，即可安装</h3>
      <a :href="downLoadUrls">
        <button>点击安装</button>
      </a>
      <p>或者用手机浏览器扫描二维码安装</p>
    </footer>
  </div>
</template>
<script>
export default {
  name: "qrcode",
  data() {
    return {
      downloadUrl: "",//url的前缀
      downLoadUrls: "",//去下载的链接
      stgImg:"https://test-icore-pts-mobile.pingan.com.cn/iCorePts-mobile",//测试环境图片的前缀
      prdImg : 'https://icore-pts-mobile.pingan.com.cn/iCorePts-mobile',//生产环境图片的前缀
      stgIosImg: "/res/logo/stg_app_ios.png", //ios测试环境图片
      prdIosImg: "/res/logo/prd_app_ios.png", //ios生产环境图片
      stgAndroidImg:
        "/res/logo/stg_app_android.png", //Android测试环境图片
      prdAndroidImg:
        "/res/logo/prd_app_android.png" //Android生产环境图片
    };
  },
  mounted() {
    // 请求接口，拿到url的前缀，再拼接
    const u = navigator.userAgent;
    const isAndroid = u.indexOf("Android") > -1 || u.indexOf("Adr") > -1; //android终端
    const isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
    if (isiOS) {
      if (this.downloadUrl == "https://icore-pts-mobile.pingan.com.cn/iCorePts-mobile") {
        //ios生产环境
        this.downLoadUrls =
          " https://itunes.apple.com/cn/app/id1335477015?mt=8";
        console.log(this.downLoadUrls);
      } else {
        //ios测试环境
        this.downLoadUrls = "http://www.pgyer.com/Nyx7";
        console.log(this.downLoadUrls);
      }
    } else if (isAndroid) {
      // this.downloadUrl = window.location.origin;//https://30.5.103.83/iCorePts-mobile
      let orgTest= 'https://test-icore-pts-mobile.pingan.com.cn/iCorePts-mobile';//测试环境的前缀
      let orgPrd = 'https://icore-pts-mobile.pingan.com.cn/iCorePts-mobile';//生产环境的前缀
      this.downloadUrl = location.origin;
      console.log("downloadUrl", this.downloadUrl);
      if (this.downloadUrl == "https://icore-pts-mobile.pingan.com.cn/iCorePts-mobile") {
        //生产环境
        let downloadUrlPrd =
          "/api/systemmgr/appversion/downloadApp/prd/android";
        this.downLoadUrls = `${orgPrd + downloadUrlPrd}`;
        console.log(this.downLoadUrls);
      } else {
        //测试环境
        let downloadUrlStg =
          "/api/systemmgr/appversion/downloadApp/stg/android";
        this.downLoadUrls = `${orgTest + downloadUrlStg}`;
        console.log(this.downLoadUrls);
      }
    }
  }
};
</script>
<style lang="less" scoped>
body,
html {
  height: 100%;
  text-align: center;
}
.box {
  text-align: center;
  header {
    a {
      img {
        margin-top: 1rem;
      }
    }
    h2 {
      height: 1.5rem;
      line-height: 1.5rem;
    }
  }
  main {
    .img {
      display: inline-block;
      img {
        width: 2rem;
        height: 2rem;
        border: 1px solid #ccc;
        margin-right: 0.1rem;
      }
    }
  }
  footer {
    h3 {
      color: red;
      padding: 0.5rem 1rem;
      font-weight: bolder;
      height: 1rem;
    }
    a {
      button {
        width: 3.7rem;
        height: 0.7rem;
        background-color: darkturquoise;
        color: #ffffff;
        border-radius: 2rem;
        font-size: 0.28rem;
        outline: none;
        border: none;
      }
    }
    p {
      height: 1rem;
      line-height: 1rem;
    }
  }
}
</style>
