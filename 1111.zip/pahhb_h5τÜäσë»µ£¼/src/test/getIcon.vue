/**
* Created by chenchangwei837 on 2018/1/22.
*/
<template>
  <div>
    <group>
      <button @touchstart="clickOne">点击获取图标</button>
      <cell>{{dealerIcon}}</cell>
      <img :src="dealerIcon"/>
    </group>

    <!--<p>显示native传递过来的值：{{checkOS}}</p>-->
  </div>
</template>

<script>
  import {Divider, Cell, Group} from 'vux'
  import API from '../common/js/comConfig.js'
  import axios from '../common/js/axiosConfig.js'
  //  import Native from '../common/js/native'
  export default {
    name: 'getIcon',
    components: {
      Divider,
      Cell,
      Group
    },
    data () {
      return {
        msg: 'Welcome to Your Vue.js App',
        checkOS: '1212',
        dealerIcon : "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAAwADADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9QvEPiDT/AArod7q+q3SWWnWcTTTzydFUew5JPQAckkAcmvENW8beMviEGnhupvAXhvJeKOEIdRuocZDyu4ItRjnYAXHdl6VZ8WXn/C0viLcxPLHP4T8JXAjW325Fzqyjc0jHusCsFA/56Fifuisb4ofCbTvjP4bi8Oa3cXC+H5L2K51Kxt2Kf2hDHuYW7uCGVDJ5bNt5Ij25G7Nfzfx9x1Vw2KWV4Ks6ML2nNK8tN+X023V3pdK7Pp8HhIUqftakeaXRPZf1+HqY03wj8La4TfXVqNekckfbL29lvWY9/nd25/Gq8Pwv0fw9N9p0WG40G6HSfSbya2YH32MAfowIPcV0Xw8/Z/8AAfwhvtVvPBnhy38OS6nHFHdx2TyLDIIyxQ+UWKBhvb5gAT3JwK5v4teEfilq2ofa/A3jrQ/DlpbQ7k0nUfD/ANs+2zDJ2y3HnAxxt8q/Im4Ak5JxX8/Us0xFTHctLHzjHdTqOcXfzUHU66J7dXY+gp4p8vvQv5L/AINjpPDfxq8RfDyUReK55PFHhwEmTVlhVb+yTsZI41CzRjuygOMk4bFfRFlfW+pWcF3aTx3VrOiyxTwuHSRCMhlYcEEcgivli3bUb7w/pt1q+nJo+rz2sct5p8c4nW1mKgyRCQcOFbI3Dritz9nvxg3hLxg3ge4mZtH1RZbrRotvy2syZee3U/3WDGRR0XbIPQV/RvAPHGJxldZTmk+aT0jPe7XRtaPyfXzOLNsppyofXMMrW3Xl3XbzNj4cxqnwtstSA/eatczajK2MbmnmeVs+v3sfhXS2Mi7QM1x3g/xJpOl/CW60281C3srnw7fXVhOtw4TYtvOybiTwBswc+lYcfxihk2yaT4a8Qa9ZkZW9tbRYrdx6q0zpvB9QMe9fhnGWAxFTMIOn7zUVfVaS5pXTd9Hfo9TenSlUjKy6u3p0Ov8AC/xY8JeOtY1bSNC1qDUNR0pY5Lq3RWUrHJny5FLACSNtpw6ZU44NYnjf4seEvBuuabpGt6zHp99qV1BZWqyQytG1xNv8iJpVQpG8nlybVdgW2MRnBrwn4L+E/A3wK8XatrVtp/j5J7+zh0xbjxFeJqMGl2MP+qt4tjs6QoAoG7ftVQAQM0nxW8J+APit8SNF8VvpvivXJtHuLa6jXSr5LfSL+e3ZzBK8cjASsm91EigZViuSKzrZTldXNZpyqvDKHuytBS5+VaPXltzX87feTSweNiklT979D2/XGxuHfNcFNqT6J4o8ManFxLaa5YkEddskywyD8UlcfjU+o+OtSusy3Hg/X4IGyWnjijuAvuVidmx9BWdoP2fxz4o8H2lhcR3cV/rVtIrRtkMlu/2iX6YWFgQe5Arp4bwmIpZlheVa88dmn1XVXPr/AHI4OqpvaLv9x6l8TvhjDqXx68P2rNG+geII5dWvdNKcS3lkI1VyehVhNHuXuYVJqL4jQ21rJYI/j6LwbdureXaTm1KXLBhyUlG5gOmFYda9N+L/AIQ1vWY9E1/wuIn8SaDcPLDBNJ5YureRds8AborMArKTxuRc4GTXlfiD4hR+Io0sm+G/i9r1gYprW88PyyoScAjzCChB7tu2981+r+IPDlepj1i8JRlLVuyjzJ8yinZcslzKSbfNa6lpqtPg8vxEqsIJy+FWeq0tfv0tZfI8y0HSdS8T2+of23rzC6try4sLg6TbxxRybGwGjchiAQR7g5GeKqeJdC/4Qvw3PNo2qXcUdoipbWt0sc0cZLBUBdl3bFLDOSSFFR6D4Y1rwXoUGh618PvEUc1u8zRi00+5nSEPIzBY57YkHCkAnPIFWx4S1/xXZajpOheCPEkE19bvAGvLOa1s4sqVHNwwVVBJJC5JyevAr4T+w80+teyWHny83w+z91q/+Xlptc+6hiaMY80qytbfmX5XPQ/hvHaNrwtrv4jx69rMcDmbRbRrZIEIADERopkG0+rd+a63wb8PdH8O/tGHU0sgt7qHh+W9HzfJFMJoo5JFToHdXQFuuE9zXI+DfE1x8OLO00XUPht4pWexhW3EGl6LJcW5ZQAds0YKupPO7POcmvV/hX4Z8Q3HiDVPGPiqAafd3lvHZaZpLSebLY2isXPmuCQZZGILBSQBGgyTmvtuA+HcZQzf63iKMouLtrHlSSvq0oqOra5Um2rXb2Ph8yr8sZ2no13Wv3fif//Z"
      }
    },
    created(){
      let ua = navigator.userAgent.toLowerCase();
      this.checkOS = ua.indexOf("iphone os") != -1 ? 'IOS' : '其他';
    },
    methods: {
      clickOne(){
        //埋点
        window.eventAnalytics('WTF','获取车型图标','1212');
        let self = this;
        Native.requestHybrid({
          tagname: 'getDealerIcon',
          param:{'dealerCode':'10001'},
          callback: function (reqData) {
            console.log(reqData.data)
            self.dealerIcon = reqData.data.dealerIcon;
          }
        })
        console.log('Native end .......')
      },

    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  * {
    margin: 0%;
    padding: 0%;
  }

  .plugin {
    padding: 10px 10px;
    text-align: center;
    font-size: 12px;
    margin-left: 50px;

  }

  h1, h2 {
    font-weight: normal;
  }

  ul {
    list-style-type: none;
    padding: 0;
  }

  li {
    display: inline-block;
    margin: 0 10px;
  }

  a {
    color: #42b983;
  }
</style>

