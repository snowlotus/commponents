<!--
  该组件是 保单管理, 推修任务, 续保查询公用搜索页面(通过url的query来区分是从哪个模块进来的页面)
  实现想法是 该组件提供输入框, 搜索按钮, 还有时间选择器 (进行数据搜集, 不发请求).
  然后引入上述三个模块的list组件, 并根据url 中对应的query值 使用对应的list组件;
  通过输入框或时间选择器 搜集到用户录入的信息后, 传递至对应的list组件 组件内部发起搜索并渲染
-->

<template>
  <section class="box">
    <div class="b-b titleWrap" style="position: fixed;">
      <a href="javascript:;" otype="button" otitle="用户头像" class="navigation_arrow fl" @click="goBack();"></a>
      <div class="entryBox por seachBox">
        <input type="text" :placeholder="placeholder" v-model="searchValue" ref="searchInput"
               @focus="changeSearchPageContent" @blur="blurSearch" @keyup.enter="blurSearch">
        <div class="entryBox_right c clear" v-if="searchValue" @click="searchValue=''">
          <img :src="offImg"/>
        </div>
      </div>
    </div>
    <div v-if="showsearchArea && taskList">
      <group>
        <datetime title="开始时间"
                  format="YYYY-MM-DD"
                  v-model="startTime"
                  :start-date="startDateTimeOption.startDate"
                  :end-date="startDateTimeOption.endDate"
                  @on-change="getTime"
        ></datetime>
        <datetime
          title="结束时间"
          format="YYYY-MM-DD"
          v-model="endTime"
          :start-date="endDateTimeOption.startDate"
          :end-date="endDateTimeOption.endDate"
          @on-change="getTime"
        ></datetime>
      </group>
      <div class="seachBtn">
        <a href="javascript:;" title="确认搜索" otitle="确认搜索" otype="button" @click="search">确认搜索</a>
      </div>
    </div>
    <div v-if="searchEventArea" class="searchWrap">
      <!--<div class="loading" v-if="showloading">
        <div class="seachLoading">
          <img :src="loadingImg" class="loadImg"><em>加载中</em>
        </div>
      </div>-->
      <div class="seachFail" v-if="showSearchNull">
        <img :src="scarchNullImg">
        <p>没有搜到匹配结果，请重试…</p>
      </div>
      <!-- 新车出单列表页 -->
      <pts-order-list :searchCondition="searchValue" flagName="A" @data-back="databack"
                      v-if="orderList && !showSearchNull"></pts-order-list>
      <!-- 推修任务列表页 -->
      <pts-task :searchCondition="searchValue" :startDate="startTime" :endDate="endTime" flagName="07" :active="true"
                @data-back="databack" v-if="taskList && !showSearchNull"></pts-task>
      <!-- 续保查询 -->
      <pts-comtinue :searchCondition="searchValue" flagName="0" :active="true"
                    @data-back="databack" v-if="continueList && !showSearchNull"></pts-comtinue>
    </div>
  </section>
</template>

<script>
  import {Group, Datetime} from 'vux'
  import toast from '../../common/comComponent/toast'
  /*import ptsOrderList from '../orderManagement/page/list.vue'
   import ptsTask from '../repairTask/page/list.vue'
   import ptsComtinue from '../continue/templates/list.vue'*/
  export default {
    name: "search",
    data () {
      return {
        startTime: '',
        endTime: '',
        startDateTimeOption: {
          startDate: '',
          endDate: ''
        },
        endDateTimeOption: {
          startDate: '',
          endDate: ''
        },
        offImg: require('../../common/images/clase.png'),
        loadingImg: require('../../common/images/loading.png'),
        scarchNullImg: require('../../common/images/failIcon.png'),
        searchValue: '',
        showsearchArea: true,
        showloading: true,
        showSearchNull: false,
        placeholder: '请输入搜索的内容（案件号、车牌)',
        orderList: false,
        taskList: false,
        continueList: false,
        toastMsg: '',
        searchEventArea: false,
        flag: 0,
        maidianId: ''
      }
    },
    methods: {
      goBack () {
        this.flag = 1;
        window.history.go(-1)
      },
      getTime () {
        this.endDateTimeOption.startDate = this.startTime;
        if (new Date(this.startTime) > new Date(this.endTime)) {
          toast('开始时间不能晚于结束时间');
          return false
        }
        window.eventAnalytics(this.maidianId, this.maidianId + '点击时间选择器');
        return true
      },
      /*
       * @info input框失去焦点时 触发 目前仅在订单列表进入时显示
       * */
      blurSearch () {
        if (this.taskList) {
          return
        }
        this.$refs.searchInput.blur();
        this.search();
      },
      /*
       * @info 搜索函数, 让显示内容的区域显示, 此时用户输入的值通过组件的 searchCondition props 传入组件内 然后让组件自己发出ajax请求请求数据,
       * */
      search () {
        if (!this.getTime()) {
          return false
        }
        if (this.searchValue.trim().length > 0 || (this.startTime && this.endTime)) {
          this.searchEventArea = true;
          this.showsearchArea = false;
          this.$nextTick(function () {
            this.showSearchNull = false;
          });
          return
        }
        setTimeout(() => {
          if (this.flag !== 1) {
            let msg = this.taskList ? '或选择时间' : '';
            toast(this.toastMsg + msg);
          }
        }, 100)

      },
      /* 当搜索框获取焦点的时候, 切换页面显示的状态, 同时会清除已搜索的逻辑 */
      changeSearchPageContent () {
        this.showsearchArea = true;
        this.searchEventArea = false;
        window.eventAnalytics(this.maidianId, this.maidianId + '点击搜索框');
      },
      /*
       * @info 监听子组件是否获取到数据 由子组件触发
       * @params flag {boolean} 当为真时, 说明没有收到数据, 查询结果为空
       * */
      databack (flag) {
        if (flag) {
          this.showloading = false
          this.showSearchNull = true
          this.showsearchArea = false
        } else {
          this.showloading = false
        }
      },
      init () {
        /* 根据url中的标记 flag 的value 来判断是从哪里进来的搜索页面*/
        const _this = this;
        this.orderList = false;
        this.taskList = false;
        this.searchValue = '';
        this.searchEventArea = false;
        const obj = {
          orderList () {
            _this.orderList = true;
            _this.placeholder = '请输入搜索的内容(车架号、车牌)';
            _this.toastMsg = '请输入车架号/车牌';
            _this.maidianId = '保单管理';
            _this.$nextTick(function () {
              _this.$refs.searchInput.focus()
            })
          },
          taskList () {
            _this.taskList = true;
            _this.placeholder = '请输入搜索的内容(案件号、车牌)';
            _this.toastMsg = '请输入案件号/车牌';
            _this.maidianId = '推修任务';
          },
          continue () {
            _this.continueList = true;
            _this.placeholder = '请输入搜索的内容(被保人、车牌)';
            _this.toastMsg = '请输入被保人/车牌';
            _this.maidianId = '续保查询';
            _this.$nextTick(function () {
              _this.$refs.searchInput.focus()
            })
          }
        };
        obj[this.$route.query.flag]();
        window.eventAnalytics(this.maidianId, '进入' + this.maidianId + '搜索页面');
      }
    },
    mounted () {
      this.init();
      const dateObj = new Date();
      const endYear = dateObj.getFullYear();
      const endMonth = dateObj.getMonth() + 1;
      const endDate = dateObj.getDate();
      const today = `${endYear}-${endMonth >= 10 ? endMonth : '0' + endMonth}-${endDate >= 10 ? endDate : '0' + endDate}`
      const startDateObj = new Date();
      startDateObj.setMonth(endMonth - 6); // 显示近六个月的搜索范围
      const startYear = startDateObj.getFullYear();
      const startMonth = startDateObj.getMonth();// 上面的endMonth已经加一 不需要再加一
      this.startDateTimeOption.startDate = this.endDateTimeOption.startDate = `${startYear}-${startMonth >= 10 ? startMonth : '0' + startMonth}-01`
      this.startDateTimeOption.endDate = this.endDateTimeOption.endDate = today;
      this.$nextTick(function () {
       this.startTime = this.endTime = today;
       });
    },
    components: {
      Group,
      Datetime,
      ptsOrderList: resolve => require.ensure([], () => resolve(require('../orderManagement/page/list.vue')), 'SearchOrderList'),
      ptsTask: resolve => require.ensure([], () => resolve(require('../repairTask/page/list.vue')), 'SearchTaskList'),
      ptsComtinue: resolve => require.ensure([], () => resolve(require('../continue/templates/list.vue')), 'SearchComtinueList')
    },
    beforeRouteLeave (to, from, next) {
      console.log(`进入页面${to.path}保留页面`);
      if (to.path === '/Order-list' || to.path === '/repairTask' || to.path === '/continueIndex') {
        console.log(`进入页面${to.path}销毁页面`);
        this.$destroy();
      }
      next()
    }
  }
</script>

<style lang="less">
  @import "../../common/css/1px.less";

  .loadImg {
    animation: loading 2s linear infinite;
  }

  .searchWrap {
    height: 100%;
    border-top: 1px solid transparent;
    box-sizing: border-box;
  }

  .b-b {
    .pts-1px-b(#D8D8D8);
  }

  @keyframes loading {
    form {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
</style>
