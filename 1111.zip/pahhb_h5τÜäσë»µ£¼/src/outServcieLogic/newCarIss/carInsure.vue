<template>
  <div class="box" :class="isWXSHOWHEADER?'':'wx_box'">
    <!--<pts-header titleText="车险投保" leftFlag @on-left="goMenu" v-if="isWXSHOWHEADER"></pts-header>-->
    <div class="t_header" v-if="isWXSHOWHEADER">
      <div class="t_header_arrow" @click.stop="goMenu"></div>
      <div class="t_header_title">车险投保</div>
      <div class="t_header_null"></div>
    </div>
    <section class="orderDtail_wrapper con_touch">
      <!--输入车牌号 start-->
      <div class="bg_fff box_shadow">
        <table cellpadding="0" cellspacing="0" border="0" class="cph_table">
          <!-- 代理人 -->
          <!--1:个人代理2:兼业代理3:专业代理4:传统经纪D:直接业务-->
          <tr v-if="businessSourceDetailCode != 'D' && PopupPickerOption.list1.length>0">
            <td class="ord_label pts-b-b" style="width: 20%;">
              {{ businessSourceDetailCode == '4' ? '经纪人':'代理人' }}
            </td>
            <td colspan="5" style="padding-left: .5rem;" class="pts-b-b">
              <popup-picker :show-name="PopupPickerOption.showName" v-model='PopupPickerOption.value1'
                            :value-text-align='PopupPickerOption.textAlign' :data="PopupPickerOption.list1" :columns="1"
                            :placeholder="PopupPickerOption.placeholder1"></popup-picker>
              <div class='iconPosition'>
                <div>
                  <img :src="PopupPickerOption.arrowLeft">
                </div>
              </div>
            </td>
          </tr>
          <!-- 投保地区 -->
          <!--<tr>
            <td class="ord_label pts-b-b" style="width: 20%;">投保地区</td>
            <td colspan="3" style="padding-left: .5rem;position:relative;" class="pts-b-b">
              <popup-picker
                :show-name="PopupPickerOption.showName"
                v-model='PopupPickerOption.value2'
                :value-text-align='PopupPickerOption.textAlign'
                :data="PopupPickerOption.list2"
                :columns="2"
                :placeholder="PopupPickerOption.placeholder2"
                @on-change="PopupPickerOption.onChange2"
              ></popup-picker>
              <div class='iconPosition'>
                <div>
                  <img :src="PopupPickerOption.arrowLeft">
                </div>
              </div>
            </td>
          </tr> -->
          <!-- 车牌号码 -->
          <tr>
            <td class="ord_label">车牌号码</td>
            <td style="padding-left:0.5rem;width:1.4rem;position:relative;" @click="showKey = true">
              <div>{{PopupPickerOption.value3}}</div>
              <!--<popup-picker
                :show-name="PopupPickerOption.showName"
                v-model='PopupPickerOption.value3'
                :value-text-align='PopupPickerOption.textAlign'
                :data="PopupPickerOption.list3"
                :columns="1"
                :placeholder="PopupPickerOption.placeholder3"
                @on-show='PopupPickerOption.onShow3'
                @on-hide='PopupPickerOption.onHide3'
              ></popup-picker>-->
              <div class='iconPosition' style="right:.15rem;">
                <div :class="PopupPickerOption.isAction3?'list3Action':'list3UnAction'">
                  <img :src="PopupPickerOption.arrowLeft">
                </div>
              </div>
            </td>
            <td>
              <input class=" input_w300" id="inputElem" type="text" :placeholder="isFlag?'不用输入车牌号':'请输入车牌号码'"
                     :readonly="isFlag"
                     v-model="carNo" @input="carNo=carNo.toUpperCase()" maxlength="6" minlength="5" style="width:2rem"/>
            </td>
            <td style="text-align:right;">
              <!--给i标签在添加“checked”样式就是选中状态-->
              <div @click.prevent="isFlag=!isFlag">
                <i class="cph_check" :class="isFlag==true?'checked':''"></i>
                <span class="cph_wsp">未上牌</span>
              </div>
            </td>
          </tr>
        </table>
      </div>
      <div class="cph_btn">
        <a v-if='true' class="cph_ljtb tac " :class="BtnFlag ? '':'closeBtn'" target="_blank" title="立即投保" otitle="立即投保"
           otype="button" @click="next">立即投保</a>
      </div>
      <!--输入车牌号 End-->
      <!--模拟form 表单提交-->
      <form :action="imcsTranData.imcsUrl" method="post" id="goToImcs" name="goToImcs" ref="formElem">
        <input type="hidden" :value="imcsTranData.params" name="params"/>
        <input type="hidden" :value="imcsTranData.signData" name="signData"/>
        <input type="hidden" :value="imcsTranData.systemId" name="systemId"/>
      </form>
    </section>
    <!-- 车牌号专用键盘 -->
    <pts-key-board v-model="showKey" @on-input="getKeyBoardValue" :checked-value="PopupPickerOption.value3"
                   inputElemId="inputElem"></pts-key-board>
  </div>
</template>

<script>
  import Toast from '../../common/comComponent/toast'
  import API from '../../common/js/comConfig'
  import Axios from '../../common/js/axiosConfig'
  import ptsKeyBoard from '../../common/comComponent/keyBoard'
  import {checkVehicleNumOrNo} from '../../common/js/comUtils'
  //2018-06-13 不在让用户选择省市
  // import specialJson from '@/common/js/data.js'
  import {PopupPicker} from 'vux'
  import {setTimeout} from 'timers'

  export default {
    components: {
      ptsKeyBoard,
      PopupPicker
    },
    data () {
      return {
        //是否显示头部
        isWXSHOWHEADER: window.PageStatus.WX_SHOW_HEADER,
        title: '车险投保',
        isFlag: true,
        carNo: '*',
        insureAddress: '',
        vehicleLicencePrefix: '',
        imcsTranData: {
          imcsUrl: '',
          params: '',
          signData: '',
          systemId: ''
        },
        BtnFlag: false,
        //业务细分来源
        businessSourceDetailCode: '',
        //全部数据
        allData: {},
        /* 这里是两个picker的配置 */
        PopupPickerOption: {
          //默认代理人
          defaultAgent: {},
          // 代理人列表
          agentList: [],
          //经纪人列表
          brokerList: [],
          // 左箭头的地址
          arrowLeft: require('./../../common/images/arrowLeft2.png'),
          // 显示name属性还是value属性
          showName: true,
          // 值的字体方向
          textAlign: 'left',
          // 城市对应的车牌前缀
          cityToNumber: {},
          // 选择1的默认值
          value1: [],
          // 选择1的提示文本
          placeholder1: '请选择代理人',
          // 选择1的数据
          list1: [],
          /*// 提示文字
          placeholder2: '请选择投保地区',
          // 选择2的默认值
          value2: [],
          // 选择2的数据
          list2: [],*/
          // 第二个的change方法
          onChange2: val => {
            //由于初始化值的value2为[],而在获取一些初始化值时会触发onchange2,此时获取城市列表的接口还没成功,导致数据有问题,报错
            if (this.PopupPickerOption.isFirst) {
              return
            }
            //当前选中城市的值
            val = val[1]
            // 初始化value3和list3
            let value3 = []
            let list3 = []
            //将城市的代码放到之前生成的城市对应的车牌前缀放入value3中
            value3.push(this.PopupPickerOption.cityToNumber[val][0].name)
            //取出的数组列表放进去
            list3 = this.PopupPickerOption.cityToNumber[val]
            this.$set(this.PopupPickerOption, 'list3', list3)
            this.$set(this.PopupPickerOption, 'value3', value3)
          },
          isFirst: true,
          isAction3: false,
          placeholder3: '',
          // 选择3的默认值
          // value3: [],
          // 由滑动选择改为手动输入 value3: [] => value3: ''
          value3: '',
          // 选择3的数据
          list3: [],
          onShow3: () => {
            this.$set(this.PopupPickerOption, 'isAction3', true)
          },
          onHide3: () => {
            this.$set(this.PopupPickerOption, 'isAction3', false)
          }
        },
        // 显示车牌键盘
        showKey: false
      }
    },
    created () {
      let self = this
      //获取城市列表,车牌前缀等 2018-06-13 不在让用户选择省市
      // getDestination(self)
      //获取初始化值包括:{默认代理人,代理人列表,默认投保城市,默认城市车牌前缀,城市车牌前缀列表}
      createindex(self)
    },
    watch: {
      carNo: function (newValue) {
        this.canSubmit()
      },
      //是否显示车牌号
      isFlag: function (flag) {
        if (flag) {
          window.eventAnalytics('车险投保', '点击了未上车牌')
          this.carNo = '*'
        } else {
          this.carNo = ''
        }
        this.canSubmit()
      },
      'PopupPickerOption.value1': function (newValue) {
        this.canSubmit()
      },
      'PopupPickerOption.value3': function (newValue) {
        this.canSubmit()
      }
    },
    methods: {
      canSubmit () {
        if (this.PopupPickerOption.value1.length == 0) {
          this.$set(this, 'businessSourceDetailCode', 'D')
        }
        if (this.PopupPickerOption.value3.length < 2) {
          this.$set(this, 'BtnFlag', false)
          return '请输入完整的车牌简称!'
        } else {
          return this.$set(this, 'BtnFlag', true)
        }
        /*if (this.PopupPickerOption.value2.length === 2) {
          if (!this.isFlag) {
            if (this.carNo) {
              this.$set(this, 'BtnFlag', true)
            } else {
              this.$set(this, 'BtnFlag', false)
              return '请输入车牌号!'
            }
          } else {
            this.$set(this, 'BtnFlag', true)
          }
        } else {
          this.$set(this, 'BtnFlag', false)
          return '请输入车牌简称!'
        }*/
      },
      //回到Native主页
      goMenu () {
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      //下单
      next () {
        window.eventAnalytics('车险投保', '点击了立即投保')
        if (!this.BtnFlag) {
          Toast(this.canSubmit())
          return
        }
        if (this.carNo.includes('-')) return Toast('车牌号格式错误');
        let newCarNo = this.PopupPickerOption.value3 + this.carNo
        if (checkVehicleNumOrNo(newCarNo)) {
          this.goToNext()
        } else {
          Toast('车牌号不正确,请重新输入!')
        }
      },
      //去下单
      goToNext () {
        let self = this
        if (self.isFlag) {
          self.carNo = '*'
        }
        let CarNo = this.PopupPickerOption.value3 + self.carNo //组合车牌号
        //初始化立即投保的数据
        let reqData = {
          licenseNo: CarNo
        }
        //选择投保区域的省市编码
        if (
          this.PopupPickerOption.value2 &&
          this.PopupPickerOption.value2.length == 2
        ) {
          reqData.provinceCode = this.PopupPickerOption.value2[0]
          reqData.cityCode = this.PopupPickerOption.value2[1]
        }
        if (this.allData.brokerList) {
          for (let i = 0; i < this.allData.brokerList.length; i++) {
            if (
              this.allData.brokerList[i].brokerCode ==
              this.PopupPickerOption.value1[0]
            ) {
              reqData.broker = {}
              reqData.broker.brokerCode = this.allData.brokerList[i].brokerCode
              reqData.broker.brokerName = this.allData.brokerList[i].brokerName
              break
            }
          }
        } else if (this.allData.agentList) {
          for (let i = 0; i < this.allData.agentList.length; i++) {
            if (
              this.allData.agentList[i].agentCode ==
              this.PopupPickerOption.value1[0]
            ) {
              reqData.agent = {}
              reqData.agent.agentCode = this.allData.agentList[i].agentCode
              reqData.agent.agentName = this.allData.agentList[i].agentName
              reqData.agent.conferNo = this.allData.agentList[i].conferNo
              reqData.agent.subConferNo = this.allData.agentList[i].subConferNo
              break
            }
          }
        }
        // let agentObj = {}
        // //获取选中代理人的所有信息,先判断是否不为直接业务,在判断代理人选项是否有值
        // if (
        //   this.businessSourceDetailCode != 'D' &&
        //   this.businessSourceDetailCode != '4' &&
        //   this.PopupPickerOption.value1[0]
        // ) {
        //   //判断代理人列表是否存在,存在时循环列表抓去代理人信息
        //   if (this.PopupPickerOption.agentList) {
        //     for (let i = 0; i < this.PopupPickerOption.agentList.length; i++) {
        //       if (
        //         this.PopupPickerOption.agentList[i].agentCode ===
        //         this.PopupPickerOption.value1[0]
        //       ) {
        //         agentObj = this.PopupPickerOption.agentList[i]
        //         break
        //       }
        //     }
        //   } else {
        //     //不存在判断是否存在默认代理人,抓取默认代理人信息
        //     if (this.PopupPickerOption.defaultAgent.agentCode) {
        //       agentObj = this.PopupPickerOption.defaultAgent
        //     }
        //   }
        //   //判断取出的代理人信息是否存在,不存在也不传过去后台
        //   if (agentObj.agentCode) {
        //     reqData.agent = {}
        //     reqData.agent.agentCode = agentObj.agentCode
        //     reqData.agent.agentName = agentObj.agentName
        //     reqData.agent.conferNo = agentObj.conferNo
        //     reqData.agent.subConferNo = agentObj.subConferNo
        //   }
        // } else if (
        //   this.businessSourceDetailCode != 'D' &&
        //   this.businessSourceDetailCode == '4' &&
        //   this.PopupPickerOption.value1[0]
        // ) {
        //   //判断代理人列表是否存在,存在时循环列表抓去代理人信息
        //   if (this.PopupPickerOption.brokerList) {
        //     for (let i = 0; i < this.PopupPickerOption.brokerList.length; i++) {
        //       if (
        //         this.PopupPickerOption.brokerList[i].brokerCode ===
        //         this.PopupPickerOption.value1[0]
        //       ) {
        //         agentObj = this.PopupPickerOption.brokerList[i]
        //         break
        //       }
        //     }
        //   } else {
        //     //不存在判断是否存在默认代理人,抓取默认代理人信息
        //     if (this.PopupPickerOption.defaultAgent.brokerCode) {
        //       agentObj = this.PopupPickerOption.defaultAgent
        //     }
        //   }
        //   //判断取出的代理人信息是否存在,不存在也不传过去后台
        //   if (agentObj.brokerCode) {
        //     reqData.broker = {}
        //     reqData.broker.brokerCode = agentObj.brokerCode
        //     reqData.broker.brokerName = agentObj.brokerName
        //   }
        // }
        Axios.post(API.getWebServiceUrls('insurancing'), reqData)
          .then(res => {
            let resData = res.data
            if (resData.code == 0) {
              self.imcsTranData['imcsUrl'] = resData.data.imcsUrl || ''
              self.imcsTranData['params'] = resData.data.params || ''
              self.imcsTranData['signData'] = resData.data.signData || ''
              self.imcsTranData['systemId'] = resData.data.systemId || ''
              setTimeout(function () {
                self.$refs.formElem.submit()
              }, 0)
            } else {
              Toast(resData.msg || '系统繁忙, 请稍后再试。')
            }
          })
          .catch(err => {
            console.log(err)
          })
      },
      // 由车商键盘组件触发, 获取用户输入的值
      getKeyBoardValue (key) {
        this.PopupPickerOption.value3 = key;
      }
    }
  }

  /* 2018-06-13 需求不在选择地区 改为用户手动输入车牌 */
  /*function getDestination(_this) {
    //获取（省、市、区）操作相关API,回调函数中对数据进行处理
    Axios.post(API.getWebServiceUrls('getDestination'))
      .then(res => {
        let data = res.data.data
        if (res.data.code === 0) {
          // 存放第二个选择器的选项
          let list2 = []
          // 存放城市所对应的车牌前缀
          let obj = {}
          // 第一次循环省份，因为省份需要和市进行联动，需要设定特定的value，一边联动。而省份在项目中为最外层，所以parent设定为0
          for (let i = 0; i < data.length; i++) {
            list2.push({
              name: data[i].provinceChineseName,
              value: data[i].provinceCode,
              parent: 0
            })
            //第二次循环是循环市级，所以需要给与parent一致的值以便联动
            for (let j = 0; j < data[i].cityList.length; j++) {
              list2.push({
                name: data[i].cityList[j].cityChineseName,
                value: data[i].cityList[j].cityCode,
                parent: data[i].provinceCode
              })
              //第三次循环将城市对应的车牌号码前缀存入到cityToNumber对象里面，有的城市有几个车牌前缀，我们以数组的方式存入
              let cityToNumberObj = []
              //判断是否在特殊地区里面
              if (
                specialJson.hasOwnProperty(data[i].cityList[j].cityChineseName)
              ) {
                let key = data[i].cityList[j].cityChineseName
                cityToNumberObj = specialJson[key]
              } else {
                //按照vux里面传入name,value,parent的方法传入
                cityToNumberObj.push({
                  name: data[i].cityList[j].vehicleLicencePrefixList[0],
                  value: data[i].cityList[j].vehicleLicencePrefixList[0],
                  parent: 0
                })
              }
              obj[data[i].cityList[j].cityCode] = cityToNumberObj
            }
          }
          //将arr设置进this中,这里将获取到的省市数据打包后放入list2中
          _this.$set(_this.PopupPickerOption, 'list2', list2)
          //将obj设置进this中,这里将城市对应的车牌前缀打包成{name.value,parent}的形式,方便后面展示数据时可以使用
          _this.$set(_this.PopupPickerOption, 'cityToNumber', obj)
          //有数据了,就把第一次的值设置为true
          _this.$set(_this.PopupPickerOption, 'isFirst', false)
        } else {
          Toast(res.data.msg)
        }
      })
      .catch(err => {
        if (err && err.msg) {
          Toast(err.msg)
        } else {
          console.log(err)
          Toast('出错了，请稍后重试')
        }
      })
  }*/

  function createindex (_this) {
    //获取列出代理人,以及初始化所有值
    Axios.post(API.getWebServiceUrls('createindex'))
      .then(res => {
        let data = res.data.data
        if (res.data.code === 0) {
          let list1 = [],
            value1 = [],
            value2 = [],
            value3 = [],
            manList = [],
            list3 = [],
            type
          _this.$set(
            _this,
            'businessSourceDetailCode',
            data.businessSourceDetailCode
          )
          if (data.businessSourceDetailCode == 'D') {
          } else if (data.businessSourceDetailCode == '4') {
            manList = data.brokerList || []
            type = 'broker'
          } else {
            manList = data.agentList || []
            type = 'agent'
          }
          for (let i = 0; i < manList.length; i++) {
            list1.push({
              name: manList[i][`${type}Name`],
              value: manList[i][`${type}Code`],
              parent: 0
            })
          }
          if (manList.length > 0) {
            value1.push(manList[0][`${type}Code`])
          }
          //设置省市县
          value2.push(data.provinceCode)
          value2.push(data.cityCode)
          //设置车牌前缀
          /*if (specialJson.hasOwnProperty([data.cityName])) {
            list3 = specialJson[data.cityName]
          } else {
            list3.push({
              name: data.vehicleLicencePrefix,
              value: data.vehicleLicencePrefix,
              parent: 0
            })
          }*/
          // 由滑动选择改为键盘输入
          // value3.push(data.vehicleLicencePrefix)
          value3 = data.vehicleLicencePrefix
          _this.$set(_this.PopupPickerOption, 'list1', list1)
          _this.$set(_this.PopupPickerOption, 'list3', list3)
          _this.$set(_this.PopupPickerOption, 'value1', value1)
          _this.$set(_this.PopupPickerOption, 'value2', value2)
          _this.$set(_this.PopupPickerOption, 'value3', value3)
          _this.$set(_this, 'allData', data)
          // _this.$set(_this, 'businessSourceDetailCode', data.businessSourceDetailCode);
          // if (data.businessSourceDetailCode === '4' && !data.brokerName && !data.brokerList) {
          //   _this.$set(_this, 'businessSourceDetailCode', 'D');
          // } else if (data.businessSourceDetailCode === '4' && !data.agentName && !data.agentList) {
          //   _this.$set(_this, 'businessSourceDetailCode', 'D');
          // }
          // if (data.businessSourceDetailCode == '4') {
          //   // 代理人列表存在agentList
          //   _this.$set(_this.PopupPickerOption, 'brokerList', data.brokerList || []);
          // } else {
          //   // 代理人列表存在agentList
          //   _this.$set(_this.PopupPickerOption, 'agentList', data.agentList || []);
          // }
          // // value默认形式为一个数组,当有多排的时候数组增加
          // // list默认为数组对象,根据popup picker分别为{name,value,parent}
          // // list为各个下拉选项的列表数据
          // let list1 = [];
          // let list3 = [];
          // // value为各个选项的默认值
          // let value1 = [];
          // let value2 = [];
          // let value3 = [];
          // let defaultAgent = {};
          // //数据回来的初始化默认（代理人｜经纪人）取出默认的代理人或经纪人,没有的时候为{}
          // let dataAgent = data.businessSourceDetailCode == 'D' ? data.broker ? data.broker : {} : data.agent ? data.agent : {};
          // //数据回来的初始化默认（代理列表｜经纪列表）取出默认的代理人列表或经纪人列表,没有的时候为{}
          // let dataList = data.businessSourceDetailCode == 'D' ? data.brokerList ? data.brokerList : [] : data.agentList ? data.agentList : [];

          // //初始化代理人或经纪人
          // if (data.businessSourceDetailCode == '4') {
          //   //判断相应的代理人名称或经纪人名称是否为空
          //   //不为空时push相应的code值
          //   if (dataAgent.brokerName) {
          //     defaultAgent = dataAgent;
          //     value1.push(dataAgent.brokerCode);
          //   }
          // } else {
          //   if (dataAgent.agentName) {
          //     defaultAgent = dataAgent;
          //     value1.push(dataAgent.agentCode);
          //   }
          // }
          // //初始化代理人列表,判断是否为空;有列表,没有默认代理人是,取列表第一项
          // if (dataList && dataList.length >= 1) {
          //   //判断取代理人列表还是经纪人列表
          //   if (data.businessSourceDetailCode == '4') {
          //     if (!dataAgent.brokerCode) {
          //       value1.push(dataList[0].brokerCode);
          //     }
          //     //循环将代理人列表的插入到选项中
          //     for (let i = 0; i < dataList.length; i++) {
          //       list1.push({
          //         name: dataList[i].brokerName,
          //         value: dataList[i].brokerCode,
          //         parent: 0
          //       })
          //     }
          //   } else {
          //     if (!dataAgent.agentCode) {
          //       value1.push(dataList[0].agentCode);
          //     }
          //     //循环将代理人列表的插入到选项中
          //     for (let i = 0; i < dataList.length; i++) {
          //       list1.push({
          //         name: dataList[i].agentName,
          //         value: dataList[i].agentCode,
          //         parent: 0
          //       })
          //     }
          //   }
          // }
          // //初始化用户默认的省市数据,为空时不设置
          // if (data.provinceCode && data.cityCode) {
          //   //初始化默认的省市
          //   value2.push(data.provinceCode);
          //   value2.push(data.cityCode);
          // }

          // //获得的默认市去特殊城市车牌前缀查询,如果有,取出前缀列表放入下拉选项中
          // if (specialJson.hasOwnProperty([data.cityName])) {
          //   list3 = specialJson[data.cityName]
          // } else {
          //   //如果没有,则该城市只有默认的一个车牌前缀.所以将其插入列表中
          //   list3.push({
          //     name: data.vehicleLicencePrefix,
          //     value: data.vehicleLicencePrefix,
          //     parent: 0
          //   })
          // }
          // if (data.vehicleLicencePrefix) {
          //   //初始化车牌的前缀
          //   value3.push(data.vehicleLicencePrefix);
          // }
          // //最后将初始化值设置进this中
          // _this.$set(_this.PopupPickerOption, 'list1', list1);
          // _this.$set(_this.PopupPickerOption, 'list3', list3);
          // _this.$set(_this.PopupPickerOption, 'defaultAgent', defaultAgent);
          // _this.$set(_this.PopupPickerOption, 'value1', value1);
          // _this.$set(_this.PopupPickerOption, 'value2', value2);
          // _this.$set(_this.PopupPickerOption, 'value3', value3);
        } else {
          Toast(res.data.msg || '系统繁忙, 请稍后再试。')
        }
      })
      .catch(err => {
        if (err && err.msg) {
          Toast(err.msg)
        } else {
          console.log(err)
          Toast('出错了，请稍后重试')
        }
      })
  }
</script>

<style lang="less">
  .box {
    .t_header {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: .88rem;
      background: #FFffff;
      box-sizing: border-box;
      color: #eee;
      display: flex;
      .t_header_arrow {
        /*flex: 1;*/
        width: .8rem;
        height: .8rem;
        background: url(../../common/images/nav_arrow.png) no-repeat center 60%;
        background-size: 10px 18px;
      }
      .t_header_title {
        flex: 6;
        font-size: .34rem;
        color: #333;
        /*margin-top: .18rem;*/
        line-height: .88rem;
        text-align: center;
      }
      .t_header_null {
        flex: 1;
      }
    }
    .t_header:before {
      content: " ";
      position: absolute;
      left: 0;
      bottom: 0;
      right: 0;
      height: 1px;
      border-bottom: 1px solid #eee;
      color: #eee;
      -webkit-transform-origin: 0 100%;
      transform-origin: 0 100%;
      transform: scaleY(0.5);
    }

    .iconPosition {
      width: .077rem;
      height: .136rem;
      position: absolute;
      right: .3rem;
      top: 50%;
      transform: translateY(-50%);
      & > div,
      img {
        width: 100%;
        height: 100%;
        position: absolute;
        left: 0;
      }
      .list3Action {
        transform: rotate(270deg);
      }
      .list3UnAction {
        transform: rotate(90deg);
      }
    }
    .vux-cell-box:before {
      border: 0 !important;
      height: 0 !important;
    }
    .weui-cell {
      padding: 0 15px 0 0 !important;
      .vux-popup-picker-select {
        .vux-cell-value {
          color: #333;
        }
        font-size: .28rem;
      }
      .weui-cell_access .weui-cell__ft:after {
        border-color: #ccc;
      }
      .weui-cell__ft {
        display: none;
      }
    }
    .vux-cell-box:before {
      border: 0;
    }
  }

  .closeBtn {
    background: #ccc;
  }
</style>
