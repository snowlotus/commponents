<template>
  <section class="box">
    <pts-header inputPlh="请输入搜索的内容(被保人、车牌)" flagName="continue" leftFlag @on-left="goMenu"></pts-header>
    <pts-Tab :titleList="tabTitle" v-model="index" ref="tabVue" @on-child-change="tabChildChange" @on-change="tabMaiDian">
      <pts-tab-item>
        <!-- 应续 -->
        <list :active="index===0" flagName="0"></list>
      </pts-tab-item>
      <pts-tab-item>
        <!-- 未续 -->
        <list :active="index===1" :tabChildFlag="tabChildFlag" flagName="1"></list>
      </pts-tab-item>
      <pts-tab-item>
        <!-- 脱保 -->
        <list :active="index===2" flagName="2"></list>
      </pts-tab-item>
      <pts-tab-item>
        <!-- 已续 -->
        <list :active="index===3" flagName="3"></list>
      </pts-tab-item>
    </pts-Tab>
  </section>
</template>

<script>
  import ptsTab from '../../common/comComponent/tab'
  import list from  './templates/list.vue'
  export default {
    name: "continueIndex",
    data () {
      return {
        tabTitle: [
          {
            title: '应续'
          },
          {
            title: '未续',
            childs: [
              {title: '未续', flag: '1'},
              {title: '当月应续', flag: '4'},
              {title: '下月应续', flag: '5'}
            ]
          },
          {title: '脱保'},
          {title: '已续'}
        ],
        index: 0,
        tabChildFlag: ''
      }
    },
    methods: {
      tabChildChange (item) {
        this.tabChildFlag = item.flag
      },
      /*
       * @info 返回app主页
       * */
      goMenu(){
        //回到Native主页
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      tabMaiDian (item) {
        window.eventAnalytics('续保查询', 'tab切换', {tabName: item.title});
      }
    },
    created () {
      this.index = ~~this.$route.query.status;
    },
    mounted () {
      this.tabName = this.tabTitle[this.index].title;
      window.eventAnalytics('续保查询', 'tab切换', {tabName: '应续'});
    },
    components: {
      ptsTab,
      ptsTabItem: ptsTab.Item,
      list: resolve => require.ensure([], () => resolve(require('./templates/list.vue')), 'SearchComtinueList')
    }
  }
</script>

<style lang="less">

</style>
