<template>
  <div class="box">
    <pts-header titleText="选择代理人"></pts-header>
    <div class="cellWrap">
      <ul class="cell-list">
        <!--  对号className: "active" -->
        <li class="cell-item pts-b-b text-hidden" v-for="(item,index) in list" :key="index" :class="{'active': activeIndex === index}"
            @click.prevent="activeIndex = index,xubao(item)">
          <p class="content text-hidden">{{item.agentCode}}-{{item.conferName}}</p>
        </li>
      </ul>
    </div>
    <form :action="fromData.imcsUrl" method="post" ref="formElem">
      <input type="hidden" name="params" :value="fromData.params">
      <input type="hidden" name="signData" :value="fromData.signData">
      <input type="hidden" name="systemId" :value="fromData.systemId">
    </form>
  </div>
</template>

<script>
  import loding from '../../common/comComponent/loading';
  import toast from '../../common/comComponent/toast';
  import axios from '../../common/js/axiosConfig';
  import url from '../../common/js/comConfig';

  export default {
    name: "cell-page",
    data () {
      return {
        list: [],
        activeIndex: 0,
        fromData: {
          imcsUrl: '',
          params: '',
          signData: '',
          systemId: ''
        }, // 一键续保 跳转from表单数据
      }
    },
    methods: {
      xubao (item) {
        let obj = Object.assign(this.$route.query, item);
        console.log(obj);
        this.oneKeyRenewal(obj);
      },
      /* 一键续保 */
      oneKeyRenewal (obj) {
        const _this = this;
        window.eventAnalytics('续保查询', '续保详情-一键续保');
        axios.post(url.getWebServiceUrls('oneKeyRenewal'), obj).then(res => {
            console.log('返回的数据为' + JSON.stringify(res.data));
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            switch (data.code) {
              case 0:
                _this.fromData.imcsUrl = data.data.imcsUrl;
                _this.fromData.params = data.data.params;
                _this.fromData.signData = data.data.signData;
                _this.fromData.systemId = data.data.systemId;
                try {
                  _this.$nextTick(function () {
                    console.log('提交form')
                    _this.$refs.formElem.submit()
                  })
                } catch (e) {
                  console.log(e)
                }
                break
              default:
                toast(data.msg)
                break
            }
          }
        ).catch(err => {
          // toast('网络错误啦~ \\(≧▽≦)/~, 请重试')
          console.log(err)
        })
      },
      // 获取数据
      getData () {
        let query = this.$route.query;
        axios.post(url.getWebServiceUrls('getOutSideAgent'))
          .then(res => {
            let data = res.data;
            if (data.code !== 0) {
              toast(data.msg);
              return;
            }
            this.list = data.data.agentList;
          })
          .catch(e => {
            console.log(e);
          })
      }
    },
    //路由第一次进入初始化数据
    mounted () {
      this.getData()
    }
  }
</script>

<style scoped lang="less">
  @import "../../common/css/theme";

  .cellWrap {
    height: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    font-size: .28rem;
    .cell-list {
      background: #fff;
      .cell-item {
        margin: 0 0.3rem;
        padding: 0.3rem 0;
        color: #333;
         &.triangle { // 向右的箭头
           padding: 0.2rem 0.5rem 0.2rem 0.2rem;
           background: url('../../common/images/icon_arrow.png') no-repeat 95% center;
           background-size: 0.12rem 0.24rem;
         }
        &.active { // 对号
          padding: 0.3rem 0;
          background: url('../../common/images/icon_tick.png') no-repeat 95% center;
          background-size: 0.2rem 0.2rem;
          & > .car-type, & > .car-info {
            color: @theme-color;
          }
        }
        .content {
          width: 100%;
          font-size: 0.3rem;
        }
        .car-type {
          width: 100%;
          margin-bottom: 0.01rem;
          font-size: 0.28rem;
          color: #000;
        }
        .car-info {
          width: 100%;
          font-size: 0.26rem;
          color: #666;
        }
      }
    }
  }
</style>
