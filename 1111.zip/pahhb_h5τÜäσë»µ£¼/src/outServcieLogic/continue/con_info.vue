<template>
  <section class="box" :class="{'pd': datas.renewalStatus !== '2' && datas.status !=='1'}">
    <pts-header titleText="续保详情"></pts-header>
    <main class="bg_f5f5f5">
      <div class="wrap insideXubaoWrap insideXubaoDetail">
        <!-- main start -->
        <div class="mainWrap" style="position: relative">
          <div class="scoreArea c" @click="goUserInfo" v-if="userMsg.renewalRate > 5">
            <div class="scoreAreaLeft">
              <div class="chartBox"><img :src="imgFiveStart" alt=""></div>
              <p class="txtT">{{userMsg.renewalFlagTop1}}</p>
              <p class="txtLM">{{userMsg.renewalFlagTop2}}</p>
              <p class="txtRM">{{userMsg.renewalFlagTop3}}</p>
              <p class="txtLD">{{userMsg.renewalFlagTop4}}</p>
              <p class="txtRD">{{userMsg.renewalFlagTop5}}</p>
            </div>
            <div class="scoreAreaRight">
              <p class="scoreNum">{{userMsg.renewalRate * 10}}分</p>
              <p>续保意愿较高</p>
            </div>
          </div>
          <div class="scoreArea c" v-else>
            <div class="scoreEmpty">
              <img :src="imgEmpty" alt="">
            </div>
          </div>
          <div class="taskArea clientArea">
            <div class="taskBox" style="padding:.4rem .3rem .2rem .45rem">
              <dl>
                <dt>被保人</dt>
                <dd>{{datas.insuredName}}</dd>
              </dl>
              <!--<dl>
                <dt>保险止期</dt>
                <dd>2018-01-29</dd>
              </dl>-->
              <dl>
                <dt>保费总额</dt>
                <dd><em><span class="font-size-half">¥</span>{{datas.totalPremium | NumberThere}}</em></dd>
              </dl>
              <!-- v-if="datas.renewalStatus !== '2' && datas.status !== '1'" -->
              <a href="javascript:;" v-if="datas.renewalStatus !== '2' && datas.status !=='1'" otype="button"
                 otitle="拨打电话"
                 class="btnState btnStateTell pts-b-l" @click.prevent.stop="awakenCallAlert">拨打电话</a>
            </div>
          </div>
          <div class="taskArea" id="testBtn" style="padding-top: 1.3rem;">
            <dl>
              <dt>车辆信息</dt>
            </dl>
            <div class="taskBox">
              <dl>
                <dt>车牌号</dt>
                <dd>{{datas.vehicleLicenceCode | vehicleFrameNoHidden }}</dd>
              </dl>
              <dl>
                <dt>车架号</dt>
                <dd>{{datas.vehicleFrameNo | fourSpace}}</dd>
              </dl>
              <dl>
                <dt>车型名称</dt>
                <dd class="text-hidden">{{datas.autoModelChnName}}</dd>
              </dl>
              <dl>
                <dt>车龄</dt>
                <dd>{{datas.vehicleAge}}年</dd>
              </dl>
            </div>
          </div>
          <div class="taskArea mt20">
            <dl>
              <dt>保费信息</dt>
            </dl>
            <div class="taskBox insideXubaoMsg" v-for="item in datas.insuranceDelite">
              <dl>
                <dt>险种</dt>
                <dd>{{item.planclass}}</dd>
              </dl>
              <dl>
                <dt>金额</dt>
                <dd><em><span class="font-size-half">¥</span>{{item.premium | NumberThere}}</em></dd>
              </dl>
              <dl>
                <dt>保险止期</dt>
                <dd>{{item.dateInsuranceEnd}}</dd>
              </dl>
              <dl class="speWidth">
                <dt>上年保单号</dt>
                <dd>{{item.lastpolicyNo | fourSpace}}</dd>
              </dl>
              <div class="bor_line"></div>
            </div>
          </div>
          <!-- 接触历史 -->
          <div class="taskArea mt20 commuArea" v-if="touchHistoryList.length">
            <dl>
              <dt>接触历史</dt>
              <dd v-if="datas.status !== '1'"><!--<a href="javascript:;" otype="button" otitle="编辑"
                                                 @click="showCallMsgWindow">编辑</a>--></dd>
            </dl>
            <div class="commuBox commuBoxRenel">
              <div class="rateCont c" v-for="item in touchHistoryList">
                <dl class="rateConTime" v-if="item.touchDate">
                  <dt>{{item.touchDate | spliceDate}}</dt>
                  <dd>{{item.touchDate | spliceTime}}</dd>
                </dl>
                <dl class="rateConTime" v-else>
                  <dt>...</dt>
                </dl>
                <dl class="rateConTxt icon_rates pts-b-l" v-if="item.operator">
                  <dt>操作人: {{item.operator}}</dt>
                  <dd>备注：{{item.touchDetail}}</dd>
                </dl>
                <dl class="rateConTxt pts-b-l" :class="{'icon_rate': item.touchDate}" v-else>
                  <dt :class="{'mb80': !item.touchDate}">{{item.touchResult}}</dt>
                  <dd></dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
        <!-- main end -->
      </div>
    </main>
    <!-- 记录打过电话的结果 -->
    <call-msg :showCallMsg.sync="showCallMsg" :time="callUserTime" @on-updata-callmsg="getMsg"></call-msg>
    <!-- 选择电话号 -->
    <call-choose-num :showAlert.sync="showCallAlert" :userNumList="userNumList"
                     @on-call="calluser"></call-choose-num>
    <!-- 填写车牌号 -->
    <pts-alert v-model="showAddMarkNo">
      <div class="addMarkNo-wrap">
        <div class="off-addMarkNo" @click="markNo='',showAddMarkNo=false"></div>
        <h1 class="addMarkNo-title pts-b-b">车牌号</h1>
        <div class="addMarkNo-input-wrap">
          <div class="addMarkNo-input-border pts-b-b">
            <input type="text" class="addMarkNo-input" placeholder="请输入车牌号,格式:粤B-88888" v-model="markNo">
          </div>
        </div>
        <button class="addMarkNo-button" @click="addMarkNo">提交</button>
      </div>
    </pts-alert>
    <form :action="fromData.imcsUrl" method="post" ref="formElem">
      <input type="hidden" name="params" :value="fromData.params">
      <input type="hidden" name="signData" :value="fromData.signData">
      <input type="hidden" name="systemId" :value="fromData.systemId">
    </form>
    <a href="javascript:;" v-if="datas.renewalStatus !== '2' && datas.status !=='1'" otype="button" otitle="一键续保"
       class="aKeyRenel pos-b" @click="renewal">一键续保</a>
  </section>
</template>

<script>
  import '../../common/filters/convertAmount';
  import '../../common/filters/conCar';
  import url from '../../common/js/comConfig';
  import axios from '../../common/js/axiosConfig';
  import toast from '../../common/comComponent/toast';
  import ptsAlert from '../../common/comComponent/alertWindow';
  import callMsg from './templates/callRemarks';
  import callChooseNum from './templates/callPhoneNumberList';
  import mixin from './templates/mixin.js';
  import {checkVehicleNumOrNo} from '../../common/js/comUtils';

  export default {
    name: "outContinueInfo",
    mixins: [mixin],
    data () {
      return {
        datas: {},
        touchHistoryList: [], // 接触历史
        fromData: {
          imcsUrl: '',
          params: '',
          signData: '',
          systemId: ''
        }, // 一键续保 跳转from表单数据
        getSuccess: false, // 记录获取接触历史是成功还是失败的状态
        errText: '接触记录查询失败, 点击重试', // 记录获取接触历史失败时显示的文字
        userMsg: {}, // 用户画像的数据
        imgFiveStart: require('../../common/images/img_score.jpg'),
        imgEmpty: require('../../common/images/img_scoreEmpty.png'),
        showAddMarkNo: false,
        markNo: ''
      }
    },
    methods: {
      /* @info 获取用户画像数据 */
      getPersona () {
        let _this = this;
        axios.post(url.getWebServiceUrls('persona'), {
          "batchNo": this.datas.batchNo,
          "idAcssVehicleInfo": this.datas.idAcssVehicleInfo
        })
          .then((res) => {
            res = res.data;
            console.log(res);
            if (res.code !== 0) {
              toast(res.msg);
              return;
            }
            _this.userMsg = res.data;
          }).catch((e) => {
          console.log(e);
        })
      },
      /* 一键续保和后台做交互 */
      oneKeyRenewal (obj) {
        const _this = this;
        window.eventAnalytics('续保查询', '续保详情-一键续保');
        axios.post(url.getWebServiceUrls('oneKeyRenewal'), obj).then(res => {
            console.log('返回的数据为' + JSON.stringify(res.data));
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            switch (data.code) {
              case 0:
                _this.fromData.imcsUrl = data.data.imcsUrl;
                _this.fromData.params = data.data.params;
                _this.fromData.signData = data.data.signData;
                _this.fromData.systemId = data.data.systemId;
                try {
                  _this.$nextTick(function () {
                    console.log('提交form')
                    _this.$refs.formElem.submit()
                  })
                } catch (e) {
                  console.log(e)
                }
                break
              default:
                toast(data.msg)
                break
            }
          }
        ).catch(err => {
          // toast('网络错误啦~ \\(≧▽≦)/~, 请重试')
          console.log(err)
        })
      },
      /* 获取接触历史 */
      getHistory () {
        /*if (this.errText.indexOf('点击重试') < 0) {
          return
        }*/
        const _this = this;
        /*this.getSuccess = false;
        this.errText = '接触记录查询中...';*/
        /*axios.post('http://localhost:8888/postGetData', {
          file: 'touch',
          path: 'xubao'
        })*/
        axios.post(url.getWebServiceUrls('touchHistory'), {
          "acssVehId": this.datas.status === '1' ? this.datas.idAcssVehicleInfo : undefined, // 1
          "renewalId": this.datas.status === '0' ? this.datas.renewalId : undefined, // 0
          "status": this.datas.status,
          "taskType": "02"
        }).then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          console.log(data);
          switch (data.code) {
            case 0:
              if (data.data && data.data.touchHistory) {
                _this.touchHistoryList = data.data.touchHistory
              } else {
                _this.touchHistoryList = [
                  {
                    touchDate: data.data.endTouchDate,
                    touchTime: data.data.touchTime,
                    touchResult: '第' + data.data.touchTime + '次联系'
                  },
                  {
                    touchResult: '共拨打' + data.data.touchTime + '次'
                  },
                  {
                    touchDate: data.data.firstTouchDate,
                    touchResult: '第1次联系'
                  }
                ]
              }
              _this.getSuccess = _this.touchHistoryList.length === 0;
              _this.errText = '接触记录查询失败, 点击重试';
              break;
            default:
              toast(data.msg);
              _this.errText = '接触记录查询失败, 点击重试';
              break;
          }
        }).catch(err => {
          _this.errText = '接触记录查询失败, 点击重试';
          console.log(err);
        })
      },
      /* 获取页面详情数据 */
      getData () {
        let _this = this;
        /*axios.post('http://localhost:8888/postGetData', {
          file: 'info',
          path: 'xubao'
        })*/
        axios.post(url.getWebServiceUrls('renewaInfo'), this.$route.query).then((res) => {
          res = res.data;
          console.log(res);
          if (res.code !== 0) {
            toast(res.msg);
            return
          }
          _this.datas = res.data;
          _this.getPersona();
          _this.getHistory();
        }).catch((e) => {
          console.log(e);
        })
      },
      /* 跳转用户画像详情 */
      goUserInfo () {
        window.eventAnalytics('续保查询', `续保详情-用户画像`);
        this.$router.push({path: '/inside/persona', query: this.userMsg});
      },
      // 手动添加接触历史
      showCallMsgWindow () {
        window.eventAnalytics('续保查询', `续保详情-添加拨打记录`);
        this.getCallTime();
        this.showCallMsg = true;
      },
      // 是否进入选择代理人分流
      whetherGoChooseAgent () {
        let policyNo = this.datas.insuranceDelite.map((v) => v.lastpolicyNo).join(',');
        let obj = {
          idAcssVehicleInfo: this.datas.idAcssVehicleInfo,
          batchNo: this.datas.batchNo,
          dealerCode: this.datas.dealerCode,
          licenceCode: this.datas.vehicleLicenceCode || this.markNo,
          insuredName: this.datas.insuredName,
          policyNo
        }
        if (this.datas.agentStatus && this.datas.agentStatus === 'Y') {
          this.$router.push({
            path: '/continuehooseAgent',
            query: obj
          })
        } else if (this.datas.agentStatus && this.datas.agentStatus === 'N') {
          this.oneKeyRenewal(obj);
        } else {
          let dealerPerserveInfo = this.datas.dealerPerserveInfoVO;
          let obj1 = {
            agentCode: dealerPerserveInfo.agent ? dealerPerserveInfo.agent : undefined,
            agentName: dealerPerserveInfo.agentName ? dealerPerserveInfo.agentName : undefined,
            brokerCode: dealerPerserveInfo.broker ? dealerPerserveInfo.broker : undefined,
            brokerName: dealerPerserveInfo.brokerName ? dealerPerserveInfo.brokerName : undefined,
            subConferNo: dealerPerserveInfo.subAgreement ? dealerPerserveInfo.subAgreement : undefined,
            conferNo: dealerPerserveInfo.agreement ? dealerPerserveInfo.agreement : undefined,
            conferName: dealerPerserveInfo.agreementName ? dealerPerserveInfo.agreementName : undefined,
          }
          let resObj = Object.assign(obj, obj1);
          this.oneKeyRenewal(resObj);
        }
      },
      // 提交用户输入的车牌号
      addMarkNo () {
        let val = this.markNo;
        if (!val) {
          toast('请输入车牌号');
          return;
        }
        if (!checkVehicleNumOrNo(val)) {
          toast('请输入正确的车牌号');
          return;
        }
        this.whetherGoChooseAgent();
      },
      // 点击一键续保按钮触发
      renewal () {
        this.datas.vehicleLicenceCode.indexOf('*') > -1 ? this.showAddMarkNo = true : this.whetherGoChooseAgent();
      }
    },
    mounted () {
      // this.datas = this.$route.query;
      this.getData();
      // this.getHistory();
      window.eventAnalytics('续保查询', `续保详情`);
    },
    components: {
      callMsg,
      callChooseNum,
      ptsAlert
    },
    filters: {
      spliceDate (v) {
        if (!v) return v;
        const index = v.indexOf('-');
        if (index < 0) {
          return v
        }
        return v.substr(index + 1, 5)
      },
      spliceTime (v) {
        if (!v) return v;
        const index = v.indexOf(' ');
        if (index < 0) {
          return v
        }
        return v.substr(index + 1, v.length)
      }
    }
  }
</script>

<style lang="less" scoped>
  @import '../../common/css/1px';
  @import "../../common/css/theme";

  .insideXubaoMsg {
    & > .bor_line {
      margin: 0.2rem auto;
    }
    &:last-child > .bor_line {
      display: none;
    }
  }

  .pd {
    position: relative;
    padding-bottom: 0.9rem;
    .pos-b {
      position: fixed;
      bottom: 0%;
      left: 0;
      width: 100%;
    }
    .aKeyRenel {
      display: block;
      height: .9rem;
      line-height: .9rem;
      margin-top: .2rem;
      font-size: .32rem;
      color: #ffffff;
      text-align: center;
      background: #fd9244;
    }
  }

  .insideXubaoWrap .commuBox .rateConTxt {
    position: relative;
    border-left: none;
    &.pts-b-l {
      .pts-1px-l(#fe8d42);
    }
  }

  .insideXubaoWrap .rateCont:last-child .pts-b-l {
    .pts-1px-l(transparent);
  }

  .insideXubaoWrap .commuBox .icon_rates:after {
    display: block;
    content: "";
    position: absolute;
    left: -0.08rem;
    top: 0;
    width: .18rem;
    height: .18rem;
    border-radius: 50%;
    background: #fe883a;
  }

  .insideXubaoDetail .taskBox {
    padding: .08rem .28rem .2rem;
  }

  .addMarkNo-wrap {
    position: relative;
    width: 6.72rem;
    height: 3.72rem;
    border-radius: 0.06rem;
    background-color: #fff;
    text-align: center;
    .off-addMarkNo {
      position: absolute;
      top: -0.24rem;
      right: -0.24rem;
      width: 0.48rem;
      height: 0.48rem;
      background: url("../../common/images/icon_closeClaim.png") no-repeat center center / 100% 100%;
    }
    .addMarkNo-title {
      height: 1rem;
      text-align: center;
      font-size: 0.3rem;
      color: #333333;
      line-height: 1rem;
    }
    .addMarkNo-input-wrap {
      height: 1.5rem;
      text-align: center;
      .addMarkNo-input-border {
        display: inline-block;
        margin-top: 0.8rem;
        width: 4.16rem;
        font-size: 0.28rem;
        .addMarkNo-input {
          width: 100%;
          height: 100%;
        }
      }
    }
    .addMarkNo-button {
      width: 6.2rem;
      height: 0.9rem;
      background: @theme-color;
      outline: none;
      border: none;
      border-radius: 0.06rem;
      font-size: 0.3rem;
      color: #FFffff;
    }
  }
</style>
