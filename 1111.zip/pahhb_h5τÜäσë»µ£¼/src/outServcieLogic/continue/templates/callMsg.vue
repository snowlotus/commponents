<template>
  <pts-alert v-model="show">
    <div class="reMaskArea minHeight boxShadow">
      <h3>记录联系结果 <a href="javascript:;" otype="button" otitle="关闭" class="closeMaskBtn"
                    @click.prevent.stop="offWindow">关闭</a></h3>
      <div class="maskBox c">
        <dl class="c">
          <dt class="_333">结果</dt>
          <dd>
            <p @click.prevent="showResult = true" :class="{'_333': msg.contactCustomerResult,'bbb': !msg.contactCustomerResult}">{{resultText}}</p>
            <ul v-if="showResult">
              <li v-for="(item, index) in result" :class="{'cur':resultActive === index}"
                  @click="chooseResult(item, index)">{{item.title}}
              </li>
            </ul>
          </dd>
        </dl>
        <dl class="c"> <!-- v-if="resultMsgList.length"-->
          <dt  class="bbb" :class="{'_333': !msg.contactCustomerResult || !msg.contactCustomerResult.includes('01')}">原因</dt>
          <dd>
            <p @click.prevent="showMsgEvent" :class="{'_333': msg.contactFailedOtherReason,'bbb': !msg.contactFailedOtherReason}">{{resultMsg}}</p>
            <ul v-if="showMsg && !showResult">
              <li :class="{'cur':msgActive===index}" v-for="(item, index) in resultMsgList"
                  @click.prevent="chooseMsg(item, index)">{{item.title}}
              </li>
            </ul>
          </dd>
        </dl>
        <div class="inTxt"><textarea name="form" ref="textElem" placeholder="手动输入原因, 最多66个汉字。"
                                                      v-model="writeMsg" maxlength="66" :readonly="!showWrite"></textarea></div><!-- v-if="showWrite"-->
      </div>
      <a href="javascript:;" otype="button" otitle="提交" class="sendUp abBtm" :class="{'saveBtn': isCanSave}" @click.prevent.stop="off(false)">提交</a>
    </div>
  </pts-alert>
</template>

<script>
  import toast from '../../../common/comComponent/toast'
  import ptsAlert from '../../../common/comComponent/alertWindow'
  export default {
    name: "call-msg",
    props: {
      showCallMsg: Boolean
    },
    data () {
      return {
        show: false,
        resultText: '请选择联系结果', // 在选择结果区域显示的文字
        result: [
          {title: '同意到店', flag: '01'},
          {
            title: '拒绝到店',
            flag: '02',
            msgList: [
              {title: '距离太远不方便', flag: '03'},
              {title: '未曾来过,不熟悉', flag: '05'},
              {title: '拒接电话', flag: '06'},
              {title: '已在别的修理厂修理', flag: '01'},
              {title: '手动输入', flag: '04'}
            ]
          },
          {
            title: '暂不确定是否到店',
            flag: '03',
            msgList: [
              {title: '电话未接通', flag: '07'},
              {title: '待跟进', flag: '08'},
              {title: '手动输入', flag: '09'}
            ]
          }
        ],
        resultActive: -1, // 选择的结果的索引 -1 代表还没有选择结果
        resultMsg: '请选择原因', // 在原因区域显示的文字
        resultMsgList: [],
        msgActive: -1,
        showResult: false,
        showMsg: false,
        showWrite: false,
        writeMsg: '',
        msg: { // 用户填写的信息 记录选择的flag
          contactCustomerResult: undefined,  // 联系结果 成功、失败、 待确定
          contactFailedOtherReason: undefined, // 联系失败的原因
          krFailReason: undefined, // 手写的信息录入
        },
        isCanSave: false
      }
    },
    methods: {
      off (flag) {
        if (flag) {
          setTimeout(function () {
            this.show = false
            this.$emit('on-updata-callmsg')
          }.bind(this), 500)
          return
        }
        if (this.resultActive < 0) {
          toast('请选择联系结果')
          return
        }
        if (this.resultActive > 0 && this.msgActive < 0) {
          toast('请选择原因')
          return
        }
        if (this.showWrite && this.writeMsg.trim().length < 1) {
          toast('请输入原因')
          return
        }
        this.msg.krFailReason = this.utf16toEntities(this.writeMsg) || undefined
        this.$emit('on-updata-callmsg', this.msg)
      },
      chooseResult (item, index) {
        /*this.resultActive = index;
        this.resultText = item.title;
        this.resultMsgList = item.msgList ? item.msgList : [];
        this.showResult = false;
        this.showWrite = false;
        this.resultMsg = '请选择原因';
        this.msgActive = -1;
        this.writeMsg = '';*/
        this.init();
        this.resultActive = index;
        this.resultText = item.title;
        this.resultMsgList = item.msgList ? item.msgList : [];
        this.msg.contactCustomerResult = item.title;
        this.isCanSave = item.flag === '01';
      },
      chooseMsg (item, index) {
        this.msgActive = index;
        this.resultMsg = item.title;
        this.showWrite = item.flag === '04' || item.flag === '09';
        this.showMsg = false;
        this.writeMsg = '';
        this.$nextTick(function () {
          this.$refs.textElem && this.$refs.textElem.focus();
        });
        this.msg.contactFailedOtherReason = item.title;
        this.isCanSave = item.flag !== '04' || item.flag !== '09';
      },
      offWindow () {
        this.off(true)
      },
      init () {
        this.isCanSave = false;
        this.resultActive = -1;
        this.resultText = '';
        this.resultMsgList = [];
        this.showResult = false;
        this.showResult = false;
        this.showWrite = false;
        this.resultMsg = '请选择原因';
        this.msgActive = -1;
        this.resultText = '请选择联系结果';
        this.writeMsg = '';
        this.isCanSave = false;
        this.msg = {
          contactCustomerResult: undefined,  // 联系结果 成功、失败、 待确定
          contactFailedOtherReason: undefined, // 联系失败的原因
          krFailReason: undefined, // 手写的信息录入
        }
      },
      /**
       * 用于把用utf16编码的字符转换成实体字符，以供后台存储
       * @param  {string} str 将要转换的字符串，其中含有utf16字符将被自动检出
       * @return {string}     转换后的字符串，utf16字符将被转换成&#xxxx;形式的实体字符
       */
      utf16toEntities (str) {
        var patt = /[\ud800-\udbff][\udc00-\udfff]/g; // 检测utf16字符正则
        str = str.replace(patt, function (char) {
          var H, L, code;
          if (char.length === 2) {
            H = char.charCodeAt(0); // 取出高位
            L = char.charCodeAt(1); // 取出低位
            code = (H - 0xD800) * 0x400 + 0x10000 + L - 0xDC00; // 转换算法
            return "&#" + code + ";";
          } else {
            return char;
          }
        });
        return str;
      },
      showMsgEvent () {
        if (this.resultMsgList.length) this.showMsg = true;
      }
    },
    watch: {
      // 'showCallMsg': {
      //   handler: function (val, old) {
      //     if (val) {
      //       this.init(); // 为真时 说明从新唤醒了, 需要将状态恢复为初始值
      //     }
      //     setTimeout(function () {
      //       this.show = val
      //     }.bind(this), 0) // 使用定时器来创造一个代码的时间差, 达到有过渡动画的效果
      //   },
      //   immediate: true
      // }
    },
    components: {
      ptsAlert
    }
  }
</script>

<style lang="less">
  .minHeight {
    min-height: 7.3rem;
    .abBtm {
      width: 100%;
      position: absolute;
      bottom: 0;
      left: 0;
    }
  }
</style>
