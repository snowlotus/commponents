<template>
  <div class="listWrap">
    <pts-scroll-ajax ref="scrollAjaxElem" :topAjax="topAjax && !searchCondition && !showDateNull"
                     :bottomAjax="bottomAjax && !showDateNull"
                     @on-top-ajax="getFirstPage" @on-bottom-ajax="getNextPage">
      <div class="searchArea" v-if=" flagName==='1' || flagName==='2' ">
        <p v-if="flagName==='1'">距离保单到期</p>
        <p v-else>距离保单脱保</p>
        <input type="tel" class="searchVal" v-model="searchDayNum" min="0" :max="flagName==='1' ? '92' : '62'"
               :placeholder="flagName==='1' ? '最多输入92天':'最多输入62天'" @keyup.enter="getFirstPage" ref="telInput">
        <p>天</p>
        <input type="button" value="搜索" class="searchBtn" @click.stop="getFirstPage">
      </div>
      <item @on-showCallAlert="awakenCallAlert" v-for="(item,index) in dataList" :key="item.idAcssVehicleInfo"
            :index="index"
            :datas="item" :flagName="flagName"></item>
      <p class="totalOrder" v-if="!searchCondition && !showDateNull && dataList.length">共{{dataLength}}单</p>
      <!--<div v-if="showDataOver" class="list-data-over">没有数据啦</div>-->
      <!-- 数据为空显示页面 -->
      <div v-if="showDateNull" class="dataNullWrap">
        <div class="imgWrap"></div>
        <div class="dataNullText">没有查询到匹配的数据…</div>
      </div>
    </pts-scroll-ajax>
    <!-- 拨打结果记录 -->
    <call-msg :showCallMsg.sync="showCallMsg" :time="callUserTime" @on-updata-callmsg="getMsg"
    ></call-msg>
    <!-- 选择电话号 -->
    <call-choose-num :showAlert.sync="showCallAlert" :userNumList="userNumList"
                  @on-call="calluser"></call-choose-num>
  </div>
</template>

<script>
  import item from './item.vue'
  import ptsScrollAjax from '../../../common/comComponent/scrollAjax'
  import toast from '../../../common/comComponent/toast'
  import url from '../../../common/js/comConfig'
  import axios from '../../../common/js/axiosConfig'
  // import ptsCallMsg from './callMsg.vue'
  import callMsg from './callRemarks'
  import callChooseNum from './callPhoneNumberList.vue'
  import mixin from './mixin';

  export default {
    name: "continueList",
    mixins: [mixin],
    props: {
      active: Boolean,
      tabChildFlag: String,
      flagName: String,
      searchCondition: String
    },
    data () {
      return {
        dataList: [],
        showDateNull: false,
        showCallMsg: false,
        showCallAlert: false,
        userNumList: [],
        searchDayNum: '',
        page: 1,
        topAjax: true,
        bottomAjax: false,
        dataLength: 0,
        showDataOver: false,
        callUserTime: '' // 用户拨打电话的时间
      }
    },
    methods: {
      /*
       * @info 获取页面数据函数
       * */
      getData (flag, topAjax) {
        const _this = this
        if (flag) {
          this.dataList = []
          this.showDateNull = false
          this.showDataOver = false
        }
        /*axios.get(url.getWebServiceUrls('pageData'), {
         params: {
         file: 'continue',
         path: 'car',
         timeout: 1,
         searchCondition: _this.searchCondition
         }
         })*/
        axios.post(url.getWebServiceUrls('renewalList'), {
          "dayNumber": _this.searchDayNum || undefined,
          "pageNo": _this.page,
          "pageSize": 10,
          "searchCondition": _this.searchCondition,
           "status": _this.tabChildFlag ? (_this.searchDayNum ? '1' : _this.tabChildFlag) :  _this.flagName // 当用户有填写搜索的天数时, 未续默认取未续, 不再去当月应续或下月应续
        }, {loading: !topAjax}).then(res => {
          let data = res.data
          switch (data.code) {
            case 0:
              _this.dataLength = data.totalCount
              if (data.data && data.data.length === 0) {
                if (flag) {
                  if (_this.searchCondition) {
                    _this.$emit('data-back', true)
                  } else {
                    _this.showDateNull = true
                    _this.bottomAjax = false
                  }
                  return
                } else {
                  _this.showDataOver = true
                  _this.bottomAjax = false
                }
                _this.$nextTick(function () {
                  _this.$refs.scrollAjaxElem && _this.$refs.scrollAjaxElem.reset(flag)
                })
                return
              }
              data.data.forEach(v => {
                _this.dataList.push(v)
              })
              _this.bottomAjax = true
              if (data.pageNo * data.pageSize > data.totalCount) {
                _this.bottomAjax = false
                if (flag) {
                  _this.showDataOver = true
                }
              }
              _this.$nextTick(function () {
                _this.$refs.scrollAjaxElem && _this.$refs.scrollAjaxElem.reset(flag)
                if (_this.searchCondition) {
                  _this.$emit('data-back')
                }
              })
              break
            default:
              toast(data.msg)
              _this.$refs.scrollAjaxElem && _this.$refs.scrollAjaxElem.reset(flag)
              if (flag) {
                if (_this.searchCondition) {
                  _this.$emit('data-back', true)
                } else {
                  _this.showDateNull = true
                }
              }
              _this.$nextTick(function () {
                _this.$refs.scrollAjaxElem && _this.$refs.scrollAjaxElem.reset(flag)
              })
              break
          }
        }).catch(err => {
          console.log(err)
          if (flag) {
            if (_this.searchCondition) {
              _this.$emit('data-back', true)
            } else {
              _this.showDateNull = true
              _this.canBottomAjax = false
            }
          }
        })
      },
      /*
       * @info 下拉刷新函数 与 搜索天数函数
       * */
      getFirstPage () {
        console.log('搜索的值为' + this.searchDayNum)
        if (this.searchDayNum === '') {
          this.page = 1;
          this.getData(true, true);
          return;
        }
        if (this.searchDayNum < 1) {
          this.searchDayNum = 1;
          toast('最小只能搜索1天的哦');
        }
        if (this.flagName === '1' && this.searchDayNum > 92) {
          this.searchDayNum = 92;
          toast('未续订单最大只能搜索92天的哦');
        }
        if (this.flagName === '2' && this.searchDayNum > 62) {
          this.searchDayNum = 62;
          toast('脱保订单最大只能搜索62天的哦');
        }
        if (this.searchDayNum && isNaN(Number(this.searchDayNum))) {
          toast('请输入数字');
          return;
        }
        if (this.searchDayNum) {
          let flagText = (this.flagName === '1' ? '未续' : undefined) || (this.flagName === '2' ? '脱续' : undefined);
          flagText && window.eventAnalytics('续保查询', flagText + '天数搜索框的搜索次数');
        }
        this.$refs.telInput.blur();
        this.page = 1;
        this.getData(true, true);
      },
      /*
       * 上拉加载函数
       * */
      getNextPage () {
        this.page++
        this.getData(false, false)
      }
    },
    mounted () {
      this.$nextTick(function () {
        if (this.active) {
          this.getData(true, false)
        }
      })
    },
    components: {
      item,
      ptsScrollAjax,
      callMsg,
      callChooseNum
    },
    watch: {
      active (to, from) {
        if (to && this.dataList.length === 0) {
          this.page = 1
          this.getData(true, false)
        }
      },
      tabChildFlag (to, from) {
        this.searchDayNum = undefined
        this.page = 1
        this.getData(true, false)
      }
    }
  }
</script>

<style lang="less" scoped>
  @import '../../../common/css/1px.less';

  .listWrap {
    width: 100%;
    height: 100%;
    box-sizing: border-box;
  }

  .bt1px {
    .pts-1px-t(#e1e1e1)
  }

  .searchArea {
    overflow: hidden;
    width: 6.9rem;
    padding: .17rem .3rem;
    font-size: .24rem;
    color: #666;
    background: #fff;
    font-size: .26rem;
  }

  .searchArea > p {
    float: left;
    height: .56rem;
    line-height: .56rem;
  }

  .searchArea > input {
    float: left;
    height: .56rem;
  }

  .searchArea > .searchVal {
    width: 3.15rem;
    margin: 0 .2rem;
    padding: 0 .15rem;
    color: #333;
    border-radius: .1rem;
    background: #f5f5f5;
  }

  .searchArea > .searchVal.w395 {
    width: 3.95rem;
  }

  .searchArea > .searchBtn {
    float: right;
    width: 1.1rem;
    color: #fff;
    text-align: center;
    border-radius: .06rem;
    background: #fe883a;
    font-size: 0.24rem;
  }
</style>
