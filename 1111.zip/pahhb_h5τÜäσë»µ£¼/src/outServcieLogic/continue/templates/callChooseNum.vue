<template>
  <pts-alert v-model="showAlert">
    <div class="doubleTelNo doubleTelNoRenel boxShadow" v-if="!showWrite">
      <dl class="stopSelect" v-for="(item, index) in userNumList">
        <dd class="stopSelect" :class="{'cur':activeIndex===index}" :index="index"
            @click.stop.prevent="activeIndex=index" v-finger:long-tap="changeNum">
          {{item | phoneType}}
        </dd>
      </dl>
      <dl v-if="userNumList.length < 3">
        <dd class="addNo" @click.stop.prevent="addNum">新增号码</dd>
      </dl>
      <p>
        <a href="javascript:;" otype="button" otitle="取消" @click.stop.prevent="cancel">取消</a>
        <a href="javascript:;" otype="button" otitle="确认拨打" class="cur" @click.stop.prevent="confirm">确认拨打</a>
      </p>
    </div>
    <div class="inTelNo inTelNoRenel boxShadow" v-if="showWrite">
      <dl>
        <dd>
          <input type="tel" placeholder="请输入需要拨打的电话号码" ref="numberInput" v-model="phone" v-if="isWrite"
                 @blur="verifyNum">
          <input type="text" placeholder="请输入需要拨打的电话号码" readonly :value="phone | phoneType" v-else
                 @click.prevent.stop="changInput">
        </dd>
      </dl>
      <p>
        <a href="javascript:;" otype="button" otitle="取消" @click.stop.prevent="cancel">取消</a>
        <a href="javascript:;" otype="button" otitle="确认拨打" class="cur" @click.stop.prevent="confirm">确认拨打</a>
      </p>
    </div>
  </pts-alert>
</template>

<script>
  import verify from '../../../common/js/comValidate'
  import toast from '../../../common/comComponent/toast'
  import ptsAlert from '../../../common/comComponent/alertWindow'

  export default {
    name: "callAlert",
    props: {
      showAlert: {
        type: Boolean,
        default: false
      },
      userNumList: Array
    },
    data () {
      return {
        isWrite: true,
        phone: null,
        showWrite: false,
        activeIndex: 0
      }
    },
    methods: {
      off (flag) {
        if (!flag) {
          this.show = false;
          setTimeout(function () {
            this.$emit('on-updata-alert', flag);
          }.bind(this), 500);
          return
        }

      },
      changeNum (num) {
        let index = num.target.getAttribute('index');
        this.activeIndex = index;
        this.phone = this.userNumList[index];
        this.showWrite = true;
        this.$nextTick(function () {
          this.$refs.numberInput.focus()
        })
      },
      verifyNum () {
        const value = this.phone + '';
        if (value.charAt(0) !== 1 && value.charAt(0) !== 0 && value.length < 9) {
          let reg = new RegExp('^\\d{7,8}$');
          if (reg.test(value)) {
            this.isWrite = false
            return true;
          }
          toast('请输入正确的电话号');
          return false;
        }
        let msg1 = value.charAt(0) === '0' ? verify.checkFixedPhone(this.phone) : verify.checkMobile(this.phone);
        if (typeof msg1 !== 'boolean') {
          toast(msg1)
          return false
        }
        this.isWrite = false
        return true
      },
      changInput () {
        this.isWrite = true
        this.$nextTick(function () {
          this.$refs.numberInput.focus()
        })
      },
      confirm () {
        const _this = this;
        let numList = [];
        if (this.showWrite) {
          if (!this.verifyNum()) return;
          let userPhoneNum = [...this.userNumList];
          if (userPhoneNum.length > 2) {
            userPhoneNum.splice(parseInt(_this.activeIndex), 1, _this.phone)
          } else {
            userPhoneNum.push(_this.phone)
          }
          numList = userPhoneNum
        }
        let phoneNum = Number(this.phone) > 1 ? this.phone : this.userNumList[this.activeIndex];
        console.log('选择的电话号为' + phoneNum);
        if (!phoneNum) {
          toast('请选择要拨打的电话');
          return
        }
        this.$emit('on-updata-alert', phoneNum, numList);
        this.$emit('update:showAlert', false);
        this.showWrite = false;
        this.activeIndex = 0;
        this.phone = null;
      },
      cancel () {
        this.$emit('update:showAlert', false);
      },
      addNum () {
        this.showWrite = true
        this.$nextTick(function () {
          this.$refs.numberInput.focus()
        })
      }
    },
    /*watch: {
      showAlert (newVal, oldVal) {
        if (newVal) {
          this.
        }
      }
    },*/
    filters: {
      phoneType (value) {
        let arr = value.split('');
        if (arr[0] === '0') {
          arr[1] < 3 ? arr.splice(3, 0, '-') : arr.splice(4, 0, '-');
          return arr.join('');
        }
        if (arr[0] === '1' && arr.length > 8) {
          if (arr.length > 3) {
            arr.splice(3, 0, '-')
          }
          if (arr.length > 7) {
            arr.splice(8, 0, '-')
          }
        }
        return arr.join('')
      }
    },
    components: {
      ptsAlert
    }
  }
</script>

<style lang="less" scoped>
  .doubleTelNo {
    position: fixed;
    top: 50%;
    left: 50%;
    z-index: 998;
    width: 5.05rem;
    border-radius: .1rem;
    background: #fff;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    -moz-transform: translate(-50%, -50%);
    -o-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
  }

  .doubleTelNo dl {
    overflow: hidden;
    line-height: 1.05rem;
    color: #666;
    border-bottom: 1px solid #eee;
  }

  .doubleTelNo dt {
    float: left;
    width: 1.55rem;
    padding-left: .25rem;
    font-size: .28rem;
    text-align: center;
  }

  .doubleTelNo dd {
    float: left;
    width: 3.2rem;
    font-size: .3rem;
  }

  .doubleTelNoRenel dd {
    width: 3.95rem;
    padding: 0 .55rem;
    color: #999;
  }

  .doubleTelNo dd.cur {
    background: url(../../../common/images/icon_tick_02.png) no-repeat 2.48rem center;
    background-size: .28rem .28rem;
  }

  .doubleTelNoRenel dd.cur {
    color: #666;
    background-position: 4.2rem center;
  }

  .doubleTelNoRenel dd.addNo {
    width: 3.5rem;
    padding-left: 1rem;
    background: url(../../../common/images/icon_add.png) no-repeat .55rem center;
    background-size: .26rem .27rem;
  }

  .doubleTelNo p,
  .inTelNo p {
  }

  .inTelNoRenel p {
    border-top: 1px solid #eee;
  }

  .doubleTelNo p a,
  .inTelNo p a {
    float: left;
    width: 2.51rem;
    line-height: .9rem;
    font-size: .3rem;
    color: #999;
    text-align: center;
  }

  .doubleTelNo p a:nth-of-type(1),
  .inTelNo p a:nth-of-type(1) {
    border-right: 1px solid #eee;
  }

  .doubleTelNo p a.cur,
  .inTelNo p a.cur {
    color: #fe8331;
  }

  .inTelNo {
    position: fixed;
    top: 50%;
    left: 50%;
    z-index: 998;
    width: 5.05rem;
    padding-top: .14rem;
    border-radius: .1rem;
    background: #fff;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    -moz-transform: translate(-50%, -50%);
    -o-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
  }

  .inTelNo dl {
    overflow: hidden;
    line-height: .64rem;
    margin: .42rem 0;
    padding: 0 .3rem;
  }

  .inTelNo dt {
    float: left;
    width: 1.4rem;
    font-size: .28rem;
    color: #666;
    text-align: center;
  }

  .inTelNo dd {
    float: left;
    font-size: .3rem;
  }

  .inTelNo dd input {
    height: .64rem;
    width: 2.6rem;
    padding: 0 .15rem;
    font-size: .3rem;
    color: #2a2a2a;
    background: #f2f2f2;
  }

  .inTelNoRenel dl input {
    width: 4.2rem;
    font-size: .28rem;
  }
</style>
