<template>
  <div class="box" :class="isWXSHOWHEADER?'':'wx_box'">
    <pts-header titleText="保单管理" showRight v-if="isWXSHOWHEADER" leftFlag @on-left="goMenu" @on-right="gotoSearch"></pts-header>
    <pts-tab :titleList="titleList" ref="swiperElem" v-model="index" @on-change="tabChange">
      <pts-tab-item>
        <!--所有订单-->
        <pts-list flagName="A" :active="index === 0" :tabChildCode="tabChildCode"></pts-list>
      </pts-tab-item>
      <pts-tab-item>
        <!--待支付订单-->
        <pts-list flagName="D" :active="index === 1" ></pts-list>
      </pts-tab-item>
      <pts-tab-item>
        <!--成功订单-->
        <pts-list flagName="S" :active="index === 2" ></pts-list>
      </pts-tab-item>
      <pts-tab-item>
        <!--失败订单-->
        <pts-list flagName="F" :active="index === 3" ></pts-list>
      </pts-tab-item>
    </pts-tab>
  </div>
</template>

<script>
  import ptsList from './page/list.vue'
  import ptsTab from '../../common/comComponent/tab'
  const list = () => [
    {
      title: '全部',
      childs: [
        {
          title: '全部',
          code: 'A'
        },
        {
          title: '新保',
          code: 'G'
        },
        {
          title: '续保',
          code: 'H'
        },
        {
          title: '转保',
          code: 'I'
        }
      ]
    },
    {title: '待支付'},
    {title: '成功'},
    {title: '失败'}
  ]
  export default {
    name: "index_OM",
    components: {
      ptsList: resolve => require.ensure([], () => resolve(require('./page/list.vue')), 'inSideSearchOrderList'),
      ptsTab,
      ptsTabItem: ptsTab.Item
    },
    data() {
      return {
        //是否显示头部
        isWXSHOWHEADER: window.PageStatus.WX_SHOW_HEADER,
        titleList: list(),
        index: 0,
        SwiperHieght: '',
        scrollOffsetTop: 0, // vux的scroll组件需要减去头部的元素的高度
        tabChildCode: ''
      }
    },
    mounted () {
      const windowHeight = document.body.clientHeight // 获取屏幕的可见高度
      const swipetHeight = this.scrollOffsetTop = this.$refs.swiperElem.$el.offsetTop // 获取swiper的容器距离头部的距离
      this.SwiperHieght = windowHeight - swipetHeight + 'px'
    },
    methods: {
      goMenu () {
//        console.log('df');
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      gotoSearch () {
        this.$router.push({path: '/search', query: {flag: 'orderList'}})
      },
      tabChange (item) {
        this.tabChildCode = item.code;
      }
    }
  }
</script>


<style scoped lang="less">

</style>
