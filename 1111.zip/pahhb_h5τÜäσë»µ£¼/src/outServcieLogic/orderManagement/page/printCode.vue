<template>
  <div class="wrap">
    <pts-header titleText="保单打印码" leftFlag @on-left="goBack"></pts-header>
    <div class="top_tips">请在保单打印机上输入打印码或扫描二维码</div>
    <div class="print_num">{{datas.printCode}}</div>
    <div class="print_img_wrap">
      <img :src="str+datas.printCodeBase64">
    </div>
    <div class="bottom_tips_wrap">
      <div class="icon">!</div>
      <div class="bottom_tips">仅深圳地区可自主打印保单,每份保单仅可打印一份</div>
    </div>
    <div class="btn">
      <button @click.stop="sharePrintCode">分享</button>
    </div>
  </div>
</template>

<script>
  import ptsHeader from '../../../common/comComponent/header'
  import toast from '../../../common/comComponent/toast'

  export default {
    name: "inPrintCode",
    components:{
      ptsHeader
    },
    data(){
      return {
        str:'data:image/jpeg;base64,',
        datas:{}
      }
    },
    created(){
      let query = this.$route.query;
      this.datas = {
        "printCode":query.printCode,
        "printCodeBase64":query.printCodeBase64,
        "icoUrl":query.icoUrl,
        "shareUrl":query.shareUrl
      }
    },
    methods:{
      //返回上一页
      goBack(){
        if(window.history.length >= 1) {
          window.history.go(-1)
        }
      },

      //分享打印码
      sharePrintCode(){
        const _this = this;
        const u = navigator.userAgent;
        const isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
        const isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端

        let shareData = {
          "title": '_*保单打印码',
          "desc": '尊敬的客户,您的保单打印码已生成,您可前往平安产险门店自助打印您的保单',
          "imgUrl": _this.datas.icoUrl,
          "url": _this.datas.shareUrl,
          "from": "平安好伙伴"
        };

        if(isiOS){
          let iframe = document.createElement("iframe");
          iframe.src = 'pagp://share|'+encodeURIComponent(window.JSON.stringify(shareData));
          iframe.style.display = "none";
          document.body.appendChild(iframe);
          iframe.parentNode.removeChild(iframe);
          iframe = null;
        }else if(isAndroid){
          window.location.href = 'pagp://share|'+JSON.stringify(shareData);
        }else{
          toast('暂不支持，请尝试在微信内打开！');
        }
      }
    }
  }
</script>

<style scoped lang="less">
  @import "../../../common/css/theme";
  .wrap{
    background: #FFffff;
    height: 100%;
    .top_tips{
      margin-top: 1.08rem;
      text-align: center;
      font-size: .28rem;
      color: #333333;
      line-height: .28rem;
    }
    .print_num{
      margin-top: .6rem;
      text-align: center;
      font-size: .6rem;
      color: #333333;
      line-height: .6rem;
    }
    .print_img_wrap{
      margin-top: .6rem;
      text-align: center;
      img{
        width: 4.86rem;
        height: 4.86rem;
      }
    }
    .bottom_tips_wrap{
      margin-top: .57rem;
      text-align: center;
      @color:#999999;
      .icon{
        position: absolute;
        left: 1.8rem;
        display: inline-block;
        width: 0.28rem;
        height: .28rem;
        color: @color;
        border: 1px solid @color;
        border-radius: .18rem;
        font-size: .01rem;
        text-align: center;
        line-height: .3rem;
        margin-right: .17rem;
        transform: rotate(180deg);
      }
      .bottom_tips{
        display: inline-block;
        width: 3.38rem;
        font-size: .26rem;
        color: @color;
        letter-spacing: .01rem;
        line-height: .3rem;
        text-align: left;
        margin-left: .3rem;
      }
    }
    .btn{
      margin-top: 1.51rem;
      text-align: center;
      button{
        width: 6.9rem;
        height: .9rem;
        color: #FFffff;
        font-size: .32rem;
        background-color: @theme-color;
        border-color: @theme-color;
        border-radius: .1rem;
      }
    }
  }
</style>
