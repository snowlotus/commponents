<template>
  <!--电子单证详情入口-->
  <div class="wrap">
    <pts-header titleText="保单详情" leftFlag @on-left="goMenu"></pts-header>
    <!--电子投保单 start-->
    <div class="box_wrap">
      <ul>
        <li class="pts-b-b">
          <div style="color: #000000;">电子投保单</div>
        </li>
        <li class="pts-b-b" v-for="(item,i) in tbList" :key="i" v-if="item.haveInsurance" @click="shareTbLink(item)">
          <div>{{item.title}}</div>
          <div class="selectIcon" :class="{active:item.checked}"></div>
        </li>
      </ul>
    </div>
    <!--电子投保单 end-->

    <!--电子保单 start-->
    <div class="box_wrap marTop20" v-if="bdList.length">
      <ul>
        <li class="pts-b-b">
          <div style="color: #000000;">电子保单</div>
        </li>
        <li class="pts-b-b" v-for="(item,i) in bdList" :key="i" v-if="item.haveInsurance" @click="shareBdLink(item)">
          <div>
            <div>{{item.title}}</div>
            <div class="selectIcon" :class="{active:item.checked}"></div>
          </div>
        </li>
        <div v-if="isSzArea">
          <li class="pts-b-b" v-if="bdTitleList[0].haveInsurance" @click.stop="goPrintCode('1')">
            <div>交强险打印码</div>
            <div class="arrowIcon"></div>
          </li>
          <li class="pts-b-b" v-if="bdTitleList[1].haveInsurance" @click.stop="goPrintCode('2')">
            <div>商业险打印码</div>
            <div class="arrowIcon"></div>
          </li>
          <li class="pts-b-b" v-if="bdTitleList[2].haveInsurance" @click.stop="goPrintCode('3')">
            <div>合并打印</div>
            <div class="arrowIcon"></div>
          </li>
        </div>
      </ul>
    </div>
    <!--电子保单 end -->

    <pts-alert v-model="showAlert">
      <div class="alert_wrap">
        <div class="alert_content">
          <em>{{msg}}</em>
        </div>
        <div class="alert_btn" @click.stop="showAlert = false">我知道了</div>
      </div>
    </pts-alert>
  </div>
</template>

<script>
  import ptsHeader from '../../../common/comComponent/header'
  import Axios from '../../../common/js/axiosConfig'
  import API from '../../../common/js/comConfig'
  import toast from '../../../common/comComponent/toast'
  import ptsAlert from '../../../common/comComponent/alertWindow'

  export default {
    name: "electronPayment",
    components: {
      ptsHeader,
      ptsAlert
    },
    data() {
      return {
        //电子投保单列表
        tbTitleList: [
          {
            title: '交强险',
            haveInsurance: true,
            checked: false
          },
          {
            title: '商业险',
            haveInsurance: true,
            checked: false
          },
          {
            title: '合并分享',
            haveInsurance: true,
            checked: false
          }
        ],
        //电子保单列表
        bdTitleList: [
          {
            title: '交强险',
            haveInsurance: true,
            checked: false
          },
          {
            title: '商业险',
            haveInsurance: true,
            checked: false
          },
          {
            title: '合并分享',
            haveInsurance: true,
            checked: false
          }
        ],

        //根据query传过来的值判断当前有无交强险或商业险,做显示或隐藏
        tbList: [],
        bdList: [],
        isSzArea: false, //判断是不是深圳地区,默认为不显示,
        showAlert:false, //弹窗
        msg:'' //点击打印码后台返回的字段
      }
    },
    created() {
      let query = this.$route.query;
      this.tbTitleList[0].haveInsurance = Boolean(query.fApplyPolicyNo);
      this.tbTitleList[1].haveInsurance = Boolean(query.bApplyPolicyNo);
      this.tbTitleList[2].haveInsurance = Boolean(query.fApplyPolicyNo && query.bApplyPolicyNo);

      this.bdTitleList[0].haveInsurance = Boolean(query.forcePolicyNo);
      this.bdTitleList[1].haveInsurance = Boolean(query.bizPolicyNo);
      this.bdTitleList[2].haveInsurance = Boolean(query.bizPolicyNo && query.forcePolicyNo);

      this.tbTitleList.forEach(v => {
        if (v.haveInsurance) {
          this.tbList.push(v)
        }
      });
      this.bdTitleList.forEach(v => {
        if (v.haveInsurance) {
          this.bdList.push(v)
        }
      });

      this.getShenzhenCode();
    },
    methods: {
      //返回上一页
      goMenu() {
        if (window.history.length >= 1) {
          window.history.go(-1)
        }
      },
      //判断是不是深圳地区,当前只有深圳地区可以打印二维码
      getShenzhenCode() {
        const _this = this;
        let obj = {
          "dealerCode": _this.$route.query.dealerCode
        };
        Axios.post(API.getWebServiceUrls('areaSwitch'), obj, {loading: false})
          .then(res => {
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            if (data.code == 0) {
              _this.isSzArea = data.data.areaswitch == 'Y' ? true : false;
            }
          })
          .catch(err => {
            console.log(err)
          })
      },

      //请求数据成功后触发Native分享
      share(shareData) {
        const u = navigator.userAgent;
        const isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
        const isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端

        if (isiOS) {
          let iframe = document.createElement("iframe");
          iframe.src = 'pagp://share|' + encodeURIComponent(window.JSON.stringify(shareData));
          iframe.style.display = "none";
          document.body.appendChild(iframe);
          iframe.parentNode.removeChild(iframe);
          iframe = null;
        } else if (isAndroid) {
          window.location.href = 'pagp://share|' + JSON.stringify(shareData);
        } else {
          toast('暂不支持，请尝试在微信内打开！');
        }
      },

      //将分享的勾选项抽离出来复用,每次调用让他们的checked都为false
      checkedToFalse() {
        this.tbList.forEach(v => {
          v.checked = false;
        });
        this.bdList.forEach(v => {
          v.checked = false;
        });
      },

      //分享电子投保单中的交强险,商业险和合并分享
      shareTbLink(item) {
        this.checkedToFalse();
        item.checked = true;
        let query = this.$route.query;
        let obj = {};
        switch (item.title) {
          case '交强险':
            obj = {
              "forceApplyNo": query.fApplyPolicyNo,
            };
            break;
          case '商业险':
            obj = {
              "bizApplyNo": query.bApplyPolicyNo,
            };
            break;
          case '合并分享':
            obj = {
              "bizApplyNo": query.bApplyPolicyNo,
              "forceApplyNo": query.fApplyPolicyNo
            };
            break;
          default:
            break;
        }
        Axios.post(API.getWebServiceUrls('shareTbLink'), obj)
          .then(res => {
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            if (data.code == 0 || data.code == '0') {
              let params = {
                "title": '_*电子投保单签名',
                "desc": '尊敬的客户,您的电子投保单已生成,请您签名确认',
                "imgUrl": data.data.icoUrl,
                "url": data.data.shareUrl,
                "from": "平安好伙伴"
              };
              this.share(params);
            } else {
              toast(data.msg || '系统繁忙,请稍后重试')
            }
          })
          .catch(err => {
            console.log(err)
          })
      },

      //分享电子保单的交强险,商业险和合并分享
      shareBdLink(item) {
        this.checkedToFalse();
        item.checked = true;
        let query = this.$route.query;
        let obj = {};
        switch (item.title) {
          case '交强险':
            obj = {
              "forcePolicyNo": query.forcePolicyNo,
              "applyNo": query.fApplyPolicyNo
            };
            break;
          case '商业险':
            obj = {
              "bizPolicyNo": query.bizPolicyNo,
              "applyNo": query.bApplyPolicyNo
            };
            break;
          case '合并分享':
            obj = {
              "applyNo": query.fApplyPolicyNo,
              "bizPolicyNo": query.bizPolicyNo,
              "forcePolicyNo": query.forcePolicyNo
            };
            break;
          default:
            break;
        }
        Axios.post(API.getWebServiceUrls('shareBdLink'), obj)
          .then(res => {
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            if (data.code == 0 || data.code == '0') {
              let params = {
                "title": '_*电子保单',
                "desc": '尊敬的客户,您的电子保单已生成,请您确认',
                "imgUrl": data.data.icoUrl,
                "url": data.data.shareUrl,
                "from": "平安好伙伴"
              };
              this.share(params);
            } else {
              toast(data.msg || '系统繁忙,请稍后重试')
            }
          })
          .catch(err => {
            console.log(err)
          })
      },

      /**
       * @info 跳转打印码页面
       * @param type 1-3分别是电子保单的交强险,商业险,合并分享
       */
      goPrintCode(type) {
        let query = this.$route.query;
        let params = [{
          "applicantName": query.applicantName,
          "departmentCode": query.departmentCode,
          "policyNo": "",
          "productCode": "",
          "relationPolicyNo": "",
          "vehicleLicenceCode": query.vehicleLicenceCode,
          "type":''
        }];
        switch (type) {
          case '1':
            params[0].policyNo = query.forcePolicyNo;
            params[0].productCode = query.fProductCode;
            params[0].type = 'F';
            break;
          case '2':
            params[0].policyNo = query.bizPolicyNo;
            params[0].productCode = query.bProductCode;
            params[0].type = 'B';
            break;
          case '3':
            params[0].policyNo = query.bizPolicyNo;
            params[0].productCode = query.bProductCode;
            params[0].relationPolicyNo = query.forcePolicyNo;
            params[0].type = 'B';
            params[1] = {
              "applicantName": query.applicantName,
              "departmentCode": query.departmentCode,
              "policyNo": query.forcePolicyNo,
              "productCode": query.fProductCode,
              "relationPolicyNo": query.bizPolicyNo,
              "vehicleLicenceCode": query.vehicleLicenceCode,
              "type": 'F'
            }
            break;
          default :
            break;
        }

        Axios.post(API.getWebServiceUrls('printCode'), params).then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (data.code == 0 || data.code == '0') {
            this.$router.push({
              path: '/OrderPrintCode',
              query: {
                "icoUrl":data.data.icoUrl,
                "url":data.data.shareUrl,
                "printCode":data.data.printCode,
                "printCodeBase64":data.data.printCodeBase64
              }
            })
          } else if (data.code == 11003 || data.code == 11007 || data.code == 11008){
            this.showAlert = true;
            this.msg = data.msg;
          } else {
            toast(data.msg || '系统繁忙,请稍后重试')
          }
        }).catch(err => {
          console.log(err)
        })
      },
    },

    activated() {
      this.getShenzhenCode();
    }
  }
</script>

<style scoped lang="less">
  .wrap > div:nth-child(2) {
    margin-top: 0;
  }

  .box_wrap {
    background: #FFffff;
    & ul li {
      height: .87rem;
      margin-left: .3rem;
      font-size: .28rem;
      line-height: .87rem;
      color: #666666;
      position: relative;
      div {
        display: inline-block;
      }
    }
    & ul > li:first-child:after {
      width: .08rem;
      height: .2rem;
      background-color: #FE883A;
      content: ' ';
      clear: both;
      position: absolute;
      left: -.3rem;
      top: 50%;
      margin-top: -.12rem;
    }
    .selectIcon {
      position: absolute;
      right: .3rem;
      top: 50%;
      margin-top: -.15rem;
      width: .3rem;
      height: .3rem;
      background: url("../../../common/images/icon_noselect@3x.png") no-repeat;
      background-size: 100%;
    }
    .selectIcon.active {
      background: url("../../../common/images/icon_selected@3x.png") no-repeat;
      background-size: 100%;
    }
    .arrowIcon {
      position: absolute;
      right: .3rem;
      top: 50%;
      margin-top: -.07rem;
      width: .07rem;
      height: .14rem;
      background: url("../../../common/images/arrowLeft2.png") no-repeat;
      background-size: 100%;
    }
  }

  .alert_wrap{
    width:5.9rem;
    height: 3.2rem;
    border-radius: 6px;
    background: #FFffff;
    .alert_content{
      box-sizing: border-box;
      height: 2.29rem;
      border-bottom: 1px solid #eee;
      text-align: center;
      font-family: PingFangSC-Regular;
      font-size: .28rem;
      color: #333333;
      line-height: 2.5rem;
    }
    .alert_btn{
      height: .89rem;
      font-size: .3rem;
      color: #FE883A;
      text-align: center;
      line-height: .89rem;
    }
  }
</style>
