<template>
  <li class="pending_payment_0 list_details por"
      :class="{'pay_lose': data.status==='F', 'pay_success': data.status==='S'}" @click.prevent="gotoInfo">
    <!--v-f="gotoInfo"-->
    <p class="orderManage-type" v-if="data.renewalType === '0'">新保</p>
    <p class="orderManage-type" v-if="data.renewalType === '1'">续保</p>
    <p class="orderManage-type" v-if="data.renewalType === '2'">转保</p>
    <p class="policy_date">{{data.credatedDate}}</p> <!--订单创建日期-->
    <p class="poa" v-if="data.status !== 'D'"
       :class="{'pay_lose_img': data.status==='F', 'pay_success_img': data.status==='S' }"
    ></p>
    <!--显示成功or失败图标-->
    <div class="marLeft30 rel">
      <p><span class="policy_price"
               :class="{'color_gray': data.status!=='D'}"><span class="font-size-half">¥</span>{{premium | NumberThere}}</span>
        <!--<span-->
        <!--class="net_premium">净保费<span class="font-size-half">¥</span>{{insurPremium | NumberThere}}</span>-->
      </p>
      <div class="marRight30" :class="{'finish': data.status !== 'D'}">
        <p class="policy_cont marTop20 c"><span class="fl">车架号</span><input class="fr"
                                                                            type="text"
                                                                            :value="data.vehicleFrameNo | fourSpace"
                                                                            readonly/></p>
        <p class="policy_cont marTop20 c"><span class="fl">车牌号</span><input class="fr"
                                                                            type="text"
                                                                            :value="data.vehicleLicenceCode | vehicleLicenceCodeHidden"
                                                                            readonly/></p>
        <p class="marTop10 padBottom23 c" @click.prevent.stop="showCheckboxEvent">
          <i class="fl"
             :class="{'check_symbols': data.status !== 'D', 'checked_symbols': data.status=== 'D'}"></i>
          <span class="dangerous_species fl">已选：<span v-if="data.F && data.F.checked">交强险</span><span
            v-if="data.F && data.B && data.F.checked && data.B.checked">、</span><span v-if="data.B && data.B.checked">商业险</span></span>
          <i class="right_arrow fr" v-if="data.status === 'D'"></i>
        </p>
      </div>
      <p class="border2px"></p>

      <div class="auxiliary_function marRight30 c">
        <p class="pay_active marLeft10 fr" v-if="data.status === 'D'"><a href="javascript:;"
                                                                         @click.prevent.stop="toPay">去支付</a></p>
        <p class="marLeft10 fr" v-if=" data.taskState == '01' || data.taskState == '02' || data.taskState == '06' "><a
          href="javascript:;" @click.prevent.stop="waitInspectCar">待验车</a></p>
        <p class="marLeft10 fr" v-if="data.status === 'D' || data.status === 'S'"><a href="javascript:;" @click.prevent.stop="goElectronPayment">电子单证</a></p>
        <p class="marLeft10 fr" v-if="data.status === 'D'"><a href="javascript:;"
                                                              @click.prevent.stop="updataItem">修改</a></p>
        <p class=" fr"><a href="javascript:;" @click.prevent.stop="deleteItem">删除</a></p>
        <p class="inspect_car" v-if="data.taskState&&parseInt(data.taskState)>1&&parseInt(data.taskState)<6">验车中</p>
      </div>
    </div>

    <!--给验车入口做form表单跳转到imcs-->
    <form :action="imcsUrl" method="post" id="goToImcs" ref="formElem">
      <input type="hidden" name="params" v-model="params">
      <input type="hidden" name="signData" v-model="signData">
      <input type="hidden" name="systemId" v-model="systemId">
    </form>
  </li>
</template>

<script>
  import '../../../common/filters/convertAmount.js'
  import axios from '../../../common/js/axiosConfig'
  import url from '../../../common/js/comConfig'
  import toast from '../../../common/comComponent/toast'

  export default {
    name: "om_item",
    props: {
      data: Object,
      index: Number,
    },
    data() {
      return {
        imcsUrl: '',
        systemId: '',
        params: '',
        signData: '',
      }
    },
    computed: {
      premium() {
        let data = this.data;
        let Bnumber = data.B && data.B.checked ? data.B.premium : 0;
        let Fnumber = data.F && data.F.checked ? data.F.premium : 0;
        return Bnumber + Fnumber
      },
      insurPremium() {
        let data = this.data;
        let Bnumber = data.B && data.B.checked ? data.B.insurPremium : 0;
        let Fnumber = data.F && data.F.checked ? data.F.insurPremium : 0;
        return Bnumber + Fnumber
      }
    },
    methods: {
      //待验车入口
      waitInspectCar() {
        const _this = this;
        console.log(_this.data)
        let obj = {
          "applyPolicyNo": _this.data.F && _this.data.F.applyPolicyNo || _this.data.B && _this.data.B.applyPolicyNo,
          "vehicleFrameCode": _this.data.vehicleFrameNo,
          "vehicleLicenceCode": _this.data.vehicleLicenceCode
        };
        axios.post(url.getWebServiceUrls('checkCar'), obj)
          .then(res => {
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            if (data.code == 0 || data.code == '0') {
              _this.imcsUrl = data.data.imcsUrl;
              _this.systemId = data.data.systemId;
              _this.params = data.data.params;
              _this.signData = data.data.signData;

              setTimeout(function () {
                _this.$refs.formElem.submit();
              }, 0);

            } else {
              toast(data.msg || '系统繁忙,请稍后重试')
            }
          }).catch(err => {
          console.log(err)
        })
      },
      //电子单证入口
      goElectronPayment() {
        const _this = this;
        _this.$router.push({
          path: '/electronicOrderInfo',
          query: {
            //供电子保单和投保单查询参数
            "bizPolicyNo": _this.data.B && _this.data.B.policyNo || '',//商业险保单号
            "forcePolicyNo": _this.data.F && _this.data.F.policyNo || '',//交强险保单号
            "fApplyPolicyNo": _this.data.F && _this.data.F.applyPolicyNo || '',//交强险投保单号
            "bApplyPolicyNo": _this.data.B && _this.data.B.applyPolicyNo || '',//商业险投保单号
            "applicantName": _this.data.info.personnelName || '', //投保人姓名
            "departmentCode": _this.data.info.orderVO[0].departmentCode || '', //出单机构
            "fProductCode": _this.data.F && _this.data.F.productCode || '', //交强险产品编码
            "bProductCode": _this.data.B && _this.data.B.productCode || '', //商业险产品编码
            "dealerCode": _this.data.info.orderVO[0].dealerCode || '', //机构编码
            "vehicleLicenceCode": _this.data.vehicleLicenceCode || '' //车牌号
          }
        })
      },

      showCheckboxEvent() {
        this.$emit('on-showCheckbox', this.data);
      },
      gotoInfo() {
        let obj = this.data.info;
        let data = this.data;
        obj.F = data.F && data.F.checked;
        obj.B = data.B && data.B.checked;
        this.$router.push({path: '/Order-info', query: obj});
      },
      deleteItem() {
        this.$emit('on-deleteItem', this.index);
      },
      updataItem() {
        let data = this.data,
          bizApplyNo = data.B ? data.B.applyPolicyNo : undefined,
          forceApplyNo = data.F ? data.F.applyPolicyNo : undefined;
        this.$emit('on-updataItem', data.flowId, data.vehicleLicenceCode, bizApplyNo, forceApplyNo);
      },
      toPay() {
        let data = this.data
        let forceApplyNo = data.F && data.F.checked ? data.F.applyPolicyNo : undefined;
        let bizApplyNo = data.B && data.B.checked ? data.B.applyPolicyNo : undefined;
        this.$emit('on-topay', data.flowId, forceApplyNo, bizApplyNo);
      }
    },
    filters: {
      vehicleLicenceCodeHidden(value) {
        if (!value) return value;
        if (value.indexOf('*新') > -1) {
          return '*_*';
        } else {
          return value;
        }
      },
      fourSpace(v) {
        if (!v) return v;
        let arr = v.split('');
        for (let i = 0; i < arr.length; i++) {
          if (i % 5 === 0) {
            arr.splice(i, 0, ' ');
          }
        }
        return arr.join('');
      }
    }
  }
</script>

<style lang="less" scoped>
  @import "../../../common/css/theme";

  .rel {
    position: relative;
    z-index: 10;
  }

  .finish > .policy_cont {
    color: #999 !important;
  }

  .finish .dangerous_species {
    color: #999 !important;
  }

  .orderManage-type {
    position: absolute;
    top: 0.13rem;
    left: 0.3rem;
    width: 0.84rem;
    height: 0.35rem;
    text-align: center;
    line-height: 0.38rem;
    border: 1px solid #FE883A;
    color: @theme-color;
  }

  .auxiliary_function {
    position: relative;
    & > p {
      width: 1rem;
      font-size: .22rem;
    }
    .inspect_car {
      border: none;
      width: 1.1rem;
      position: absolute;
      left: -.2rem;
      top: .2rem;
      color: @theme-color;
    }
  }
</style>
