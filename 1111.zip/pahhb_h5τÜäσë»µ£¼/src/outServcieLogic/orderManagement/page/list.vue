<template>
  <pts-scroll-ajax @on-bottom-ajax="getDatas" :topAjax="canTopAjax && !showDataNull"
                   @on-top-ajax="updataPageData"
                   ref="swiperAjax"
                   :bottomAjax="canBottomAjax"
                   :overflow="showCheckbox && checkboxActive.status && checkboxActive.status==='D'"> <!---->
    <div class="list_show" v-if="dataList.length">
      <ul>
        <pts-om-item v-for="(item, index) in dataList" :key="index" :data="item" :index="index"
                     @on-showCheckbox="showCheckboxEvent"
                     @on-deleteItem="deleteItem" @on-updataItem="updataItem" @on-topay="topay"
        ></pts-om-item>
      </ul>
    </div>
    <!--<div v-if="showDataOver" class="list-data-over">没有数据啦</div>-->
    <div v-if="showDataNull" class="dataNullWrap">
      <div class="imgWrap"></div>
      <div class="dataNullText">没有查询到匹配的数据…</div>
    </div>
    <pts-checkbox v-if="showCheckbox"
                  :showContent="showCheckbox"
                  @on-updata="getCheckboxValue"
                  :datas="checkboxActive"
    ></pts-checkbox>
    <form :action="formData.url" method="post" ref="formElem">
      <input type="hidden" v-model="formData.params" name="params">
      <input type="hidden" v-model="formData.signData " name="signData">
      <input type="hidden" v-model="formData.systemId " name="systemId">
    </form>
  </pts-scroll-ajax>
</template>

<script>
  import toast from '../../../common/comComponent/toast'
  import ptsOmItem from './item.vue'
  import url from 'common/js/comConfig'
  import axios from 'common/js/axiosConfig'
  import ptsScrollAjax from '../../../common/comComponent/scrollAjax'
  import ptsCheckbox from '../checkbox'

  export default {
    name: "list-OM",
    props: {
      flagName: String,
      active: {
        type: Boolean,
        default: false
      },
      scrollOffsetTop: Number,
      scrollModel: {
        pullupStatus: 'default'
      },
      searchCondition: String,
      tabChildCode: ''
    },
    data() {
      return {
        dataList: [],
        pageindex: 1,
        showDataOver: false,
        showCheckbox: false,
        checkboxActive: {},
        formData: {
          url: '',
          params: '',
          signData: '',
          systemId: ''
        },
        canBottomAjax: false,
        canTopAjax: true,
        showDataNull: false,
        checkCarStatusArr: [], //用来装验车状态的数组,列表接口返回状态为C的项
        realCarStatusArr: [], //通过状态为C的项请求后台后返回的实际验车状态
      }
    },
    activated(){
      this.getData(true,true);
    },
    methods: {
      /*
       * ajax函数向后台接受数据
       * isEmpty 为true 时代表是 第一次查询数据
       * */
      getData(isEmpty, topajax) {
        const _this = this;
        _this.showDataNull = false;
        _this.showDataOver = false;
        /*axios.get(url.getWebServiceUrls('pageData'), {
         params: {
         file: 2,
         pageNo: _this.pageindex,
         pageSize: 10,
         status: "A",
         timeout: 2,
         path: 'car'
         }
         })*/
        axios.post(url.getWebServiceUrls('orderList'), {
          "pageNo": _this.pageindex,
          "pageSize": 10,
          "status": this.tabChildCode || this.flagName,
          searchCondition: _this.searchCondition && _this.searchCondition.trim()
        }, {loading: !topajax})
          .then(function (response) {
//            console.log(response);
            const data = typeof response.data === 'string' ? JSON.parse(response.data) : response.data
            switch (data.code) {
              case 0:
                if (isEmpty) {
                  _this.dataList = []
                }
                if (data.data && data.data.length === 0) {
                  if (isEmpty) {
                    if (_this.searchCondition) {
                      _this.$emit('data-back', true) // 没有收到数据, 搜索页面显示无搜索结果
                    } else {
                      _this.showDataNull = true;
                      _this.showDataOver = false;
                      _this.canBottomAjax = false;
                    }
                  } else {
                    _this.showDataOver = true;
                    _this.canBottomAjax = false;
                  }
                  _this.$nextTick(function () {
                    _this.$refs.swiperAjax && _this.$refs.swiperAjax.reset(isEmpty);
                  })
                  return
                }
                data.data.forEach(v => {
                  if (v.orderVO.length > 1) {
                    // 这里不清楚哪个是商业险 与 交强险 直接全部取出来， 在下面根据planclass字段区分
                    let msg1 = v.orderVO[0];
                    let msg2 = v.orderVO[1];
                    if (msg1.status === msg2.status) {  // 两笔订单状态一直显示一条目录
                      _this.buildData(_this, v, msg1, msg2)
                    } else { // 显示两条数据
                      _this.buildData(_this, v, msg1);
                      _this.buildData(_this, v, msg2);
                    }
                  } else {
                    _this.buildData(_this, v, v.orderVO[0])
                  }

                  //判断当前此单的状态需不需要验车
                  if (v.orderVO[0].status == 'C') {
                    let obj = {
                      "applyPolicyNo": v.orderVO[0].applyPolicyNo,
                      "vehicleFrameCode": v.vehicleFrameNo,
                      "vehicleLicenceCode": v.vehicleLicenceCode,
                    }
                    _this.checkCarStatusArr.push(obj)
                  }
                });
                _this.canBottomAjax = true;
                if (_this.checkCarStatusArr.length > 0) {
                  _this.realCarStatusArr = [];
                  axios.post(url.getWebServiceUrls('checkCarStatus'), {
                    "checkAcessors": _this.checkCarStatusArr
                  }, {loading: false})
                    .then(res => {
                      let response = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
                      let obj = response.data;
                      if (response.code == 0) {
                        for (var key in obj) {
                          const item = obj[key];
                          if (item.resultCode == 0) {
                            let itemData = typeof item.resultData === 'string' ? JSON.parse(item.resultData) : item.resultData;
                            _this.realCarStatusArr.push(itemData);
                          }
                        }

                        //遍历两个数组,如果他们的车架号相同,就给dataList添加属性taskState
                        if (_this.realCarStatusArr.length > 0) {
                          _this.realCarStatusArr.forEach(v => {
                            _this.dataList.forEach(d => {
                              if (v.vehicleFrameCode == d.vehicleFrameNo && d.status == 'C') {
                                d.taskState = v.taskState;
                                // Object.assign(d,{'taskState':v.taskState})
                                _this.$set(d, d) //为了触发vue响应式更新
                              }
                            })
                          })
                        } else {
                          _this.checkCarStatusArr.forEach(v => {
                            _this.dataList.forEach(d => {
                              if (v.vehicleFrameCode == d.vehicleFrameNo && d.status == 'C') {
                                d.taskState = '02';
                                _this.$set(d,d)
                              }
                            })
                          })
                        }
                      }
                    })
                    .catch(err => {
                      console.log(err)
                    })
                }
                break;
              default:
                toast(data.msg);
                _this.$refs.swiperAjax && _this.$refs.swiperAjax.reset(isEmpty)
                _this.canBottomAjax = false;
                if (isEmpty && _this.searchCondition) {
                  _this.showDataOver = false;
                  _this.$emit('data-back', true) // 没有收到数据, 搜索页面显示无搜索结果
                }
                break
            }
            if (isEmpty && _this.dataList.length > 0 && _this.searchCondition) {
              _this.$emit('data-back') // 收到数据, 搜索页面显示搜索结果
            }
            if (data.pageNo * data.pageSize > data.totalCount) {
              _this.canBottomAjax = false;
              _this.showDataOver = true;
              _this.$nextTick(function () {
                _this.$refs.swiperAjax && _this.$refs.swiperAjax.reset(isEmpty)
              })
            } else {
              _this.$nextTick(function () {
                _this.$refs.swiperAjax && _this.$refs.swiperAjax.reset(isEmpty)
              })
            }
          })
          .catch(function (error) {
            isEmpty ? _this.showDataNull = true : _this.showDataOver = true;
            _this.canBottomAjax = false;
            _this.$refs.swiperAjax && _this.$refs.swiperAjax.reset(isEmpty);
            if (_this.searchCondition && isEmpty) {
              _this.$emit('data-back', true);
              _this.showDataNull = false;
              _this.showDataOver = false;
            }
            console.log(error);
          });
      },
      /* 下拉加载数时触发， 在这个函数中调整页数*/
      getDatas() {
        this.pageindex++;
        this.getData(false)
      },
      /* 更新checkbox的显示状态， 由checkbox组件触发*/
      getCheckboxValue(type) {
        this.showCheckbox = type;
        this.$nextTick(function () {
          window.PageStatus.tabhidden = false;
          window.PageStatus.headerStop = false;
        });
      },
      /* 显示checkbox的函数， 由子组件触发*/
      showCheckboxEvent(item) {
        if (item.status && item.status === 'D') {
          this.checkboxActive = item;
          this.showCheckbox = true;
          this.$nextTick(function () {
            window.PageStatus.tabhidden = true;
            window.PageStatus.headerStop = true;
          })
        }
      },
      /* 删除项目的函数， 由子组件触发*/
      deleteItem(index) {
        let _this = this;
        window.eventAnalytics('保单管理', '列表中点击删除');
        this.$vux.confirm.show({
          title: '确认删除？',
          content: '确认删除该订单？',
          confirmText: '删除',
          cancelText: '取消',
          onConfirm() {
            /*
             {
             params: {
             policyNo: _this.dataList[index].documentNo,
             timeout: 2,
             path: 'car',
             file: 'success'
             }
             }*/
            axios.post(url.getWebServiceUrls('deleteOrderList'), {
              "flowId": _this.dataList[index].flowId,
              "bizApplyNo": _this.dataList[index].B ? _this.dataList[index].B.applyPolicyNo : undefined,
              "forceApplyNo": _this.dataList[index].F ? _this.dataList[index].F.applyPolicyNo : undefined
            })
              .then(res => {
                switch (res.data.code) {
                  case 0:
                    _this.dataList.splice(index, 1)
                    toast('删除成功')
                    break
                  default:
                    toast(res.data.msg)
                    break
                }
              })
              .catch(error => {
                console.log(error)
              })
          }
        })
      },
      updataItem(flowId, licenseNo, bizApplyNo, forceApplyNo) {
        let _this = this
        window.eventAnalytics('保单管理', '列表中点击修改')
        axios.post(url.getWebServiceUrls('updateOrderList'), {
          flowId,
          licenseNo,
          bizApplyNo,
          forceApplyNo
        })
          .then(res => {
//            console.log(res)
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
            switch (data.code) {
              case 0:
                let formElem = this.$refs.formElem
                _this.formData.url = data.data.imcsUrl
                _this.formData.params = data.data.params
                _this.formData.signData = data.data.signData
                _this.formData.systemId = data.data.systemId
                _this.$nextTick(function () {
                  formElem.submit()
                })
                break
              default:
                toast(data.msg)
                break
            }
          }).catch(err => {
          console.log(err)
        })
      },
      /*
       * 将数据构建成页面渲染需要用到的函数
       * context  必传 上下文 这里传入当前vue实例化。
       * data     必传 从后台拿到的list中的每一个条目。
       * item1    必传 条目中的项目商业险或交强险的详细数据。
       * item2    选传 同item1， 当它存在时，说明 商业险或交强险订单状态相同渲染为一条数据。
       * */
      buildData(context, data, item1, item2 = undefined) {
        /*
         * 将数据处理为以下数据 用以显示订单页面
         * {
         * credatedDate： 订单创建日期
         *  "flowId": "string", 订单号
         *  "status": "string", 订单状态
         *  "vehicleFrameNo": "string", 车架号
         *  "vehicleLicenceCode": "string", 车牌号
         *  "renewalType": "String" 续保状态
         *  “B”: {  商业险信息
         *     insurPremium: 净保费，
         *     premium： 总保费,
         *     vehicleTaxTotalPremium: 车船税
         *  },
         *  "F": {  交强险
         *     insurPremium: 净保费 ，
         *     premium： 总保费 + vehicleTaxTotalPremium,
         *     vehicleTaxTotalPremium: 车船税
         *  },
         *  info: {}  数据中如果是两条在一条显示的则不动， 如果不是则要分开
         * }
         */
        let obj = {
          "credatedDate": '',
          "flowId": "",
          "status": "",
          "vehicleFrameNo": "",
          "vehicleLicenceCode": "",
          "renewalType": "",
          "B": {
            insurPremium: 0,
            premium: 0,
            applyPolicyNo: 0
          },
          "F": {
            insurPremium: 0,
            premium: 0,
            applyPolicyNo: 0
          }
        };
        for (let q of Object.keys(obj)) {
          obj[q] = data[q]
        }
        obj.info = {};
        obj.renewalType = item1.renewalType;
        obj[item1.planclass] = {
          insurPremium: item1.insurPremium,
          premium: item1.premium + item1.vehicleTaxTotalPremium,
          applyPolicyNo: item1.applyPolicyNo,
          checked: true,
          policyNo: item1.policyNo || '',
          productCode:item1.productCode || ''
        };

        if (item2 !== undefined) {
          obj[item2.planclass] = {
            insurPremium: item2.insurPremium,
            premium: item2.premium + item2.vehicleTaxTotalPremium,
            applyPolicyNo: item2.applyPolicyNo,
            checked: true,
            policyNo: item2.policyNo || '',
            productCode: item2.productCode || ''
          };
          obj.info = data.info
        } else { // 处理显示详情的时候的数据
          Object.keys(data.info).forEach(v => {
            if (Object.prototype.toString.call(data.info[v]) !== '[object Array]') {
              obj.info[v] = data.info[v]
            }
          });
          obj.info.orderVO = [];
          if (data.info.orderVO.length > 1) {
            data.info.orderVO.forEach((v) => {
              if (v.planclass === item1.planclass) {
                obj.info.orderVO.push(v)
              }
            })
          } else {
            obj.info.orderVO.push(data.info.orderVO[0])
          }
        }
        obj.info.renewalType = item1.renewalType;
        obj.status = item1.status;
        context.dataList.push(obj);
      },
      /* 去支付函数 由子组件触发*/
      topay(flowId, forceApplyNo, bizApplyNo) {
        window.eventAnalytics('保单管理', '列表中点击去支付');
        /*{
         params: {
         flowId: flowId,
         forceApplyNo: forceApplyNo,
         bizApplyNo: bizApplyNo,
         path: 'car',
         file: 'updata'
         }
         }*/
        axios.post(url.getWebServiceUrls('toPayOrderList'), {
          "bizApplyNo": bizApplyNo,
          "flowId": flowId,
          "forceApplyNo": forceApplyNo
        }).then(res => {
//          console.log(res)
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
          switch (data.code) {
            case 0:
              window.location.href = data.data.imcsPayUrl
              break
            default:
              toast(data.msg)
              break
          }
        }).catch(err => {
          console.log(err)
        })
      },
      /*下拉刷新触发, 从新获取页面数据, 相当与重新进入页面*/
      updataPageData() {
        this.pageindex = 1;
        this.getData(true, true);
      }
    },
    mounted() {
      if (this.flagName === 'A') {
        this.getData(true)
        this.canTopAjax = !(this.$route.name === 'search')
      }
    },
    components: {
      ptsScrollAjax,
      ptsCheckbox,
      ptsOmItem
    },
    watch: {
      active(to, form) {
        if (to && !this.dataList.length) {
          this.getData(true)
        }
      },
      tabChildCode() {
        this.getData(true);
      }
    },
    beforeRouteEnter(to, from, next) {
      console.log(to)
    }
  }
</script>

<style>

</style>
