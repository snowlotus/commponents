<template>
  <div class="box" :class="isWXSHOWHEADER?'':'wx_box'" :style="{'paddingBottom': datas.orderVO && datas.orderVO[0].status=== 'D' ? '1.1rem' : '0'}">
    <pts-header v-if="isWXSHOWHEADER" titleText="保单详情"></pts-header>
    <main class="bg_f5f5f5">
      <div class="wrap insideXubaoWrap insideXubaoDetail">
        <!-- main start -->
        <div class="mainWrap" style="position: relative">
          <div class="scoreArea c">
            <div class="scoreEmpty">
              <img :src="imgEmpty" alt="">
            </div>
          </div>
          <div class="taskArea clientArea">
            <div class="taskBox" style="padding:.4rem .3rem .2rem .45rem">
              <dl>
                <dt>被保人</dt>
                <dd>{{datas.personnelName}}</dd>
              </dl>
              <!--<dl>
                <dt>电话号</dt>
                <dd>{{datas.mobileTelephoneNo | thereSpace}}</dd>
              </dl>-->
              <dl>
                <dt>保费总额</dt>
                <dd><em><span class="font-size-half">¥</span>{{insurPremium | NumberThere}}</em></dd>
              </dl>
            </div>
          </div>
          <div class="taskArea" id="testBtn" style="padding-top: 1.2rem;">
            <dl>
              <dt>车辆信息</dt>
            </dl>
            <div class="taskBox">
              <dl>
                <dt>车牌号</dt>
                <dd>{{datas.vehicleLicenceCode | vehicleFrameNoHidden }}</dd>
              </dl>
              <dl>
                <dt>车架号</dt>
                <dd>{{datas.vehicleFrameNo | fourSpace}}</dd>
              </dl>
              <!--<dl>
                <dt>车型名称</dt>
                <dd class="text-hidden">{{datas.autoModelChnName}}</dd>
              </dl>
              <dl>
                <dt>车龄</dt>
                <dd>{{datas.vehicleAge}}年</dd>
              </dl>-->
            </div>
          </div>
          <div class="taskArea mt20">
            <dl>
              <dt>保费信息</dt>
            </dl>
            <div class="taskBox insideXubaoMsg" v-for="(item,index) in datas.orderVO">
              <dl>
                <dt>险种</dt>
                <dd>{{item.planclass === 'B' ? '商业险':'交强险'}}</dd>
              </dl>
              <dl>
                <dt>金额</dt>
                <dd><em><span class="font-size-half">¥</span>{{item.premium | NumberThere}}</em></dd>
                <dd class="insurance_detail" style="color:#508CEE;" @click.stop="goInsuranceDetail">{{item.planclass === 'B' ? '查看明细' : ''}}</dd>
              </dl>
              <dl>
                <dt>有效期</dt>
                <dd>{{item.dateInsuranceBegin.split(' ')[0]}}至{{item.dateInsuranceEnd.split(' ')[0]}}</dd>
              </dl>
              <dl v-if="item.status === 'S' "> <!--class="speWidth"-->
                <dt>保单号</dt>
                <dd>{{item.policyNo | fourSpace}}</dd>
              </dl>
              <div class="bor_line" v-if="datas.orderVO.length > 1 && index < 1"></div>
            </div>
          </div>
        </div>
        <!-- main end -->
      </div>
    </main>
    <!--去支付 start-->
    <section class="ord_qzf" v-if="datas.orderVO && datas.orderVO[0].status=== 'D'">
      <div class="por">
        <p class="ord_hj">合计 <span
          class="ord36"><span class="font-size-half">¥</span>{{insurPremium + shou + vehicleTaxTotalPremium | NumberThere}}</span>
        </p>
        <a class="ord_quzf" href="javascript:;" target="_blank" title="去支付" otitle="去支付" otype="button"
           @touchstart="gotopay">去支付</a>
      </div>
    </section>
  </div>

</template>

<script>
  import filters from '../../common/filters/convertAmount.js'
  import '../../common/filters/conCar';
  import axios from 'common/js/axiosConfig.js'
  import url from 'common/js/comConfig.js'
  import toast from 'pts/toast'

  export default {
    name: "om_info",
    data () {
      return {
        imgEmpty: require('../../common/images/order-info-img.png'),
        datas: {},
        insurPremium: 0, // 在apply函数中计算出来的总保费
        shou: 0, // 在apply函数中计算出来的总手续费
        //是否显示头部
        isWXSHOWHEADER: window.PageStatus.WX_SHOW_HEADER,
        vehicleTaxTotalPremium: 0
      }
    },
    methods: {
      gotopay () {
        window.eventAnalytics('保单管理', '详情中点击去支付');
        let data = this.datas;
        let forceApplyNo = undefined;
        let bizApplyNo = undefined;
        data.orderVO.forEach(v => {
          if (v.planclass === 'F' && data.F) {
            forceApplyNo = v.applyPolicyNo
          }
          if (v.planclass === 'B' && data.B) {
            bizApplyNo = v.applyPolicyNo
          }
        });
        axios.post(url.getWebServiceUrls('toPayOrderList'), {
          flowId: data.flowId,
          forceApplyNo: forceApplyNo,
          bizApplyNo: bizApplyNo
        }).then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          switch (data.code) {
            case 0:
//              toast('成功')
              window.location.href = data.data.imcsPayUrl;
              break;
            default:
              toast(data.msg);
              break
          }
        }).catch(err => {
          console.log(err)
        })
      },
      applyData () {
        this.datas = this.$route.query;
        let data = this.datas;
        let insurPremium = 0;
        let shou = 0;
        let vehicleTaxTotalPremium = 0;
        let list = []
        data.orderVO.forEach(v => {
          if (data[v.planclass]) {
            insurPremium += v.insurPremium;
            shou += v.agencyCommision;
            vehicleTaxTotalPremium += (v.vehicleTaxTotalPremium ? v.vehicleTaxTotalPremium : 0)
            list.push(v);
          }
        });
        this.insurPremium = insurPremium;
        this.shou = shou;
        this.vehicleTaxTotalPremium = vehicleTaxTotalPremium;
        // 保证两条时 交强险显示在商业险前面
        if (list.length > 1 && list[0].planclass === 'B') {
          list.unshift(list.splice(1, 1)[0]);
        }
        data.orderVO = list;
        console.log(data);
      },

      //查看商业险种明细
      goInsuranceDetail(){
        this.$router.push({
          path:'/outInsuranceDetail',
          query:{
            "bApplyPolicyNo":this.datas.orderVO[0].planclass === 'B' ? this.datas.orderVO[0].applyPolicyNo : this.datas.orderVO[1].applyPolicyNo,
            "bPolicyNo":this.datas.orderVO[0].planclass === 'B' ? this.datas.orderVO[0].policyNo : this.datas.orderVO[1].policyNo || '',
          }
        })
      }
    },
    activated () {
      this.applyData()
    }
  }
</script>

<style lang="less">
  @import "../../common/css/1px";

  .insurance_detail {
    margin-left: .3rem;
    font-size: .22rem;
    margin-top: .03rem;
  }
  .insideXubaoMsg {
    & > .bor_line {
      margin: 0.2rem auto;
    }
    &:last-child > .bor_line {
      display: none;
    }
  }
  .pts-border {
    @c: #DDDDDD;
    .pts-1px-b(@c);
  }

  .pts-border:last-child {
    @c: transparent;
    .pts-1px-b(@c);
  }

  .num_org {
    color: #FF8208;
  }
</style>
