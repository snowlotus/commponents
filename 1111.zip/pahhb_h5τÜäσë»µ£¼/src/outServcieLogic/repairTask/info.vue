<template>
  <section class="box">
    <pts-header titleText="推修详情" leftFlag @on-left="goBack" :showRight="false"> <!--屏蔽分享按钮-->
      <a href="javascript:;" otype="button" otitle="分享按钮" class="nav_share_icon fr" slot="right" @click="shareCase"></a>
    </pts-header>
    <div class="mainWrap pt20 pb30" v-if="data.caseStatus && !showDataNull">
      <div class="taskArea reportMsgArea">
        <dl>
          <dt>出险信息</dt>
          <dd v-if="data.caseStatus  === '00'">新任务</dd>
          <dd v-if="data.caseStatus  === '02'">待确认</dd>
        </dl>
        <div class="taskBox">
          <dl>
            <dt>出险原因</dt>
            <dd>{{data.accidentSituation}}</dd>
          </dl>
          <dl>
            <dt>出险地点</dt>
            <dd>{{data.accidentSite}}</dd>
          </dl>
          <dl>
            <dt>出险时间</dt>
            <dd>{{data.accidentTime}}</dd>
          </dl>
          <a href="javascript:;" otype="button" otitle="案件图片" class="case_noImg_btn" :class="{active:isCaseImg}"
             @click.stop.prevent="goShowBanner"></a>
        </div>
      </div>
      <div class="taskArea detailArea">
        <dl>
          <dt>报案人信息</dt>
        </dl>
        <div class="taskBox">
          <dl>
            <dt>报案人</dt>
            <dd>{{data.reportName}}</dd>
          </dl>
          <dl>
            <dt>报案时间</dt>
            <dd>{{data.reportDate}}</dd>
          </dl>
          <a href="javascript:;" v-if="data.caseStatus !== '03'" otype="button" otitle="拨打电话"
             class="btnState btnStateTell pts-b-l"
             @click.stop.prevent="calluser">拨打电话</a>
        </div>
      </div>
      <div class="taskArea detailArea">
        <dl>
          <dt>案件信息</dt>
        </dl>
        <div class="taskBox">
          <dl>
            <dt>案件号</dt>
            <dd>{{data.reportNo | fourSpace}}</dd>
          </dl>
          <dl>
            <dt>车牌</dt>
            <dd>{{data.vehicleLicenceCode | vehicleLicenceCodeHidden}}</dd>
          </dl>
          <dl>
            <dt>车型</dt>
            <dd>{{data.carType}}</dd>
          </dl>
          <dl>
            <dt>客户类型</dt>
            <dd v-if="data.repairType == 0">非本店客户<span style="color:#999;">(送修)</span></dd>
            <dd v-else-if="data.repairType == 1">本店客户<span style="color:#999;">(返修)</span></dd>
            <dd v-else>非本店客户<span style="color:#999;">(三者)</span></dd>
          </dl>
          <dl>
            <dt>案件状态</dt>
            <dd v-if="data.accidentType == 1">单方事故</dd>
            <dd v-else-if="data.accidentType == 2">双方事故</dd>
          </dl>
          <dl>
            <dt>是否大案</dt>
            <dd v-if="data.majorCase==='Y'">是</dd>
            <dd v-else>否</dd>
          </dl>
          <dl>
            <dt>承保险别</dt>
            <dd>
              <span v-if="data.planList[0]">{{data.planList[0].dutyName}}<br></span>
              <span v-if="data.planList[1]">{{data.planList[1].dutyName}}<br></span>
              <span v-if="data.planList[2]">{{data.planList[2].dutyName}}<br></span>
              <a href="javascript:;" v-if="data.planList.length > 0" otype="button" otitle="点击查看详情" class="checkDetail"
                 @click.prent.stop="showInsureMsgEvent">点击查看详情</a>
            </dd>
          </dl>
        </div>
      </div>
      <div class="taskArea detailArea">
        <dl>
          <dt>查勘员信息</dt>
        </dl>
        <div class="taskBox">
          <dl>
            <dt>查勘员</dt>
            <dd>{{data.surveyName}}</dd>
          </dl>
          <dl>
            <dt>查勘电话</dt>
            <dd><a :href="'tel:'+data.surveyTelephone" otype="button" otitle="152-7441-1234"
                   class="telNo">{{data.surveyTelephone | phoneType}}</a></dd>
          </dl>
        </div>
      </div>
      <div class="taskArea commuArea">
        <dl>
          <dt>接触历史</dt>
        </dl>
        <div class="commuBox">
          <div class="rateCont c" v-for="(item, index) in data.touchHistoryList" v-if="data.touchHistoryList.length">
            <dl class="rateConTime">
              <dt>{{item.touchDate | spliceDate}}</dt>
              <dd>{{item.touchDate | spliceTime}}</dd>
            </dl>
            <dl class="rateConTxt icon_rate" :class="{'icon_time': index===0}">
              <dt style="word-break: break-all;">{{item.touchResult}}<span v-if="item.touchDetail">--{{item.touchDetail}}</span>
              </dt>
              <dd>操作人：{{item.operator}}（<a :href="'tel:'+item.operatorPhone" otype="button"
                                           otitle="152-7441-1234">{{item.operatorPhone | phoneType}}</a>）</dd>
            </dl>
          </div>
          <div v-else style="text-align: center;padding: 0.5rem 0; color:#999;">暂无接触记录</div>
        </div>
      </div>
    </div>
    <!-- 第一次获取的数据为空时显示的页面 -->
    <div v-if="showDataNull" class="dataNullWrap">
      <div class="imgWrap"></div>
      <div class="dataNullText">{{errText}}</div>
    </div>
    <!-- 确认拨号弹窗 -->
    <pts-call-alert :showAlert="showCallAlert"
                    @on-updata-alert="calluser" :userNum="userNumList"></pts-call-alert>
    <!-- 拨打结果记录 -->
    <pts-call-msg :showCallMsg="showCallMsg" @on-updata-callmsg="getMsg"
    ></pts-call-msg>
    <!-- 承保险别详情 -->
    <pts-alert v-model="showInsureMsg">
      <div class="reMaskArea">
        <h3>承保险别详情</h3>
        <table border="0" cellspacing="0" cellpadding="0" width="100%">
          <thead style="display: block">
          <tr style="display:block; width: 100%;">
            <td style="display: inline-block; width: 62%;"><p>承保险别</p></td><td style="display: inline-block; width:37.6%;"><p style="color: #666;">保额（元）</p></td>
          </tr>
          </thead>
          <tbody style="display:block;height: 5rem; overflow: auto; width: 100%;">
          <tr v-if="data.planList" v-for="item in data.planList">
            <td width="62%"><p>{{item.dutyName}}</p></td>
            <td width="38%"><p><span class="font-size-half">¥</span>{{item.payLimit | NumberThere}}</p></td>
          </tr>
          </tbody>
        </table>
        <a href="javascript:;" otype="button" otitle="我知道了" class="sendUp saveBtn"
           @click.prevent="showInsureMsg = false">我知道了</a>
      </div>
    </pts-alert>
  </section>
</template>

<script>
  import toast from '../../common/comComponent/toast'
  import axios from '../../common/js/axiosConfig'
  import url from '../../common/js/comConfig'
  import ptsCallAlert from './page/callAlert.vue'
  import ptsCallMsg from './page/callMsg.vue'
  import '../../common/filters/convertAmount'
  import ptsAlert from '../../common/comComponent/alertWindow'
  export default {
    name: "repairTaskInfo",
    data () {
      return {
        showCallAlert: false,
        showCallMsg: false,
        showInsureMsg: false,
        showDataNull: false,
        data: {},
        userNumList: '',
        errText: '查询失败, 退出重试',
        isCaseImg:false, //判断有无案件照片
        imgArr:[] //存储图片ID
      }
    },
    methods: {
      /*分享按钮*/
      shareCase(){
        const _this = this;
        const u = navigator.userAgent;
        const isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
        const isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端

        let shareData = {
          "title": "您有一个推修案件,请查看",
          "desc": "车牌: "+_this.data.vehicleLicenceCode.indexOf('*') > -1 ? '*_*' : _this.data.vehicleLicenceCode,
          "imgUrl": _this.data.icoUrl,
          "url": _this.data.shareUrl,
          "from": "平安好伙伴"
        };
        if(isiOS){
          let iframe = document.createElement("iframe");
          iframe.src = 'pagp://share|'+encodeURIComponent(window.JSON.stringify(shareData));
          iframe.style.display = "none";
          document.body.appendChild(iframe);
          iframe.parentNode.removeChild(iframe);
          iframe = null;
        }else if(isAndroid){
          window.location.href = 'pagp://share|'+JSON.stringify(shareData);
        }else{
          toast('暂不支持，请尝试在微信内打开！');
        }
        /*Native.requestHybrid({
          tagname : 'PAGP_H5_Share'
        })*/
        window.eventAnalytics('推修任务','案件详情分享')
      },

      /*进入案件图片*/
      goShowBanner(){
        if(this.isCaseImg){
          const obj = this.$route.query;
          this.$router.push({path:'/repairShowImage',
            query:{
              carMark:obj.carMark,
              reportNo:obj.reportId,
              vehicleFrameNo:obj.vehicleFrameNo,
              caseImgArr:this.imgArr
            }
          });
        }else{
          return false
        }
      },

      /* 获取页面数据 */
      getData (reportId, taskId, carMark) {
        /*axios.get(url.getWebServiceUrls('pageData'), {
         params: {
         file: 'info',
         path: 'car',
         timout: 1
         }
         })*/
        axios.post(url.getWebServiceUrls('contactCustomerDetail'), {
          reportId: reportId,
          taskId: taskId,
          carMark: carMark
        }).then(res => {
          console.log('获取到的数据为: ' + JSON.stringify(res.data));
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          switch (data.code) {
            case 0:
              this.data = data.data ? data.data : {};
              if (!data.data.caseStatus && !data.data.reportName) {
                this.showDataNull = true;
              };

              //判断有无案件图片
              if(data.data.fileIdList && data.data.fileIdList.length > 0){
                this.isCaseImg = true;
                this.imgArr = data.data.fileIdList;
              };
              break;
            default:
              this.showDataNull = true;
              this.errText = '查询错误, 请重试';
              toast(data.msg);
              break
          }
        }).catch(err => {
          this.showDataNull = true;
          this.errText = '查询错误, 请重试';
          console.log(err);
        })
      },
      /* 获取安全号码并拨打 */
      calluser (flag, num, numList) {
        const _this = this
        window.eventAnalytics('推修任务', '详情页面点击拨打电话');
//        this.showCallAlert = false
//        if (!flag) {
//          return
//        }
        /* 如果用户修改号码 通知navtive 刷新修改的电话号 */
//        if (numList) {
//          _this.userNum = numList
//          Native.requestHybrid({
//            tagname: 'setUserPhoneNum',
//            param: {
//              numList: numList + ''
//            },
//            callback: function (data) {
//            }
//          })
//        }
        axios.post(url.getWebServiceUrls('applysecurityphonenumber'), {
          taskId: _this.$route.query.taskId
        }).then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
          switch (data.code) {
            case 0:
              if (window.urlHeader.os === 'iOS') {
                window.getUserIsCall = function () {
                  setTimeout(function () {
                    _this.showCallMsg = true;
                  }, 1000);
                  return window.getUserIsCall = null;
                }
              }
              window.location.href = 'tel: ' + data.data;
              if (window.urlHeader.os === 'iOS') return;
              setTimeout( () => {
                this.showCallMsg = true
              }, 1000);
              break
            default:
              toast(data.msg)
              break
          }
        }).catch(err => {
          console.log(err)
          // toast('获取安全号码失败, 请重试。')
        })
      },
      /* 获取用户填写的信息并发送到服务端 */
      getMsg (msg) {
        const _this = this;
//        console.log(msg)
        axios.post(url.getWebServiceUrls('contactresult'), {
          contactCustomerResult: msg.contactCustomerResult,
          contactFailedOtherReason: msg.contactFailedOtherReason || msg.krFailReason,
          taskId: _this.$route.query.taskId
        }).then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data
          switch (data.code) {
            case 0:
              _this.showCallMsg = false;
              toast('提交成功');
              const query = this.$route.query;
              _this.getData(query.reportId, query.taskId, query.carMark);
              break;
            default:
              toast(data.msg);
              break;
          }
        }).catch(err => {
          // toast('提交失败, 请重试');
          console.log(err);
        })
      },
      /* 唤醒选择电话号弹窗 */
      awakenCallAlert () {
        const _this = this
        Native.requestHybrid({
          tagname: 'getUserPhoneNum',
          callback: function (data) {
            let datas = typeof data === 'string' ? JSON.parse(data) : data
            // console.log(JSON.stringify(datas))
            _this.userNumList = datas.data.phoneNum
          }
        })
        _this.showCallAlert = true
      },
      goBack () {
        if (window.history.length > 1) {
          window.history.go(-1)
        } else {
          Native.requestHybrid({
            tagname: 'backHome'
          })
        }
      },
      showInsureMsgEvent () {
        this.showInsureMsg = true;
        window.eventAnalytics('推修任务', '推修详情查看投保详情');
      }
    },
    mounted () {
      const query = this.$route.query;
      this.getData(query.reportId, query.taskId, query.carMark);
    },
    components: {
      ptsCallAlert,
      ptsCallMsg,
      ptsAlert
    },
    filters: {
      fourSpace (v) {
        if (!v) {
          return v
        }
        let arr = v.split('');
        for (let i = 0; i < arr.length; i++) {
          if (i % 5 === 0) {
            arr.splice(i, 0, ' ')
          }
        }
        return arr.join('')
      },
      phoneType (value) {
        if (!value) {
          return value
        }
        let arr = (value + '').split('')
        if (arr.length > 3) {
          arr.splice(3, 0, '-')
        }
        if (arr.length > 7) {
          arr.splice(8, 0, '-')
        }
        return arr.join('')
      },
      spliceDate (v) {
        if (!v) return v;
        const index = v.indexOf('-')
        if (index < 0) {
          return v
        }
        return v.substr(index + 1, 5)
      },
      spliceTime (v) {
        if (!v) return v;
        const index = v.indexOf(' ')
        if (index < 0) {
          return v
        }
        return v.substr(index + 1, v.length)
      },
      vehicleLicenceCodeHidden (value) {
        if (!value) return value
        if (value.indexOf('*') > -1) {
          return '*_*'
        } else {
          return value
        }
      }
    }
  }
</script>

<style lang="less" scoped>
  .nav_share_icon{
    display: inline-block;
    width: .45rem;
    height: .45rem;
    background: url("../../common/images/share_icon@3x.png") no-repeat;
    background-size: 100%;
    margin-top: -0.5rem;
    margin-right: .27rem;
  }
  .case_noImg_btn{
    display: block;
    content: "";
    position: absolute !important;
    width: .69rem;
    height: .68rem;
    background: url(../../common/images/icon_noImg@3x.png) no-repeat;
    background-size: .69rem .68rem;
    right: .31rem;
    top: 1rem;
  }
  .active{
    display: block;
    content: "";
    position: absolute !important;
    width: .69rem;
    height: .68rem;
    background: url("../../common/images/icon_haveImg@3x.png") no-repeat;
    background-size: .69rem .68rem;
    right: .31rem;
    top: 1rem;
  }

  /*推修详情 start*/
  .reportMsgArea {
    background: #fff;
  }

  .detailArea,
  .commuArea {
    margin-top: .2rem;
  }

  .reportMsgArea > dl,
  .detailArea > dl,
  .commuArea > dl {
    position: relative;
  }

  .reportMsgArea > dl,
  .detailArea > dl,
  .commuArea > dl {
    width: 7.5rem;
    padding: 0;
  }

  .reportMsgArea > dl dt,
  .detailArea > dl dt,
  .commuArea > dl dt {
    position: relative;
    padding: 0;
    width: 2rem;
    font-size: .28rem;
    color: #000;
    border: none;
    text-align: left;
  }

  .reportMsgArea > dl dt,
  .detailArea > dl dt,
  .commuArea > dl dt {
    padding-left: .3rem;
  }

  .reportMsgArea > dl dt:before,
  .detailArea > dl dt:before,
  .commuArea > dl dt:before {
    display: block;
    content: "";
    position: absolute;
    top: 50%;
    left: 0;
    width: .1rem;
    height: .2rem;
    margin-top: -.12rem;
    background: #fe883a;
  }

  .reportMsgArea > dl dd,
  .detailArea > dl dd,
  .commuArea > dl dd {
    height: .33rem;
    line-height: .39rem;
    margin-top: .145rem;
    padding: 0 .06rem;
    font-size: .24rem;
    color: #fe812f;
    border: 1px solid #fe812f;
  }

  .reportMsgArea > dl dd,
  .detailArea > dl dd {
    margin-right: .3rem;
  }

  .reportMsgArea .taskBox,
  .detailArea .taskBox {
    width: 7.5rem;
    padding: 0 0 .3rem;
  }

  .detailArea .msgSpBox {
    padding-bottom: 0;
  }

  .reportMsgArea .taskBox > dl,
  .detailArea .taskBox > dl {
    overflow: hidden;
    line-height: .52rem;
    padding: 0.1rem 0 0 0;
  }

  .reportMsgArea .taskBox > dl dt,
  .detailArea .taskBox > dl dt {
    float: left;
    width: 1.4rem;
    margin-right: .25rem;
    font-size: .28rem;
    color: #666;
    text-align: right;
  }

  .reportMsgArea .taskBox > dl dd,
  .detailArea .taskBox > dl dd {
    float: left;
    width: 4.48rem;
  }

  .detailArea .taskBox > dl dd a {
    font-size: .28rem;
    color: #508CEE;
  }

  .commuBox {
    padding-top: .2rem;
    background: #fff;
  }

  .commuBox .rateCont {
  }

  .commuBox .rateCont .rateConTime {
    float: left;
    width: 1.94rem;
    color: #888;
    text-align: center;
  }

  .commuBox .rateCont .rateConTime dt {
    line-height: .36rem;
    font-size: .28rem;
  }

  .commuBox .rateCont .rateConTime dd {
    line-height: .28rem;
    font-size: .2rem;
  }

  .commuBox .rateCont .rateConTxt {
    position: relative;
    float: left;
    width: 4.7rem;
    padding-left: .6rem;
    line-height: .36rem;
    border-left: 1px dashed #eee;
  }

  .commuBox .rateCont .icon_rate:before {
    display: block;
    content: "";
    position: absolute;
    top: .11rem;
    left: -.08rem;
    width: .14rem;
    height: .14rem;
    border-radius: 50%;
    background: #fe883a;
  }

  .commuBox .rateCont .icon_time:before {
    display: block;
    content: "";
    position: absolute;
    top: 0;
    left: -.12rem;
    width: .27rem;
    height: .3rem;
    background: #fff url(../../common/images/icon_time.png) no-repeat 0 bottom;
    background-size: .23rem .23rem;
  }

  .commuBox .rateCont .rateConTxt dt {
    margin-bottom: .2rem;
    font-size: .28rem;
    color: #666;
  }

  .commuBox .rateCont .rateConTxt dd {
    padding-bottom: .6rem;
    font-size: .24rem;
    color: #999;
  }

  .commuBox .rateCont .rateConTxt dd a {
    color: #508CEE;
  }

  /*推修详情 end*/
</style>
