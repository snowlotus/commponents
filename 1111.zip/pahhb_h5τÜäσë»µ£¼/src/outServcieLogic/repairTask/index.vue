<template>
  <div class="box">
    <pts-header leftFlag @on-left="goMenu"></pts-header>
    <pts-tab :titleList="titleList" v-model="index" ref="tabElem" @on-child-change="tabChildChange"
             @on-change="tabChange">
      <pts-tab-item>
        <!--全部-->
        <pts-task-list flagName="07" :active="index===0"></pts-task-list>
      </pts-tab-item>
      <pts-tab-item>
        <!--新任务-->
        <pts-task-list flagName="00" @on-offRedDot="offRedDot" :active="index===1"></pts-task-list>
      </pts-tab-item>
      <pts-tab-item>
        <!--待确认-->
        <pts-task-list flagName="02" :active="index===2"></pts-task-list>
      </pts-tab-item>
      <pts-tab-item>
        <!--成功-->
        <pts-task-list flagName="06" :active="index===3" :tabChild="tabChild"></pts-task-list>
      </pts-tab-item>
    </pts-tab>
  </div>
</template>

<script>
  import ptsTab from '../../common/comComponent/tab'
  //  import ptsTaskList from './page/list.vue'
  export default {
    name: "repairTask",
    data () {
      return {
        titleList: [
          {
            title: '全部'
          },
          {
            title: '新任务',
            isRed: false
          },
          {
            title: '待确认'
          },
          {
            title: '已完成',
            childs: [
              {title: '已完成', flag: '06'},
              {title: '成功', flag: '04'},
              {title: '失败', flag: '05'},
              {title: '失效', flag: '03'}
            ]
          }
        ],
        index: 0,
        tabChild: '06'
      }
    },
    components: {
      ptsTab,
      ptsTabItem: ptsTab.Item,
      ptsTaskList: resolve => require.ensure([], () => resolve(require('./page/list.vue')), 'SearchTaskList')
    },
    methods: {
      tabChildChange (item) {
        this.tabChild = item.flag
      },
      goMenu () {
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      offRedDot () {
        this.titleList[1].isRed = false
      },
      tabChange (item) {
        window.eventAnalytics('推修任务', 'tab切换', {tabName: item.title});
      }
    },
    created () {
      const _this = this
      window.setRedDot = function () {
        _this.titleList[1].isRed = true
      }
    },
    watch: {
      index (to) {
        if (to === 1) {
          this.offRedDot();
        }
      }
    }
  }
</script>

<style lang="less" scoped>

</style>
