<template>
  <section class="taskArea pt20">
    <dl class="pts-b-b">
      <dt v-if="datas.taskStatus === '00'">新任务</dt>
      <dt v-if="datas.taskStatus === '02'">待确认</dt>
      <dt v-if="datas.taskStatus === '04'" style="border-color:#2ab768; color:#2ab768;">成功</dt>
      <dt v-if="datas.taskStatus === '05'" style="border-color:#ff6666; color:#ff6666;">失败</dt>
      <dd class="numberFamily" style="color:#CCC;">{{datas.pushDate}}</dd>
    </dl>
    <div class="taskBox" :class="{'fontcolor333': datas.taskStatus === '03' }" @click="goInfo">
      <dl>
        <dt>报案人</dt>
        <dd >{{datas.reportName}}</dd>
      </dl>
      <dl>
        <dt>车牌</dt>
        <dd >{{datas.carMark | vehicleLicenceCodeHidden}}</dd>
      </dl>
      <dl>
        <dt>客户类型</dt>
        <dd  v-if="datas.repairType == 0">非本店客户<span style="color:#999;">(送修)</span></dd>
        <dd  v-else-if="datas.repairType == 1">本店客户<span style="color:#999;">(返修)</span></dd>
        <dd  v-else>非本店客户<span style="color:#999;">(三者)</span></dd>
      </dl>
      <!--<dl>
        <dt>案件号</dt>
        <dd >{{datas.reportId | fourSpace}}</dd>
      </dl>-->
      <dl>
        <dt>是否大案</dt>
        <!--<dd>{{datas.majorCase==='Y' ? '是' : '否'}}</dd>-->
        <dd :class="{active:datas.majorCase==='Y'}">{{datas.majorCase==='Y' ? '是' : '否'}}{{datas.isThirdType=='Y' ? '(三者)' : ''}}</dd>
      </dl>
      <dl>
        <dt>出险时间</dt>
        <dd>{{datas.accidentTime}}</dd>
      </dl>
      <dl>
        <dt>出险地点</dt>
        <dd>{{datas.accidentSite | joinStr}}</dd>
      </dl>
      <!--<dl>
        <dt>车型</dt>
        <dd class="text-hidden">{{datas.carType || '*_*'}}</dd>
      </dl>-->
      <a href="javascript:;" v-if="datas.contactCustomerResult === '03'" class="btnState btnState_loseeff"
         otype="button" otitle="拨打电话"></a>
      <a href="javascript:;" @click.stop.prevent="call" class="btnState btnStateTell pts-b-l"  v-else
         otype="button" otitle="拨打电话">拨打电话</a>
    </div>
  </section>
</template>

<script>
  import '../../../common/filters/convertAmount'
  export default {
    name: "taskItem",
    props: {
      datas: Object
    },
    data () {
      return {
        type: 'new'
      }
    },
    methods: {
      goInfo () {
        this.$router.push({
          path: '/repairTaskInfo',
          query: {
            reportId: this.datas.reportId,
            taskId: this.datas.taskId,
            carMark: this.datas.carMark,
          }
        });
        window.eventAnalytics('推修任务', '进入推修详情',{
          reportId: this.datas.reportId,
          taskId: this.datas.taskId,
          carMark: this.datas.carMark
        });
      },
      call () {
        this.$emit('on-call', this.datas.taskId)
      }
    },
    filters: {
      vehicleLicenceCodeHidden (value) {
        if (!value) return value
        if (value.indexOf('*') > -1) {
          return '*_*'
        } else {
          return value
        }
      },
      joinStr(value){
        if(!value) return value
        return value.split('-').join('')
      }
    }
  }
</script>

<style lang="less" scoped>
  .active{
    color: #FF4141;
  }
</style>
