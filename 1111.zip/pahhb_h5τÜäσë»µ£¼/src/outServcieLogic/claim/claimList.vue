<template>
  <div class="box">
    <pts-header leftFlag @on-left="goMenu(backName)" flagName="claimList"></pts-header>
    <pts-tabs :titleList="titleList" v-model="index" @on-child-change="tabChildChange" v-if="showFlag">
      <pts-tab-item>
        <pts-claim-list :flagName="index" :active="index===0" :childs="tabChild"></pts-claim-list>
        <!--<div v-else class="dataNullWrap">-->
          <!--<div class="imgWrap"></div>-->
          <!--<div class="dataNullText">没有搜到匹配的数据…</div>-->
        <!--</div>-->
      </pts-tab-item>
      <pts-tab-item>
        <pts-claim-list :flagName="index" :active="index===1"></pts-claim-list>
      </pts-tab-item>
      <pts-tab-item>
        <pts-claim-list :flagName="index" :active="index===2"></pts-claim-list>
      </pts-tab-item>
    </pts-tabs>
    <!-- <pts-tab-item v-if="!showFlag" style="width: 100%;">
         <pts-claim-list :dataList="newList" :active="9"></pts-claim-list>
     </pts-tab-item>-->

  </div>
</template>

<script>
  import ptsTabs from '../../common/comComponent/tab'
  import ptsClaimList from './template/list.vue'
  import Axios from '../../common/js/axiosConfig'
  import API from '../../common/js/comConfig'
  import Toast from '../../common/comComponent/toast'

  export default {
    name: 'claimList',
    data() {
      return {
        searchContext: '请输入搜索的内容（案件号、车牌）',
        titleList: [
          {
            title: '全部',
            childs: [
              {title: '全部', flag: ''},
              {title: '报案', flag: '00'},
              {title: '定损', flag: '01'},
              {title: '理算', flag: '02'},
              {title: '结案', flag: '03'}
            ]
          }, {
            title: '定损'
          }, {
            title: '结案'
          }
        ],
        index: 0,
        tabChild: '0',
        claimData: [],
        backName: '',
        newList: [],
        showFlag: true,
        showFlagChilds: false,
        dataListCount: 0, //近30天的数据
        flagName: 0
      }
    },
    created() {
//      this.getData();
    },

    methods: {
      getData() {

      },
      tabChildChange(item) {
        this.showFlagChilds = true;
        this.tabChild = item.flag
      },
      goMenu(val) {
        Native.requestHybrid({
          tagname: 'backHome'
        })
      }
    },
    watch: {
      active(to, from) {
        console.log(to)
      }
    },
    components: {
      ptsTabs,
      ptsTabItem: ptsTabs.Item,
      ptsClaimList
    }
  }
</script>

<style lang='less'>

</style>
