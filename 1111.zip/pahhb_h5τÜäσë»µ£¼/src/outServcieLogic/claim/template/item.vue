<template>
  <div class="taskArea pt20">
    <dl class="pts-b-b">
      <dt>{{data.taskStatus | taskStatusType}}</dt>
      <dd>{{data.reportDate}}</dd>
    </dl>
    <div class="taskBox" @click="getInfo" data-value="data.carRackNo">
      <dl>
        <dt>报案人</dt>
        <dd>{{data.reportName}}</dd>
      </dl>
      <!-- <dl>
         <dt>案件号</dt>
         <dd>{{data.reportNo | fourSpace}}</dd>
       </dl>-->
      <dl>
        <dt>车型</dt>
        <dd>{{data.carTypeName||'*_*'}}</dd>
      </dl>
      <dl>
        <dt>出险事故</dt>
        <dd>{{data.accidentType | threaAdvice}}<span style="color: #FF8C41;">{{data.isInjured | isInjured}}</span></dd>
      </dl>
      <!--<dl>-->
        <!--<dt>出险地点</dt>-->
        <!--<dd class="addre">{{data.accidentPlace}}</dd>-->
      <!--</dl>-->
    </div>
  </div>

</template>

<script>
  import {fourSpace} from '../../../common/filters/convertAmount'
  import {taskStatusType, threaAdvice, isInjured} from '../../../common/filters/convertIdType'

  export default {
    name: 'claimItem',
    props: {
      data: Object
    },
    methods: {
      getInfo() {
        window.eventAnalytics('理赔查询', '点击了理赔的详情页');
        this.$router.push({
          path: 'claimInfo', query: {
            carMark: this.data.carMark,
            carRackNo: this.data.carRackNo,
            reportNo: this.data.reportNo,
            taskStatus: this.data.taskStatus
          }
        })
        //console.log('hello')
      }
    }
  }
</script>

<style lang='less'>
  .addre {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
</style>
