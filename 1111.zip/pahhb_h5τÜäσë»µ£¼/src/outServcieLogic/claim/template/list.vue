<template>
  <div class="listScroll">
    <!--&& !searchCondition && !showDateNull && !showDateNull-->
    <pts-scroll-ajax ref="scrollAjaxElem" :topAjax="topAjax &&!showDataNull && searchFlag"
                     :bottomAjax="bottomAjax &&!showDataNull && searchFlag"
                     @on-top-ajax="getFirstPage" @on-bottom-ajax="getNextPage">
      <pts-claim-item v-if="newArr&&newArr.length>0" v-for="item in newArr" :key="item.reportId"
                      :data="item"></pts-claim-item>
      <!-- 第一次获取的数据为空时显示的页面 -->
      <div v-if="showDataNull" class="dataNullWrap">
        <div class="imgWrap"></div>
        <div class="dataNullText">没有搜到匹配的数据…</div>
      </div>
      <p class="totalOrder pof_b1" v-if="newArr&&newArr.length>0&&showDan">近31天共{{dataListCount || 0}}单</p>
    </pts-scroll-ajax>
  </div>
</template>

<script>
  import ptsClaimItem from './item.vue'
  import ptsScrollAjax from '../../../common/comComponent/scrollAjax'
  import Toast from '../../../common/comComponent/toast/index'
  import Axios from '../../../common/js/axiosConfig'
  import API from '../../../common/js/comConfig'

  export default {
    data() {
      return {
        showDataNull: false,
        newArr: [],
        num: 0,
        status: '',
        dataListCount: '',
        showDan: true,
        dataList: [],//接口List
        reqData: {},
        page: 1,
        topAjax: true, //下拉刷新
        bottomAjax: false,//上拉加载
      }
    },
    props: {
      childs: String,
      active: Boolean,
      flagName: Number,
//      claimData: Array,
      dataSearchList: Array,
      dataCount: String,
      searchFlag: {
        type: Boolean,
        default: true
      },
      startTime: String,
      endTime: String
//      dataListCount : Number
    },
    created() {
      let self = this;
      let req = {
        currentPage: this.page,//当前页
        queryTaskType: this.status,//查询类型
        perPageSize: 20
      }

      //dataSearchList
      if (self.dataSearchList && self.dataSearchList.length) {
//        self.showDan = false; //搜索界面隐藏单数
        this.$nextTick(function () {
          this.$refs.scrollAjaxElem && this.$refs.scrollAjaxElem.reset(true);
        })
        self.newArr = self.dataSearchList;
        self.dataListCount = self.dataCount;
        self.bottomAjax = self.dataListCount > 20 ? true : false;
        console.log(self.startTime + "   " + self.endTime + "  " + self.searchFlag);
        return;
      }

      this.$nextTick(function () {
        this.searchFlag = true;
        if (this.active) {
          this.getData(req);
        }
      })
    },
    methods: {
      getData: function (reqData, flag = true) {
        //taskStatus (string, optional): 任务状态 00:报案 01:定损 02:核损 03:单证齐全 04:已结案
        console.log(reqData);
        Axios.post(API.getWebServiceUrls('settlementList'), reqData).then(res => {
          let repData = typeof res.data === "string" ? JSON.parse(res.data) : res.data;
          if (repData.code == 0 && repData.data) {
            this.newArr = this.dataList = repData.data.claimsReturnList || []; //得到总对象
            this.dataListCount = repData.data.totalNum;
            if (this.newArr && this.newArr.length <= 0) {
              this.showDataNull = true;
            } else {
              this.showDataNull = false;
            }
            if (20 * this.page < this.dataListCount) {
              this.bottomAjax = true;
            } else {
              this.bottomAjax = false;
            }
            this.$nextTick(function () {
              this.$refs.scrollAjaxElem && this.$refs.scrollAjaxElem.reset(true)
            })
            return
          } else {
            Toast(repData.msg || '系统繁忙请稍后重试');
          }
        }).catch(err => {
          console.log(err);
        });
      },
      /**
       * 上拉刷新
       * */
      getFirstPage: function () {
        console.log('上拉刷新');
        this.page = 1;
        let req = {};
        if (this.searchFlag) {
          req = {
            currentPage: this.page,//当前页
            queryTaskType: this.status,//查询类型
            perPageSize: 20,
            reportStartDate: this.startTime || "",
            reportEndDate: this.endTime || "",
          }
        } else {
          req = {
            currentPage: this.page,//当前页
            queryTaskType: this.status,//查询类型
            perPageSize: 20,
          }
        }

        this.getData(req, true)
      },
      /**
       * 下拉加载
       * */
      getNextPage: function () {
        console.log('下拉加载')
        this.page++;
        let req = {};
        if (this.searchFlag) {
          req = {
            currentPage: this.page,//当前页
            queryTaskType: this.status,//查询类型
            perPageSize: 20,
            reportStartDate: this.startTime || "",
            reportEndDate: this.endTime || "",
          }
        } else {
          req = {
            currentPage: this.page,//当前页
            queryTaskType: this.status,//查询类型
            perPageSize: 20,
          }
        }
        this.getData(req, false);
      }
    },
    mounted() {

    },
    components: {
      ptsClaimItem,
      ptsScrollAjax
    },
    watch: {
      flagName(to, old) {
        /*let self = this;
        if (this.active) {
          let arr = [];
          this.showDataNull = false;
          if (this.claimData.dataList && this.claimData.dataList.length > 0) {
            if (to === 1) { //定损
              window.eventAnalytics('理赔查询', '查看定损列表');
              arr = this.claimData.damageList || [];
            } else if (to === 2) { //结案
              window.eventAnalytics('理赔查询', '查看结案列表');
              arr = this.claimData.closeCaseList || [];
            } else {
              if (to === 0 && this.status === '09') {
                window.eventAnalytics('理赔查询', '查看全部列表');
                arr = this.claimData.dataList ? this.claimData.dataList : []; //显示全部
              } else {
                this.claimData.dataList.forEach(v => {
                  if (v['taskStatus'] === self.status) {
                    if (v['taskStatus'] === '01') {  //取定损的list
                      window.eventAnalytics('理赔查询', '查看全部-定损');
                      arr = self.claimData.damageList;
                    } else if (v['taskStatus'] === '04') {
                      window.eventAnalytics('理赔查询', '查看全部-结案');
                      arr = self.claimData.closeCaseList;  //取结案的list
                    } else {
                      arr.push(v)
                    }
                  }
                })
              }
            }
          } else {
            arr = [];
          }
          this.newArr = arr.length > 0 ? arr : this.showDataNull = true;
        }*/
        //00:报案 01:定损 02:理算 03:结算 空为所有状态

        if (this.active) {
          if (to === 1) {
            this.status = '01';
            let req = {
              currentPage: 1,//当前页
              queryTaskType: this.status,//查询类型
              perPageSize: 20
            };
            console.log('这是定损的列表');
            this.getData(req);
          } else if (to === 2) {
            this.status = '03';
            let req = {
              currentPage: 1,//当前页
              queryTaskType: this.status,//查询类型
              perPageSize: 20 //每页多少条
            };
            this.getData(req);
            console.log('这是结案的列表');
          } else {
            if (to === 0 && this.status === '') {
              this.status = '';
              let req = {
                currentPage: 1,//当前页
                queryTaskType: this.status,//查询类型
                perPageSize: 20 //每页多少条
              };
              this.getData(req)
              console.log('这是全部列表');
            } else {
              let req = {
                currentPage: 1,//当前页
                queryTaskType: this.status,//查询类型
                perPageSize: 20 //每页多少条
              }
              this.getData(req);
            }
          }
        }

      },
      childs(to, old) {
        let self = this;
        this.showDataNull = false;
        this.status = to;
        let req = {
          currentPage: 1,//当前页
          queryTaskType: this.status,//查询类型
          perPageSize: 20 //每页多少条
        }
        this.getData(req);
      }
//      childs(to, form) {
//        let self = this;
//        this.showDataNull = false;
//        this.status = to;
//        let arr = [];
//        if (this.claimData.dataList && this.claimData.dataList.length > 0) {
//          if (to === '09') {
//            window.eventAnalytics('理赔查询', '查看全部-全部');
//            arr = this.claimData.dataList;
//          } else {
//            this.claimData.dataList.forEach(v => {
//              if (v['taskStatus'] === self.status) {
//                if (v['taskStatus'] === '01') {  //取定损的list
//                  window.eventAnalytics('理赔查询', '查看全部-定损');
//                  arr = self.claimData.damageList;
//                } else if (v['taskStatus'] === '04') {
//                  window.eventAnalytics('理赔查询', '查看全部-结案');
//                  arr = self.claimData.closeCaseList;  //取结案的list
//                } else {
//                  arr.push(v)
//                }
//              }
//            })
//          }
//        } else {
//          arr = [];
//        }
//        this.newArr = arr.length > 0 ? arr : this.showDataNull = true;
//      }
    }
  }
</script>

<style lang='less'>
  .listScroll {
    height: 100%;
    /*overflow: auto;*/
    /*-webkit-overflow-scrolling: touch;*/
  }

  .pof_b1 {
    bottom: 0;
  }

  /*.scroll-wrap{*/
  /*width: 100%;*/
  /*height: 100%;*/
  /*overflow: scroll;*/
  /*position: relative;*/
  /*}*/
</style>
