<template>
  <section class="box">
    <div class="titleWrap">
      <a href="javascript:;" otype="button" class="navigation_arrow fl" @click="goBack"></a>
      <div class="entryBox por seachBox">
        <input type="text" :placeholder="placeholder" v-model="searchValue" ref="searchInput"
               @focus="changeSearchPageContent" @blur="blurSearch" @keyup.enter="blurSearch">
        <div class="entryBox_right c clear" v-if="searchValue"
             @click="searchValue='';searchShow=true;searchEventArea=false;BtnShow=true;showFlag=false">
          <img :src="offImg"/>
        </div>
      </div>
    </div>
    <div v-if="searchShow">
      <group>
        <datetime title="开始时间"
                  format="YYYY-MM-DD"
                  v-model="startTime"
                  :start-date="dateTimeOption.startDate"
                  :end-date="dateTimeOption.endDate"
                  @on-change="getTime"
        ></datetime>
        <!--:min-year="dateTimeOption.minYear"
                  :max-year="dateTimeOption.maxYear"-->
        <datetime
          title="结束时间"
          format="YYYY-MM-DD"
          v-model="endTime"
          :start-date="endDateTimeOption.startDate"
          :end-date="endDateTimeOption.endDate"
          @on-change="getTime"
        ></datetime>
      </group>
    </div>
    <div v-if="BtnShow">
      <div class="seachBtn" v-if="searchBtnFlag">
        <a href="javascript:;" title="确认搜索" otitle="确认搜索" otype="button" @click="search">确认搜索</a>
      </div>
      <div class="closeBtn" v-if="!searchBtnFlag">
        <a href="javascript:;" title="确认搜索" otitle="确认搜索" otype="button">确认搜索</a>
      </div>
    </div>
    <div v-if="searchEventArea">
      <div class="loading" v-if="showloading">
        <div class="seachLoading">
          <img :src="loadingImg" class="loadImg"><em>加载中</em>
        </div>
      </div>
      <div class="seachFail" v-if="showSearchNull">
        <img :src="scarchNullImg">
        <p>没有搜到匹配结果，请重试…</p>
      </div>

    </div>
    <!--<pts-scroll-ajax ref="scrollAjaxElem" :topAjax="topAjax &&!showFlag"-->
    <!--:bottomAjax="bottomAjax &&!showFlag"-->
    <!--@on-top-ajax="getFirstPage" @on-bottom-ajax="getNextPage">-->
    <pts-tab-item v-if="showFlag" style="width: 100%;">
      <pts-claim-list :dataSearchList="newList" :dataCount.sync="count" :searchFlag.sync="searchFlag"
                      :startTime="startTime" :endTime="endTime"></pts-claim-list>
    </pts-tab-item>
    <!--</pts-scroll-ajax>-->
  </section>
</template>

<script>
  /*import {Group, Datetime} from 'vux'
  import Toast from '../../common/toast'
  import Axios from '../../../common/js/axiosConfig'
  import {checkVehicleNumOrNo} from '../../../common/js/comUtils'
  import ptsTabs from '../../common/tab'
  import ptsClaimList from './list.vue'
  import API from '../../../common/js/comConfig'*/
  import {Group, Datetime, Cell} from 'vux'
  import ptsScrollAjax from '../../../common/comComponent/scrollAjax'
  import Toast from '../../../common/comComponent/toast'
  import Axios from '../../../common/js/axiosConfig'
  import {checkVehicleNumOrNo, days} from '../../../common/js/comUtils'
  import ptsTabs from '../../../common/comComponent/tab'
  import ptsClaimList from './list.vue'
  import API from '../../../common/js/comConfig'

  export default {
    name: "claimSearch",
    data() {
      return {
//        topAjax: true,
//        bottomAjax: false,
        page: 1,
        startTime: '',
        endTime: '',
        dateTimeOption: {
          startDate: '',
          endDate: ''
        },
        endDateTimeOption: {
          startDate: '',
          endDate: ''
        },
        offImg: require('../../../common/images/clase.png'),
        loadingImg: require('../../../common/images/loading.png'),
        scarchNullImg: require('../../../common/images/failIcon.png'),
        searchValue: '',
        carMark: '',
        showsearchArea: true,
        showloading: true,
        showSearchNull: false,
        placeholder: '请输入搜索的内容（案件号、车牌)',
        orderList: false,
        taskList: false,
        toastMsg: '',
        searchEventArea: false,
        searchBtnFlag: false,
        searchShow: true,
        BtnShow: true,
        newList: [],
        count: 0,
        showFlag: false,
        searchFlag: false,
      }
    },
    methods: {
      goBack() {
        window.history.go(-1)
      },
//      getFirstPage() {
//          this.page =1;
//          this.search();
//      },
//      getNextPage() {
//        console.log('下拉加载')
//        this.page++;
//        this.search();
//      },
      getTime() {
        this.endDateTimeOption.startDate = this.startTime;
        if (new Date(this.startTime) > new Date(this.endTime)) {
          toast('开始时间不能晚于结束时间')
          return false
        }
        return true
//        window.eventAnalytics('理赔查询','点击了理赔查询选择日期');
//        if (new Date(this.startTime) > new Date(this.endTime)) {
//          Toast('开始时间不能晚于结束时间')
//          return false
//        } else if (this.startTime !== '' && this.endTime === '') {
//          Toast('结束时间不能为空')
//          return false;
//        } else if (this.startTime === '' && this.endTime !== '') {
//          Toast('开始时间不能为空')
//          return false;
//        }
//        return true
      },
      /*
       * @info input框失去焦点时 触发 目前仅在订单列表进入时显示
       * */
      blurSearch() {
        if (!this.orderList) {
          return
        }
        this.searchValue = this.searchValue.replace(/\s/g, '');
        this.$refs.searchInput.blur()

        //this.search()
      },
      /*
       * @info 搜索函数, 让显示内容的区域显示, 此时用户输入的值通过组件的 searchCondition props 传入组件内 然后让组件自己发出ajax请求请求数据,
       * */
      search() {
        window.eventAnalytics('理赔查询', '点击了确定搜索按钮');
        let self = this;
        if (!this.getTime()) {
          return false
        }
        let isCarMark = checkVehicleNumOrNo(this.searchValue) ? this.searchValue : '';
        let reprotNo = checkVehicleNumOrNo(this.searchValue) ? '' : this.searchValue;
        let reqData = {
          carMark: isCarMark || "",
          reportNo: reprotNo || "",
          reportStartDate: this.startTime || "",
          reportEndDate: this.endTime || "",
          currentPage: this.page,//当前页
          perPageSize: 20
        }
        // API.getWebServiceUrls('settlementList')'http://localhost:8888/index?id=claimList&path=car&dateFrom=20171030'
        Axios.post(API.getWebServiceUrls('settlementList'), reqData).then(res => {
          let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (data.code === 0 && data.data.claimsReturnList) {
            self.searchEventArea = false;
            self.newList = data.data.claimsReturnList;
            self.count = data.data.totalNum;
            if (self.startTime && self.endTime) {
                self.searchFlag =  true;
            }else {
                self.searchFlag =  false;
            }
//            if(this.page*20>self.count){
//              self.bottomAjax = false;
//            }else{
//              self.bottomAjax = true;
//            }
            if (self.newList && self.newList.length > 0) {
//              self.searchFlag = false;
              self.topAjax = true;
              self.showFlag = true;
              self.searchShow = false;
              self.BtnShow = false;
              self.searchEventArea = false;
            } else {
              self.topAjax = false;
              self.bottomAjax = false;
              self.showFlag = false;
              self.searchShow = false;
              self.BtnShow = false;
              self.searchEventArea = true;
              self.showloading = false;
              self.showSearchNull = true;
            }

          } else {
            self.BtnShow = false;
            self.searchShow = false;
            self.searchEventArea = true;
            self.showloading = false;
            self.showSearchNull = true;
          }
          this.$nextTick(function () {
            this.$refs.scrollAjaxElem && this.$refs.scrollAjaxElem.reset(true)
          })
          return;
        }).catch(err => {
          console.log(err)
        })
//        this.searchEventArea = true
//        this.showsearchArea = false
//        this.$nextTick(function () {
//          this.showSearchNull = false
//          this.showloading = true
//        })
      },
      changeSearchPageContent() {
        window.eventAnalytics('理赔查询', '点击了理赔查询精确搜索');
        this.BtnShow = true;
        this.searchBtnFlag = false;
        if (this.searchValue !== '') {
          this.searchBtnFlag = true;
        }
        if (this.startTime !== '' || this.endTime !== '') {
          this.BtnShow = true;
          this.searchBtnFlag = true;
        }
        this.showsearchArea = true;
        this.searchEventArea = false;
        this.searchShow = true;
        this.showFlag = false;

      },
      init() {
        const _this = this
        this.orderList = false
        this.taskList = false
        this.searchValue = ''
        this.searchEventArea = false
        const obj = {
          claimList() {
            _this.orderList = true
            _this.placeholder = '请输入搜索的内容（案件号、车牌)'
            _this.toastMsg = '请输入案件号/车牌'
          },
        }
        obj[this.$route.query.flag]()
        this.$nextTick(function () {
          console.log('input框获取焦点')
          //this.$refs.searchInput.focus()
        })
      }
    },
    watch: {
      searchValue(to, from) {
        if (this.searchValue !== '') {
          //console.log(this.searchValue);
          this.startTime = '';
          this.endTime = '';
          this.searchValue = to.trim();
          this.BtnShow = true;
          this.searchBtnFlag = true;
          this.searchShow = false;
        } else {
          this.searchBtnFlag = false;
          this.searchShow = true;
        }
      },
      startTime(to, from) {
        if (this.startTime !== '') {
          this.searchBtnFlag = true
        } else if (this.searchValue === '') {
          this.searchBtnFlag = false;
        }
      },
      endTime(to, from) {
        if (this.endTime !== '') {
          this.searchBtnFlag = true
        } else if (this.searchValue === '') {
          this.searchBtnFlag = false;
        }
      }
    },
    mounted() {
      window.eventAnalytics("外部端理赔查询",'进入' + this.titleText + '搜索页面');
      this.init();
      const dateObj = new Date()
      const endYear = dateObj.getFullYear()
      const endMonth = dateObj.getMonth() + 1
      const endDate = dateObj.getDate()
      const today = `${endYear}-${endMonth >= 10 ? endMonth : '0' + endMonth}-${endDate >= 10 ? endDate : '0' + endDate}`
      // const endDay       =`${endYear}-${endMonth >= 10 ? endMonth : '0' + endMonth}-${endDate >= 10 ? endDate : '0' + endDate}`
      const startDateObj = new Date()
      startDateObj.setMonth(endMonth - 1) // 显示近六个月的搜索范围
      const startYear = startDateObj.getFullYear()
      const startMonth = startDateObj.getMonth() // 上面的endMonth已经加一 不需要再加一
      this.dateTimeOption.startDate = this.endDateTimeOption.startDate = `${startYear}-${startMonth >= 10 ? startMonth : '0' + startMonth}-01`
      this.dateTimeOption.endDate = this.endDateTimeOption.endDate = today
      this.$nextTick(function () {
        this.startTime = this.endTime = today;
      })
    },
    components: {
      Group,
      Datetime,
      ptsTabItem: ptsTabs.Item,
      ptsClaimList,
      ptsScrollAjax
    },
    beforeRouteLeave(to, from, next) {
      if (to.path === '/claimList') {
        this.$destroy()
      }
      next()
    }
  }
</script>

<style lang="less">
  .loadImg {
    animation: loading 2s linear infinite;
  }

  .closeBtn a {
    margin-left: 0.3rem;
    margin-top: 0.6rem;
    display: block;
    background-color: #d4cfcc;
    box-shadow: 0 0.02rem 0.11rem 0 rgba(222, 222, 222, 0.50);
    border-radius: 0.04rem;
    width: 6.9rem;
    height: .9rem;
    line-height: .9rem;
    font-size: .32rem;
    color: #fff;
    text-align: center;
  }

  @keyframes loading {
    form {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
</style>
