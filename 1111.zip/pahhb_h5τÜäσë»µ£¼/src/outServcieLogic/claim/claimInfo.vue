<template>
  <div class="wrap box">
    <pts-header :titleText="titleText"></pts-header>
    <!-- main start -->
    <div class="fixRateArea po_ab">
      <ul class="c">
        <li :class="taskStatus==='00'?'nowSate':(stateArr[0]?'lineRate pastRate':'')"><i></i>报案</li>
        <li :class="taskStatus==='01'?'nowSate':(stateArr[1]?'lineRate pastRate':'')"><i></i>定损</li>
        <li :class="taskStatus==='02'?'nowSate':(stateArr[2]?'lineRate pastRate':'')"><i></i>理算</li>
        <li :class="taskStatus==='03'?'nowSate':(stateArr[3]?'lineRate pastRate':'')"><i></i>已结案</li>
      </ul>
    </div>
    <div class="mainWrap pb30" style="margin-top: 1.35rem;" v-if="resData.reportName">
      <div>
        <div class="taskArea reportMsgArea">
          <dl>
            <dt>报案人信息</dt>
          </dl>
          <div class="taskBox">
            <dl>
              <dt>报案人</dt>
              <dd>{{resData.reportName || ''}}</dd>
            </dl>
            <dl>
              <dt>案件号</dt>
              <dd>{{resData.reportNo | fourSpace}}</dd>
            </dl>
            <dl>
              <dt>报案时间</dt>
              <dd>{{resData.reportDate ||''}}</dd>
            </dl>
          </div>
        </div>
        <div class="taskArea detailArea">
          <dl>
            <dt>案件信息</dt>
          </dl>
          <div class="taskBox">
            <dl>
              <dt>车牌</dt>
              <dd>{{resData.carMark ||''}}</dd>
            </dl>
            <dl>
              <dt>车型</dt>
              <dd>{{resData.carTypeName || '*_*'}}</dd>
            </dl>
            <!--<dl>-->
            <!--<dt>推修类型</dt>-->
            <!--<dd>不知道字段</dd>-->
            <!--</dl>-->
            <!-- <dl>
              <dt style="width:2.0rem;font-size:0.24rem;text-align:left;">预估损失金额</dt>
              <dd style="width:2.4rem;margin-left:-0.6rem;" class="f_c_fe883a">¥{{resData.estimateAmount | NumberThere}}</dd>
            </dl> -->
            <!--<dl>-->
              <!--<dt>出险时间</dt>-->
              <!--<dd>{{resData.accidentDate ||''}}</dd>-->
            <!--</dl>-->
            <!--<dl>-->
              <!--<dt>出险地点</dt>-->
              <!--<dd class="moreRow">{{resData.accidentPlace ||''}}</dd>-->
            <!--</dl>-->
            <dl v-if="policyDutyDataList.length>0">
              <dt>承保险别</dt>
              <!--<dd class="moreRow">{{policyDutyDataList[0].dutyName}}</dd>-->
              <dd v-for="(item,index) in resData.policyDutyDataList" v-if="index>2?false:true" :class="index===0?'moreRow':'marginLeft'">
                {{item.dutyName}}
              </dd>
              <dd class="moreRow" style="margin-left: 1.75rem;">
                <a href="javascript:;" otype="button" otitle="点击查看详情" class="checkDetail" @click.prent.stop="showDetails">点击查看详情</a>
              </dd>
            </dl>
            <!--<dl>-->
              <!--<dt>出险经过</dt>-->
              <!--<dd class="moreRow">{{resData.accidentDetail}}</dd>-->
            <!--</dl>-->
          </div>
        </div>
        <div class="taskArea detailArea">
          <dl>
            <dt>查勘信息</dt>
          </dl>
          <div class="taskBox">
            <dl>
              <dt>查勘人</dt>
              <dd>{{resData.surveyorName || ''}}</dd>
            </dl>
            <dl>
              <dt>查勘电话</dt>
              <dd><a href="#" otype="button" otitle="152-7441-1235" @click="callTel(resData.surveyorMobile)">{{resData.surveyorMobile | phoneType}}</a></dd>
            </dl>
            <!-- <dl>
              <dt>责任系数</dt>
              <dd>{{resData.dutyCoefficient}}%</dd>
            </dl> -->
            <!-- <dl>
                 <dt>赔付结论</dt>
                 <dd>{{resData.indemnityConclusion|indemnityConclusionType}}</dd>
               </dl>-->
          </div>
        </div>
        <div class="taskArea detailArea">
          <dl>
            <dt>定损信息</dt>
          </dl>
          <div class="taskBox msgSpBox">
            <dl>
              <dt>定损员</dt>
              <dd>{{resData.assessUmName}}</dd>
            </dl>
            <dl>
              <dt>定损电话</dt>
              <dd><a href="#" otype="button" otitle="152-7441-1235" @click="callTel(resData.assessUmMobile)">{{resData.assessUmMobile | phoneType}}</a></dd>
            </dl>
            <dl>
              <dt>定损时间</dt>
              <dd>{{resData.lossConfirmCompleteTime}}</dd>
            </dl>
            <!--<dl>
                <dt>复勘任务状态</dt>
                <dd>{{resData.resurveyStatus|surveyorStatusType}}</dd>
              </dl>-->
            <!-- <dl>
                 <dt>案件状态</dt>
                 <dd>{{resData.caseStatus|caseStatusType}}</dd>
               </dl>-->
            <dl class="bor_b pb20">
              <dt>定损总额</dt>
              <dd class="f_c_fe883a">¥{{resData.totalAgreedAmount | NumberThere}}</dd>
            </dl>
            <!--  <div class="withBorAggra" v-if="resData.materialList">
                  <dl>
                    <dt>定损配件列表</dt>
                    <dd>合计：¥{{lossTotalAmount|NumberThere}}</dd>
                  </dl>
                  <dl v-if="materialList.length>0" v-for="item in materialList">
                    <dt>{{item.lossName}}</dt>
                    <dd>¥{{item.lossAmount|NumberThere}}</dd>
                  </dl>
                </div>-->
            <!--<div class="withBorAggra" v-if="manpowerList">
                <dl>
                  <dt>定损工时列表</dt>
                  <dd>合计：¥{{manpowerTotalAmount|NumberThere}}</dd>
                </dl>
                <dl v-if="manpowerList.length>0" v-for="item in manpowerList">
                  <dt>{{item.lossName}}</dt>
                  <dd>¥{{item.lossAmount|NumberThere}}</dd>
                </dl>
              </div>
              <div class="withBorAggra" v-if="outerRepairDetailList">
                <dl>
                  <dt>定损外修列表</dt>
                </dl>
                <dl v-if="outerRepairDetailList.length>0" v-for="(item,index) in outerRepairDetailList" :key="item.id">
                  <dt>{{item.lossName}}</dt>
                  <dd>{{item.lossAmount|NumberThere}}</dd>
                </dl>
              </div>-->
          </div>
        </div>
        <div class="taskArea detailArea" v-if="resData.paymentInfoList">
          <dl>
            <dt>支付信息</dt>
          </dl>
          <div class="taskBox" v-for="item in resData.paymentInfoList">
            <dl>
              <dt>支付时间</dt>
              <dd>{{item.payDate}}</dd>
            </dl>
            <dl>
              <dt>支付对象</dt>
              <dd>{{item.clientName}}</dd>
            </dl>
            <dl>
              <dt>支付金额</dt>
              <dd class="f_c_fe883a">¥{{item.payAmount | NumberThere}}</dd>
            </dl>
            <dl>
              <dt>支付状态</dt>
              <dd>{{item.payStatus | payStatusType}}</dd>
            </dl>
            <dl>
              <dt>备注</dt>
              <dd>{{item.remark}}</dd>
            </dl>
          </div>
        </div>
      </div>
      <pts-alert v-model="showInsureMsg">
        <div class="reMaskArea">
          <h3>承保险别详情</h3>
          <table border="0" cellspacing="0" cellpadding="0" width="100%">
            <thead style="display: block">
              <tr style="display:block; width: 100%;">
                <td style="display: inline-block; width: 62%;">
                  <p>承保险别</p>
                </td>
                <td style="display: inline-block; width:36%;">
                  <p style="color: #666;">保额（元）</p>
                </td>
              </tr>
            </thead>
            <tbody style="display:block;max-height: 5rem; overflow: auto; width: 100%;">
              <tr style="display:table; width: 6.01rem;" v-if="policyDutyDataList" v-for="item in policyDutyDataList">
                <td width="64%">
                  <p>{{item.dutyName}}</p>
                </td>
                <td width="36%">
                  <p>¥{{item.payLimit | NumberThere}}</p>
                </td>
              </tr>
            </tbody>
          </table>
          <a href="javascript:;" otype="button" otitle="我知道了" class="sendUp saveBtn" @click.prevent="showInsureMsg = false">我知道了</a>
        </div>
      </pts-alert>
    </div>
  </div>
</template>

<script>
  import Axios from "../../common/js/axiosConfig";
  import API from "../../common/js/comConfig";
  import Toast from "../../common/comComponent/toast/index";
  import ptsAlert from "../../common/comComponent/alertWindow";
  import {
    fourSpace,
    NumberThere
  } from "../../common/filters/convertAmount";
  import {
    indemnityConclusionType,
    surveyorStatusType,
    caseStatusType,
    payStatusType
  } from "../../common/filters/convertIdType";

  export default {
    name: "claimInfo",
    data() {
      return {
        titleText: "案件详情",
        showInsureMsg: false,
        resData: {},
        manpowerTotalAmount: 0, //定损工时总金额
        lossTotalAmount: 0, //定损配件列表总金额
        taskStatus: "",
        flag: false,
        stateArr: [false, false, false, false, false, false],
        num: 0,
        manpowerList: [], //定损工时列表
        materialList: [], //定损配件列表
        outerRepairDetailList: [], //定损外修列表
        policyDutyDataList: [] //承保险别列表
      };
    },
    watch: {
      taskStatus(to, form) {
        console.log("to=" + to);
      }
    },
    created() {
      let self = this;
      let carMark = this.$route.query.carMark;
      let carRackNo = this.$route.query.carRackNo;
      let reportNo = this.$route.query.reportNo;
      let status = (this.taskStatus = this.$route.query.taskStatus);
      if (status === "02" || status === "03") {
        for (let n = 0; n < ~~status + 1; n++) {
          self.stateArr[n] = true;
        }
      } else {
        for (let n = 0; n < ~~status; n++) {
          self.stateArr[n] = true;
        }
      }
      let reqData = {
        carMark: carMark,
        carRackNo: carRackNo,
        reportNo: reportNo
      };
      //'http://localhost:8888/index?id=claimInfo&path=car&dateFrom=20171030'API.getWebServiceUrls('settlementDetail')
      Axios.post(API.getWebServiceUrls("settlementDetail"), reqData)
        .then(res => {
          let self = this;
          let dataInfo =
            typeof res.data === "string" ? JSON.parse(res.data) : res.data;
          if (dataInfo.code === 0 || dataInfo.code === "0") {
            self.resData = dataInfo.data;
            self.policyDutyDataList = dataInfo.data.policyDutyDataList || [];
            //materialAndManpowerAndOuterRepair
            //定损工时总金额   materialList 定损配件列表  manpowerList 定损工时列表 outerRepairDetailList 定损外修列表
            /*self.manpowerList = dataInfo.data.materialAndManpowerAndOuterRepair.manpowerList;// 定损工时List
            if(self.manpowerList && self.manpowerList.length>0){
              self.manpowerList.forEach(v=>{
                   self.manpowerTotalAmount += ~~v.lossAmount;
                 })
            }*/
            /*    //定损配件列表总金
             self.materialList = dataInfo.data.materialAndManpowerAndOuterRepair.materialList;// 定损配件List
             if(self.materialList && self.materialList.length>0) {
               self.materialList.forEach(v => {
                   self.lossTotalAmount += ~~v.lossAmount;
                 })
             }*/
            //定损外修List
            //self.outerRepairDetailList = dataInfo.data.materialAndManpowerAndOuterRepair.outerRepairDetailList;
            //console.log(self.resData);
          } else {
            Toast(dataInfo.msg || "出错了,请稍后重试!");
          }
        })
        .catch(err => {
          //Toast('出错了,请稍后重试!');
          console.log(err);
        });
    },
    methods: {
      showDetails() {
        this.showInsureMsg = true;
      },
      callTel(tel) {
        //      tel:resData.assessUmMobile
        window.location.href = "tel:" + tel;
      }
    },
    components: {
      ptsAlert
    }
  };
</script>

<style lang='less'>
  .marginLeft {
    margin-left: 1.75rem;
  }

  .po_ab {
    position: absolute;
    z-index: 1;
  }

  .reportMsgArea>dl dt,
  .detailArea>dl dt {
    width: 2rem;
    text-align: left;
    color: #000;
  }
</style>
