<template>
  <section class="box" style="overflow-x: hidden;">
    <pts-header titleText="客户流向" :showRight="showHeaderRight" leftFlag @on-left="goMenu">
      <a href="javascript:;" slot="right" class="poa dataHeard_right hidden"
         @click.prevent.stop="showChooseCity = true">{{cityMsg.cityName}}</a>
    </pts-header>
    <div class="pageTab bgwhite">
      <ul class="tdDate c clear">
        <li :class="{'on':activeDate ==='day'}" @click.prevent="changeTab('day')">日</li>
        <li :class="{'on':activeDate ==='month'&&!showDateTime, 'active': showDateTime}"
            @click.prevent="changeTab('month')">
          <p v-if="monthValue === 'D'">月<i></i></p>
          <p v-else>{{monthValue | chineseMonth}}月<i></i></p>
        </li>
      </ul>
      <p class="dateTime">{{dataTime}}</p>
      <ul class="chartList">
        <li>
          <p class="dateTime_title mt10">推修量:<span>{{sumCity | NumberThere}}台</span></p>
          <div class="pillarChart">
            <pts-flow-bar ref="ptsBar" :options="barOption"></pts-flow-bar>
          </div>
        </li>
        <li v-if="activeDate ==='month'">
          <p class="dateTime_title">维修数据走势</p>
          <div class="pillarChart">
            <pts-flow-line ref="ptsLine" :options="lineOption"></pts-flow-line>
          </div>
        </li>
      </ul>
    </div>
    <pts-choose-city :show="showChooseCity" @on-hide="onHide"></pts-choose-city>
  </section>
</template>

<script>
  import ptsFlowBar from '../../../common/comComponent/echarts/bar.vue'
  import ptsFlowLine from '../../../common/comComponent/echarts/line.vue'
  import ptsChooseCity from '../../../common/comComponent/linkageMenu';
  import {remInPx, loadEcharts} from '../../../common/js/comUtils'
  import axios from '../../../common/js/axiosConfig'
  import url from '../../../common/js/comConfig'
  import toast from '../../../common/comComponent/toast'
  import '../../../common/filters/convertDate'
  import '../../../common/filters/convertAmount'
  let date = new Date()
  let year = date.getFullYear()
  const flowBarColors = ['#FE883A', '#FFDB4B', '#5284FF', '#5FE8A4', '#8452F7', '#FE6D6D']
  export default {
    name: "pushDataFlow",
    data () {
      return {
        activeDate: 'day', // 当前选中的tab
        barOption: {
          legend: {
            data: ['成功到店', '本品牌其他4s店', '非本品牌其他4s店', '合作总修厂', '非合作厂', '零注拒']
          },
          color: ['#FE883A', '#FFDB4B', '#5284FF', '#5FE8A4', '#8452F7', '#FE6D6D'],
          grid: {
            left: '0%',
            right: '0%',
            top: '8%',
            bottom: '15%',
            containLabel: true
          },
          xAxis: {
            show: false,
            type: 'category',
            splitNumber: 1,
            data: ['数据总览']
          },
          yAxis: {
            type: 'value',
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed',
                color: '#eee'
              }
            },
            axisLine: {
              show: false
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              color: '#999999',
              fontSize: remInPx(0.26)
            }
          },
          series: [
            {
              name: '成功到店',
              type: 'bar',
              label: {
                normal: {
                  show: true,
                  position: 'top',
                  textStyle: {
                    color: '#666666'
                  }
                }
              },
              itemStyle: {
                normal: {
                  color: flowBarColors[0]
                },
                emphasis: {
                  color: flowBarColors[0]
                }
              },
              data: []
            },
            {
              name: '本品牌其他4s店',
              type: 'bar',
              label: {
                normal: {
                  show: true,
                  position: 'top',
                  textStyle: {
                    color: '#666666'
                  }
                }
              },
              itemStyle: {
                normal: {
                  color: flowBarColors[1]
                },
                emphasis: {
                  color: flowBarColors[1]
                }
              },
              data: []
            },
            {
              name: '非本品牌其他4s店',
              type: 'bar',
              label: {
                normal: {
                  show: true,
                  position: 'top',
                  textStyle: {
                    color: '#666666'
                  }
                }
              },
              itemStyle: {
                normal: {
                  color: flowBarColors[2]
                },
                emphasis: {
                  color: flowBarColors[2]
                }
              },
              data: []
            },
            {
              name: '合作总修厂',
              type: 'bar',
              label: {
                normal: {
                  show: true,
                  position: 'top',
                  textStyle: {
                    color: '#666666'
                  }
                }
              },
              itemStyle: {
                normal: {
                  color: flowBarColors[3]
                },
                emphasis: {
                  color: flowBarColors[3]
                }
              },
              data: []
            },
            {
              name: '非合作厂',
              type: 'bar',
              label: {
                normal: {
                  show: true,
                  position: 'top',
                  textStyle: {
                    color: '#666666'
                  }
                }
              },
              itemStyle: {
                normal: {
                  color: flowBarColors[4]
                },
                emphasis: {
                  color: flowBarColors[4]
                }
              },
              data: []
            },
            {
              name: '零注拒',
              type: 'bar',
              label: {
                normal: {
                  show: true,
                  position: 'top',
                  textStyle: {
                    color: '#666666'
                  }
                }
              },
              itemStyle: {
                normal: {
                  color: flowBarColors[5]
                },
                emphasis: {
                  color: flowBarColors[5]
                }
              },
              data: []
            }
          ]
        }, // 柱状图的设置项
        lineOption: {
          /* 这里配置 在common 的line.vue中已配置*/
          /*title: [
           {
           text: '',
           textStyle: {
           fontSize: remInPx(0.25),
           fontWeight: 'normal',
           color: '#666666'
           },
           top: '70%',
           left: '5%'
           },
           {
           text: '',
           textStyle: {
           fontSize: remInPx(0.25),
           fontWeight: 'normal',
           color: '#666666'
           },
           top: '70%',
           left: 'right'
           }
           ],
           tooltip: {
           trigger: 'axis',
           axisPointer: {
           animation: false,
           lineStyle: {
           color: '#FE8F46'
           }
           },
           backgroundColor: '#FFE0CB',
           textStyle: {
           color: '#FF954E'
           }
           },*/
          title: [
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.25),
                fontWeight: 'normal',
                color: '#666666'
              },
              top: '75%',
              left: '4%'
            },
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.25),
                fontWeight: 'normal',
                color: '#666666'
              },
              top: '75%',
              left: 'right'
            }
          ],
          color: ['#FE883A', '#FFDB4B', '#5284FF', '#5FE8A4', '#8452F7', '#FE6D6D'],
          legend: {
            data: ['成功到店', '本品牌其他4s店', '非本品牌其他4s店', '合作总修厂', '非合作厂', '零注拒'],
            itemGap: 10
          },
          grid: {
            bottom: '23%'
          },
          /*legend: {
           data: ['成功到店', '本品牌其他4s店', '非本品牌其他4s店', '合作总修厂', '非合作厂', '零注拒'],
           /!*textStyle: {
           fontSize: remInPx(0.22)
           },
           bottom: 0,
           itemWidth: remInPx(0.1),
           itemHeight: remInPx(0.1)*!/
           },
           grid: {
           left: '0%',
           right: '2%',
           top: '3%',
           bottom: '20%',
           containLabel: true
           },
           xAxis: {
           show: false,
           type: 'category',
           splitNumber: 1,
           data: [],
           boundaryGap: false,
           axisLine: {
           show: false
           },
           axisTick: {
           show: false
           },
           axisLabel: {
           color: '#999999',
           fontSize: remInPx(0.26)
           }
           },
           yAxis: {
           type: 'value',
           splitLine: {
           show: true,
           lineStyle: {
           type: 'dashed'
           }
           },
           axisLine: {
           show: false
           },
           axisTick: {
           show: false
           },
           axisLabel: {
           color: '#999999',
           fontSize: remInPx(0.26)
           }
           },*/
          series: [
            {
              name: '成功到店',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            }, {
              name: '本品牌其他4s店',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            }, {
              name: '非本品牌其他4s店',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            }, {
              name: '合作总修厂',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            }, {
              name: '非合作厂',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            }, {
              name: '零注拒',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            }
          ]
        }, // 折线图的设置项
        monthValue: 'D', // 当月还是当日的区分
        dataTime: '', // 查询数据的时间 来自于后台
        activeMonth: '',
        showChooseCity: false,
        cityMsg: {
          cityName: '大集团',
          cityCode: '',
          provicesCode: '',
          dealerCode: ''
        },
        showHeaderRight: false,
        sumCity: 0, // 总推修量
        showDateTime: false
      }
    },
    mounted () {
      const dealerData = window.dealerData;
      this.showHeaderRight = (~~dealerData.dealerType) === 1;
      this.cityMsg.provicesCode = undefined;
      this.cityMsg.cityName = dealerData.dealerName;
      this.activeMonth = `${year}-${(date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1)}`
      this.getData('A')
    },
    components: {
      ptsFlowBar,
      ptsFlowLine,
      ptsChooseCity
    },
    methods: {
      goMenu () {
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      /*
       * @info 切换选项卡函数
       * @param type {string} day 与 month 当日与当月
       * */
      changeTab (type) {
        const _this = this
        if (type === 'day' && this.activeDate === type) {
          return
        }
        let month = (type === 'month' ? (this.monthValue === 'D' ? (new Date().getMonth() + 1) : this.monthValue) : 0);
        if (this.activeDate === 'month' && type === 'month') {
          this.$vux.datetime.show({
            value: this.activeMonth,
            cancelText: '取消',
            confirmText: '确定',
            format: 'YYYY-MM',
            minYear: year,
            maxYear: year,
            startDate: `${year}-01-01`,
            endDate: `${year}-${date.getMonth() + 1 > 0 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1}-01`,
            onConfirm: (a) => {
              if (this.activeMonth === a) return;
              this.activeMonth = a;
              month = a.substr(a.indexOf('-') + 1);
              this.monthValue = month;
              this.getData('B', month);
            },
            onShow: () => {
              this.showDateTime = true;
            },
            onHide: () => {
              this.showDateTime = false;
            }
          })
          return
        }
        this.activeDate = type
        month > 0 ? this.getData('B', month) : this.getData('A')
      },
      /*
       * @info 发起ajax请求 并设置图标数据的函数
       * @param type {String} 当月(B) or 当日(A)
       * @param month {String || Number} 用户选择的月份
       * */
      getData (type, month) {
        const _this = this;
        this.initEcharts();
        let flagText = type === 'A' ? '当日' : month ? month + '月' : '当月';
        window.eventAnalytics('客户流向', '查看' + flagText + '数据');
        /*axios.get(url.getWebServiceUrls('pageData'), {
         params: {
         path: 'car',
         file: 'flow',
         timeout: 1,
         queryType: type
         }
         })*/
        axios.post(url.getWebServiceUrls('flowDirectionAnalysis'), {
          monthDate: month ? month + '' : undefined,
          queryType: type,
          city: _this.cityMsg.cityCode || undefined,
          dealerCode: _this.cityMsg.dealerCode || undefined,
          provice: _this.cityMsg.provicesCode || undefined
        }).then(res => {
//          console.log(res)
          let data = res.data
          switch (data.code) {
            case 0:
//              console.log(data.data)
              _this.dataTime = data.data.flowDirectionAnalysisResult.sysTimes
              _this.$nextTick(function () {
                _this.$refs.ptsBar.setData(function (echart) {
                  // ['成功到店', '本品牌其他4s店', '非本品牌其他4s店', '合作总修厂', '非合作厂', '零注拒']
                  let flowDatas = data.data.flowDirectionAnalysisResult;
                  _this.sumCity = flowDatas.sumRepairSuccess + flowDatas.sumBrandOtherFourS + flowDatas.sumUnBrandOtherFourS + flowDatas.sumCooperativeRepairYard + flowDatas.sumNoCooperativeField + flowDatas.sumZeroInjectionRejection;
                  let datas = [
                    {data: [flowDatas.sumRepairSuccess]},
                    {data: [flowDatas.sumBrandOtherFourS]},
                    {data: [flowDatas.sumUnBrandOtherFourS]},
                    {data: [flowDatas.sumCooperativeRepairYard]},
                    {data: [flowDatas.sumNoCooperativeField]},
                    {data: [flowDatas.sumZeroInjectionRejection]}
                  ];
                  let ass = [flowDatas.sumRepairSuccess, flowDatas.sumBrandOtherFourS, flowDatas.sumUnBrandOtherFourS, flowDatas.sumCooperativeRepairYard, flowDatas.sumNoCooperativeField, flowDatas.sumZeroInjectionRejection];
                  let max = Math.max.apply(Math, ass);
                  echart.setOption({
                    yAxis: {
                      minInterval: Math.ceil(max / 4)
                    },
                    series: datas
                  })
                })
                if (month) {
                  let repairSuccess = [], // 成功到店
                    brandOtherFourS = [], // 本品牌其他4S店
                    unBrandOtherFourS = [], // 非本品牌其他4S店
                    cooperativeRepairYard = [], // 合作总修长
                    noCooperativeField = [], // 非合作厂
                    zeroInjectionRejection = []; // 零注拒
                  data.data.flowDirectionAnalysisResult.flowDirectionAnalysis.forEach(v => {
                    repairSuccess.push(v.repairSuccess)
                    brandOtherFourS.push(v.brandOtherFourS)
                    unBrandOtherFourS.push(v.unBrandOtherFourS)
                    cooperativeRepairYard.push(v.cooperativeRepairYard)
                    noCooperativeField.push(v.noCooperativeField)
                    zeroInjectionRejection.push(v.zeroInjectionRejection)
                  })
                  _this.$refs.ptsLine.setData(function (echarts) {
                    let showSymbol = repairSuccess.length < 2
                    let arr = [
                      {
                        showSymbol: showSymbol,
                        data: repairSuccess
                      },
                      {
                        showSymbol: showSymbol,
                        data: brandOtherFourS
                      },
                      {
                        showSymbol: showSymbol,
                        data: unBrandOtherFourS
                      },
                      {
                        showSymbol: showSymbol,
                        data: cooperativeRepairYard
                      },
                      {
                        showSymbol: showSymbol,
                        data: noCooperativeField
                      },
                      {
                        showSymbol: showSymbol,
                        data: zeroInjectionRejection
                      }
                    ];
                    let date = data.data.flowDirectionAnalysisResult.yearAndMonth;
//                    let xStart = date.substr(5, date.length);
                    let xdatas = _this.xDatas(date, repairSuccess.length);
                    let ass = Array.prototype.concat.call([], repairSuccess, brandOtherFourS, unBrandOtherFourS, cooperativeRepairYard, noCooperativeField, zeroInjectionRejection);
                    let max = Math.max.apply(Math, ass);
                    ass = null; // 内存回收
                    echarts.setOption({
                      title: [
                        {
                          text: `01` // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                        },
                        {
                          text: `${xdatas.length > 9 ? xdatas.length : '0' + xdatas.length}` // ${~~xStart > 9 ? xStart : '0' + xStart}.${xdatas.length > 9 ? xdatas.length : '0' + xdatas.length}
                        }
                      ],
                      xAxis: {
                        data: xdatas
                      },
                      yAxis: {
                        minInterval: Math.ceil(max / 4)
                      },
                      series: arr
                    })
                  })
                }
              })
              break
            default:
              toast(data.msg)
              break
          }
        }).catch(err => {
          console.log(err)
        })
      },
      /*
       * @info 生成 x 轴数据 YYYY-MM-DD格式
       * @param month {number, string} MM的值
       * @param day {number} 一共生成多少天
       * @return array 值类型是YYYY-MM-DD格式 的数组
       * */
      xDatas (month, day) {
        let arr = []
        for (let i = 1; i <= day; i++) {
          arr.push(`${month}-${i < 10 ? '0' + i : i}`)
        }
        return arr
      },
      /* chooseCity隐藏执行的操作 */
      onHide (closeFlag, msg) {
        this.showChooseCity = false;
        if (!msg) {
          return
        }
        const name = `${msg.provicesName}${msg.cityName}${msg.dealerName}`.replace('暂不选择', '');
        if (this.cityMsg.cityName === name) return;
        this.cityMsg.cityName = name;
        this.cityMsg.cityCode = name === '全国' ? undefined : msg.cityCode;
        this.cityMsg.provicesCode = name === '全国' ? undefined : msg.provicesCode;
        this.cityMsg.dealerCode = name === '全国' ? undefined : msg.dealerCode;
        const type = this.activeDate === 'day';
        const monthValue = this.monthValue === 'D' ? new Date().getMonth() + 1 : this.monthValue
        const month = type ? undefined : monthValue;
        this.getData(type ? 'A' : 'B', month);
      },
      initEcharts () {
        this.$nextTick(function () {
          this.$refs.ptsBar.setData((echart) => {
            // ['成功到店', '本品牌其他4s店', '非本品牌其他4s店', '合作总修厂', '非合作厂', '零注拒']
            this.sumCity = 0;
            let datas = [
              {data: [0]},
              {data: [0]},
              {data: [0]},
              {data: [0]},
              {data: [0]},
              {data: [0]}
            ]
            echart.setOption({
              series: datas
            })
          })
          this.$refs.ptsLine && this.$refs.ptsLine.setData(function (echarts) {
            let arr = [
              {
                data: []
              },
              {
                data: []
              },
              {
                data: []
              },
              {
                data: []
              },
              {
                data: []
              },
              {
                data: []
              }
            ]
            echarts.setOption({
              xAxis: {
                data: []
              },
              series: arr
            })
          })
        })
      }
    },
    beforeRouteEnter (to, from, next) {
      loadEcharts(next);
    }
  }
</script>

<style lang="less">

</style>
