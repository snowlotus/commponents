<template>
  <section class="box">
    <pts-header titleText="产值分析" leftFlag @on-left="goMenu" :showRight="showRight">
      <div slot="right">
        <a href="javascript:;" class="poa dataHeard_right hidden" @click.stop="showPopuPicker=true;">
          {{branchName}}
        </a>
      </div>
    </pts-header>
    <div class="wrap insideXubaoWrap insideTuixiuWrap">
      <div class="mainWrap pos-rel"> <!--mainWrap pb120 pos-rel 屏蔽口径选项删除 pb120-->
        <ul class="taskTitleArea c columnThree date-tab">
          <li class="pts-b-b" :class="{cur:state==0}" @click.stop="state=0;monthActive='day'"><em>日</em></li>
          <li  class="moreOption pts-b-b" :class="{cur:state==1}" @click.stop="state=1; selectMonth('month');">
            <em>{{nowMonth | chineseMonth}}月<a href="javascript:;" otype="button" otitle="展开" :class="{arrowUp:showDateTime}">展开</a></em>
          </li>
          <li class="pts-b-b" :class="{cur:state==2}" @click.stop="state=2;monthActive='day'"><em>年</em></li>
        </ul>

        <!-- 日 start -->
        <div v-if="state==0" style="margin-top: -0.1rem">
          <div class="tuixiuBox">
            <div class="dataArea dataSpeArea pt20 pb40">
              <p class="timeTxt"><i style="padding-right: .2rem;">结案口径</i>{{sysTime}}</p>
              <dl class="_mt20">
                <dt>产值(万元)</dt>
                <dd>大案占比</dd>
              </dl>
              <div class="chartBox">
                <pts-bar ref="ptsBar1" :options="setOptionBar"></pts-bar>
              </div>
            </div>
            <div class="dataArea dataSpeArea pt20 pb40">
              <dl class="_mt20">
                <dt>推修量(台)</dt>
                <dd>大案占比</dd>
              </dl>
              <div class="chartBox">
                <pts-bar ref="ptsBar2" :options="setOptionBar"></pts-bar>
              </div>
            </div>
            <div class="dataArea dataSpeArea pt20 pb20">
              <dl class="_mt20">
                <dt>维修量(台)</dt>
                <dd>大案占比</dd>
              </dl>
              <div class="chartBox">
                <pts-bar ref="ptsBar3" :options="setOptionBar"></pts-bar>
              </div>
            </div>
          </div>
        </div>
        <!-- 日 end -->

        <!-- 月 start -->
        <div v-if="state==1" style="margin-top: -0.1rem">
          <div class="tabWrap pt20">
            <ul class="analyBtnArea analyBtnCol3">
              <li :class="{cur:monthIndex==0}" @click.stop="monthIndex=0">产值</li>
              <li :class="{cur:monthIndex==1}" @click.stop="monthIndex=1">推修量</li>
              <li :class="{cur:monthIndex==2}" @click.stop="monthIndex=2">维修量</li>
            </ul>
          </div>
          <div class="tuixiuBox">
            <div class="dataArea dataSpeArea pt20 pb40">
              <p class="timeTxt"><i style="padding-right: .2rem;">结案口径</i>{{sysTime}}</p>
              <dl class="_mt20">
                <dt v-if="monthIndex==0">产值分析(万元)</dt>
                <dt v-if="monthIndex==1">推修量(台)</dt>
                <dt v-if="monthIndex==2">维修量(台)</dt>
                <dd>大案占比</dd>
              </dl>
              <div class="chartBox">
                <pts-bar ref="ptsBar4" :options="setOptionBar"></pts-bar>
              </div>
            </div>
            <div class="dataArea dataSpeArea pt20 pb15">
              <dl class="_mt20">
                <dt>数据走势</dt>
              </dl>
              <div class="chartBox pb20">
                <pts-line ref="ptsLine1" :options="setOptionLine"></pts-line>
              </div>
            </div>
          </div>
        </div>
        <!-- 月 end -->

        <!-- 年 start -->
        <div v-if="state==2" style="margin-top: -0.1rem">
          <!--<div v-if="dateType==='C'" class="dataNullWrap">-->
          <!--<div class="imgYear"></div>-->
          <!--<div class="dataNullText">暂无数据</div>-->
          <!--</div>-->
          <div>
            <div class="tabWrap pt20">
              <ul class="analyBtnArea analyBtnCol3">
                <li :class="{cur:yearIndex==0}" @click.stop="yearIndex=0">产值</li>
                <li :class="{cur:yearIndex==1}" @click.stop="yearIndex=1">推修量</li>
                <li :class="{cur:yearIndex==2}" @click.stop="yearIndex=2">维修量</li>
              </ul>
            </div>
            <div class="tuixiuBox">
              <div class="dataArea dataSpeArea pt20 pb40">
                <p class="timeTxt"><i style="padding-right: .2rem;">结案口径</i>{{sysTime}}</p>
                <dl class="_mt20">
                  <dt v-if="yearIndex==0">产值分析(万元)</dt>
                  <dt v-if="yearIndex==1">推修量(台)</dt>
                  <dt v-if="yearIndex==2">维修量(台)</dt>
                  <dd>大案占比</dd>
                </dl>
                <div class="chartBox">
                  <pts-bar ref="ptsBar5" :options="setOptionBar"></pts-bar>
                </div>
              </div>
              <div class="dataArea dataSpeArea pt20 pb15">
                <dl class="_mt20">
                  <dt>数据走势</dt>
                </dl>
                <div class="chartBox pb20">
                  <pts-line ref="ptsLine2" :options="setOptionLine"></pts-line>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- 年 end -->
        <!--<ul class="tuixiuUnderBtnArea c d n">-->
          <!--<li :class="{cur:KJ==0}" @click.stop="KJ=0;changeKJ('A')"><a href="javascript:;" otype="button" otitle="报案口径">报案口径</a></li>-->
          <!--<li :class="{cur:KJ==1}" @click.stop="KJ=1;changeKJ('C')"><a href="javascript:;" otype="button" otitle="定损口径">定损口径</a></li>-->
          <!--<li :class="{cur:KJ==2}" @click.stop="KJ=2;changeKJ('B')"><a href="javascript:;" otype="button" otitle="结案口径">结案口径</a></li>-->
        <!--</ul>-->
      </div>
      <pts-link-menu :show='showPopuPicker' @on-hide="onHide"></pts-link-menu>
    </div>
  </section>
</template>

<script>
  import {remInPx} from "../../../common/js/comUtils";
  import ptsBar from '../../../common/comComponent/echarts/bar'
  import ptsLine from '../../../common/comComponent/echarts/line'
  import {loadEcharts,roundTwo} from "../../../common/js/comUtils";
  import {chineseMonth} from '../../../common/filters/convertDate'
  import Axios from '../../../common/js/axiosConfig'
  import API from '../../../common/js/comConfig'
  import toast from '../../../common/comComponent/toast'
  import ptsLinkMenu from '../../../common/comComponent/linkageMenu/index'

  const myDate = new Date();
  let month = (myDate.getMonth() + 1) < 10 ? ('0' + (myDate.getMonth() + 1)) : (myDate.getMonth() + 1);
  const year = myDate.getFullYear();

  export default {
    name: "pushDataVsiual",
    data(){
      return {
        branchName:'',//选择机构名
        provinceCode: '',//省
        cityCode: '',//市
        dealerCode:'',
        institutionName: '',//机构名
        showRight:false,
        showPopuPicker:false,
        /*==================*/
        sysTime: '', //系统时间
        lineYmax: '',// 折线图Y轴五条分割线
        lineDayArrs:[], //天数
        lineArrs: [],//组装三个 数组(lineActualAmount,lineBackTotalAmount,lineThirdTotalAmount)
        yearAndMonth:'',
        /*==================*/
        nowMonth: "", //显示每月月份
        state:0, //选中日/月/年
        monthActive: 'day',
        showDateTime:false, //切换月份上下箭头
        KJ:0, //口径
        monthIndex:0, //月下的产值,推修量,维修量下标
        yearIndex:0, //年下的产值,推修量,维修量下标
        dateType: 'B',  //保存报案口径类型 A C B//报案 定损 结案  默认显示结案口径
        queryType: 'A', //年月日的类型C
        show_month_type: 0,// 月份的显示类型
        show_year_type: 0, //年的显示类型
        setOptionBar: {
          xAxis: [
            {
              type: 'category',
              boundaryGap: true,
              axisLine:{
                show:false
              },
              axisLabel:{
                fontSize:remInPx(0.24),
                padding:[10,0,0,0]
              },
              axisTick: {
                show: false
              },
              data:['总量','送修','返修','三者']
            },

          ],
          yAxis: [
            {
              type: 'value',
              show: true,
              axisLine:{
                show:false
              },
              axisLabel:{
                color:'#999999',
                fontSize:remInPx(0.26)
              },
              axisTick: {
                show: false
              },
              splitLine:{
                lineStyle:{
                  type:'dash',
                  color:'#EEEEEE',
                }
              },
              // splitNumber:5,
              // minInterval:1
            }
          ],
          grid:{
            top:'10%',
            left:'1%',
            right:'1%'
          },
          tooltip : {
            trigger: 'item',
            formatter: "{c}",
          },
          series: [
            {
              type:'line',
              symbol:'circle',
              symbolSize:remInPx(0.16),
              lineStyle:{
                width:1,
              },
              itemStyle : {
                color:'#FFDB4B',
              },
              data:[],
            },
            {
              type:'bar',
              silent:true,
              data:[],
              label:{
                show:true,
                position:'top',
                distance:remInPx(0.21),
                color:'#666666',
                fontSize:remInPx(0.22)
              },
              barWidth:remInPx(0.9),
              itemStyle:{
                color:function (params){
                  var colorList = ['#549DFF','#8ABCFF'];
                  return colorList[params.dataIndex]
                }
              }
            }
          ]
        },  //柱状图和B折现图
        setOptionLine: {
          color: ['#85E4B1', '#FFDB4B', '#5284FF'],
          title: [
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.25),
                fontWeight: 'normal',
                color: '#999999'
              },
              top: '80%',
              left: '5%'
            },
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.25),
                fontWeight: 'normal',
                color: '#999999'
              },
              top: '80%',
              left: '93%'
            }
          ],
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              animation: false,
              lineStyle: {
                color: '#FE8F46'
              }
            },
            backgroundColor: '#FFE0CB',
            textStyle: {
              color: '#FF954E'
            }
          },
          legend: {
            data: ['送修(台)', '返修(台)', '三者(台)'],
            left: 'center',
            itemWidth: remInPx(0.1),
            itemHeight: remInPx(0.1),
            itemGap: 40,
            textStyle: {
              fontFamily: 'Microsoft YaHei',
              fontSize: remInPx(0.22),
              color: '#666',
              lineHeight: remInPx(0.22)
            }
          },
          grid: {
            top: '10',
            bottom: '15%',
            right: '1%'
          },
          xAxis: {
            type: 'category',
            boundaryGap: false,
            show: false,
            data: [],
            axisLine: {
              show: false,
            },
            axisTick: {
              show: false,
            }
          },
          yAxis: [
            {
              splitNumber: 5,
              type: 'value',
              show: true,
              axisLine: {
                show: false,
              },
              axisTick: {
                show: false,
              },
              splitLine: {
                show: true,
                lineStyle: {
                  color: ['#DBDBDB'],
                  type: 'dotted'
                }
              },
              axisLabel: {
                color: '#999999',
                fontSize: remInPx(0.26)
              }
            }
          ],
          series: [
            {
              name: '送修(台)',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            },
            {
              name: '返修(台)',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            },
            {
              name: '三者(台)',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [],
            },
          ]
        }, //折线图
        addStorage:{}, //存储月或年下的产值/推修量/维修量数据, 月或年后台一次性把数据返回了
        /*==================*/
        KJArr:['报案口径','定损口径','结案口径'], //存储口径埋点
        reportArr:['日报','月报','年报'], //存储日报埋点
        repairArr:['产值','推修量','维修量'] //存储月/年下的产值埋点
      }
    },
    created() {
      let dealerData = window.dealerData;
      this.showRight = (~~dealerData.dealerType) === 1 ? true : false;
      this.branchName = dealerData.dealerName || '集团';
      let rqData = {
        provice: this.provinceCode || '',
        city: this.cityCode || '',
        dealerCode: this.dealerCode || '',
        dateType: this.dateType,
        queryType: this.queryType
      };
      this.$nextTick(function () {
        this.reDataPack(rqData);
      });
      window.eventAnalytics('产值分析', '查看当日数据')
    },
    methods:{
      //回到Native主页
      goMenu(){
        Native.requestHybrid({
          tagname:'backHome'
        })
      },

      /**
       * 选择网点机构
       * */
      onHide(closeFlag, msg) {
        window.eventAnalytics('产值分析', '点击切换了网点')
        this.showPopuPicker = false;
        if (!msg) {
          return;
        }
        console.log("state" + this.state);
        if (closeFlag) {
          if (this.institutionName[1] === "暂不选择") {
            this.institutionName = (this.institutionName.slice(0, this.institutionName.length - 2));
          }
          this.provinceCode = msg.provicesCode || '';
          this.cityCode = msg.cityCode || '';
          this.dealerCode = msg.dealerCode || '';
          this.branchName = `${msg.provicesName + msg.cityName + msg.dealerName}`.replace("暂不选择", '');
          // this.provinceCity.push(this.institutionName[0],this.institutionName[1]);
          if (msg.provicesName && msg.provicesName === '全国') {
            this.cityCode = "";
            this.dealerCode = "";
            this.provinceCode = "";
          }
          let reqData = {
            provice: this.provinceCode || '',
            city: this.cityCode || '',
            dealerCode: this.dealerCode || '',
            queryType: 'A',
            dateType: this.dateType
          }
          switch (this.state) {
            case 0: //日
              //reqData, elem, dateType, dataType
              window.eventAnalytics('产值分析', '查看当日数据', {'selectNetDay': '查看当日数据切换了网点'})
              this.reDataPack(reqData);
              break;
            case 1:  //月份
              window.eventAnalytics('产值分析', '查看当月数据', {'selectNetMonth': '查看当月数据切换了网点'})
              reqData = {
                provice: this.provinceCode || '',
                city: this.cityCode || '',
                dealerCode: this.dealerCode || '',
                monthDate: this.nowMonth || month,
                dateType: this.dateType,
                queryType: 'B'
              }
              this.reDataPack(reqData);
              break;
            case 2: //年
              window.eventAnalytics('产值分析', '查看当年数据', {'selectNetYear': '查看当年数据切换了网点'})
              reqData = {
                provice: this.provinceCode || '',
                city: this.cityCode || '',
                dealerCode: this.dealerCode || '',
                dateType: this.dateType,
                queryType: 'C'
              }
              this.reDataPack(reqData);
              break;
            default:
              Toast("系统繁忙,请稍后重试。");
              break;
          }
        }
      },

      /**
       * @param reqData 请求参数 object
       *
       */
      reDataPack(reqData) {
        const _this = this;
        _this.lineArrs.splice(0,_this.lineArrs.length); //清空数组
        _this.lineDayArrs.splice(0,_this.lineDayArrs.length);
        _this.addStorage = {};
        Axios.post(API.getWebServiceUrls('repairAnalysis'), reqData).then(
          res => {
            let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            // console.log(res)
            if (res.data.code == 0 && res.data.data) {
              data = data.data;
              _this.sysTime = data.sysTimes;

              //产值ov (outputVal)
              let ovTotal = roundTwo(data.outPutValueVOCount.allTotalAmount); //总量
              let ovBigTotal = roundTwo(data.outPutValueVOCount.allMajorCaseTotalAmount); //大案总量
              let ovSendRepairTotal = roundTwo(data.outPutValueVOCount.allSendBackTotalAmount); //送修总量
              let ovSendRepairBigTotal = roundTwo(data.outPutValueVOCount.allSendMajorCaseTotalAmount); //送修大案
              let ovBackRepairTotal = roundTwo(data.outPutValueVOCount.allBackTotalAmount); // 返修总量
              let ovBackRepairBigTotal = roundTwo(data.outPutValueVOCount.allBackMajorCaseTotalAmount); //返修大案
              let ovThirdTotal = roundTwo(data.outPutValueVOCount.allThirdTotalAmount); //三者总量
              let ovThirdBigTotal = roundTwo(data.outPutValueVOCount.allThirdMajorCaseTotalAmount); //三者大案

              //推修量pr (pushRepair)
              let prTotal = data.pushValueVOCount.allRrfCount; //推修总量
              let prBigTotal = data.pushValueVOCount.allRrfMajorCaseCount; //大案总量
              let prSendRepairTotal = data.pushValueVOCount.allRrfSendCount; //送修总量
              let prSendRepairBigTotal = data.pushValueVOCount.allRrfSendMajorCaseCount; //送修大案
              let prBackRepairTotal = data.pushValueVOCount.allRrfBackCount; //返修总量
              let prBackRepairBigTotal = data.pushValueVOCount.allRrfBackMajorCaseCount; //返修大案
              let prThirdTotal = data.pushValueVOCount.allRrfThirdCount; //三者总量
              let prThirdBigTotal = data.pushValueVOCount.allRrfThirdMajorCaseCount; //三者大案

              //维修量rv (repairVal)
              let rvTotal = data.repairValueVOCount.allActualCount; //维修总量
              let rvBigTotal = data.repairValueVOCount.allActualMajorCaseCount; //大案总量
              let rvSendRepairTotal = data.repairValueVOCount.allSendBackCount; //送修总量
              let rvSendRepairBigTotal = data.repairValueVOCount.allSendMajorCaseCount; //送修大案
              let rvBackRepairTotal = data.repairValueVOCount.allBackCount; //返修总量
              let rvBackRepairBigTotal = data.repairValueVOCount.allBackMajorCaseCount; //返修大案
              let rvThirdTotal = data.repairValueVOCount.allThirdCount; //三者总量
              let rvThirdBigTotal = data.repairValueVOCount.allThirdMajorCaseCount; //三者大案

              //存储月或年下的产值/推修量/维修量数据
              if (_this.queryType == 'B' || _this.queryType == 'C') {
                _this.addStorage = data;
              }

              let lineActualAmount = [];//line 送修产值
              let lineBackTotalAmount = [];//line 返修 产值
              let lineThirdTotalAmount = [];//line 三者 产值
              _this.yearAndMonth = data.yearAndMonth || year + "-" + (this.nowMonth || month); //获取月份时间 1号是判断

              /**
               * @info 设置所有柱状图的数据
               *
               */
              _this.$nextTick(function(){
                if (_this.queryType == 'A') {
                  _this.$refs.ptsBar1.setData(function (echarts) {
                    echarts.setOption({
                      yAxis: {
                        minInterval: Math.ceil(ovTotal / 4)
                      },
                      series: [
                        {
                          data: [ovBigTotal, ovSendRepairBigTotal, ovBackRepairBigTotal, ovThirdBigTotal]
                        },
                        {
                          data: [ovTotal, ovSendRepairTotal, ovBackRepairTotal, ovThirdTotal]
                        }
                      ]
                    })
                  }); //产值(日)
                  _this.$refs.ptsBar2.setData(function (echarts) {
                    echarts.setOption({
                      yAxis: {
                        minInterval: Math.ceil(prTotal / 4)
                      },
                      series: [
                        {
                          data: [prBigTotal, prSendRepairBigTotal, prBackRepairBigTotal, prThirdBigTotal]
                        },
                        {
                          data: [prTotal, prSendRepairTotal, prBackRepairTotal, prThirdTotal]
                        }
                      ]
                    })
                  }); //推修量(日)
                  _this.$refs.ptsBar3.setData(function (echarts) {
                    echarts.setOption({
                      yAxis: {
                        minInterval: Math.ceil(rvTotal / 4)
                      },
                      series: [
                        {
                          data: [rvBigTotal, rvSendRepairBigTotal, rvBackRepairBigTotal, rvThirdBigTotal]
                        },
                        {
                          data: [rvTotal, rvSendRepairTotal, rvBackRepairTotal, rvThirdTotal]
                        }
                      ]
                    })
                  }); //维修量(日)
                };

                if (_this.queryType == 'B') {

                  switch (_this.monthIndex) {
                    case 0:
                      _this.$refs.ptsBar4.setData(function (echarts) {
                        echarts.setOption({
                          yAxis: {
                            minInterval: Math.ceil(ovTotal / 4)
                          },
                          series: [
                            {
                              data: [ovBigTotal, ovSendRepairBigTotal, ovBackRepairBigTotal, ovThirdBigTotal]
                            },
                            {
                              data: [ovTotal, ovSendRepairTotal, ovBackRepairTotal, ovThirdTotal]
                            }
                          ]
                        })
                      }); //产值bar(月)
                      break;
                    case 1:
                      _this.$refs.ptsBar4.setData(function (echarts) {
                        echarts.setOption({
                          yAxis: {
                            minInterval: Math.ceil(prTotal / 4)
                          },
                          series: [
                            {
                              data: [prBigTotal, prSendRepairBigTotal, prBackRepairBigTotal, prThirdBigTotal]
                            },
                            {
                              data: [prTotal, prSendRepairTotal, prBackRepairTotal, prThirdTotal]
                            }
                          ]
                        })
                      }); //推修量bar(月)
                      break;
                    case 2:
                      _this.$refs.ptsBar4.setData(function (echarts) {
                        echarts.setOption({
                          yAxis: {
                            minInterval: Math.ceil(rvTotal / 4)
                          },
                          series: [
                            {
                              data: [rvBigTotal, rvSendRepairBigTotal, rvBackRepairBigTotal, rvThirdBigTotal]
                            },
                            {
                              data: [rvTotal, rvSendRepairTotal, rvBackRepairTotal, rvThirdTotal]
                            }
                          ]
                        })
                      }); //维修量bar(月)
                      break;
                  }
                };

                if (_this.queryType == 'C') {
                  switch (_this.yearIndex){
                    case 0:
                      _this.$refs.ptsBar5.setData(function (echarts) {
                        echarts.setOption({
                          yAxis: {
                            minInterval: Math.ceil(ovTotal / 4)
                          },
                          series: [
                            {
                              data: [ovBigTotal, ovSendRepairBigTotal, ovBackRepairBigTotal, ovThirdBigTotal]
                            },
                            {
                              data: [ovTotal, ovSendRepairTotal, ovBackRepairTotal, ovThirdTotal]
                            }
                          ]
                        })
                      }); //产值bar(年)
                      break;
                    case 1:
                      _this.$refs.ptsBar5.setData(function (echarts) {
                        echarts.setOption({
                          yAxis: {
                            minInterval: Math.ceil(prTotal / 4)
                          },
                          series: [
                            {
                              data: [prBigTotal, prSendRepairBigTotal, prBackRepairBigTotal, prThirdBigTotal]
                            },
                            {
                              data: [prTotal, prSendRepairTotal, prBackRepairTotal, prThirdTotal]
                            }
                          ]
                        })
                      }); //推修量bar(年)
                      break;
                    case 2:
                      _this.$refs.ptsBar5.setData(function (echarts) {
                        echarts.setOption({
                          yAxis: {
                            minInterval: Math.ceil(rvTotal / 4)
                          },
                          series: [
                            {
                              data: [rvBigTotal, rvSendRepairBigTotal, rvBackRepairBigTotal, rvThirdBigTotal]
                            },
                            {
                              data: [rvTotal, rvSendRepairTotal, rvBackRepairTotal, rvThirdTotal]
                            }
                          ]
                        })
                      }); //维修量bar(年)
                      break;
                  }
                };
              });

              /**
               * @info 设置获取折线图的数据
               *
               */
              if(_this.queryType == 'B') {
                switch (_this.monthIndex) {
                  case 0: //产值
                    for (let n = 0; n < data.outPutValueVO.length; n++) {
                      lineActualAmount.push(roundTwo(data.outPutValueVO[n].actualSendBackTotalAmount || 0)); //组装折线图数据 送修
                      lineBackTotalAmount.push(roundTwo(data.outPutValueVO[n].actualBackTotalAmount || 0));// 返修
                      lineThirdTotalAmount.push(roundTwo(data.outPutValueVO[n].actualThirdTotalAmount || 0));//三者
                    }
                    break;
                  case 1: //推修量
                    for (let i = 0; i < data.pushValueVO.length; i++) {
                      lineActualAmount.push(data.pushValueVO[i].rrfSendCount); //组装折线图数据 送修
                      lineBackTotalAmount.push(data.pushValueVO[i].rrfBackCount);// 返修
                      lineThirdTotalAmount.push(data.pushValueVO[i].rrfThirdCount);//三者
                    }
                    break;
                  case 2: //维修量
                    for (let k = 0; k < data.repairValueVO.length; k++) {
                      lineActualAmount.push(data.repairValueVO[k].actualSendBackCount); //组装折线图数据 送修
                      lineBackTotalAmount.push(data.repairValueVO[k].actualBackCount);// 返修
                      lineThirdTotalAmount.push(data.repairValueVO[k].actualThirdCount);//三者
                    }
                    break;
                };
                let findMax = Array.prototype.concat.call([],lineActualAmount,lineBackTotalAmount,lineThirdTotalAmount);
                _this.lineYmax = Math.max.apply(Math,findMax);
                _this.lineArrs.push(lineActualAmount,lineBackTotalAmount,lineThirdTotalAmount); //折线图数组
                _this.getLineData('ptsLine1')
              }else if (_this.queryType == 'C'){
                switch (_this.yearIndex){
                  case 0: //产值
                    for(let n = 0; n < data.outPutValueVO.length; n++){
                      lineActualAmount.push(roundTwo(data.outPutValueVO[n].actualSendBackTotalAmount || 0)); //组装折线图数据 送修
                      lineBackTotalAmount.push(roundTwo(data.outPutValueVO[n].actualBackTotalAmount || 0));// 返修
                      lineThirdTotalAmount.push(roundTwo(data.outPutValueVO[n].actualThirdTotalAmount || 0));//三者
                    }
                    break;
                  case 1: //推修量
                    for(let i = 0; i < data.pushValueVO.length; i++){
                      lineActualAmount.push(data.pushValueVO[i].rrfSendCount); //组装折线图数据 送修
                      lineBackTotalAmount.push(data.pushValueVO[i].rrfBackCount);// 返修
                      lineThirdTotalAmount.push(data.pushValueVO[i].rrfThirdCount);//三者
                    }
                    break;
                  case 2: //维修量
                    for (let k = 0; k < data.repairValueVO.length; k++) {
                      lineActualAmount.push(data.repairValueVO[k].actualSendBackCount); //组装折线图数据 送修
                      lineBackTotalAmount.push(data.repairValueVO[k].actualBackCount);// 返修
                      lineThirdTotalAmount.push(data.repairValueVO[k].actualThirdCount);//三者
                    }
                    break;
                };
                let findMax = Array.prototype.concat.call([],lineActualAmount,lineBackTotalAmount,lineThirdTotalAmount);
                _this.lineYmax = Math.max.apply(Math,findMax);
                _this.lineArrs.push(lineActualAmount,lineBackTotalAmount,lineThirdTotalAmount); //折线图数组
                _this.getLineData('ptsLine2')
              }
            } else {
              toast(res.data.msg || '系统繁忙,请稍后重试');
            }
          }
        ).catch(err => {
          console.log(err)
        })
      },

      /**
       * 获取折现图数据
       * @param elem type Array
       */
      getLineData(elem) {
        let arr = [];
        let self = this;
        if (elem == 'ptsLine1') {
          let options = this.lineArrs;
          let arrMonthName = this.monthIndex !== 0 ? ['送修(台)', '返修(台)', '三者(台)'] : ['送修', '返修', '三者'];
          let xDatas = this.getLineXData();
          let showSymbol = xDatas.length < 2;
          this.$nextTick(function () {
            options.forEach((v, index) => {
              arr.push({data: v, type: 'line', name: arrMonthName[index], showSymbol: showSymbol})
            })
            self.$refs[elem].setData(function (echarts) {
              echarts.setOption({
                legend: {
                  data: arrMonthName
                },
                title: [
                  {
                    text: `${xDatas[0].substring(5)}` // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                  },
                  {
                    text: `${xDatas[xDatas.length-1].substring(5)}`, // ${~~xStart > 9 ? xStart : '0' + xStart}.${xData.length > 9 ? xData.length : '0' + xData.length}
                    left:'89%'
                  }
                ],
                yAxis: {
                  minInterval: Math.ceil(self.lineYmax / 4)
                },
                xAxis: {
                  data: xDatas
                },
                series: arr
              })
            })
          })
        } else {
          let optionsYear = this.lineArrs;
          let arrYearName = this.yearIndex !== 0 ? ['送修(台)', '返修(台)', '三者(台)'] : ['送修', '返修', '三者'];
          let xYearDatas = this.getLineXYearData(this.lineArrs[0].length);
          let showSymbol = xYearDatas.length < 2;
          optionsYear.forEach((v, index) => {
            arr.push({data: v, type: 'line', name: arrYearName[index], showSymbol: showSymbol})
          })
          this.$nextTick(function () {
            self.$refs[elem].setData(function (echart) {
              echart.setOption({
                legend: {
                  data: arrYearName
                },
                title: [
                  {
                    text: `01` // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                  },
                  {
                    text: `${xYearDatas.length > 9 ? xYearDatas.length : '0' + xYearDatas.length}` // ${~~xStart > 9 ? xStart : '0' + xStart}.${xData.length > 9 ? xData.length : '0' + xData.length}
                  }
                ],
                yAxis: {
                  minInterval: Math.ceil(self.lineYmax / 4)
                },
                xAxis: {
                  data: xYearDatas
                },
                series: arr
              })
            })
          })
        }
      },

      /**
       * 获得折线图的月份X轴
       *
       * @returns {Array}
       */
      getLineXData() {
        /*let arr = [];
        for (let n = 0; n < day; n++) {
          arr.push(`${month}-${(n + 1) < 10 ? ("0" + (n + 1)) : (n + 1)}`)
        }
        return arr;*/
        let arr = [];
        if (this.addStorage.pushValueVO) {
          for (let i = 0;i < this.addStorage.pushValueVO.length;i++) {
            arr.push(this.addStorage.pushValueVO[i].dataTime)
          }
        }
        return arr
      },
      /**
       * 获得折线图的年份X轴
       * @param month
       * @returns {Array}
       */
      getLineXYearData(month = 12) {
        let arr = [];
        for (let n = 0; n < month; n++) {
          arr.push(`${year}-${ (n + 1) < 10 ? '0' + (n + 1) : n + 1}`)
        }
        return arr;
      },
      /**
       * 切换报案口径
       * @param dateType
       */
      changeKJ(dateType) {
        const _this = this;
        this.dateType = dateType;
        let reqData = {};

        //临时判断定损口径没有年的数据
        // if(this.state === 2 && this.dateType==='C') return;

        if (this.queryType === 'B') {
          reqData = {
            provice: this.provinceCode || '',
            city: this.cityCode || '',
            dealerCode: this.dealerCode,
            monthDate: this.nowMonth == '' ? month : this.nowMonth,
            dateType: dateType,
            queryType: this.queryType
          }
        } else {
          reqData = {
            provice: this.provinceCode || '',
            city: this.cityCode || '',
            dealerCode: this.dealerCode,
            dateType: dateType,
            queryType: this.queryType
          }
        }
        this.reDataPack(reqData);
        switch (_this.state) {
          case 0:
            window.eventAnalytics('产值分析',`${_this.KJArr[_this.KJ]}-日报`)
            break;
          case 1:
            window.eventAnalytics('产值分析',`${_this.KJArr[_this.KJ]}-${_this.reportArr[_this.state]}-${_this.repairArr[_this.monthIndex]}`)
            break;
          case 2:
            window.eventAnalytics('产值分析',`${_this.KJArr[_this.KJ]}-${_this.reportArr[_this.state]}-${_this.repairArr[_this.yearIndex]}`)
            break;
          default :
            break;
        }

      },

      selectMonth(type) {
        const _this = this;
        if (this.monthActive === type) {
          this.$vux.datetime.show({
            cancelText: '取消',
            confirmText: '确定',
            format: 'YYYY-MM',
            minYear: year,
            maxYear: year,
            startDate: `${year}-01-01`,
            endDate: `${year}-${month < 10 ? '0' + month : month}-01`,
            //value: _this.nowMonth,
            onConfirm(val) {
              let month = val.split('-')[1];
              _this.yearAndMonth = `${year}-${month}`;
              let nowMonth = _this.nowMonth = month;
              let rqData = {
                provice: _this.provinceCode || '',
                city: _this.cityCode || '',
                monthDate: nowMonth,
                dealerCode: _this.dealerCode,
                dateType: _this.dateType,
                queryType: _this.queryType
              };
              window.eventAnalytics('产值分析', '查看当月数据', {'selectMonth': "切换到了" + nowMonth + "月份数据"});
              _this.reDataPack(rqData);
            },
            onShow() {
              _this.showDateTime = true;
            },
            onHide() {
              _this.showDateTime = false;
            }
          })
        }
        this.monthActive = type;
      }
    },
    watch: {
      //监听日月年选择状态
      state(newVal, oldVal) {
        let _this = this;
        switch (newVal) {
          case 0:
            _this.queryType = 'A';
            window.eventAnalytics('产值分析',`${_this.KJArr[_this.KJ]}-日报`)
            break;
          case 1:
            _this.queryType = 'B';
            window.eventAnalytics('产值分析',`${_this.KJArr[_this.KJ]}-月报-${_this.repairArr[_this.monthIndex]}`)
            break;
          case 2:
            _this.queryType = 'C';
            window.eventAnalytics('产值分析',`${_this.KJArr[_this.KJ]}-年报-${_this.repairArr[_this.yearIndex]}`)
            break;
          default :
            break;
        }

        let rqData = {
          provice: _this.provinceCode || '',
          city: _this.cityCode || '',
          dealerCode: _this.dealerCode || '',
          monthDate: _this.nowMonth||month,
          dateType: _this.dateType,
          queryType: _this.queryType
        }
        _this.reDataPack(rqData);
      },

      //监听月下的产值,推修量,维修量选择状态
      monthIndex(newVal,oldVal){
        const _this = this;
        let data = _this.addStorage;
        _this.lineArrs = []; //清空数组
        _this.dayArrs = [];

        let lineActualAmount = [];//line 送修产值
        let lineBackTotalAmount = [];//line 返修 产值
        let lineThirdTotalAmount = [];//line 三者 产值
        _this.yearAndMonth = data.yearAndMonth || year + "-" + (this.nowMonth || month); //获取月份时间 1号是判断

        //产值ov (outputVal)
        let ovTotal = roundTwo(data.outPutValueVOCount.allTotalAmount); //总量
        let ovBigTotal = roundTwo(data.outPutValueVOCount.allMajorCaseTotalAmount); //大案总量
        let ovSendRepairTotal = roundTwo(data.outPutValueVOCount.allSendBackTotalAmount); //送修总量
        let ovSendRepairBigTotal = roundTwo(data.outPutValueVOCount.allSendMajorCaseTotalAmount); //送修大案
        let ovBackRepairTotal = roundTwo(data.outPutValueVOCount.allBackTotalAmount); // 返修总量
        let ovBackRepairBigTotal = roundTwo(data.outPutValueVOCount.allBackMajorCaseTotalAmount); //返修大案
        let ovThirdTotal = roundTwo(data.outPutValueVOCount.allThirdTotalAmount); //三者总量
        let ovThirdBigTotal = roundTwo(data.outPutValueVOCount.allThirdMajorCaseTotalAmount); //三者大案

        //推修量pr (pushRepair)
        let prTotal = data.pushValueVOCount.allRrfCount; //推修总量
        let prBigTotal = data.pushValueVOCount.allRrfMajorCaseCount; //大案总量
        let prSendRepairTotal = data.pushValueVOCount.allRrfSendCount; //送修总量
        let prSendRepairBigTotal = data.pushValueVOCount.allRrfSendMajorCaseCount; //送修大案
        let prBackRepairTotal = data.pushValueVOCount.allRrfBackCount; //返修总量
        let prBackRepairBigTotal = data.pushValueVOCount.allRrfBackMajorCaseCount; //返修大案
        let prThirdTotal = data.pushValueVOCount.allRrfThirdCount; //三者总量
        let prThirdBigTotal = data.pushValueVOCount.allRrfThirdMajorCaseCount; //三者大案

        //维修量rv (repairVal)
        let rvTotal = data.repairValueVOCount.allActualCount; //维修总量
        let rvBigTotal = data.repairValueVOCount.allActualMajorCaseCount; //大案总量
        let rvSendRepairTotal = data.repairValueVOCount.allSendBackCount; //送修总量
        let rvSendRepairBigTotal = data.repairValueVOCount.allSendMajorCaseCount; //送修大案
        let rvBackRepairTotal = data.repairValueVOCount.allBackCount; //返修总量
        let rvBackRepairBigTotal = data.repairValueVOCount.allBackMajorCaseCount; //返修大案
        let rvThirdTotal = data.repairValueVOCount.allThirdCount; //三者总量
        let rvThirdBigTotal = data.repairValueVOCount.allThirdMajorCaseCount; //三者大案

        if (newVal == 0) {
          _this.$refs.ptsBar4.setData(function (echarts) {
            echarts.setOption({
              yAxis: {
                minInterval: Math.ceil(ovTotal / 4)
              },
              series: [
                {
                  data: [ovBigTotal, ovSendRepairBigTotal, ovBackRepairBigTotal, ovThirdBigTotal]
                },
                {
                  data: [ovTotal, ovSendRepairTotal, ovBackRepairTotal, ovThirdTotal]
                }
              ]
            })
          }); //产值(月)
        } else if (newVal == 1) {
          _this.$refs.ptsBar4.setData(function (echarts) {
            echarts.setOption({
              yAxis: {
                minInterval: Math.ceil(prTotal / 4)
              },
              series: [
                {
                  data: [prBigTotal, prSendRepairBigTotal, prBackRepairBigTotal, prThirdBigTotal]
                },
                {
                  data: [prTotal, prSendRepairTotal, prBackRepairTotal, prThirdTotal]
                }
              ]
            })
          }); //推修量(月)
        } else {
          _this.$refs.ptsBar4.setData(function (echarts) {
            echarts.setOption({
              yAxis: {
                minInterval: Math.ceil(rvTotal / 4)
              },
              series: [
                {
                  data: [rvBigTotal, rvSendRepairBigTotal, rvBackRepairBigTotal, rvThirdBigTotal]
                },
                {
                  data: [rvTotal, rvSendRepairTotal, rvBackRepairTotal, rvThirdTotal]
                }
              ]
            })
          }); //维修量(月)
        }

        /**
         * @info 这里设置获取折线图的数据
         *
         */
        switch (newVal) {
          case 0: //产值
            for (let n = 0; n < data.outPutValueVO.length; n++) {
              lineActualAmount.push(roundTwo(data.outPutValueVO[n].actualSendBackTotalAmount || 0)); //组装折线图数据 送修
              lineBackTotalAmount.push(roundTwo(data.outPutValueVO[n].actualBackTotalAmount || 0));// 返修
              lineThirdTotalAmount.push(roundTwo(data.outPutValueVO[n].actualThirdTotalAmount || 0));//三者
            }
            break;
          case 1: //推修量
            for (let i = 0; i < data.pushValueVO.length; i++) {
              lineActualAmount.push(data.pushValueVO[i].rrfSendCount); //组装折线图数据 送修
              lineBackTotalAmount.push(data.pushValueVO[i].rrfBackCount);// 返修
              lineThirdTotalAmount.push(data.pushValueVO[i].rrfThirdCount);//三者
            }
            break;
          case 2: //维修量
            for (let k = 0; k < data.repairValueVO.length; k++) {
              lineActualAmount.push(data.repairValueVO[k].actualSendBackCount); //组装折线图数据 送修
              lineBackTotalAmount.push(data.repairValueVO[k].actualBackCount);// 返修
              lineThirdTotalAmount.push(data.repairValueVO[k].actualThirdCount);//三者
            }
            break;
        };
        let findMax = Array.prototype.concat.call([],lineActualAmount,lineBackTotalAmount,lineThirdTotalAmount);
        _this.lineYmax = Math.max.apply(Math,findMax);
        _this.lineArrs.push(lineActualAmount,lineBackTotalAmount,lineThirdTotalAmount); //折线图数组
        _this.getLineData('ptsLine1');
        window.eventAnalytics('产值分析',`${_this.KJArr[_this.KJ]}-月报-${_this.reportArr[newVal]}`)
      },

      //监听年下的产值,推修量,维修量选择状态
      yearIndex(newVal,oldVal){
        const _this = this;
        let data = _this.addStorage;
        _this.lineArrs = []; //清空数组
        _this.dayArrs = [];

        let lineActualAmount = [];//line 送修产值
        let lineBackTotalAmount = [];//line 返修 产值
        let lineThirdTotalAmount = [];//line 三者 产值
        _this.yearAndMonth = data.yearAndMonth || year + "-" + (this.nowMonth || month); //获取月份时间 1号是判断

        //产值ov (outputVal)
        let ovTotal = roundTwo(data.outPutValueVOCount.allTotalAmount); //总量
        let ovBigTotal = roundTwo(data.outPutValueVOCount.allMajorCaseTotalAmount); //大案总量
        let ovSendRepairTotal = roundTwo(data.outPutValueVOCount.allSendBackTotalAmount); //送修总量
        let ovSendRepairBigTotal = roundTwo(data.outPutValueVOCount.allSendMajorCaseTotalAmount); //送修大案
        let ovBackRepairTotal = roundTwo(data.outPutValueVOCount.allBackTotalAmount); // 返修总量
        let ovBackRepairBigTotal = roundTwo(data.outPutValueVOCount.allBackMajorCaseTotalAmount); //返修大案
        let ovThirdTotal = roundTwo(data.outPutValueVOCount.allThirdTotalAmount); //三者总量
        let ovThirdBigTotal = roundTwo(data.outPutValueVOCount.allThirdMajorCaseTotalAmount); //三者大案

        //推修量pr (pushRepair)
        let prTotal = data.pushValueVOCount.allRrfCount; //推修总量
        let prBigTotal = data.pushValueVOCount.allRrfMajorCaseCount; //大案总量
        let prSendRepairTotal = data.pushValueVOCount.allRrfSendCount; //送修总量
        let prSendRepairBigTotal = data.pushValueVOCount.allRrfSendMajorCaseCount; //送修大案
        let prBackRepairTotal = data.pushValueVOCount.allRrfBackCount; //返修总量
        let prBackRepairBigTotal = data.pushValueVOCount.allRrfBackMajorCaseCount; //返修大案
        let prThirdTotal = data.pushValueVOCount.allRrfThirdCount; //三者总量
        let prThirdBigTotal = data.pushValueVOCount.allRrfThirdMajorCaseCount; //三者大案

        //维修量rv (repairVal)
        let rvTotal = data.repairValueVOCount.allActualCount; //维修总量
        let rvBigTotal = data.repairValueVOCount.allActualMajorCaseCount; //大案总量
        let rvSendRepairTotal = data.repairValueVOCount.allSendBackCount; //送修总量
        let rvSendRepairBigTotal = data.repairValueVOCount.allSendMajorCaseCount; //送修大案
        let rvBackRepairTotal = data.repairValueVOCount.allBackCount; //返修总量
        let rvBackRepairBigTotal = data.repairValueVOCount.allBackMajorCaseCount; //返修大案
        let rvThirdTotal = data.repairValueVOCount.allThirdCount; //三者总量
        let rvThirdBigTotal = data.repairValueVOCount.allThirdMajorCaseCount; //三者大案

        if (newVal == 0) {
          _this.$refs.ptsBar5.setData(function (echarts) {
            echarts.setOption({
              yAxis: {
                minInterval: Math.ceil(ovTotal / 4)
              },
              series: [
                {
                  data: [ovBigTotal, ovSendRepairBigTotal, ovBackRepairBigTotal, ovThirdBigTotal]
                },
                {
                  data: [ovTotal, ovSendRepairTotal, ovBackRepairTotal, ovThirdTotal]
                }
              ]
            })
          }); //产值(月)
        } else if (newVal == 1) {
          _this.$refs.ptsBar5.setData(function (echarts) {
            echarts.setOption({
              yAxis: {
                minInterval: Math.ceil(prTotal / 4)
              },
              series: [
                {
                  data: [prBigTotal, prSendRepairBigTotal, prBackRepairBigTotal, prThirdBigTotal]
                },
                {
                  data: [prTotal, prSendRepairTotal, prBackRepairTotal, prThirdTotal]
                }
              ]
            })
          }); //推修量(月)
        } else {
          _this.$refs.ptsBar5.setData(function (echarts) {
            echarts.setOption({
              yAxis: {
                minInterval: Math.ceil(rvTotal / 4)
              },
              series: [
                {
                  data: [rvBigTotal, rvSendRepairBigTotal, rvBackRepairBigTotal, rvThirdBigTotal]
                },
                {
                  data: [rvTotal, rvSendRepairTotal, rvBackRepairTotal, rvThirdTotal]
                }
              ]
            })
          }); //维修量(月)
        }

        /**
         * @info 这里设置获取折线图的数据
         *
         */
        switch (newVal){
          case 0: //产值
            for(let n = 0; n < data.outPutValueVO.length; n++){
              lineActualAmount.push(roundTwo(data.outPutValueVO[n].actualSendBackTotalAmount || 0)); //组装折线图数据 送修
              lineBackTotalAmount.push(roundTwo(data.outPutValueVO[n].actualBackTotalAmount || 0));// 返修
              lineThirdTotalAmount.push(roundTwo(data.outPutValueVO[n].actualThirdTotalAmount || 0));//三者
            }
            break;
          case 1: //推修量
            for(let i = 0; i < data.pushValueVO.length; i++){
              lineActualAmount.push(data.pushValueVO[i].rrfSendCount); //组装折线图数据 送修
              lineBackTotalAmount.push(data.pushValueVO[i].rrfBackCount);// 返修
              lineThirdTotalAmount.push(data.pushValueVO[i].rrfThirdCount);//三者
            }
            break;
          case 2: //维修量
            for (let k = 0; k < data.repairValueVO.length; k++) {
              lineActualAmount.push(data.repairValueVO[k].actualSendBackCount); //组装折线图数据 送修
              lineBackTotalAmount.push(data.repairValueVO[k].actualBackCount);// 返修
              lineThirdTotalAmount.push(data.repairValueVO[k].actualThirdCount);//三者
            }
            break;
        };
        let findMax = Array.prototype.concat.call([],lineActualAmount,lineBackTotalAmount,lineThirdTotalAmount);
        _this.lineYmax = Math.max.apply(Math,findMax);
        _this.lineArrs.push(lineActualAmount,lineBackTotalAmount,lineThirdTotalAmount); //折线图数组
        _this.getLineData('ptsLine2')
        window.eventAnalytics('产值分析',`${_this.KJArr[_this.KJ]}-年报-${_this.reportArr[newVal]}`)
      }
    },
    beforeRouteEnter(to, from, next) {
      loadEcharts(next);
    },
    components:{
      ptsLinkMenu,
      ptsBar,
      ptsLine,
    }
  }
</script>

<style scoped lang="less">

</style>
