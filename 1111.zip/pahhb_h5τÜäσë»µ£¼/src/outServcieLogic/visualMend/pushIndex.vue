<template>
  <section>
    <pts-header titleText="推修数据" leftFlag @on-left="goMenu"></pts-header>
    <ul class="analysis">
      <li class="bg1 por">
        <router-link to="/pushDataVsiual" title="维修分析" otitle="维修分析" otype="button">维修分析<i></i></router-link>
      </li>
      <li class="bg2 por">
        <router-link to="/pushDataCon" title="联系分析" otitle="联系分析" otype="button">联系分析<i></i></router-link>
      </li>
      <li class="bg3 por">
        <router-link to="/pushDataFlow" title="流向分析" otitle="流向分析" otype="button">流向分析<i></i></router-link>
      </li>
    </ul>
  </section>
</template>
<script>
  export default {
    name: 'pushIndex',
    data(){
      return {}
    },
    mounted () {
      // 进入此页面时从cdn上加载echarts
      const echartsScript = document.querySelector('#echartsScript')
      if (!echartsScript) {
        const environment = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
        const scriptElem = document.createElement('script')
        scriptElem.id = 'echartsScript'
        scriptElem.src = environment ? './static/echarts.common.min.js' : 'https://cdn.bootcss.com/echarts/3.7.2/echarts.common.min.js'
        document.body.appendChild(scriptElem)
      }
    },
    methods: {
      goMenu(){
        //回到Native主页
        Native.requestHybrid({
          tagname: 'backHome'
        })
      }
    }
  }
</script>
