<template>
  <section class="box">
    <!-- 联系分析 -->
    <pts-header titleText="推修过程分析" leftFlag @on-left="goMenu"></pts-header>
    <div class="pageTab bgwhite pos-rel">
      <ul class="tdDate c clear bgwhite date-tab">
        <li class="pts-b-b" :class="{'on':activeTab==='day'}" @click.prevent="changeTab('day')">日</li>
        <li class="pts-b-b" :class="{'on':activeTab==='month'&& !showDateTime, 'active': showDateTime}"
            @click.prevent="changeTab('month')">
          <p v-if="monthValue === 'D'">月<i></i></p>
          <p v-else>{{monthValue | chineseMonth}}月<i></i></p>
        </li>
      </ul>
      <div class="premium">
        <p>{{dataTime}}</p>
        <pts-pie-con :options="pieOptions" ref="pie"></pts-pie-con>
      </div>
      <ul class="contact">
        <li>
          <div class="c clear por contact_box" @click.prevent="showSuccess = !showSuccess">
            <div class="fl contactLeft"><i class="call"></i><em>已联系(台)</em></div>
            <div class="fr contactRight"><em class="numberFamily">{{successMsg.sum}}</em><i :class="{'on': showSuccess}"></i></div>
          </div>
          <!--<transition name="successMsg">-->
          <ul class="contactList" v-if="showSuccess">
            <li class="c clear">
              <div class="fl">同意到店<span class="bbb">(成功)</span></div>
              <p class="fr numberFamily">{{successMsg.confirm}}</p>
            </li>
            <li class="c clear">
              <div class="fl">拒绝到店<span class="bbb">(失败)</span></div>
              <p class="fr numberFamily">{{successMsg.decline}}</p>
            </li>
            <li class="c clear">
              <div class="fl">暂不确定是否到店<span class="bbb">(待确认)</span></div>
              <p class="fr numberFamily">{{successMsg.indeterminacy}}</p>
            </li>
          </ul>
          <!--</transition>-->
        </li>
        <li>
          <div class="c clear por contact_box" @click.prevent="showFail = !showFail">
            <div class="fl contactLeft"><i class="nocall"></i><em>未联系(台)</em></div>
            <div class="fr contactRight"><em class="numberFamily">{{noCallMsg.sum}}</em><i
               :class="{'on': showFail}"></i></div>
          </div>
          <ul class="contactList" v-if="showFail">
            <!-- <li class="c clear">
              <div class="fl">超时二推</div>
              <p class="fr numberFamily">{{noCallMsg.timeOut}}</p></li> -->
            <li class="c clear">
              <div class="fl">返修自留</div>
              <p class="fr numberFamily">{{noCallMsg.self}}</p></li>
          </ul>
        </li>
      </ul>
      <div class="pageTab_year_hr"></div>
      <div class="boxsh2" style="border-top: 1px solid transparent">
        <p class="dateTime_title">联系时效</p>
        <div class="pillarChart">
          <pts-bar-con :options="barOptions" ref="bar"></pts-bar-con>
        </div>
        <section v-if="activeTab==='month'">
          <p class="dateTime_title">维修数据走势</p>
          <div class="pillarChart borno">
            <pts-line-con :options="lineOptions" ref="line"></pts-line-con>
          </div>
        </section>
      </div>
      <div class="pageTab_year_hr"></div>
    </div>
  </section>
</template>

<script>
  import ptsPieCon from '../../../common/comComponent/echarts/bar.vue'
  import ptsLineCon from '../../../common/comComponent/echarts/line.vue'
  import ptsBarCon from '../../../common/comComponent/echarts/bar.vue'
  import {remInPx, loadEcharts} from '../../../common/js/comUtils'
  import axios from '../../../common/js/axiosConfig'
  import url from '../../../common/js/comConfig'
  import toast from '../../../common/comComponent/toast'
  import '../../../common/filters/convertDate'
  const date = new Date()
  const year = date.getFullYear()
  const colors = ['#60D194', '#FFDB4B', '#559EFF'];
  export default {
    name: "pushDataCon",
    data () {
      return {
        activeTab: 'day',
        showSuccess: false,
        showFail: false,
        pieOptions: {
          title: [
            {
              text: '总推修量(台)',
              textStyle: {
                fontSize: remInPx(0.26),
                fontWeight: 'normal',
                color: '#666666'
              },
              top: '32%',
              left: 'center'
            },
            {
              text: '0',
              textStyle: {
                fontSize: remInPx(0.6),
                fontWeight: 'normal',
                color: '#333'
              },
              top: '42%',
              left: 'center'
            }
          ],
          color: colors,
          series: [
            {
              name: '其实没什么用',
              type: 'pie',
              radius: ['75%', '90%'],
              label: {
                normal: {
                  show: false
                },
                emphasis: {
                  show: false
                }
              },
              hoverAnimation: false,
              data: [
                {
                  value: 0,
                  name: '未联系'
                },
                {
                  value: 0,
                  name: '已联系'
                }
              ]
            }
          ]
        },
        lineOptions: {
          /*title: [
           {
           text: '',
           textStyle: {
           fontSize: remInPx(0.25),
           fontWeight: 'normal',
           color: '#666666'
           },
           top: '90%',
           left: '3%'
           },
           {
           text: '',
           textStyle: {
           fontSize: remInPx(0.25),
           fontWeight: 'normal',
           color: '#666666'
           },
           top: '90%',
           left: 'right'
           }
           ],
           tooltip: {
           trigger: 'axis',
           axisPointer: {
           lineStyle: {
           color: '#FE8F46'
           }
           },
           backgroundColor: '#FFE0CB',
           textStyle: {
           color: '#FF954E'
           },
           formatter: '{b0}<br>{a0}: {c0}<br>{a1}: {c1}<br>{a2}: {c2}<br>'
           },*/
          color: colors,
          legend: {
            data: ['大案', '非大案', '均值']
            /*textStyle: {
             fontSize: remInPx(0.22)
             },
             itemWidth: remInPx(0.1),
             itemHeight: remInPx(0.1),
             itemGap: 80*/
          },
          /*grid: {
           left: '0%',
           right: '2%',
           top: '20%',
           bottom: '3%',
           containLabel: true
           },
           xAxis: {
           show: false,
           type: 'category',
           boundaryGap: false,
           data: []
           },
           yAxis: {
           type: 'value',
           splitLine: {
           show: true,
           lineStyle: {
           type: 'dashed'
           }
           },
           axisLine: {
           show: false
           },
           axisTick: {
           show: false
           },
           axisLabel: {
           color: '#999999',
           fontSize: remInPx(0.26)
           }
           },*/
          series: [
            {
              name: '大案',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            }, {
              name: '非大案',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            },
            {
              name: '均值',
              type: 'line',
              showSymbol: false,
              symbol: 'circle',
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            }
          ]
        },
        barOptions: {
          legend: {
            data: ['大案', '非大案'],
            itemGap: 100
          },
          color: colors,
          xAxis: [
            {
              show: true,
              type: 'category',
              splitNumber: 1,
              data: ['其实没什么用'],
              axisLine: {
                show: true,
                lineStyle: {
                  type: 'dashed',
                  color: 'rgba(0,0,0,0)'
                }
              },
              axisTick: {
                show: false
              },
              position: 'bottom',
              boundaryGap: true
            }, {
              type: 'category',
              boundaryGap: false,
              data: (function () {
                var res = [];
                var len = 0;
                while (len < 10) {
                  res.push(len);
                  len++;
                }
                return res;
              })(),
              axisLine: {
                show: true,
                lineStyle: {
                  type: 'dashed',
                  color: 'rgba(0,0,0,0)'
                }
              },
              axisTick: {
                show: false
              },
              position: 'top'
            }
          ],
          yAxis: {
            type: 'value',
            splitLine: {
              show: true,
              lineStyle: {
                type: 'dashed',
                color: '#eee'
              }
            },
            axisLine: {
              show: false
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              color: '#999999',
              fontSize: remInPx(0.26)
            }
          },
          series: [
            {
              name: '大案',
              type: 'bar',
              label: {
                normal: {
                  show: true,
                  position: 'top',
                  textStyle: {
                    color: '#666666'
                  }
                }
              },
              itemStyle: {
                normal: {
                  color: colors[0]
                },
                emphasis: {
                  color: colors[0]
                }
              },
              barGap: '150%',
              barWidth: remInPx(1),
              data: []
            },
            {
              name: '非大案',
              type: 'bar',
              label: {
                normal: {
                  show: true,
                  position: 'top',
                  textStyle: {
                    color: '#666666'
                  }
                }
              },
              itemStyle: {
                normal: {
                  color: colors[1]
                },
                emphasis: {
                  color: colors[1]
                }
              },
              barGap: '150%',
              barWidth: remInPx(1),
              data: []
            },
            {
              name: '均值',
              type: 'line',
              xAxisIndex: 1,
              data: [],
              lineStyle: {
                normal: {
                  width: 1,
                  color: '#c0c0c0'
                }
              },
              symbol: 'rect',
              symbolSize: 1,
              showSymbol: true,
              label: {
                normal: {
                  show: true,
                  position: 'top',
                  formatter: function (a) {
                    if (a.dataIndex > 8) {
                      return `均值: ${a.data}分钟`
                    } else {
                      return ''
                    }
                  },
                  color: '#c0c0c0'
                },
                emphasis: {
                  show: true,
                  position: 'right',
                  formatter: function (a) {
                    if (a.dataIndex > 8) {
                      return `均值: ${a.data}分钟`
                    } else {
                      return ''
                    }
                  },
                  color: '#c0c0c0'
                }
              }
            }
          ]
        },
        successMsg: {
          sum: 0, // 总数
          confirm: 0, // 确定到店
          decline: 0, // 拒绝
          indeterminacy: 0 // 不确定
        },
        noCallMsg: {
          sum: 0,
          timeOut: 0, // 超时
          self: 0 // 自修
        },
        monthValue: 'D',
        dataTime: '',
        activeMonth: '',
        showDateTime: false,
        addStorage:{}, //存储每次请求回来的数据
      }
    },
    components: {
      ptsPieCon,
      ptsLineCon,
      ptsBarCon
    },
    mounted () {
      this.activeMonth = `${year}-${(date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1)}`;
      this.getData('A');
      window.eventAnalytics('推修过程分析', '查看当日数据');
    },
    methods: {
      goMenu () {
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      /*
       * @info 切换tab函数
       * */
      changeTab (type) {
        if (type === 'day' && this.activeTab === type) {
          return
        }
        if (type === 'month') {
          let month = this.monthValue === 'D' ? (date.getMonth() + 1 < 10 ? ('0' + (date.getMonth() + 1)) : date.getMonth() + 1) : this.monthValue;
          if (this.activeTab === type) {
            this.$vux.datetime.show({
              value: this.activeMonth,
              cancelText: '取消',
              confirmText: '确定',
              format: 'YYYY-MM',
              minYear: year,
              maxYear: year,
              startDate: `${year}-01-01`,
              endDate: `${year}-${(date.getMonth() + 1) > 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1)}-01`,
              onConfirm: (a) => {
                if (this.activeMonth === a) return;
                this.activeMonth = a;
                month = a.substr(a.indexOf('-') + 1);
                this.monthValue = month;
                this.getData('B', month);
                window.eventAnalytics('推修过程分析', '查看' + month + '数据');
              },
              onShow: () => {
                this.showDateTime = true;
              },
              onHide: () => {
                this.showDateTime = false;
              }
            });
            return
          } else {
            this.getData('B', month);
          }
        } else {
          this.$nextTick(function () {
            this.getData('A')
          })
        }
        this.activeTab = type;
        let flagText = type === 'day' ? '当日' : '当月';
        window.eventAnalytics('推修过程分析', '查看' + flagText + '数据');
      },
      /*
       * @info 发起ajax请求 并设置图标数据的函数
       * @param type {String} 当月(B) or 当日(A)
       * @param month {String || Number} 用户选择的月份
       * */
      getData (type, month) {
        const _this = this;
        _this.addStorage = {};
        this.initEcharts();
        /*axios.get(url.getWebServiceUrls('pageData'), {
         params: {
         file: 'cons',
         path: 'car',
         timeout: 1,
         queryType: type,
         month
         }
         })*/
        axios.post(url.getWebServiceUrls('contactAnalysis'), {
          monthDate: month + '',
          queryType: type
        }).then(res => {
          let data = res.data;

          if (_this.activeTab == 'month' && data.data.contactAnalysisResult) {
            _this.addStorage = data.data.contactAnalysisResult;
          }

          switch (data.code) {
            case 0:
              data = data.data;
//              console.log(data)
              _this.dataTime = data.sysTimes;
              let successSum = data.successNum + data.failNum + data.undeterminedNum;
              let fileSum = data.timeOutTwoPush + data.repairRetention;
              let majorCase = data.contactAnalysisResult.sumMajorCase; // 大案
              let unMajorCase = data.contactAnalysisResult.sumUnMajorCase;  // 非大案
              let averageValue = data.contactAnalysisResult.sumAverageValue; // 均值
              _this.successMsg = {
                sum: successSum,
                confirm: data.successNum,
                decline: data.failNum,
                indeterminacy: data.undeterminedNum
              };
              _this.noCallMsg = {
                sum: fileSum,
                timeOut: data.timeOutTwoPush, // 超时
                self: data.repairRetention // 自修
              };
              _this.$nextTick(function () {
                _this.$refs.pie.setData(function (echarts) {
                  echarts.setOption({
                    title: [
                      {},
                      {
                        text: (function (value) {
                          if (Number.isNaN(Number(value))) {
                            return value;
                          }
                          if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
                            return Number(value).toLocaleString();
                          } else {
                            return value;
                          }
                        })((successSum + fileSum))
                      }
                    ],
                    series: [
                      {
                        data: [
                          {value:successSum},
                          {value:fileSum}
                        ]
                      }
                    ]
                  })
                });
                _this.$refs.bar.setData(function (echarts) {
                  let arr = [
                    {data: [majorCase]}, // 大案
                    {data: [unMajorCase]}, // 非大案
                    {
                      data: (function () {
                        let lishi = [];
                        let i = 0;
                        while (i < 10) {
                          lishi.push(averageValue);
                          i++
                        }
                        return lishi
                      })()
                    } // 均值
                  ];
                  let ass = [majorCase, unMajorCase];
                  let max = Math.max.apply(Math, ass);
                  echarts.setOption({
                    yAxis: {
                      minInterval: Math.ceil(max / 4)
                    },
                    series: arr
                  });
                  max = null;
                  ass = null;
                });
                if (month) {
                  let majorCases = []; // 大案
                  let unMajorCases = []; // 非大案
                  let averageValues = []; // 均值
                  data.contactAnalysisResult.contactMajorCaseVO.forEach(v => {
                    majorCases.push(v.majorCase);
                    unMajorCases.push(v.unMajorCase);
                    averageValues.push(v.averageValue)
                  });
                  _this.$refs.line.setData(function (echarts) {
                    let arrs = [
                      {
                        data: majorCases,
                        showSymbol: majorCases.length < 2
                      },
                      {
                        data: unMajorCases,
                        showSymbol: unMajorCases.length < 2
                      },
                      {
                        data: averageValues,
                        showSymbol: averageValues.length < 2
                      }
                    ];
                    let date = data.yearAndMonth;
//                    let xStart = date.substr(5, date.length);
                    let xData = _this.xDatas();
                    let ass = Array.prototype.concat.call([], majorCases, unMajorCases, averageValues);
                    let max = Math.max.apply(Math, ass);
                    ass = null; // 内存回收
                    echarts.setOption({
                      title: [
                        {
                          text: `${xData[0].substring(5)}` // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                        },
                        {
                          text: `${xData[xData.length-1].substring(5)}` // ${~~xStart > 9 ? xStart : '0' + xStart}.${xData.length > 9 ? xData.length : '0' + xData.length}
                        }
                      ],
                      xAxis: {
                        data: xData
                      },
                      yAxis: {
                        // 为了显示五个y轴
                        minInterval: Math.ceil(max / 4)
                      },
                      series: arrs
                    });
                    max = null;
                  })
                }
              });
              break;
            default:
              toast(data.msg);
              break
          }
        }).catch(err => {
          console.log(err)
        })
      },
      /*
       * @info 生成 x 轴数据 YYYY-MM-DD格式
       * @param month {number, string} MM的值
       * @param day {number} 一共生成多少天
       * @return array 值类型是YYYY-MM-DD格式 的数组
       * */
      xDatas () {
        /*let arr = [];
        for (let i = 1; i <= day; i++) {
          arr.push(`${month}-${i < 10 ? '0' + i : i}`)
        }
        return arr*/
        let arr = [];
        let dataArr = this.addStorage.contactMajorCaseVO;
        for (let i = 0;i < dataArr.length;i++) {
          arr.push(`${dataArr[i].datatime.substring(0,4)}-${dataArr[i].datatime.substring(4,6)}-${dataArr[i].datatime.substring(6)}`)
        }
        return arr
      },
      initEcharts () {
        this.$nextTick(function () {
          this.successMsg = {
            sum: 0,
            confirm: 0,
            decline: 0,
            indeterminacy: 0
          }
          this.noCallMsg = {
            sum: 0,
            timeOut: 0, // 超时
            self: 0 // 自修
          }
          this.$refs.pie.setData(function (echarts) {
            echarts.setOption({
              title: [
                {},
                {
                  text: (function (value) {
                    if (Number.isNaN(Number(value))) {
                      return value;
                    }
                    if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
                      return Number(value).toLocaleString();
                    } else {
                      return value;
                    }
                  })(0)
                }
              ],
              series: [
                {
                  data: [
                    {value: 0},
                    {value: 0}
                  ]
                }
              ]
            })
          });
          this.$refs.bar.setData(function (echarts) {
            let arr = [
              {data: [0]}, // 大案
              {data: [0]}, // 非大案
              {
                data: (function () {
                  let lishi = []
                  let i = 0
                  while (i < 10) {
                    lishi.push(0)
                    i++
                  }
                  return lishi
                })()
              } // 均值
            ]
            echarts.setOption({
              series: arr
            })
          });
          this.$refs.line && this.$refs.line.setData(function (echarts) {
            let arrs = [
              {
                data: []
              },
              {
                data: []
              },
              {
                data: []
              }
            ]
            echarts.setOption({
              xAxis: {
                data: []
              },
              series: arrs
            })
          });
        })
      }
    },
    beforeRouteEnter (to, from, next) {
      loadEcharts(next);
    },
    watch: {
      showSuccess () {
        window.eventAnalytics('推修过程分析', '已联系的点击次数');
      },
      showFail () {
        window.eventAnalytics('推修过程分析', '未联系的点击次数');
      }
    }
  }
</script>

<style lang="less" scoped>
  .call {
    background: #60D194;
  }

  .nocall {
    background: #FFDB4B;
  }

  .successMsg-enter-active {
    animation: slideDown 500ms;
  }

  .successMsg-leave-active {
    animation: slideUp 500ms;
  }

  @keyframes slideDown {
    from {
      -webkit-transform: translate3d(0, -100%, 0);
      transform: translate3d(0, -100%, 0);
      opacity: 0;
      visibility: visible;
    }

    to {
      -webkit-transform: translate3d(0, 0, 0);
      opacity: 1;
      transform: translate3d(0, 0, 0);
    }
  }

  @keyframes slideUp {
    from {
      -webkit-transform: translate3d(0, 0, 0);
      opacity: 1;
      transform: translate3d(0, 0, 0);
    }

    to {
      visibility: hidden;
      -webkit-transform: translate3d(0, -100%, 0);

      transform: translate3d(0, -100%, 0);
    }
  }
</style>
