<template>
  <div>
    <div class="billboardHtml_td">
      <ul class="billboardHtml_tab c clear">
        <li v-for="(item,index) in billList" class="pts-b-t" v-if="billList.length>0">
          <s v-if="index===0" :class="[flagName===0?'bg1':'fcFF5']">{{flagName===0?'':index+1}}</s>
          <s v-else-if="index===1" :class="[flagName===0?'bg2':'fcFFA']">{{flagName===0?'':index+1}}</s>
          <s v-else-if="index===2" :class="[flagName===0?'bg3':'fc40C']">{{flagName===0?'':index+1}}</s>
          <s v-else>{{index+1}}</s>
          <em>{{item.flagName}}</em>
          <span>{{(item.preCount/10000).toFixed(2)|NumberThere}}</span>
          <span v-if="flagName!==0&&index<3" style="color: #FF5454;">{{item.preNum}}</span>
          <span v-else>{{item.preNum}}</span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>

  import Toast from '../../common/comComponent/toast/index'
  import API from '../../common/js/comConfig'
  import Axios from '../../common/js/axiosConfig'
  import {NumberThere} from '../../common/filters/convertAmount'

  let count = 0;
  export default {
    name: 'boardList',
    data() {
      return {
        showDataNull: false,
        //dataList:[],
        billList: [],
        planAndCutBill: {},//签单税前榜单
        planAndTaxBill: {},//签单税后榜单
        signAndCutBill: {},//企划税后榜单
        signAndTaxBill: {},//企划税前榜单
        num: 0,
        isActive: true
      }
    },
    props: {
      active: Boolean,
      flagName: Number,
      trademarkId: String,
      dayTandC: {
        type: Object,
        default: {}
      },
//      province : String,
//      city : String,
      institution: Object
    },
    created() {
      //判断城市是否是暂不选择
      if (this.institution && this.institution.cityName === '暂不选择') {
        this.institution.cityCode = '';
      }
      //判断机构是否是全国
      if (this.institution && this.institution.provicesName === '全国') {
        this.institution.provicesCode = '';
        this.institution.cityCode = '';
      }
      let reqData = {
        provices: this.institution ? this.institution.provicesCode : '',
        citys: this.institution ? this.institution.cityCode : '',
        trademarkId: this.trademarkId || ''
      };
      if (this.active) {
        this.isActive = true;
        this.getBillList(reqData);

      }
      this.$watch('dayTandC', function (val, oldVal) {
        // if (val.dayType != oldVal.dayType || val.dayCalibreType != oldVal.dayCalibreType) {
        this.active && this.showBillList(val);
        // }
      }, {
        deep: true
      });
    },
    methods: {
      //"http://localhost:8888/index?id=billList&path=car&dateFrom=20171030"
      //     "http://localhost:8888/postGetData", {
      //   "path": 'car',
      //     "file": 'billList'
      // }
      //API.getWebServiceUrls('billList'),reqData,{'loading':false}
      getBillList(reqData) {
        let self = this;
        Axios.post(API.getWebServiceUrls('billList'), reqData, {'loading': false}).then(res => {
          const billData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (billData.code === 0 || billData.code === '0') {
            this.planAndCutBill = billData.data.planAndCutBill || {};
            this.planAndTaxBill = billData.data.planAndTaxBill || {};
            this.signAndCutBill = billData.data.signAndCutBill || {};
            this.signAndTaxBill = billData.data.signAndTaxBill || {};
            this.showBillList(self.dayTandC);
          } else {
            Toast(billData.msg || '系统繁忙,请稍后重试')
          }
        }).catch(e => {
          console.log(e);
//        	Toast('接口出错了,请稍后重试!')
        })
      },
      /**
       * 显示榜单列表
       * @param obj
       */
      showBillList(obj) {
        let self = this;
        let dandC = obj, billData = {};
        if (dandC.dayCalibreType && dandC.dayCalibreType === '0') { //dandC.dayCalibreType 0  签单  1 企划
          //dandC.dayType 0  税后  1 税前
          billData = dandC.dayType === '0' ? self.signAndCutBill : self.signAndTaxBill;
        } else {
          billData = dandC.dayType === '0' ? self.planAndCutBill : self.planAndTaxBill;
        }
        console.log("flagName", self.flagName);
        self.billList = self.flagName === 0 ? billData.starBill : billData.enterpriseBill;
        this.$emit('billLen', this.billList && this.billList.length + 1 || 1); //高度需要加1
      }
    },
    watch: {
      active(to, old) {
        let _this = this;
        if (this.institution && this.institution.cityName === '暂不选择') {
          this.institution.cityCode = '';
        }
        if (this.institution && this.institution.provicesName === '全国') {
          this.institution.provicesCode = '';
          this.institution.cityCode = '';
        }
        //&& this.billList.length===0 如果 trademarkId或者网点变了 切换的时候需要再次请求
        if (to === old) return;
        if (to) {
          let reqData = {
            provices: this.institution ? this.institution.provicesCode : '',
            citys: this.institution ? this.institution.cityCode : '',
            // listFlag: _this.flagName,
            trademarkId: this.trademarkId
          }
          this.isActive = false;
          this.getBillList(reqData)
          console.log("滑动到" + this.flagName);
        }
      },
      institution(val, oldVal) {
        if (this.active) {
          if (this.institution && this.institution.cityName === '暂不选择') {
            this.institution.cityCode = '';
          }
          if (this.institution && this.institution.provicesName === '全国') {
            this.institution.provicesCode = '';
            this.institution.cityCode = '';
          }
          let reqData = {
            provices: this.institution ? this.institution.provicesCode : '',
            citys: this.institution ? this.institution.cityCode : '',
            // listFlag: this.flagName,
            trademarkId: this.trademarkId
          }
          this.getBillList(reqData)
        }
      },
      trademarkId(val, oldVal) {
        if (this.institution && this.institution.cityName === '暂不选择') {
          this.institution.cityCode = '';
        }
        if (this.institution && this.institution.provicesName === '全国') {
          this.institution.provicesCode = '';
          this.institution.cityCode = '';
        }
        if (val !== oldVal) {
          let reqData = {
            provices: this.institution ? this.institution.provicesCode : '',
            citys: this.institution ? this.institution.cityCode : '',
            // listFlag: this.flagName,
            trademarkId: val
          }
          this.getBillList(reqData)
        }
      },
    },
  }
</script>

<style lang='less'>
  .listScroll {
    height: 100%;
    overflow: auto;
    -webkit-overflow-scrolling: touch;
  }

  .pof_b1 {
    bottom: 0;
  }

  .font_color {
    color: #FF5454;
  }
</style>
