<template>
  <section class="box insideXubaoWrap insideYejiWrap" style="overflow-x: hidden;">
    <!--<div class="insideXubaoWrap insideYejiWrap">-->
    <pts-header :title-text="titleText" leftFlag @on-left="goMenu()" :showRight="showRight">
      <div slot="right" class="flexBox">
        <img :src="dealerIcon" class="allSeries" @touchstart="getIcon"/>
        <a href="javascript:;" class="dataHeard_right poa text-hidden" style="max-width: 1.25rem;"
           @click.stop="showPopuPicker=true">
          {{branchName}}
        </a>
      </div>
    </pts-header>
    <div class="wrap insideXubaoWrap insideYejiWrap">
      <!-- main start -->
      <div class="mainWrap pb100 pos-rel">
        <ul class="taskTitleArea c date-tab">
          <li class="pts-b-b" :class="{'cur':activeTab==='D'}" @click.stop="changTab('D')"><em>实时</em></li>
          <li class="pts-b-b" :class="{'cur':activeTab==='A'}" @click.stop="changTab('A')"><em>日</em></li>
          <li class="moreOption pts-b-b" :class="{'cur':activeTab==='B'}" @click.stop="changTab('B')">
            <em>{{monthValue.slice(4)|chineseMonth}}月<a href="javascript:;" otype="button" otitle="展开" class="openSlect"
                                                        :class="{arrowUp:showFlag}">展开</a></em>
          </li>
          <li class="pts-b-b" :class="{'cur':activeTab==='C'}" @click.stop="changTab('C')"><em>年</em></li>
        </ul>
        <div class="yejiTabArea" style="margin-top: -1px;">
          <!-- 实时 start -->
          <div v-if="activeTab==='D'">
            <div class="dataArea pt20 mb20">
              <ul class="analyBtnArea mb20">
                <li :class="{'cur':nowData.nowType==='0'}" @click="nowData.nowType='0',changeTax('D')">税后</li>
                <li :class="{'cur':nowData.nowType==='1'}" @click="nowData.nowType='1',changeTax('D')">税前</li>
              </ul>
              <p class="timeTxt">更新时间 {{nowData.updateTime}}</p>
              <div class="mb15 c">
                <div class="chartBoxImg echart_top">
                  <!--<img src="images/img_yejidate04.jpg" alt="" class="img_w_01">-->
                  <pts-echarts-pie :options="setPieOption" ref="nowPie"></pts-echarts-pie>
                </div>
                <div class="ul_m">
                  <ul class="chartBoxTxt m_b">
                    <li class="f_c_blue">新保
                      <em class="m_em">{{nowData.nowType==='0'?(Math.round(nowData.signAndCut.newInsurancePremCutTotal/100)/100).toFixed(2):(Math.round(nowData.signAndTax.newInsurancePremCutTotal/100)/100).toFixed(2)|NumberThere}}</em>
                    </li>
                    <li class="f_c_green">转保<em class="m_em">{{nowData.nowType==='0'?(Math.round(nowData.signAndCut.reiInsurancePremCutTotal/100)/100).toFixed(2):(Math.round(nowData.signAndTax.reiInsurancePremCutTotal/100)/100).toFixed(2)|NumberThere}}</em>
                    </li>
                    <li class="f_c_yellow">续保<em class="m_em">{{nowData.nowType==='0'?(Math.round(nowData.signAndCut.renInsurancePremCutTotal/100)/100).toFixed(2):(Math.round(nowData.signAndTax.renInsurancePremCutTotal/100)/100).toFixed(2)|NumberThere}}</em>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="chartDataBox">
                <dl>
                  <dt>交强险</dt>
                  <dd>
                    <em>{{nowData.nowType==='0'?(nowData.signAndCut.compulsoryInsurancePremTotal/10000).toFixed(2):(nowData.signAndTax.compulsoryInsurancePremTotal/10000).toFixed(2)|NumberThere}}</em>
                    <em>签单量：{{nowData.nowType==='0'?nowData.signAndCut.compulsoryInsurancePremNumTotal:nowData.signAndTax.compulsoryInsurancePremNumTotal|NumberThere}}</em>
                  </dd>
                </dl>
                <dl>
                  <dt>商业险</dt>
                  <dd>
                    <em>{{nowData.nowType==='0'?(nowData.signAndCut.commercialInsurancePremTotal/10000).toFixed(2):(nowData.signAndTax.commercialInsurancePremTotal/10000).toFixed(2)|NumberThere}}</em>
                    <em>签单量：{{nowData.nowType==='0'?nowData.signAndCut.commercialInsurancePremNumTotal:nowData.signAndTax.commercialInsurancePremNumTotal|NumberThere}}</em>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <!-- 实时 end -->

          <!-- 日 start -->
          <div v-if="activeTab==='A'">
            <div class="dataArea pt20 mb20">
              <ul class="analyBtnArea mb20">
                <li :class="{cur:dayTandC.dayType==='0'}" @click.stop="dayTandC.dayType='0',changeTax('A')">税后</li>
                <li :class="{cur:dayTandC.dayType==='1'}" @click.stop="dayTandC.dayType='1',changeTax('A')">税前</li>
              </ul>
              <p class="timeTxt">{{otherData.systemDate}}</p>
              <div class="mb15 c"><!--chartBox-->
                <div class="chartBoxImg echart_top">
                  <!--<img src="images/img_yejidate04.jpg" alt="" class="img_w_01">-->
                  <pts-echarts-pie :options="setPieOption" ref="dayPie"></pts-echarts-pie>
                </div>
                <div class="ul_m">
                  <ul class="chartBoxTxt m_b">
                    <li class="f_c_blue">新保<em class="m_em">{{otherData.newInsurancePremCutTotal}}</em></li>
                    <li class="f_c_green">转保<em class="m_em">{{otherData.reiInsurancePremCutTotal}}</em></li>
                    <li class="f_c_yellow">续保<em class="m_em">{{otherData.renInsurancePremCutTotal}}</em></li>
                  </ul>
                </div>
              </div>
              <div class="chartDataBox">
                <dl>
                  <dt>交强险</dt>
                  <dd>
                    <em :class="{lin_h : dayTandC.dayCalibreType==='1'}">{{otherData.compulsoryInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:dayTandC.dayCalibreType==='1'}">签单量：{{otherData.compulsoryInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
                <dl>
                  <dt>商业险</dt>
                  <dd>
                    <em :class="{lin_h : dayTandC.dayCalibreType==='1'}">{{otherData.commercialInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:dayTandC.dayCalibreType==='1'}">签单量：{{otherData.commercialInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
              </div>
              <ul class="tuixiuUnderBtnArea c">
                <li :class="{cur:dayTandC.dayCalibreType==='0'}"
                    @click="dayTandC.dayCalibreType='0',changeTax('A')"><a href="javascript:;" otype="button"
                                                                           otitle="签单口径">签单口径</a></li>
                <li :class="{cur:dayTandC.dayCalibreType==='1'}"
                    @click="dayTandC.dayCalibreType='1',changeTax('A')"><a href="javascript:;" otype="button"
                                                                           otitle="企划口径">企划口径</a></li>
              </ul>
            </div>
            <div class="billboardHtml boxsh2 por" v-if="showRight&&isShowBoard" style="background-color: #FFFFFF;">
              <!--<div class="pageTab_year_hr"></div>-->
              <pts-tabs :titleList="titleList" @on-child-change="tabChildChange" v-model="index" :height="tabHeight">
                <!--style="border-bottom: .02rem solid #eee;"-->
                <div class="c clear billboardHtml_th" slot="boardList">
                  <div class="fl">名称</div>
                  <div class="fl">
                    <p class="fl">总保费(万元)</p>
                    <p class="fl">签单量</p>
                  </div>
                </div>
                <pts-tab-item>
                  <pts-list :active="index===0" :flagName="0" :institution="institution" :trademarkId='trademarkId'
                            :dayTandC="dayTandC"
                            @billLen="getBillLen"></pts-list>
                </pts-tab-item>
                <pts-tab-item>
                  <pts-list :active="index===1" :flagName="1" :institution="institution" :trademarkId='trademarkId'
                            :dayTandC="dayTandC"
                            @billLen="getBillLen"></pts-list>
                </pts-tab-item>
              </pts-tabs>
              <div class="pageTab_year_hr"></div>
            </div>
          </div>
          <!-- 日 end -->

          <!-- 月 start -->
          <div v-if="activeTab==='B'">
            <div class="dataArea pt20 mb20">
              <ul class="analyBtnArea mb20">
                <li :class="{cur:monthTandC.monthType==='0'}" @click.stop="monthTandC.monthType='0',changeTax('B')">税后
                </li>
                <li :class="{cur:monthTandC.monthType==='1'}" @click.stop="monthTandC.monthType='1',changeTax('B')">税前
                </li>
              </ul>
              <p class="timeTxt">{{otherData.systemDate}}</p>

              <div class="mb15 c"><!--chartBox-->
                <div class="chartBoxImg echart_top">
                  <pts-echarts-pie ref="monthPie" :options="setPieOption"></pts-echarts-pie>
                </div>
                <div class="ul_m">
                  <ul class="chartBoxTxt m_b">
                    <li class="f_c_blue">新保<span class='f_s'>月增速<i
                      :class="Number(otherData.newInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.newInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.newInsurancePremCutTotal}}</em></li>
                    <li class="f_c_green">转保<span class="f_s">月增速<i
                      :class="Number(otherData.reiInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.reiInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.reiInsurancePremCutTotal}}</em></li>
                    <li class="f_c_yellow">续保<span class="f_s">月增速<i
                      :class="Number(otherData.renInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.renInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.renInsurancePremCutTotal}}</em></li>
                  </ul>
                </div>
              </div>
              <div class="chartDataBox">
                <dl class="self">
                  <dt class="selfLeft">交强险
                    <div class="left">
                      <span class="f_s_m" ref="jqxtb" v-if="nowMonth!==monthValue.slice(4)">同比<i
                      :class="Number(otherData.yoycompulsoryGrowth)<0?'i_r':'i_g'">{{otherData.yoycompulsoryGrowth}}%</i></span>
                    </div>
                    <div class="right">
                      <span class="f_s_m" ref="jqxhb" v-if="nowMonth!==monthValue.slice(4)">环比<i
                        :class="Number(otherData.momcompulsoryGrowth)<0?'i_r':'i_g'">{{otherData.momcompulsoryGrowth}}%</i></span>
                    </div>
                  </dt>
                  <dd class="selfRight">
                    <em :class="{lin_h : monthTandC.monthCalibreType==='1'}">{{otherData.compulsoryInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:monthTandC.monthCalibreType==='1'}">签单量：{{otherData.compulsoryInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
                <dl class="self">
                  <dt class="selfLeft">商业险
                    <div class="left">
                    <span class="f_s_m" ref="syxtb" v-if="nowMonth!==monthValue.slice(4)">同比<i
                      :class="Number(otherData.yoycommercialGrowth)<0?'i_r':'i_g'">{{otherData.yoycommercialGrowth}}%</i></span>
                    </div>
                    <div class="right">
                    <span class="f_s_m" ref="syxhb" v-show="nowMonth!==monthValue.slice(4)">环比<i
                      :class="Number(otherData.momcommercialGrowth)<0?'i_r':'i_g'">{{otherData.momcommercialGrowth}}%</i></span>

                    </div>
                  </dt>
                  <dd class="selfRight">
                    <em :class="{lin_h : monthTandC.monthCalibreType==='1'}">{{otherData.commercialInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:monthTandC.monthCalibreType==='1'}">签单量：{{otherData.commercialInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
              </div>
            </div>

            <div class="dataArea dataSpeArea pb15 mb20">
              <dl class="mb10">
                <dt>保费变化(万元)</dt>
                <dd>均值</dd>
              </dl>
              <div class="chartBox">
                <pts-echarts-bar ref="monthBar" :options="setBarOptions"></pts-echarts-bar>
                <!--<img src="images/img_yejidate02.jpg" alt="" class="img_w_02">-->
              </div>
              <ul class="trendAreaTipsYeji c">
                <li style="margin-bottom:.2rem;">工作日</li>
                <li style="margin-bottom:.2rem;">非工作日</li>
              </ul>
            </div>

            <div class="dataArea dataSpeArea pb15">
              <dl class="mb10">
                <dt>保费走势</dt>
              </dl>
              <div class="chartBox">
                <!--<img src="images/img_xubaodata_04.jpg" alt="" class="img_w_03">-->
                <pts-echarts-line ref="monthLineOne" :options="setLineOptions"></pts-echarts-line>
              </div>
              <ul class="trendAreaTips c">
                <li class="f_c_blue mgBot">新保</li>
                <li class="f_c_green mgBot">转保</li>
                <li class="f_c_yellow mgBot">续保</li>
              </ul>
            </div>

            <div class="dataArea dataSpeArea pb20 dataAreaYeji mb120">
              <div class="bor_line"></div>
              <div class="chartBox">
                <!--<img src="images/img_yejidate03.jpg" alt="" class="img_w_03">-->
                <pts-echarts-line ref="monthLineTwo" :options="setLineOptions"></pts-echarts-line>
              </div>
              <ul class="trendAreaTips c">
                <li class="f_c_blue">交强险</li>
                <li class="f_c_green">商业险</li>
              </ul>
            </div>
            <ul class="tuixiuUnderBtnArea c">
              <li :class="{cur:monthTandC.monthCalibreType==='0'}"
                  @click="monthTandC.monthCalibreType='0',changeTax('B')"><a href="javascript:;" otype="button"
                                                                             otitle="签单口径">签单口径</a></li>
              <li :class="{cur:monthTandC.monthCalibreType==='1'}"
                  @click="monthTandC.monthCalibreType='1',changeTax('B')"><a href="javascript:;" otype="button"
                                                                             otitle="企划口径">企划口径</a></li>
            </ul>
          </div>
          <!--<ul class="tuixiuUnderBtnArea c">-->
          <!--<li class="cur"><a href="javascript:;" otype="button" otitle="签单口径">签单口径</a></li>-->
          <!--<li><a href="javascript:;" otype="button" otitle="企划口径">企划口径</a></li>-->
          <!--</ul>-->
          <!-- 月 end -->

          <!-- 年 start -->
          <div v-if="activeTab==='C'" class="year">
            <div class="dataArea pt20 mb20">
              <ul class="analyBtnArea mb20">
                <li :class="{cur:yearTanC.yearType==='0'}" @click.stop="yearTanC.yearType='0',changeTax('C')">税后</li>
                <li :class="{cur:yearTanC.yearType==='1'}" @click.stop="yearTanC.yearType='1',changeTax('C')">税前</li>
              </ul>
              <p class="timeTxt">{{otherData.systemDate}}</p>
              <div class="mb15 c"><!--chartBox-->
                <div class="chartBoxImg echart_top">
                  <!--<img src="images/img_yejidate05.jpg" alt="" class="img_w_01">-->
                  <pts-echarts-pie ref="yearPie" :options="setPieOption"></pts-echarts-pie>
                </div>
                <div class="ul_m">
                  <ul class="chartBoxTxt m_b">
                    <li class="f_c_blue">新保<span class="f_s">年增速<i
                      :class="Number(otherData.newInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.newInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.newInsurancePremCutTotal|NumberThere}}</em></li>
                    <li class="f_c_green">转保<span class="f_s">年增速<i
                      :class="Number(otherData.reiInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.reiInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.reiInsurancePremCutTotal|NumberThere}}</em></li>
                    <li class="f_c_yellow">续保<span class="f_s">年增速<i
                      :class="Number(otherData.renInsuranceGrowthRate)<0?'i_r':'i_g'">{{otherData.renInsuranceGrowthRate}}%</i></span><em
                      class="m_em">{{otherData.renInsurancePremCutTotal|NumberThere}}</em></li>
                  </ul>
                </div>
              </div>
              <div class="chartDataBox">
                <dl>
                  <dt>交强险
                    <span class="f_s">同比<i :class="Number(otherData.yoycompulsoryGrowth)<0?'i_r':'i_g'">{{otherData.yoycompulsoryGrowth}}%</i></span>
                  </dt>
                  <dd>
                    <em :class="{lin_h : yearTanC.yearCalibreType==='1'}">{{otherData.compulsoryInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:yearTanC.yearCalibreType==='1'}">签单量：{{otherData.compulsoryInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
                <dl>
                  <dt>商业险
                    <span class="f_s">同比<i :class="Number(otherData.yoycommercialGrowth)<0?'i_r':'i_g'">{{otherData.yoycommercialGrowth}}%</i></span>
                  </dt>
                  <dd>
                    <em :class="{lin_h : yearTanC.yearCalibreType==='1'}">{{otherData.commercialInsurancePremTotal|NumberThere}}</em>
                    <em :class="{show_catype:yearTanC.yearCalibreType==='1'}">签单量：{{otherData.commercialInsurancePremNumTotal}}</em>
                  </dd>
                </dl>
              </div>
            </div>

            <div class="dataArea dataSpeArea pb15">
              <div style="padding-top: .3rem;">
                <ul class="analyBtnArea mb10">
                  <li :class="{cur:!insAndyear}" @click.stop="insAndyear = !insAndyear,changeTax('C')">保费走势
                  </li>
                  <li :class="{cur:insAndyear}" @click.stop="insAndyear = !insAndyear,changeTax('C')">环比&同比
                  </li>
                </ul>
              </div>
              <!--<dl class="mb10">-->
              <!--<dt>保费走势</dt>-->
              <!--</dl>-->
              <div class="chartBox" v-if="!insAndyear">
                <pts-echarts-line ref="yearLineOne" :options="setLineOptions"></pts-echarts-line>
              </div>
              <div class="chartBox" v-if="insAndyear">
                <span>月增速</span>
                <pts-echarts-line ref="yearLineSone" :options="setLineOptions"></pts-echarts-line>
              </div>
              <ul class="trendAreaTips c">
                <li class="f_c_blue mgBot">新保</li>
                <li class="f_c_green mgBot">转保</li>
                <li class="f_c_yellow mgBot">续保</li>
              </ul>
            </div>
            <div class="dataArea dataSpeArea pb20 dataAreaYeji">
              <div class="bor_line"></div>
              <div class="chartBox" v-if="!insAndyear">
                <pts-echarts-line ref="yearLineTwo" :options="setLineOptions"></pts-echarts-line>
              </div>
              <div class="chartBox" v-if="insAndyear">
                <span>同比</span>
                <pts-echarts-line ref="yearLineStwo" :options="setLineOptions"></pts-echarts-line>
              </div>
              <ul class="trendAreaTips c" :class="{mb120:!insAndyear}">
                <li class="f_c_blue">交强险</li>
                <li class="f_c_green">商业险</li>
              </ul>
            </div>
            <div class="dataArea dataSpeArea pb20 dataAreaYeji" v-if="insAndyear">
              <div class="bor_line"></div>
              <div class="chartBox">
                <span>环比</span>
                <pts-echarts-line ref="yearLineSthree" :options="setLineOptions"></pts-echarts-line>
              </div>
              <ul class="trendAreaTips c mb120">
                <li class="f_c_blue">交强险</li>
                <li class="f_c_green">商业险</li>
              </ul>
            </div>
            <ul class="tuixiuUnderBtnArea c">
              <li :class="{cur:yearTanC.yearCalibreType==='0'}" @click="yearTanC.yearCalibreType='0',changeTax('C')"><a
                href="javascript:;" otype="button" otitle="签单口径">签单口径</a></li>
              <li :class="{cur:yearTanC.yearCalibreType==='1'}" @click="yearTanC.yearCalibreType='1',changeTax('C')"><a
                href="javascript:;" otype="button" otitle="企划口径">企划口径</a></li>
            </ul>
          </div>
          <!-- 年 end -->
        </div>
      </div>
      <!-- main end -->

      <!-- 遮罩层 start -->
      <div class="shade dn" id="shade"></div>
      <!--月份弹窗-->
      <!-- 遮罩层 end -->
    </div>
    <!--</div>-->
    <pts-link-menu v-if="showRight" :show='showPopuPicker' @on-hide="onHide" :trademarkId="trademarkId"
                   :queryValue="monthValue" :queryType="activeTab"></pts-link-menu>
  </section>
</template>

<script>

  import ptsEchartsPie from '../../common/comComponent/echarts/pie.vue'
  import ptsEchartsLine from '../../common/comComponent/echarts/line.vue'
  import ptsEchartsBar from '../../common/comComponent/echarts/bar.vue'
  import Axios from '../../common/js/axiosConfig'
  import API from '../../common/js/comConfig'
  import {chineseMonth} from '../../common/filters/convertDate'
  import {NumberThere} from '../../common/filters/convertAmount'
  import {remInPx, loadEcharts, roundTwo} from '../../common/js/comUtils'
  import ptsTextScroll from '../../common/comComponent/textScroll'
  import Toast from '../../common/comComponent/toast'
  import ptsList from './boardList.vue'
  import ptsLinkMenu from '../../common/comComponent/linkageMenu/index'
  import ptsTabs from '../../common/comComponent/tab'
  import {XProgress} from 'vux'

  const q_green = "image://" + require('./image/QLS.png');
  const q_blue = "image://" + require('./image/QNS.png');
  const q_yell = "image://" + require('./image/QHS.png');
  const date = new Date()
  const YEAR = date.getFullYear();
  const MONTH = date.getMonth() + 1;
  export default {
    name: "inCoreData",
    data() {
      return {
        titleText: '业绩查询',
        showFlag: false,
        showPopuPicker: false,//控制网点隐藏和显示
        branchName: '全国',//机构名称  默认全国
        branchCode: 'QG',//机构code
        provinceCode: '', //省份code
        cityCode: '',//城市code
        isShowBoard: true,
        innerAccountRoleType: '',//角色 1,2,3
        insAndyear: false,//保费走势和同比&环比的状态
        nowData: {
          nowType: '0', //0 税后  1 税前
          signAndCut: {},//税后
          signAndTax: {},//税前
          systemDate: '',
          updateTime: ''
        },
        dayTandC: {
          dayType: '0', //0 税后  1 税前
          dayCalibreType: '0',//0 签单 1 企划
        },
        monthTandC: {
          monthType: '0', //0 税后  1 税前
          monthCalibreType: '0',//0 签单 1 企划
        },
        yearTanC: {
          yearType: '0', //0 税后  1 税前
          yearCalibreType: '0',//0 签单 1 企划
        },
        otherData: {
          signAndCut: {},//签单口径税后
          signAndTax: {},//签单口径税前
          planAndTax: {}, //企划口径税前
          planAndCut: {},// 企划口径税后
          systemDate: '',
          updateTime: '',
          growthRate: '',//增速
          commercialInsurancePremTotal: '0',   //商业险保费
          commercialInsurancePremNumTotal: '0',  //商业险保费笔数
          compulsoryInsurancePremTotal: '0',      //交强险保费
          compulsoryInsurancePremNumTotal: '0',    //交强险保费笔数
          momcommercialGrowth: '',//商业险环比
          momcompulsoryGrowth: '',//交强险环比
          yoycommercialGrowth: '',//商业险同比
          yoycompulsoryGrowth: '',//交强险同比
          newInsuranceGrowthRate: '', //新保增数
          reiInsuranceGrowthRate: '', //转保增数
          renInsuranceGrowthRate: '', //续保增数
        },
        monthValue: `${YEAR}${MONTH > 10 ? MONTH : '0' + MONTH}`,
        yearAndMonth: `${YEAR}-${MONTH > 10 ? MONTH : '0' + MONTH}`,
        nowMonth: `${MONTH > 10 ? MONTH : '0' + MONTH}`,
        dealerIcon: require('../../common/images/allCarIcon.png'),
        activeTab: 'D', //tab栏的类型
        showRight: false,//是否显示头部右边
        trademarkId: '',//车型图标ID
        //饼状图
        setPieOption: {
          color: ['#559EFF', '#60D194', '#FFDB4B'],
          title: [
            {
              text: '总保费(万元)',
              textStyle: {
                fontSize: remInPx(0.26),
                fontWeight: 'normal',
                color: '#666',
              },
              top: '35%',
              left: 'center'
            },
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.5),
                fontWeight: 'normal',
                color: '#333',
              },
              top: '44%',
              left: 'center'
            }

          ],
          grid: {
            left: '0%',
            right: '10%',
            top: '10%',
            bottom: '0%',
            containLabel: true
          }, legend: {
            data: [],
          },
          series: [
            {
              name: '其实没什么用',
              type: 'pie',
              radius: ['60%', '75%'],
              hoverAnimation: false,
              data: [
                {
                  value: '',
                  name: '新保'
                },
                {
                  value: '',
                  name: '续保'
                },
                {
                  value: '',
                  name: '转报'
                }
              ]
            }
          ]
        },
        //柱状图
        setBarOptions: {
          legend: {
            // data: ['工作日','非工作日'],
            // top: 'bottom',
            // left: 'center',
            padding: [0, 0, 0, 0],
            itemWidth: remInPx(0.1),
            itemHeight: remInPx(0.1),
            // itemGap: 20,
            textStyle: {
              fontFamily: 'Microsoft YaHei',
              fontSize: remInPx(0.24),
              color: '#666666',
              lineHeight: remInPx(0.24),
            }
          },
          grid: {
            top: '7%',
            left: '3%',
            right: '4%',
            // bottom: '8%'
          },
          xAxis: [
            {
              type: 'category',
              show: false,
              data: ['工作日', '非工作日']
            }
          ],
          yAxis: [
            {
              type: 'value',
              show: true,
              axisLine: {
                show: false,
              },
              axisTick: {
                show: false,
              },
              splitLine: {
                show: true,
                lineStyle: {
                  color: ['#DBDBDB'],
                  type: 'dotted'
                }
              },
              axisLabel: {
                color: '#999999',
                fontSize: remInPx(0.26)
              }
            }
          ],
          tooltip: {
            trigger: 'axis',
            formatter: '{b}:{c0}',
            axisPointer: {
              animation: false,
              lineStyle: {
                color: '#FE8F46'
              },
            },
            backgroundColor: '#FFE0CB',
            textStyle: {
              color: '#FF954E'
            },
          },
          series: [
            {
              // name: '增速',
              type: 'line',
              // stack: '保费',
              // name:'均值',
              yAxisIndex: 0,
              label: {
                normal: {
                  show: false,
                  position: 'top',
                }
              },
              itemStyle: {
                color: '#FFDB4B'
              },
              lineStyle: {
                color: '#FFDB4B',
                normal: {
                  // width: 3,
                  // shadowColor: 'rgba(0,0,0,0.4)',
                  // shadowBlur: 10,
                  // shadowOffsetY: 10
                }
              },

              data: []
            },
            {
              // name: '工作日',
              // barCategoryGap: '100%',
              // barGap: '-100%', // Make series be overlap
              type: 'bar',
              stack: '保费',
              barWidth: 40,
              data: [],
              label: {
                normal: {
                  position: 'top',
                  show: true,
                  textStyle: {
                    color: '#666666'
                  }
                },
              },
              itemStyle: {
                normal: {
                  position: 'top',
                  color: function (val) {
                    let colorList = ['#549DFF', '#60D194'];
                    return colorList[val.dataIndex];
                  }
                },
                // emphasis: {
                //   position: 'top',
                //   color: ['#549DFF','#60D194']
                // }
              }
            }
          ]
        },
        setLineOptions: {
          color: ['#559EFF', '#60D194', '#FFDB4B'],
          title: [
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.25),
                fontWeight: 'normal',
                color: '#999999',
              },
              top: '80%',
              left: '2%',
            },
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.25),
                fontWeight: 'normal',
                color: '#999999'
              },
              top: '80%',
              left: '78%',
            }
          ],
          tooltip: {
            trigger: 'axis',
            // formatter: function (params) {
            //   if(params.length>2){
            //     return params[0].axisValue + '<br/>' +
            //       params[0].seriesName + ':' + params[0].value + '<br/>'  +
            //       params[1].seriesName + ':' + params[1].value + '<br/>'  +
            //       params[2].seriesName + ':' + params[2].value + '<br/>';
            //   }else{
            //     return params[0].axisValue + '<br/>' +
            //       params[0].seriesName + ':' + params[0].value + '<br/>'  +
            //       params[1].seriesName + ':' + params[1].value + '<br/>';
            //   }
            //
            // },
            axisPointer: {
              animation: false,
              lineStyle: {
                color: '#FE8F46'
              }
            },
            backgroundColor: '#FFE0CB',
            textStyle: {
              color: '#FF954E'
            }
          },
          legend: {
            // data: ['送修', '返修', '三者'],
            left: 'center',
            itemWidth: remInPx(0.1),
            itemHeight: remInPx(0.1),
            itemGap: 40,
            // bottom:20,
            textStyle: {
              fontFamily: 'Microsoft YaHei',
              fontSize: remInPx(0.22),
              color: '#666',
              lineHeight: remInPx(0.22),
            }
          },
          grid: {
            top: '10',
            bottom: '5%',
            right: '1%'
          },
          xAxis: {
            type: 'category',
            boundaryGap: false,
            show: false,
            data: [],
            axisLine: {
              show: false,
            },
            axisTick: {
              show: false,
            }
          },
          yAxis: [
            {
              splitNumber: 5,
              type: 'value',
              show: true,
              axisLine: {
                show: false,
              },
              axisTick: {
                show: false,
              },
              splitLine: {
                show: true,
                lineStyle: {
                  color: ['#DBDBDB'],
                  type: 'dotted'
                }
              },
              axisLabel: {
                color: '#999999',
                fontSize: remInPx(0.26)
              }
            }
          ],
          series: [
            {
              // name: '',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,

              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            },
            {
              // name: '',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            },
            {
              // name: '',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [],
            },
          ]
        },  //折线图
        lineYmaxOne: '',//Y轴最大值 新 转 续
        lineYmaxTwo: '', //Y轴最大值 交强 商业
        lineYMaxThree: '',//年的月增数最大值
        lineYmaxFour: '',//年的同比
        lineYmaxFive: '',//年的环比
        typeList: ['税后', '税前'],  //用于数据埋点
        caList: ['签单口径', '企划口径'],//用于数据埋点
        timeData: { //用于数据埋点
          'D': '-实时-',
          'A': '-日报-',
          'B': '-月报-',
          'C': '-年报-'
        },
        titleList: [{'title': '明星榜'}, {'title': '进取榜'}],
        index: 0,
        tabHeight: .88,//.88 * parseFloat(document.documentElement.style.fontSize),
        institution: {
          provicesName: '',
          provicesCode: '',
          cityName: '',
          cityCode: '',
          branchCode: '',
          dealerName: ''
        },
        percent2: 13
      }
    },
    mounted() {
      // isShowBoard
      // this.innerAccountRoleType = window.dealerData.innerAccountRoleType;
      this.branchCode = window.dealerData.dealerCode || ''; //机构code
      this.branchName = window.dealerData.dealerName || ''; //首次进来角色的机构名称

      window.eventAnalytics("车商端_业绩查询", `${this.caList[this.dayTandC.dayType] + "-实时"}`);
      this.showRight = window.dealerData.dealerType === '1' ? true : false;
      // debugger;
      let reqData = {
        branchCode: this.branchCode || '',//机构编码
        provices: this.provinceCode || '',
        citys: this.cityCode || '',
        queryType: this.activeTab, //查询类型
        queryValue: this.activeTab === 'B' ? self.monthValue || MONTH : undefined, //类型的值
        trademarkId: this.trademarkId || ''
      }
      this.$nextTick(function () {
        this.getRealTime('nowPie', this.nowData.nowType, reqData);
      })
    },
    // watch: {
    //   'otherData.momcommercialGrowth': function (to, from) {
    //     console.log(to);
    //   }
    // },
    methods: {
      /**
       * 返回首页
       * */
      goMenu() {
        Native.requestHybrid({
          tagname: 'backHome'
        });
      },
      /**
       * 获取排行榜的高度
       **/
      getBillLen(val) {
        console.log(val);
        let fontS = parseFloat(document.documentElement.style.fontSize);
        this.tabHeight = 0.88 * val * fontS + 1.46 * fontS + 10;
        console.log(this.tabHeight);
      },
      tabChildChange() {
        console.log('点击了啥');
      },
      /**
       * 获取车行图标
       */
      getIcon() {
        window.eventAnalytics("车商端_业绩查询", "品牌筛选");
        let self = this;
        let obj = {
          city: self.cityCode, //城市
          province: self.provinceCode, //省份
          branchCode: this.branchCode || '',//机构编码
          queryType: this.activeTab, //查询类型
          queryValue: this.activeTab === 'B' ? self.monthValue || YEAR + `${MONTH > 10 ? MONTH : "0" + MONTH}` : undefined //类型的值
        };
        //console.log("开始调用。。。。")
        Native.requestHybrid({
          tagname: 'getDealerIcon',
          param: obj,
          callback: function (req) {
            //console.log("Icon:"+reqData);
            self.dealerIcon = req.data.dealerIcon || "";
            self.trademarkId = req.data.trademarkId || "";
            const reqData = {
              citys: self.cityCode, //城市
              provices: self.provinceCode, //省份
              branchCode: self.branchCode || '',//机构编码
              queryType: self.activeTab,
              queryValue: self.activeTab === 'B' ? self.monthValue || YEAR + `${MONTH > 10 ? MONTH : "0" + MONTH}` : undefined, //类型的值
              trademarkId: self.trademarkId
            }
            //console.log("类型"+this.activeTab)
            if (self.activeTab != 'D') {
              self.getData(self.activeTab, '', reqData);
            } else {
              self.getRealTime('nowPie', self.nowData.nowType, reqData);
            }
          }
        })
      },
      /**
       * 选择机构
       **/
      onHide(closeFlag, msg) {
        let self = this;
        this.showPopuPicker = false;
        if (!msg) {
          return;
        }
        console.log('msg', msg);
        this.isShowBoard = !msg.dealerCode ? true : false;
        if (closeFlag) {
          this.institution = msg;
          this.branchName = `${msg.provicesName + msg.cityName + msg.dealerName}`.replace("暂不选择", '');
          if (msg.dealerName) {
            this.branchName = msg.dealerName.substr(msg.dealerName.indexOf('市') + 1, msg.dealerName.length)
          }
          this.cityCode = msg.cityName === '暂不选择' ? '' : msg.cityCode;
          console.log(this.cityCode + msg.cityName);
          this.provinceCode = msg.provicesCode || '';
          this.branchCode = msg.dealerCode || '';
          if (msg.provicesName && msg.provicesName === '全国') {
            this.cityCode = "";
            this.branchCode = window.dealerData.dealerCode;//"QG";
            this.provinceCode = "";
          }
          const reqData = {
            queryType: self.activeTab, //查询类型,
            queryValue: self.activeTab === 'B' ? self.monthValue || MONTH : '', //类型的值
            provices: this.provinceCode,
            citys: this.cityCode,
            branchCode: this.branchCode,
            trademarkId: this.trademarkId || ''
          }
          console.log(reqData);
          if (this.activeTab === 'D') {
            this.getRealTime('nowPie', this.nowData.nowType, reqData);
          } else {
            this.getData(self.activeTab, '', reqData);
          }
        }

      },
      /**
       * 切换业绩查询tab栏
       * @param val
       */
      changTab(type) {
        //测试
        // this.trademarkId = '1111';
        let self = this;
        let reqData = {};
        if ((type === 'D' || type === 'A' || type === "C") && this.activeTab === type) {
          return
        }
        switch (type) {
          case 'A':
            //window.eventAnalytics("内部端业绩查询", "查看日数据");
            window.eventAnalytics("车商端_业绩查询", `${this.caList[this.dayTandC.dayCalibreType] + this.timeData[type] + this.typeList[this.dayTandC.dayType]}`);
            reqData = {
              queryType: type,
              month: undefined,
              provices: this.provinceCode,
              citys: this.cityCode,
              branchCode: this.branchCode || '',
              trademarkId: this.trademarkId || ''
            };
            this.$nextTick(function () {
              this.getData(type, "", reqData);
            });
            break;
          case 'B':
            //window.eventAnalytics("内部端业绩查询", "查看月份数据");
            this.index = 0;
            let month = date.getMonth() + 1;
            let newMonth = 12 - month === 0 ? 1 : month + 1;
            let year = date.getFullYear();
            // this.yearAndMonth =
            console.log(newMonth);
            if (self.activeTab === type) {
              this.showFlag = true;
              this.$vux.datetime.show({
                value: this.yearAndMonth,
                cancelText: '取消',
                confirmText: '确定',
                format: 'YYYY-MM',
                minYear: year - 1,
                maxYear: year,
                startDate: `${year - 1}-${newMonth > 10 ? newMonth : '0' + newMonth}-01`,
                endDate: `${year}-${month > 10 ? '0' + month : month}-01`,
                onConfirm: (a) => {
                  window.eventAnalytics("车商端_业绩查询", `${this.caList[this.monthTandC.monthCalibreType] + this.timeData[type] + '选择月份' + this.typeList[this.monthTandC.monthType]}`);
                  if (this.yearAndMonth === a) return
                  // this.monthValue = a
                  this.monthValue = a.replace('-', '');
                  // this.monthValue = this.selectMonth
                  this.yearAndMonth = a;
                  reqData = {
                    queryType: type,
                    queryValue: this.monthValue,//`${this.monthValue > 10 ? this.monthValue : '0' + this.monthValue}`,
                    provices: this.provinceCode,
                    citys: this.cityCode,
                    branchCode: this.branchCode || '',
                    trademarkId: this.trademarkId || ''
                  }
                  this.$nextTick(function () {
                    this.getData(type, month, reqData);
                  })
                  // this.getWorkData(type, month, reqData);
                },
                onShow: () => {
                  //window.eventAnalytics("内部端-业绩查询", "点击了切换月份", {'confirmBtn': '点击了切换月份的确认按钮'});
                  this.showDateTime = true;
                },
                onHide: () => {
                  this.showFlag = false;
                  //window.eventAnalytics("内部端-业绩查询", "点击了切换月份", {'cancelBtn': '点击了切换月份的取消按钮'});
                  this.showDateTime = false;
                }
              })
            } else {
              //window.eventAnalytics("内部端业绩查询", "查看实时数据");
              this.index = 0;
              window.eventAnalytics("车商端_业绩查询", `${this.caList[this.monthTandC.monthCalibreType] + this.timeData[type] + this.typeList[this.monthTandC.monthType]}`);
              reqData = {
                queryType: type,
                queryValue: this.monthValue,//year + `${month > 10 ? month : "0" + month}`,//this.monthValue > 10 ? this.monthValue : '0' + this.monthValue || month > 10 ? month : '0' + month,
                provices: this.provinceCode,
                citys: this.cityCode,
                branchCode: this.branchCode || '',
                trademarkId: this.trademarkId || ''
              }
              this.getData(type, this.monthValue, reqData);
              //this.getWorkData(type, month, reqData);
            }
            break;
          case 'C':
            this.index = 0;//恢复到明星榜
            // window.eventAnalytics("内部端业绩查询", "查看年数据");
            window.eventAnalytics("车商端_业绩查询"+`${this.caList[this.yearTanC.yearCalibreType] + this.timeData[type] + this.typeList[this.yearTanC.yearType]}`);
            reqData = {
              queryType: type,
              provices: this.provinceCode,
              citys: this.cityCode,
              branchCode: this.branchCode || '',
              trademarkId: this.trademarkId || ''
            };
            this.$nextTick(function () {
              this.getData(type, "", reqData);
            });
            break;
          case'D':
            window.eventAnalytics("车商端_业绩查询", `${this.typeList[this.nowData.nowType] + "-实时"}`);
            reqData = {
              queryType: type,
              provices: this.provinceCode,
              citys: this.cityCode,
              branchCode: this.branchCode || '',
              trademarkId: this.trademarkId || ''
            }
            this.$nextTick(function () {
              this.getRealTime('nowPie', self.nowData.nowType, reqData);
            })
            break;
          default:
            break;
        }
        this.activeTab = type;
      },
      /**
       * 获取税前 税后 企划 签单
       * */
      changeTax(tType) {
        let self = this;
        let pieData = {};
        if (tType === 'A') {  //日
          window.eventAnalytics("车商端_业绩查询", `${this.caList[this.dayTandC.dayCalibreType] + this.timeData[tType] + this.typeList[this.dayTandC.dayType]}`);
          pieData = this.packPieData(this.dayTandC.dayType, this.dayTandC.dayCalibreType);
          this.getInsData(tType, pieData);
          this.getPieData('dayPie', pieData);
        } else if (tType === 'B') { //月
          window.eventAnalytics("车商端_业绩查询", `${this.caList[this.monthTandC.monthCalibreType] + this.timeData[tType] + this.typeList[this.monthTandC.monthType]}`);
          pieData = this.packPieData(this.monthTandC.monthType, this.monthTandC.monthCalibreType);
          // console.log('pieData',pieData);
          this.getInsData(tType, pieData);
          this.getPieData('monthPie', pieData);
          this.getBarData('monthBar', pieData);
          this.getLineData(['monthLineOne', 'monthLineTwo'], pieData);
        } else if (tType == 'C') {  //年
          window.eventAnalytics("车商端_业绩查询", `${this.caList[this.yearTanC.yearCalibreType] + this.timeData[tType] + this.typeList[this.yearTanC.yearType]}`);
          pieData = this.packPieData(this.yearTanC.yearType, this.yearTanC.yearCalibreType);
          this.getInsData(tType, pieData);
          this.getPieData('yearPie', pieData);
          if (this.insAndyear) {
            this.getLineInsAndYearData(['yearLineSone', 'yearLineStwo', 'yearLineSthree'], pieData);
          } else {
            this.getLineData(['yearLineOne', 'yearLineTwo'], pieData);
          }
        } else {
          window.eventAnalytics("车商端_业绩查询", `${this.typeList[this.nowData.nowType] + "-实时"}`);
          pieData = this.nowData.nowType === '0' ? self.nowData.signAndCut : self.nowData.signAndTax;
          this.getPieData('nowPie', pieData);
        }
      },
      /**
       * 获得pieData 数据
       * ttype 税前 税后
       * ctype 口径类型
       **/
      packPieData(ttype, ctype) {
        console.log(ttype, ctype)
        let self = this;
        let pieData = {};
        if (ttype === '1') {  //税前
          pieData = ctype === '0' ? self.otherData.signAndTax : self.otherData.planAndTax;
        } else {
          pieData = ctype === '0' ? self.otherData.signAndCut : self.otherData.planAndCut;
        }
        return pieData;
      },
      /**
       * 获取实时数据
       * elem 类型
       * type 税前 税后
       **/
      getRealTime(elem, type, reqData) {
        let self = this;
        //"http://localhost:8888/postGetData"
        // "http://localhost:8888/postGetData", {
        //   "path": 'car',
        //   "file": 'queryOuterTimelyCoreData'
        // }
        //API.getWebServiceUrls('queryOuterTimelyCoreData'),reqData
        Axios.post(API.getWebServiceUrls('queryOuterTimelyCoreData'), reqData).then(res => {
          let resData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if ((resData.code === 0 || resData.code === '0') && resData.data && resData.data.signAndCut) {
            self.nowData.signAndCut = resData.data.signAndCut;//税后
            self.nowData.signAndTax = resData.data.signAndTax;//税前
            self.nowData.systemDate = resData.data.systemDate; //系统时间
            self.nowData.updateTime = resData.data.updateTime; //更新时间
            let pieData = type === '0' ? self.nowData.signAndCut : self.nowData.signAndTax;
            this.getPieData(elem, pieData);
          } else {
            Toast(resData.msg || "系统繁忙请稍后重试");
          }
        }).catch(err => {
          console.log(err);
        })
      },
      /*
       * @info 发起ajax请求 并设置图标数据的函数
       * @param type {String}  实时(A) 当月(C) or 当日(B) or 当年(D)
       * @param month {String || Number} 用户选择的月份
       * */
      getData(type, month, reqData) {
        console.log(reqData);
        // this.otherData={};
        let _this = this;
        //API.getWebServiceUrls('queryPreamData')
        // "http://localhost:8888/postGetData", {
        //   "file": "queryOuterPreamData",
        //   "path": "car"
        // }
        //API.getWebServiceUrls('queryOuterPreamData')
        Axios.post(API.getWebServiceUrls('queryOuterPreamData'), reqData).then(res => {
          const resData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (resData.code === 0 || resData.code === '0') {
            //_this.otherData 日 月 年数据
            _this.otherData.systemDate = resData.data.systemDate;
            _this.otherData.updateTime = resData.data.updateTime;
            _this.otherData.yearAndMonth = resData.data.yearAndMonth;
            _this.otherData.planAndCut = resData.data.planAndCut;  //企划
            _this.otherData.planAndTax = resData.data.planAndTax;
            _this.otherData.signAndCut = resData.data.signAndCut;  //签单
            _this.otherData.signAndTax = resData.data.signAndTax;
            // _this.changeTax(type);
            if (type === "B") {
              // this.changeTax(type);
              this.getWorkData(type, month, reqData);
            } else {
              _this.changeTax(type);
            }
          } else {
            Toast('系统繁忙请稍后重试');
          }
        }).catch(err => {
          console.log(err);
        })
      },
      /*
       * @info 发起ajax请求 获取工作日和非工作日数据
       * @param type {String}  实时(A) 当月(C) or 当日(B) or 当年(D)
       * @param month {String || Number} 用户选择的月份
       * */
      //"http://localhost:8888/postGetData", {
      // "file": 'queryInnerCoreDataWorking',
      // "path": 'car'
      //}
      getWorkData(type, month, reqData) {
        const _this = this;
        Axios.post(API.getWebServiceUrls('queryOuterCoreDataWorking'), reqData, {loading: false}).then(res => {
          let resData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          if (resData.code === 0 || resData.code === '0') {
            _this.otherData.planAndCut = Object.assign(_this.otherData.planAndCut, resData.data.planAndCut);  //企划
            _this.otherData.planAndTax = Object.assign(_this.otherData.planAndTax, resData.data.planAndTax);
            _this.otherData.signAndCut = Object.assign(_this.otherData.signAndCut, resData.data.signAndCut);  //签单
            _this.otherData.signAndTax = Object.assign(_this.otherData.signAndTax, resData.data.signAndTax);
            _this.changeTax(type);
          } else {
            Toast('系统繁忙请稍后重试');
          }
        }).catch(err => {
          console.log(err);
        });
      },
      /**
       * 商业险 交强险 环比 同比 保费 笔数等数据复制
       */
      getInsData(type, pieData) {

        if (this.type != 'D') {
          this.dayTandC.growthRate = pieData.growthRate || "0";//增速
          this.otherData.commercialInsurancePremTotal = roundTwo(pieData.commercialInsurancePremTotal);//商业险保费
          this.otherData.commercialInsurancePremNumTotal = pieData.commercialInsurancePremNumTotal;//商业险保费笔数
          this.otherData.compulsoryInsurancePremTotal = roundTwo(pieData.compulsoryInsurancePremTotal);//交强险保费
          this.otherData.compulsoryInsurancePremNumTotal = pieData.compulsoryInsurancePremNumTotal;//交强险保费笔数
          this.otherData.newInsurancePremCutTotal = roundTwo(pieData.newInsurancePremCutTotal);//新保保费
          this.otherData.reiInsurancePremCutTotal = roundTwo(pieData.reiInsurancePremCutTotal);//转保费
          this.otherData.renInsurancePremCutTotal = roundTwo(pieData.renInsurancePremCutTotal);//续保保费
          // if (this.nowMonth !== this.monthValue.slice(4)) {
          this.otherData.momcommercialGrowth = pieData.momcommercialGrowth || 0; //商业险环比
          this.otherData.momcompulsoryGrowth = pieData.momcompulsoryGrowth || 0;//交强险环比
          this.otherData.yoycommercialGrowth = pieData.yoycommercialGrowth || 0; //商业险同比
          this.otherData.yoycompulsoryGrowth = pieData.yoycompulsoryGrowth || 0; //交强想同比
          // }
          this.otherData.newInsuranceGrowthRate = pieData.newInsuranceGrowthRate || 0; //新保增速
          this.otherData.reiInsuranceGrowthRate = pieData.reiInsuranceGrowthRate || 0; //转保增速
          this.otherData.renInsuranceGrowthRate = pieData.renInsuranceGrowthRate || 0; //续保增速
        }
        // console.log((~~this.monthValue.slice(4)-1),(~~this.nowMonth-1));
        // if((~~this.monthValue.slice(4))===(~~this.nowMonth-1)){
        //   this.getElement(pieData);
        // }
      },
      /**
       * 获取同比 环比的 dom
       */
     /* getElement(pieData) {
        if (
          this.$refs.jqxtb &&
          this.$refs.jqxhb &&
          this.$refs.syxtb &&
          this.$refs.syxhb
        ) {
          let jqxtb = this.$refs.jqxtb.getElementsByTagName('i')[0]
          let jqxhb = this.$refs.jqxhb.getElementsByTagName('i')[0]
          let syxtb = this.$refs.syxtb.getElementsByTagName('i')[0]
          let syxhb = this.$refs.syxhb.getElementsByTagName('i')[0]

          jqxtb.innerHTML = pieData.yoycompulsoryGrowth + '%'
          jqxhb.innerHTML = pieData.momcompulsoryGrowth + '%'
          syxtb.innerHTML = pieData.yoycommercialGrowth + '%'
          syxhb.innerHTML = pieData.momcommercialGrowth + '%'

          jqxtb.className = ''
          jqxhb.className = ''
          syxtb.className = ''
          syxhb.className = ''

          pieData.yoycompulsoryGrowth < 0
            ? (jqxtb.className += 'i_r')
            : (jqxtb.className += 'i_g')
          pieData.momcompulsoryGrowth < 0
            ? (jqxhb.className += 'i_r')
            : (jqxhb.className += 'i_g')
          pieData.yoycommercialGrowth < 0
            ? (syxtb.className += 'i_r')
            : (syxtb.className += 'i_g')
          pieData.momcommercialGrowth < 0
            ? (syxhb.className += 'i_r')
            : (syxhb.className += 'i_g')
        }
      },*/
      /**
       * 饼状图
       * @param elem type elem string
       * @param pieData type object
       */
      getPieData(elem, pieData) {
        let self = this;
        let totalPremium = 0;//总保费
        let title = []; //圆的标题
        let realData = pieData;//type === '0' ? self.nowData.signAndCut : self.nowData.signAndTax;
        totalPremium = (roundTwo(Number(realData.newInsurancePremCutTotal)) + roundTwo(Number(realData.reiInsurancePremCutTotal)) + roundTwo(Number(realData.renInsurancePremCutTotal)));
        totalPremium = totalPremium.toFixed(2);

        if (this.activeTab != 'D' && this.activeTab != 'A') {
          let core_color = Number(self.dayTandC.growthRate) < 0 ? "#FE3A3A" : "#2BAF64";
          title = [
            {},
            {
              text: (function (value) {
                if (Number.isNaN(Number(value))) {
                  return value;
                }
                if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
                  return Number(value).toLocaleString();
                } else {
                  return value;
                }
              })(totalPremium)
            },
            {
              //Number(self.dayTandC.growthRate) < 0 ? self.dayTandC.growthRate+"%" :
              text: ((self.activeTab === 'B' ? '月增速' : '年增速') + Number(self.dayTandC.growthRate) + "%"),
              textStyle: {
                fontSize: remInPx(0.23),
                fontWeight: 'normal',
                color: core_color,
              },
              top: '60%',
              left: 'center'
            }
          ];
        } else {
          title = [
            {},
            {
              text: (function (value) {
                if (Number.isNaN(Number(value))) {
                  return value;
                }
                if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
                  return Number(value).toLocaleString();
                } else {
                  return value;
                }
              })(totalPremium)
            }, {
              text: ''
            }
          ];
        }
        // if(self.activeTab!='D'){
        // }else{
        //   totalPremium =()
        // }
        this.$nextTick(function () {
          self.$refs[elem].setData(function (echarts) {
            echarts.setOption({
              title: title,
              series: [
                {
                  data: [
                    {
                      value: realData.newInsurancePremCutTotal,
                      name: Number(realData.newInsurancePremCutTotal) === 0 ? "" : roundTwo(realData.newInsurancePremCutTotal),
                      label: {show: Number(realData.newInsurancePremCutTotal) === 0 ? false : true},
                      labelLine: {
                        show: Number(realData.newInsurancePremCutTotal) === 0 ? false : true,
                        length: 5,
                        length2: 10
                      },
                      itemStyle: {color: '#559EFF'} //强制设置,如果value 数值一样,样色会是同一个
                    },
                    {
                      value: realData.reiInsurancePremCutTotal,
                      name: Number(realData.reiInsurancePremCutTotal) === 0 ? "" : roundTwo(realData.reiInsurancePremCutTotal),
                      label: {show: Number(realData.reiInsurancePremCutTotal) === 0 ? false : true},
                      labelLine: {
                        show: Number(realData.reiInsurancePremCutTotal) === 0 ? false : true,
                        length: 5,
                        length2: 10
                      },
                      itemStyle: {color: '#60D194'}
                    },
                    {
                      value: realData.renInsurancePremCutTotal,
                      name: Number(realData.renInsurancePremCutTotal) === 0 ? "" : roundTwo(realData.renInsurancePremCutTotal),
                      label: {
                        show: Number(realData.renInsurancePremCutTotal) === 0 ? false : true,
                      },
                      labelLine: {
                        show: Number(realData.renInsurancePremCutTotal) === 0 ? false : true,
                        length: 5,
                        length2: 10
                      },
                      itemStyle: {color: '#FFDB4B'}
                    }
                  ]
                }
              ]
            })
          })

        })
      }
      ,
      getBarData(elem, pieData) {
        let self = this;
        console.log(pieData);
        //工作日和非工作日数据
        let insuranceAmountChange = pieData.insuranceAmountChange;
        let dayTotalArr = [], dayAvgArr = [];
        dayTotalArr = [roundTwo(insuranceAmountChange.totalAmountWeekday), roundTwo(insuranceAmountChange.totalAmountNonWeekday)];
        dayAvgArr = [roundTwo(insuranceAmountChange.averageWeekday), roundTwo(insuranceAmountChange.averageNonWeekday)];
        let maxData = Array.prototype.concat.call([], dayTotalArr);
        let maxValue = ~~Math.max.apply(Math, maxData);
        this.$nextTick(function () {
          self.$refs[elem].setData(function (echarts) {
            echarts.setOption({
              series: [{
                data: dayAvgArr
              }, {
                data: dayTotalArr,
              }],
              yAxis: {
                minInterval: Math.ceil(maxValue / 4)//+(20-Math.ceil(maxValue / 4)%10)
              },
            })
          })
        });
      }
      ,
      getLineData(elem, pieData) {
        console.log(elem);
        //获得X轴数据
        let self = this;
        let xData = [];
        let arrOne = [], newInsur = [], reiInsur = [], renInsur = [];
        let arrtwo = [], compul = [], commerc = [];
        let totalArr = [];
        if (pieData.premiumQueryResults && pieData.premiumQueryResults.length > 0) {
          for (let n = 0; n < pieData.premiumQueryResults.length; n++) {
            xData.push(pieData.premiumQueryResults[n].dataTime);
            newInsur.push(roundTwo(pieData.premiumQueryResults[n].newInsurancePrem));//新保保费
            reiInsur.push(roundTwo(pieData.premiumQueryResults[n].reiInsurancePrem));//转保保费
            renInsur.push(roundTwo(pieData.premiumQueryResults[n].renInsurancePrem));//续保保费
            compul.push(roundTwo(pieData.insPremiumResults[n].compulsoryInsurancePrem));//交强险
            commerc.push(roundTwo(pieData.insPremiumResults[n].commercialInsurancePrem));//商业险
          }
        }
        let findMaxOne = Array.prototype.concat.call([], newInsur, reiInsur, renInsur);
        this.lineYmaxOne = ~~Math.max.apply(Math, findMaxOne);
        let findMaxTwo = Array.prototype.concat.call([], compul, commerc);
        this.lineYmaxTwo = ~~Math.max.apply(Math, findMaxTwo);
        arrOne.push({data: newInsur, type: 'line', name: '新保'}, {
          data: reiInsur,
          type: 'line',
          name: '转保',
          showSymbol: true
        }, {data: renInsur, type: 'line', name: '续保'});
        arrtwo.push({data: compul, type: 'line', name: '交强险'}, {
          data: commerc,
          type: 'line',
          name: '商业险'
        });
        totalArr.push(arrOne, arrtwo);
        elem.forEach((v, i) => {
          this.$nextTick(function () {
            self.$refs[v].setData(function (echarts) {
              echarts.setOption({
                xAxis: {
                  data: xData
                },
                legend: {
                  data: [
                    {name: self.CZDA, icon: q_green},
                    {name: self.TXDA, icon: q_yell},
                    {name: self.WXDA, icon: q_blue}]
                },
                yAxis: {
                  minInterval: Math.ceil((i === 0 ? self.lineYmaxOne : self.lineYmaxTwo) / 4)
                },
                title: [
                  {
                    text: xData[0],
                    bottom: '5px'
                    //text: `01` // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                  },
                  {
                    text: xData[xData.length - 1],
                    bottom: '5px'
                    //text: `${xDatas.length > 9 ? xDatas.length : '0' + xDatas.length}` // ${~~xStart > 9 ? xStart : '0' + xStart}.${xData.length > 9 ? xData.length : '0' + xData.length}
                  }
                ],
                tooltip: {
                  trigger: 'axis',
                  formatter: function (a) {
                    let arr = [
                      a.length > 0 ? a[0].axisValue + '<br/>' : ''
                    ];
                    a.forEach(v => {
                      arr.push(`${v.seriesName}: ${v.value}<br/>`);
                    })
                    return arr.join('');
                  },
                  axisPointer: {
                    animation: false,
                    lineStyle: {
                      color: '#FE8F46'
                    }
                  },
                  backgroundColor: '#FFE0CB',
                  textStyle: {
                    color: '#FF954E'
                  }
                },
                series: totalArr[i]
              });

            });
          })
        });


      },

      getLineInsAndYearData(elem, pieData) {
        console.log(elem);
        //获得X轴数据
        let self = this;
        let xData = [];
        // Y 交强险 L 商业险  mom环比  yoy 同比
        //交强险的环比 交强险的同比 商业险的环比 商业险的同比
        let momYArr = [], yoyYArr = [], momLArr = [], yoyLArr = [], arrThree = [], arrFour = [];
        let newMRate = [], reiMRate = [], renMRate = [], yearInMSpeedArr = [];
        let totalArr = [];
        if (pieData.premiumQueryResults && pieData.premiumQueryResults.length > 0) {
          for (let n = 0; n < pieData.premiumQueryResults.length; n++) {
            xData.push(pieData.premiumQueryResults[n].dataTime);
            momYArr.push(pieData.insPremiumResults[n].momcompulsoryGrowth); //交强险环比
            yoyYArr.push(pieData.insPremiumResults[n].yoycompulsoryGrowth); //交强险同比
            momLArr.push(pieData.insPremiumResults[n].momcommercialGrowth); //商业险环比
            yoyLArr.push(pieData.insPremiumResults[n].yoycommercialGrowth); //商业险同比
            newMRate.push(pieData.premiumQueryResults[n].newMonGrowthRate); //年的新保月增数
            reiMRate.push(pieData.premiumQueryResults[n].reiMonGrowthRate); //年的转保月增数
            renMRate.push(pieData.premiumQueryResults[n].renMonGrowthRate); //年的续保月增数
          }
        }
        let findMaxThree = Array.prototype.concat.call([], newMRate, reiMRate, renMRate);
        this.lineYMaxThree = ~~Math.max.apply(Math, findMaxThree);
        let findMaxFour = Array.prototype.concat.call([], yoyYArr, yoyLArr);
        this.lineYmaxFour = ~~Math.max.apply(Math, findMaxFour);
        let findMaxFive = Array.prototype.concat.call([], momYArr, momLArr);
        this.lineYmaxFive = ~~Math.max.apply(Math, findMaxFive);
        // let newMRateArr = [], reiMRateArr = [], renMRateArr = [], newMomYArr = [],
        //   newYoyYArr = [], newMomLArr = [], newYoyLArr = [];
        // let mArr = [newMRate, reiMRate, renMRate], yArr = [momYArr, momLArr], mArr = [yoyYArr, yoyLArr];
        // for (var i = 0; i < mArr.length; i++) {
        //   mArr[i].forEach((v, k) => {
        //
        //   })
        // }
        // newMRate.forEach((v, i) => {
        //   newMRateArr.push(newMRate[i]);
        // });
        // reiMRate.forEach((v, i) => {
        //   newMRateArr.push(reiMRate[i]);
        // })
        // renMRate.forEach((v, i) => {
        //   newMRateArr.push(renMRate[i]);
        // })
        //年的月增数折线图
        yearInMSpeedArr.push({data: newMRate, type: 'line', name: '新保', showSymbol: true}, {
          data: reiMRate,
          type: 'line',
          name: '转保',
          showSymbol: true
        }, {data: renMRate, type: 'line', name: '续保', showSymbol: true});
        //交强险 商业险同比
        arrThree.push({data: yoyYArr, type: 'line', name: '交强险', showSymbol: true}, {
          data: yoyLArr,
          type: 'line',
          name: '商业险',
          showSymbol: true
        });
        //交强险 商业险环比
        arrFour.push({data: momYArr, type: 'line', name: '交强险', showSymbol: true}, {
          data: momLArr,
          type: 'line',
          name: '商业险',
          showSymbol: true
        });
        totalArr.push(yearInMSpeedArr, arrThree, arrFour);
        elem.forEach((v, i) => {
          this.$nextTick(function () {
            self.$refs[v].setData(function (echarts) {
              echarts.setOption({
                xAxis: {
                  data: xData
                },
                legend: {
                  data: [
                    {name: self.CZDA, icon: q_green},
                    {name: self.TXDA, icon: q_yell},
                    {name: self.WXDA, icon: q_blue}]
                },
                yAxis: {
                  minInterval: function () {
                    switch (i) {
                      case 0:
                        return Math.ceil(self.lineYMaxThree / 4); //年月增速
                        break;
                      case 1:
                        return Math.ceil(self.lineYmaxFour / 4); //同比
                        break;
                      case 2:
                        return Math.ceil(self.lineYmaxFive / 4); //环比
                        break;
                      default:
                        break;
                    }
                  }//Math.ceil((i === 0 ? self.lineYmaxOne : self.lineYmaxTwo) / 4)
                },
                title: [
                  {
                    text: xData[0],
                    bottom: '5px'
                    //text: `01` // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                  },
                  {
                    text: xData[xData.length - 1],
                    bottom: '5px'
                    //text: `${xDatas.length > 9 ? xDatas.length : '0' + xDatas.length}` // ${~~xStart > 9 ? xStart : '0' + xStart}.${xData.length > 9 ? xData.length : '0' + xData.length}
                  }
                ],
                tooltip: {
                  trigger: 'axis',
                  formatter: function (a) {
                    let arr = [
                      a.length > 0 ? a[0].axisValue + '<br/>' : ''
                    ];
                    a.forEach(v => {
                      arr.push(`${v.seriesName}: ${v.value}%<br/>`);
                    })
                    return arr.join('');
                  },
                  axisPointer: {
                    animation: false,
                    lineStyle: {
                      color: '#FE8F46'
                    }
                  },
                  backgroundColor: '#FFE0CB',
                  textStyle: {
                    color: '#FF954E'
                  }
                },
                series: totalArr[i]
              });

            });
          })
        });


      }
    }
    ,

    beforeRouteEnter(to, from, next) {

      loadEcharts(next);
      // next(()=>{
      //   let queryName= this.$router.query;
      //   console.log(queryName);
      // });
    }
    ,
    components: {
      ptsTabs,
      ptsTabItem: ptsTabs.Item,
      ptsList,
      ptsEchartsPie,
      ptsEchartsLine,
      ptsEchartsBar,
      ptsTextScroll,
      ptsLinkMenu
    }
  }
</script>

<style scoped lang="less">
  .mb120 {
    margin-bottom: 1.2rem;
  }

  .ul_m {
    /*padding-bottom: .8rem;*/
    /*margin-left: .3rem;*/
  }

  .m_b {
    width: 100%;
    height: 1rem;
    line-height: 1rem;
    padding-bottom: 1.45rem;
  }

  .m_b li {
    /*border-bottom: .01rem solid #eee;*/
    /*width: 100%;*/
    height: .8rem;
    line-height: 0.8rem;
    overflow: hidden;
    padding: 0 .6rem;
    color: #333333;
    border-bottom: .02rem solid #eee;
    font-size: .28rem
  }

  .m_em {
    float: right;
    text-align: right;
    margin-right: -.3rem;
  }

  .m_b li :before {
    margin-left: .3rem;
  }

  .f_s {
    margin-left: 0.8rem;
    font-size: .2rem;
    color: #999999;
  }

  .f_s_m {
    margin-left: 0.8rem;
    font-size: .2rem;
    color: #999999;
  }

  .i_g {
    color: #2BAF64;
    margin-left: .05rem;
  }

  .i_r {
    color: #FE3A3A;
    margin-left: .05rem;
  }

  .insideYejiWrap .chartBoxTxt {
    float: left;
    /* width: .8rem; */
    margin-top: .3rem;
    margin-left: 0rem;
  }

  .dataHeard_right {
    display: inline-block;
    height: .35rem;
    right: .15rem !important;
    top: 50%;
    margin-top: -.175rem;
    font-size: .24rem;
    color: #444;
    padding-right: .2rem;
  }

  .insideYejiWrap .allSeries {
    position: fixed;
    right: .8rem;
    margin-right: .85rem;
    width: .6rem;
    height: .6rem;
    margin-top: .15rem;
    line-height: .6rem;
    font-size: .2rem;
    color: #454545;
    text-align: center;
    border-radius: 50%;
    background: #E9E9E9;
  }

  .insideYejiWrap .dataHeard_right:before {
    top: 50%;
    width: .13rem;
    height: .4rem !important;
    margin-top: -.04rem !important;
    background: url(../../common/images/icon_arrow_down.png) no-repeat 0 0;
    background-size: .14rem .12rem;
    transform: rotate(0deg) !important;
    -ms-transform: rotate(180deg);
    -moz-transform: rotate(180deg);
    -webkit-transform: rotate(180deg);
    -o-transform: rotate(180deg);
  }

  .echart_top {
    margin-top: .1rem;
  }

  .series_icon {
    position: absolute;
    top: 50%;
    right: 1.32rem;
    width: .6rem;
    height: .6rem;
    margin-top: -.3rem;
    line-height: .6rem;
    font-size: .2rem;
    color: #454545;
    text-align: center;
    border-radius: 50%;
    background: #E9E9E9;
  }

  .show_catype {
    display: none !important;
  }

  .lin_h {
    line-height: .85rem !important;
  }

  .insideYejiWrap .trendAreaTipsYeji {
    width: 4.1rem;
    margin: 0 auto;
    padding-left: .25rem;
    padding-bottom: .05rem;
  }

  /*.bar-area {*/
  /*width: 100%;*/
  /*height: 5rem !important;*/
  /*}*/
  /*.c:after {*/
  /*padding-top: .3rem;*/
  /*}*/

  .mb120 {
    margin-bottom: 1.2rem !important;
  }

  .mgBot {
    margin-bottom: .35rem;
  }
.f_s_m,.f_s{
  margin-left: .4rem;
}
.self{
  display: flex;
  .selfLeft{
    flex:75;
    overflow: hidden;
    display: flex;
    .left{
      flex: 4;
      overflow: hidden;
    }
    .right{
      flex: 3;
      overflow: hidden;
      .f_s_m{
        margin: 0 .4rem 0 0;
      }
    }
  }
  .selfRight{
    flex:25;
    overflow: hidden;
  }
}
.year{
  .f_s{
    margin-left: 1.2rem
  }
}
</style>
