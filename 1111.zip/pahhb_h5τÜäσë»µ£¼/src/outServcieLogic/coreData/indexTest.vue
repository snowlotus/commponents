<template>
  <section class="box" style="overflow-x: hidden;">
    <pts-header titleText="业绩查询" leftFlag @on-left="goMenu()" :showRight="showRight">
      <div slot="right" class="flexBox">
        <img :src="dealerIcon" class="titleAllCar" @touchstart="getIcon"/>
        <a href="javascript:;" class="dataHeard_right txhidden coreHeader" @click.stop="showPopuPicker=true;"
           v-finger:long-tap="showNoun" >
          {{branchName}}
        </a>
      </div>
    </pts-header>
    <div class="bt_top">
      <ul class="ytdDate c clear">
        <li :class="{'on':activeTab==='A'}" @click.prevent="changeTab('A')">日</li>
        <li :class="{'on':activeTab==='B','active': showDateTime}" @click.prevent="changeTab('B')">
          <p v-if="monthValue === ''">月<i></i></p>
          <p v-else>{{monthValue | chineseMonth}}月<i></i></p>
        </li>
        <li :class="{'on':activeTab==='C'}" @click.prevent="changeTab('C')">年</li>
      </ul>
    </div>
    <main class="bgwhite">
      <div class="pageHtml">
        <!--当日-->
        <div class="pageTab btop" v-if="activeTab==='A'">
          <div class="premium">
            <p>{{sysTimes}}</p>
            <pts-echarts-pie :options="pieOptions" ref="pie"></pts-echarts-pie>
          </div>
          <ul class="carHtml boxsh1 c clear">
            <li class="por">
              <div class="core_content">
                <div class="core_left carHtml_text"><i class="new_color"></i>新保</div>
                <div class="core_right carHtml_text_num">
                  <p class="font_center">{{pieAreaData.newInsurance | NumberThere}}</p>
                  <p>签单量：{{pieAreaData.newNum}}</p></div>
              </div>
            </li>
            <li class="por">
              <div class="core_content">
                <div class="core_left carHtml_text"><i class="z_color"></i>转保</div>
                <div class="core_right carHtml_text_num">
                  <p class="font_center">{{pieAreaData.turnInsurance | NumberThere}}</p>
                  <p>签单量：{{pieAreaData.turnNum}}</p></div>
              </div>
            </li>
            <li class="por">
              <div class="core_content">
                <div class="core_left carHtml_text"><i class="x_color"></i>续保</div>
                <div class="core_right carHtml_text_num">
                  <p class="font_center">{{pieAreaData.addInsurance | NumberThere}}</p>
                  <p>签单量：{{pieAreaData.addNum}}</p></div>
              </div>
            </li>
          </ul>

          <div class="billboardHtml boxsh2 por" v-if="showRight&&isShowBoard">
            <div class="pageTab_year_hr"></div>
            <pts-tabs :titleList="titleList" @on-child-change="tabChildChange" v-model="index" :height="tabHeight">
              <div class="c clear billboardHtml_th" slot="boardList" style="border-bottom: .02rem solid #eee;">
                <div class="fl">名称</div>
                <div class="fl">
                  <p class="fl">总保费(万元)</p>
                  <p class="fl">签单量</p>
                </div>
              </div>
              <pts-tab-item>
                <pts-list :active="index===0" :flagName="0" :institution="institution" :trademarkId='trademarkId'
                          @billLen="getBillLen"></pts-list>
              </pts-tab-item>
              <pts-tab-item>
                <pts-list :active="index===1" :flagName="1" :institution="institution" :trademarkId='trademarkId'
                          @billLen="getBillLen"></pts-list>
              </pts-tab-item>
            </pts-tabs>
            <div class="pageTab_year_hr"></div>
          </div>
        </div>
        <!--当月-->
        <div class="pageTab btop" v-else-if="activeTab==='B'">
          <div class="premium">
            <p>{{sysTimes}}</p>
            <pts-echarts-pie :options="pieOptions" ref="monthPie"></pts-echarts-pie>
          </div>
          <ul class="carHtml boxsh1 c clear">
            <li class="por">
              <div class="core_content">
                <div class="core_left carHtml_text"><i class="new_color"></i>新保</div>
                <div class="core_right carHtml_text_num">
                  <p class="font_center">{{pieAreaData.newInsurance | NumberThere}}</p>
                  <p>签单量：{{pieAreaData.newNum}}</p></div>
              </div>
            </li>
            <li class="por">
              <div class="core_content">
                <div class="core_left carHtml_text"><i class="z_color"></i>转保</div>
                <div class="core_right carHtml_text_num">
                  <p class="font_center">{{pieAreaData.turnInsurance | NumberThere}}</p>
                  <p>签单量：{{pieAreaData.turnNum}}</p></div>
              </div>
            </li>
            <li class="por">
              <div class="core_content">
                <div class="core_left carHtml_text"><i class="x_color"></i>续保</div>
                <div class="core_right carHtml_text_num">
                  <p class="font_center">{{pieAreaData.addInsurance | NumberThere}}</p>
                  <p>签单量：{{pieAreaData.addNum}}</p></div>
              </div>
            </li>
          </ul>
          <div class="pageTab_year_hr"></div>
          <div class="trend boxsh1">
            <p class="dateTime_title">保费走势</p>
            <div class="pillarChart borno">
              <div class="pillarChart_img">
                <pts-echarts-line :options="setLineOption" ref="monthLine"></pts-echarts-line>
              </div>
            </div>
          </div>
        </div>
        <!--当年-->
        <div class="pageTab btop" v-else-if="activeTab==='C'">
          <div class="premium">
            <p>{{sysTimes}}</p>
            <pts-echarts-pie :options="pieOptions" ref="yearPie"></pts-echarts-pie>
          </div>
          <ul class="carHtml boxsh1 c clear">
            <li class="por">
              <div class="core_content">
                <div class="core_left carHtml_text"><i class="new_color"></i>新保</div>
                <div class="core_right carHtml_text_num">
                  <p class="font_center">{{pieAreaData.newInsurance | NumberThere}}</p>
                  <p>签单量：{{pieAreaData.newNum}}</p></div>
              </div>
            </li>
            <li class="por">
              <div class="core_content">
                <div class="core_left carHtml_text"><i class="z_color"></i>转保</div>
                <div class="core_right carHtml_text_num">
                  <p class="font_center">{{pieAreaData.turnInsurance | NumberThere}}</p>
                  <p>签单量：{{pieAreaData.turnNum}}</p></div>
              </div>
            </li>
            <li class="por">
              <div class="core_content">
                <div class="core_left carHtml_text"><i class="x_color"></i>续保</div>
                <div class="core_right carHtml_text_num">
                  <p class="font_center">{{pieAreaData.addInsurance | NumberThere}}</p>
                  <p>签单量：{{pieAreaData.addNum}}</p></div>
              </div>
            </li>
          </ul>
          <div class="pageTab_year_hr"></div>
          <div class="trend boxsh1">
            <p class="dateTime_title">保费走势</p>
            <div class="pillarChart borno">
              <div class="pillarChart_img">
                <pts-echarts-line :options="setLineOption" ref="yearLine"></pts-echarts-line>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <pts-link-menu :show='showPopuPicker' @on-hide="onHide"></pts-link-menu>
  </section>
</template>

<script>
  import ptsEchartsPie from '../../common/comComponent/echarts/pie.vue'
  import ptsEchartsLine from '../../common/comComponent/echarts/line.vue'
  import {PopupPicker} from 'vux'
  import ptsList from './boardList.vue'
  import ptsLinkMenu from '../../common/comComponent/linkageMenu/index'
  import ptsTabs from '../../common/comComponent/tab'
  import Toast from '../../common/comComponent/toast'
  import {remInPx, loadEcharts} from '../../common/js/comUtils'
  import Axios from '../../common/js/axiosConfig'
  import API from '../../common/js/comConfig'
  import '../../common/filters/convertDate'
  import '../../common/filters/convertAmount'
  const date = new Date()
  const YEAR = date.getFullYear();
  const MONTH = date.getMonth() + 1;
  export default {
    name: "coreData",
    data() {
      return {
        activeTab: 'A',
        monthValue: '',
        branchName: '',
        showRight: true,
        pieOptions: {
          title: [
            {
              text: '总保费(万元)',
              textStyle: {
                fontSize: remInPx(0.26),
                fontWeight: 'normal',
                color: '#666',
              },
              top: '36%',
              left: 'center'
            },
            {
              text: '',
              textStyle: {
                fontSize: remInPx(0.5),
                fontWeight: 'normal',
                color: '#333',
              },
              top: '50%',
              left: 'center'
            }
          ],
          color: ['#60D194', '#FFDB4B', '#559EFF'],
          grid: {
            left: '0%',
            right: '0%',
            top: '0%',
            bottom: '0%',
            containLabel: false
          },
          series: [
            {
              name: '其实没什么用',
              type: 'pie',
              radius: ['75%', '90%'],
              label: {
                normal: {
                  show: false
                },
                emphasis: {
                  show: false
                }
              },
              hoverAnimation: false,
              data: [
                {
                  value: '',
                  name: '新保'
                },
                {
                  value: '',
                  name: '续保'
                },
                {
                  value: '',
                  name: '转报'
                }
              ]
            }
          ]
        },
        setLineOption: {
          color: ['#85E4B1', '#FFDB4B', '#5284FF'],
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              animation: false,
              lineStyle: {
                color: '#FE8F46'
              },
            },
//            position : function (point, params, dom) {
//              var posDis = window.innerWidth - dom.offsetWidth;
//              return posDis < point[0] ? [posDis, '10%'] : [point[0], '10%'];
//            },
            backgroundColor: '#FFE0CB',
            textStyle: {
              color: '#FF954E'
            },
            formatter: function (a, b, c) {
              let arr = [
                a.length > 0 ? a[0].axisValue + '<br/>' : ''
              ];
              a.forEach(v => {
                arr.push(`${v.seriesName}: ${v.value} 万<br/>`);
              })
              return arr.join('');
            }
          },
          legend: {
            data: ['新保', '转保', '续保'],
            top: 'bottom',
            left: 'center',
            itemWidth: remInPx(0.1),
            itemHeight: remInPx(0.1),
            //itemGap:22,
            textStyle: {
              fontFamily: 'Microsoft YaHei',
              fontSize: remInPx(0.22),
              color: '#666',
              lineHeight: remInPx(0.22),
              padding: [0, remInPx(0.1), 0, remInPx(0.1)]
            }
          },
          grid: {
            top: '12%',
            bottom: '10%'
          },
          xAxis: {
            type: 'category',
            boundaryGap: false,
            show: false,
            data: [],
            axisLine: {
              show: false,
            },
            axisTick: {
              show: false,
            }
          },
          yAxis: [
            {
//              name: '万元',
              type: 'value',
              show: true,
              axisLine: {
                show: false,
              },
              axisTick: {
                show: false,
              },
              splitLine: {
                show: true,
                lineStyle: {
                  color: ['#DBDBDB'],
                  type: 'dotted'
                }
              },
              axisLabel: {
                color: '#999999',
                fontSize: remInPx(0.26)
              }
            }
          ],
          series: [
            {
              name: '新保',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            },
            {
              name: '转保',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: []
            },
            {
              name: '续保',
              type: 'line',
              symbol: 'circle',
              showSymbol: false,
              hoverAnimation: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              data: [],
            },
          ]
        },
        pieAreaData: {},
        lineArrs: [],
        nowMonth: '',//当前月份
        yearAndMonth: '',//当前服务器返回时间
        sysTimes: '',
        showPopuPicker: false,
        show: false,
        titleList: [{'title': '明星榜'}, {'title': '进取榜'}],
        index: 0,
        tabHeight: 0,//.88 * parseFloat(document.documentElement.style.fontSize),
        insDataList: [],
        isShowBoard: true,
        provinceCode: '',//省份code
        cityCode: '', //城市code
        dealerCode: '', //机构code
        institution: {
          provicesName: '',
          provicesCode: '',
          cityName: '',
          cityCode: '',
          dealerCode: '',
          dealerName: ''
        },
        dealerIcon: require('../../common/images/allCarIcon.png'),
        trademarkId: '', //车型图标id
        showDateTime: false, //月份图标
        lineYmax: '', //y轴刻度线
        selectMonth: ''

      }
    },
    methods: {
      /**
       *返回主界面
       **/
      goMenu() {
        Native.requestHybrid({
          tagname: 'backHome'
        })
      },
      /**
       * 长按显示具体网点名称
       * */
      showNoun(evt){
        Toast(this.branchName);
      },
      /*
       * @info 切换tab 选择 当日(A) 当月(B) 当年(C)
       * @param type {String} A or B or C
       * */
      changeTab(type) {
        if ((type === 'A' || type === 'C') && this.activeTab === type) {
          return
        }
//        this.queryTimeType =  type;
        const year = date.getFullYear()
        let reqData = {};
        if (type === 'B') {
          window.eventAnalytics("业绩查询", "查看当月数据");
          this.index = 0; //恢复到明星榜
          let month = date.getMonth() + 1;
          if (this.activeTab === type) {
            this.$vux.datetime.show({
              value: this.activeMonth,
              cancelText: '取消',
              confirmText: '确定',
              format: 'YYYY-MM',
              minYear: year,
              maxYear: year,
              startDate: `${year}-01-01`,
              endDate: `${year}-${month > 10 ? '0' + month : month}-01`,
              onConfirm: (a) => {
                window.eventAnalytics("业绩查询", "点击了切换月份");
                if (this.activeMonth === a) return
                this.activeMonth = a
                this.selectMonth = a.substr(a.indexOf('-') + 1)
                this.monthValue = this.selectMonth
                this.yearAndMonth = `${this.activeMonth}`
                reqData = {
                  queryType: 'B',
                  queryValue: this.monthValue,
                  provices: this.provinceCode || '',
                  citys: this.cityCode || '',
                  dealerCode: this.dealerCode || '',
                  trademarkId: this.trademarkId || ''
                }
                this.getData('B', month, reqData)
              },
              onShow: () => {
                window.eventAnalytics("业绩查询", "点击了切换月份", {'confirmBtn': '点击了切换月份的确认按钮'});
                this.showDateTime = true;
              },
              onHide: () => {
                window.eventAnalytics("业绩查询", "点击了切换月份", {'cancelBtn': '点击了切换月份的取消按钮'});
                this.showDateTime = false;
              }
            })
          } else {
            reqData = {
              queryType: 'B',
              queryValue: this.selectMonth || month,
              provices: this.provinceCode || '',
              citys: this.cityCode || '',
              dealerCode: this.dealerCode || '',
              trademarkId: this.trademarkId || ''
            }
            this.getData('B', month, reqData)
          }
        } else if (type === 'C') {
          window.eventAnalytics("业绩查询", "查看当年数据");
          this.index = 0;//恢复到明星榜
          reqData = {
            queryType: 'C',
            queryValue: '',
            provices: this.provinceCode || '',
            citys: this.cityCode || '',
            dealerCode: this.dealerCode || '',
            trademarkId: this.trademarkId || ''
          }
          this.getData('C', '', reqData);
        } else {
          window.eventAnalytics("业绩查询", "查看当日数据");
          reqData = {
            queryType: 'A',
            provices: this.provinceCode || '',
            citys: this.cityCode || '',
            dealerCode: this.dealerCode || '',
            trademarkId: this.trademarkId || ''
          }
          this.getData('A', '', reqData);
        }
        this.activeTab = type
      },
      /**
       * 获取月份X轴
       * */
      getLineXData(month, day = 30) {
        let arr = [];
        for (let n = 0; n < day; n++) {
          arr.push(`${month}-${(n + 1) < 10 ? ("0" + (n + 1)) : (n + 1)}`)
        }
        return arr;
      },
      /**
       * 获取年X轴
       * */
      getLineXYearData(month = 12) {
        let arr = [];
        for (let n = 0; n < month; n++) {
          arr.push(`${ (n + 1) < 10 ? '0' + (n + 1) : n + 1}` + '月')
        }
        return arr;
      },
      /*
       * @info 发起ajax请求 并设置图标数据的函数
       * @param type {String} 当月(B) or 当日(A) or 当年(C)
       * @param month {String || Number} 用户选择的月份
       * */
      getData(type, month, reqData) {
        const _this = this
        // 'http://localhost:8888/index?id=queryPreamData&path=car&dateFrom=20171030'
        Axios.post(API.getWebServiceUrls('queryPreamData'), reqData).then(res => {
          const data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          switch (data.code) {
            case 0:
              _this.pieAreaData = {};
              _this.pieAreaData = {
                newInsurance: (data.data.newInsurancePremCutTotal / 10000 || 0).toFixed(2), // 新保
                newNum: data.data.newInsurancePremNumTotal || 0, //新保单数
                turnInsurance: (data.data.reiInsurancePremCutTotal / 10000 || 0).toFixed(2), // 转保
                turnNum: data.data.reiInsurancePremNumTotal || 0,//转保单数
                addInsurance: (data.data.renInsurancePremCutTotal / 10000 || 0).toFixed(2), // 续保
                addNum: data.data.renInsurancePremNumTotal || 0 //续保单数
              };
              _this.sysTimes = data.data.systemDate;
              this.yearAndMonth = data.data.yearAndMonth || `${YEAR}-${MONTH}`;
              let newArr = [], trunArr = [], addArr = [];
              this.lineArrs = [];
              const dataList = data.data.premiumQueryResults || [];
              if (dataList && dataList.length > 0) {
                for (let n = 0; n < dataList.length; n++) {
                  newArr.push(((dataList[n].newInsurancePremCut || 0) / 10000).toFixed(2))//新保
                  trunArr.push(((dataList[n].reiInsurancePremCut || 0) / 10000).toFixed(2)) // 转保
                  addArr.push(((dataList[n].renInsurancePremCut || 0) / 10000).toFixed(2)) // 续保
                }
              }
              this.lineArrs.push(newArr, trunArr, addArr);
              if (type === "B" || type === "C") {
                let findMax = Array.prototype.concat.call([], newArr, trunArr, addArr);
                this.lineYmax = Math.max.apply(Math, findMax);
              }
              if (type === "B") { //月
                this.getPieData('monthPie');
                this.getLineData('monthLine', this.yearAndMonth);
              } else if (type === "C") { //年
                this.getPieData('yearPie');
                this.getLineData('yearLine', month)
              } else { //日
                this.getPieData('pie');
              }
              break
            default:
              Toast(data.msg)
//              console.log("AAAAA" + data.code + "========" + data.msg)
              break
          }
        }).catch(err => {
          console.log(err)
//          Toast("1" + data.code + "========" + data.msg)
//          console.log("BBBBBB" + data.code + "========" + data.msg)
        })
      },

      /**
       * 饼状图
       * @param type  类型
       * @param month  月份
       */
      getPieData(elem) {
        let self = this;
        let totalPremium = (Number(this.pieAreaData.newInsurance) + Number(this.pieAreaData.turnInsurance) + Number(this.pieAreaData.addInsurance)).toFixed(2);
        this.$nextTick(function () {
          self.$refs[elem].setData(function (echarts) {
            echarts.setOption({
              title: [
                {},
                {
                  text: (function (value) {
                    if (Number.isNaN(Number(value))) {
                      return value;
                    }
                    if (typeof value === 'string' && value.length > 3 || typeof value === 'number' && value >= 1000) {
                      return Number(value).toLocaleString();
                    } else {
                      return value;
                    }
                  })(totalPremium)
                }
              ],
              series: [
                {
                  data: [
                    {value: self.pieAreaData.newInsurance},
                    {value: self.pieAreaData.turnInsurance},
                    {value: self.pieAreaData.addInsurance}
                  ]
                }
              ]
            })
          })

        })
      },
      /**
       * 折线图
       * @param elem  dom
       */
      getLineData(elem, month) {
        let arr = [];
        let self = this;
        if (elem == 'yearLine') {
          let optionsYear = this.lineArrs;
          let xYearDatas = this.getLineXYearData(this.lineArrs[0].length);
          let showSymbol = xYearDatas.length < 2;
          optionsYear.forEach(v => {
            arr.push({data: v, type: 'line', showSymbol: showSymbol})
          })
          console.log(arr);
          this.$nextTick(function () {
            self.$refs[elem].setData(function (echart) {
              echart.setOption({
                title: [
                  {
                    text: `01` // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                  },
                  {
                    text: `${xYearDatas.length > 9 ? xYearDatas.length : '0' + xYearDatas.length}` // ${~~xStart > 9 ? xStart : '0' + xStart}.${xData.length > 9 ? xData.length : '0' + xData.length}
                  }
                ],
                xAxis: {
                  data: xYearDatas
                },
                yAxis: {
                  minInterval: Math.ceil(self.lineYmax / 4)
                },
                series: arr
              })
            })
          })
        } else {
          //let options = this.getLineSeriesData(day);
          let options = this.lineArrs;
          let xDatas = this.getLineXData(this.yearAndMonth, options[0].length);
          let showSymbol = xDatas.length < 2;
          self.$nextTick(function () {
            options.forEach(v => {
              arr.push({data: v, type: 'line', showSymbol: showSymbol})
            })
            self.$refs[elem].setData(function (echart) {
              echart.setOption({
                title: [
                  {
                    text: `01` // ${~~xStart > 9 ? xStart : '0' + xStart}.01
                  },
                  {
                    text: `${xDatas.length > 9 ? xDatas.length : '0' + xDatas.length}` // ${~~xStart > 9 ? xStart : '0' + xStart}.${xData.length > 9 ? xData.length : '0' + xData.length}
                  }
                ],
                xAxis: {
                  data: xDatas
                },
                yAxis: {
                  minInterval: Math.ceil(self.lineYmax / 4)
                },
                series: arr
              })
            })
          })
        }
      },
      tabChildChange() {
        console.log('点击了啥');
      },
      onHide(closeFlag, msg) {
        let self = this;
        this.showPopuPicker = false;
        if (!msg) {
          return;
        }
        this.isShowBoard = !msg.dealerCode ? true : false;
        if (closeFlag) {
          this.institution = msg;
          this.branchName = `${msg.provicesName + msg.cityName + msg.dealerName}`.replace("暂不选择", '');
          if (msg.dealerName) {
            this.branchName = msg.dealerName.substr(msg.dealerName.indexOf('市') + 1, msg.dealerName.length)
          }
          this.cityCode = msg.cityName === '暂不选择' ? '' : msg.cityCode;
          console.log(this.cityCode + msg.cityName);
          this.provinceCode = msg.provicesCode || '';
          this.dealerCode = msg.dealerCode || '';
          if (msg.provicesName && msg.provicesName === '全国') {
            this.cityCode = "";
            this.dealerCode = "";
            this.provinceCode = "";
          }
          const reqData = {
            queryType: self.activeTab, //查询类型,
            queryValue: self.activeTab === 'B' ? self.monthValue || MONTH : '', //类型的值
            provices: this.provinceCode,
            citys: this.cityCode,
            dealerCode: this.dealerCode,
            trademarkId: this.trademarkId || ''
          }
          console.log(reqData);
          this.getData(self.activeTab, '', reqData);
        }

      },
      /**
       * 获取车行图标
       */
      getIcon() {
        let self = this;
        let obj = {
          city: self.cityCode, //城市
          province: self.provinceCode, //省份
          dealerCode: self.dealerCode, //车商编号
          queryType: self.activeTab, //查询类型
          queryValue: self.activeTab === 'B' ? self.monthValue || MONTH : undefined //类型的值
        };
        //console.log("开始调用。。。。")
        Native.requestHybrid({
          tagname: 'getDealerIcon',
          param: obj,
          callback: function (req) {
            //console.log("Icon:"+reqData);
            self.dealerIcon = req.data.dealerIcon || "";
            self.trademarkId = req.data.trademarkId || "";
            const reqData = {
              queryType: self.activeTab,
              queryValue: self.activeTab === 'B' ? self.monthValue || MONTH : undefined, //类型的值
              provices: self.provinceCode || '',
              citys: self.cityCode || '',
              dealerCode: self.dealerCode || '',
              trademarkId: self.trademarkId
            }
            //console.log("类型"+this.activeTab)
            self.getData(self.activeTab, '', reqData);
          }
        })

//        console.log("调用结束.......");
//        console.log("获得native的值"+this.dealerIcon);
      },
      getBillLen(val) {
        console.log(val);
        let fontS = parseFloat(document.documentElement.style.fontSize);
        this.tabHeight = 0.88 * val * fontS + 1.46 * fontS + 10;
        console.log(this.tabHeight);
      }
    },
    mounted() {
      let self = this;
      let dealerData = window.dealerData;
      console.log(dealerData)
      this.showRight = (~~dealerData.dealerType) === 1 ? true : false;
      this.branchName = dealerData.dealerName;
      let code = dealerData.dealerCode;
      console.log(dealerData.dealerType + "======" + this.branchName + "=====" + code);
      const reqData = {
        queryType: 'A',
        provices: this.provinceCode || '',
        citys: this.cityCode || '',
        dealerCode: this.dealerCode || '',
        trademarkId: this.trademarkId || ''
      }
      this.getData('A', '', reqData);
    },
    components: {
      PopupPicker,
      ptsTabs,
      ptsTabItem: ptsTabs.Item,
      ptsList,
      ptsEchartsPie,
      ptsEchartsLine,
      ptsLinkMenu
    },
    watch: {},
    beforeRouteEnter(to, from, next) {
      loadEcharts(next);
    }
  }
</script>

<style lang="less">
  .flexBox {
    display: flex;
    position: absolute;
    right: 0;
    top: 0;
    height: 100%;
    width: 3rem;
    justify-content: flex-end;
    .coreHeader {
      margin-top: 0.3rem;
      margin-right: 0.3rem;
      &:before {
        top: 60%;
        right: 0.3rem;
      }
    }
    .txhidden {
      max-width: 1.2rem;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      text-align: right;
    }
  }

  .titleAllCar {
    margin-top: 0.19rem;
    margin-right: 0.2rem;
    display: block;
    width: .5rem;
    height: .5rem;
    line-height: .6rem;
    font-size: .2rem;
    color: #454545;
    text-align: center;
    /* border-radius: 50%; */
    object-fit: scale-down;
    /* background-size: cover; */
  }

  .core_left {
    font-size: .3rem;
    width: 20%;
    float: left;
    margin-left: 0.7rem;
    line-height: 0.9rem;
    margin-top: 0.09rem;
  }

  .core_right {
    width: 26%;
    float: right;
    margin-right: 0.2rem;
    margin-top: 0.1rem;
  }

  .font_center {
    text-align: left
  }

  .core_content {
    margin-left: auto;
    margin-right: auto;
    text-decoration: underline;
  }

  .new_color {
    background-color: #60D194;
  }

  .z_color {
    background-color: #FFDB4B;
  }

  .x_color {
    background-color: #559EFF;
  }

  .btop {
    margin-top: .8rem;
  }

</style>
